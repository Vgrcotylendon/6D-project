import { Box, Container, Grid } from "@mui/material";
import React, { useState } from "react";
import Verify from "../Components/Screens/SignUp/Verify";
import Email from "../Components/Screens/SignIn/Email";
import SignInForm from "../Components/Screens/SignIn/SignInForm";
import YellowCard from "../Components/Card/YellowCard";
import TermsModal from "../Components/Screens/SignIn/TermsModal";
import PolicyModal from "../Components/Screens/SignIn/PolicyModal";
 
export default function SignIn() {
  const [email, setEmail] = useState<string>("");
  const [mobileNumber, setMobileNumber] = useState<string>("");
  const [val, setVal] = useState<number>(0);
  const [openTerms, setOpenTerms] = useState(false);
  const [openPolicy, setOpenPolicy] = useState(false);
  const handleCloseTerms = () => setOpenTerms(false);
  const handleClosePolicy = () => setOpenPolicy(false);
  const height = window.innerHeight;
  const MarginPercent = (80 / height) * 100;
  const MarginTopPercent = (152 / height) * 100;

  const marginTop = (MarginTopPercent / 100) * height;
  const marginBottom = (MarginPercent / 100) * height;
  const maxheight = height - (marginTop + marginBottom);

  return (
    <>
      {(openTerms === true || openPolicy === true) && (
        <>
          {" "}
          {openTerms === true && (
            <TermsModal
              maxheight={maxheight}
              height={height}
              marginTop={marginTop}
              marginBottom={marginBottom}
              handleCloseTerms={handleCloseTerms}
            />
          )}
          {openPolicy === true && (
            <PolicyModal
              maxheight={maxheight}
              height={height}
              marginTop={marginTop}
              marginBottom={marginBottom}
              handleClosePolicy={handleClosePolicy}
            />
          )}
        </>
      )}
 
      {openTerms === false && openPolicy === false && (
        <Container
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "100vh",
            margin: "auto",
          }}
        >
          <Grid
            container
            spacing={8}
            paddingLeft={10}
            paddingRight={10}
            paddingTop={7}
            sx={{
              // minHeight: "75%",
              display: "flex",
              justifyContent: "space-evenly",
              alignItems: "center",
              // padding: "25px 50px",
            }}
          >
            <Grid
              item
              xs={6}
              sx={{ display: { xs: "none", sm: "none", md: "block" } }}
            >
              <YellowCard />
            </Grid>
 
            <Grid item xs={12} sm={8} md={6}>
              {val === 0 && (
                <SignInForm
                  email={email}
                  mobileNumber={mobileNumber}
                  setEmail={setEmail}
                  setMobileNumber={setMobileNumber}
                  setOpenTerms={setOpenTerms}
                  setOpenPolicy={setOpenPolicy}
                  setVal={setVal}
                />
              )}
              {val === 1 && email && (
                <Email setVal={setVal} emailValue={email} />
              )}
              {val === 1 && mobileNumber && (
                <Verify
                  setVal={setVal}
                  value={
                    mobileNumber ? "Phone Number" : email ? "Email Address" : ""
                  }
                  email={email}
                  mobileNumber={mobileNumber}
                  setEmail={setEmail}
                  setMobileNumber={setMobileNumber}
                />
              )}
            </Grid>
          </Grid>
        </Container>
      )}
    </>
  );
}