import React, { useState, useRef } from "react";
import {
  Box,
  Grid,
  TextField,
  Checkbox,
  FormControl,
  Autocomplete,
} from "@mui/material";
import { Editor } from "@tinymce/tinymce-react";
import CustomAutoComplete from "../../Components/Input/CustomAutoComplete";
import CustomButton from "../../Components/Button/CustomButton";
import { useSelector } from "react-redux";
import { RootState } from "../../Store/UserSlice";
import { instance } from "../../Controller/Common";
import ReactHtmlParser from "react-html-parser";

const CreateFinalAssessment = () => {
  const ApiKey = process.env.REACT_APP_TINY_MCE_API_KEY;
  const editorRef = useRef<any>(null);
  const [courseData, setCourseData] = useState<
    { label: string; value: number }[]
  >([]);
  const [selectedCourse, setSelectedCourse] = useState<{
    label: string;
    value: number;
  } | null>(null);
  const [instruction, setInstruction] = useState("");
  const [cutoffScore, setCutoffScore] = useState("");
  const [attemptInstructions, setAttemptInstructions] = useState("");
  const [questionData, setQuestionData] = useState<any[]>([]);
  const [selectedQuestion, setSelectedQuestion] = useState<string[]>([]);


  const handleCourseChange = (value: any) => {
    setSelectedCourse(value);
  };

  const GetAllCourses = async () => {
    try {
      const response = await instance.get(`/6D/Course/getAllCourse`);
      if (response.status === 200) {
        const courseOptions = response.data.map((course: any) => ({
          label: course.TITLE,
          value: course.CID,
        }));
        setCourseData(courseOptions);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleQuestionChange = (value: { value: string; label: string }[]) => {
    const selectedIds = value.map((question) => question.value.toString());
    setSelectedQuestion(selectedIds);
  };
  const handleInstructionChange = (content: string) => {
    setInstruction(content);
  };
  const handleAttemptInstructionsChange = (content: string) => {
    setAttemptInstructions(content);
  };

  const GetAllAssessment = async () => {
    try {
      const response = await instance.get(`/6D/assessment/getAssessment`);
      if (response.status === 200) {
        const options = response.data.map((assessment: any) => ({
          label: assessment.NAME,
          value: assessment.AID,
        }));
        setQuestionData(options);
      }
    } catch (error) {
      console.error("Error fetching assessments:", error);
    }
  };
  const CreateFinalAssess = async () => {
    if (!selectedCourse || selectedQuestion.length === 0 || !cutoffScore) {
      alert("Please fill in all required fields.");
      return;
    }
    try {
      const response = await instance.post(
        `/6D/assessment/map-finalAssessment`,
        {
          CID: selectedCourse?.value,
          AID: selectedQuestion,
          cut_off_score: cutoffScore,
          assessment_instructions: instruction,
          attempt_instructions: attemptInstructions,
        }
      );
      if (response.status === 201) {
        alert("Final Assessment Successfully Created");
      }
      setSelectedCourse(null);
      setSelectedQuestion([]);
      setInstruction("");
      setCutoffScore("");
      setAttemptInstructions("");
    } catch (error) {
      console.error("Error fetching assessments:", error);
    }
  };

  React.useEffect(() => {
    GetAllCourses();
    GetAllAssessment();
  }, []);

  return (
    <div style={{ margin: "50px", marginTop: "100px" }}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={6}>
          <CustomAutoComplete
            label="Select Course"
            options={courseData}
            onChange={(_, value) => handleCourseChange(value)}
            value={selectedCourse}
            required
          />
        </Grid>
        <Grid item xs={12} sm={6} md={6}>
          <FormControl fullWidth required>
            <label
              style={{
                fontSize: "18px",
                color: "black",
                padding: "0 0 5px 0",
              }}
            >
              Select Assessment*
            </label>
            <Autocomplete
              id="select-Assessment"
              options={Array.isArray(questionData) ? questionData : []}
              onChange={(_, value) => {
                handleQuestionChange(value);
              }}
              value={questionData.filter((q) =>
                selectedQuestion.includes(q.value.toString())
              )}
              multiple
              disableCloseOnSelect
              renderOption={(props, option) => {
                const selected = selectedQuestion.includes(
                  option.value.toString()
                );

                return (
                  <li {...props}>
                    <Checkbox style={{ marginRight: 8 }} checked={selected} />
                    {ReactHtmlParser(option.label)}
                  </li>
                );
              }}
              renderInput={(params) => (
                <TextField {...params} id="select-Assessment" required />
              )}
            />
          </FormControl>
          <p>please select 3 set of assessment</p>
        </Grid>
        <Grid item xs={12} sm={6} md={6}>
          <TextField
            fullWidth
            label="Cutoff Score"
            id="cutoff-score"
            type="number"
            value={cutoffScore}
            onChange={(e) => setCutoffScore(e.target.value)}
            required
            sx={{ mt: 2 }}
          />
        </Grid>
      </Grid>
      <div  style={{ marginTop: "50px" }}>
      <p>Final Instruction*</p>
      <Editor
        apiKey={ApiKey}
        onInit={(evt: any, editor: any) => (editorRef.current = editor)}
        init={{
          plugins: [
            "anchor",
            "autolink",
            "charmap",
            "codesample",
            "emoticons",
            "image",
            "link",
            "lists",
            "media",
            "searchreplace",
            "table",
            "visualblocks",
            "wordcount",
            "checklist",
            "mediaembed",
            "casechange",
            "export",
            "formatpainter",
            "pageembed",
            "a11ychecker",
            "tinymcespellchecker",
            "permanentpen",
            "powerpaste",
            "advtable",
            "advcode",
            "editimage",
            "advtemplate",
            "ai",
            "mentions",
            "tinycomments",
            "tableofcontents",
            "footnotes",
            "mergetags",
            "autocorrect",
            "typography",
            "inlinecss",
            "markdown",
          ],
          font_family_formats: 'Poppins=Poppins;',
          content_style: `
          @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
          body { font-family: Poppins; }
          `,
          toolbar:
            "undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat",
          tinycomments_mode: "embedded",
          tinycomments_author: "Author name",
          mergetags_list: [
            { value: "First.Name", title: "First Name" },
            { value: "Email", title: "Email" },
          ],
          height: 400,
          content_css: "default",
        }}
        value={instruction}
        onEditorChange={handleInstructionChange}
      />
      <div style={{marginTop:"50px"}}>
       <p>Attempt Instruction*</p>
      <Editor
        apiKey={ApiKey}
        onInit={(evt: any, editor: any) => (editorRef.current = editor)}
        init={{
          plugins: [
            "anchor",
            "autolink",
            "charmap",
            "codesample",
            "emoticons",
            "image",
            "link",
            "lists",
            "media",
            "searchreplace",
            "table",
            "visualblocks",
            "wordcount",
            "checklist",
            "mediaembed",
            "casechange",
            "export",
            "formatpainter",
            "pageembed",
            "a11ychecker",
            "tinymcespellchecker",
            "permanentpen",
            "powerpaste",
            "advtable",
            "advcode",
            "editimage",
            "advtemplate",
            "ai",
            "mentions",
            "tinycomments",
            "tableofcontents",
            "footnotes",
            "mergetags",
            "autocorrect",
            "typography",
            "inlinecss",
            "markdown",
          ],
          font_family_formats: 'Poppins=Poppins;',
          content_style: `
          @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
          body { font-family: Poppins; }
          `,
          toolbar:
            "undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat",
          tinycomments_mode: "embedded",
          tinycomments_author: "Author name",
          mergetags_list: [
            { value: "First.Name", title: "First Name" },
            { value: "Email", title: "Email" },
          ],
          height: 400,
          content_css: "default",
        }}
        value={attemptInstructions}
        onEditorChange={handleAttemptInstructionsChange}
      />
      </div>
      </div>
      <Box sx={{ display: "flex", justifyContent: "space-between", mt: 5 }}>
        <CustomButton name="Submit" onClick={CreateFinalAssess} />
      </Box>
    </div>
  );
};

export default CreateFinalAssessment;
