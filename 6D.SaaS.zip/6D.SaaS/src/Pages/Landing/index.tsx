import { Box } from "@mui/material";
import React, { useEffect } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import styled from "styled-components";
import Drawers from "../../Components/Bar/Drawer";
import TourModal from "../../Components/Modal/TourModal";
import { useDispatch } from "react-redux";
import Cookies from "universal-cookie";
import { GetAcessToken, Verify_Token } from "../../Controller/Common";

const CustomBox = styled(Box)`
  margin: 63px 0 0 82px;
`;

export default function Landing() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const cookies = new Cookies();
  const status = cookies.get("modal");
  const Temp = cookies.get("temp") ?? false;

  const location = useLocation();
  const path = location.pathname === "/landing/activity";

  useEffect(() => {
    Verify_Token(dispatch, navigate);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  //  1800000 milliseconds = 30 minutes
  useEffect(() => {
    const intervalId = setInterval(() => {
      GetAcessToken();
    }, 1800000);
    return () => clearInterval(intervalId);
  }, []);

  return (
    <>
      {path && status === false && Temp === false && <TourModal />}
      <Drawers />
      <CustomBox>
        <Outlet />
      </CustomBox>
    </>
  );
}
