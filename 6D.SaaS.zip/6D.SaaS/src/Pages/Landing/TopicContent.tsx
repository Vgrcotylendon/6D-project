import React, { useRef, useState } from "react";
import { Editor } from "@tinymce/tinymce-react";
import { instance } from "../../Controller/Common";
import CustomTextInput from "../../Components/Input/CustomTextInput";
import CustomButton from "../../Components/Button/CustomButton";
import { Box } from "@mui/material";

interface TopicContentProps {
  selectedModule?: { label: string; value: number } | null;
  selectedCourse?: { label: string; value: number } | null;
  setSelectedCourse: (value: { label: string; value: number } | null) => void;
  setSelectedModule: (value: { label: string; value: number } | null) => void;
}

export default function TopicContent({
  selectedModule,
  selectedCourse,
  setSelectedCourse,
  setSelectedModule,
}: TopicContentProps) {
  const ApiKey = process.env.REACT_APP_TINY_MCE_API_KEY;
  const editorRef = useRef<any>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [charCount, setCharCount] = useState(5000);
  const [duration, setDuration] = useState<string>("");

  const logContent = () => {
    if (!title) {
      alert("Please provide a topic title.");
      return;
    }
    if (!editorRef.current) {
      alert("Editor is not loaded properly.");
      return;
    }

    const data = editorRef.current.getContent();
    if (!data) {
      alert("Please provide content for the topic.");
      return;
    }
    if (!selectedCourse) {
      alert("Please select a course.");
      return;
    }
    if (!selectedModule) {
      alert("Please select a module.");
      return;
    }

    setContent(data);
    createTopic(title, data);
  };

  const createTopic = async (name: string, content: string) => {
    try {
      const response = await instance.post("/6D/Topic/CreateTopic", {
        NAME: name,
        CONTENT: content,
        CONTENT_TYPE: "PDF",
        DURATION: duration,
        METADATA: "Link will be provided",
      });

      if (response.status === 200) {
        console.log("Success: Topic created successfully.");

        try {
          const mapResponse = await instance.post(
            "/6D/map/Course-Module-Topic",
            {
              CID: selectedCourse?.value,
              MID: selectedModule?.value,
              TID: response.data.data.TID,
              ModuleOrder: null,
              TopicOrder: null,
            }
          );

          if (mapResponse.status === 200) {
            console.log(
              "Success: Mapping course, module, and topic is successful."
            );
            setTitle("");
            setContent("");
            setDuration("");
            if (editorRef.current) {
              editorRef.current.setContent("");
            }
            setSelectedCourse(null);
            setSelectedModule(null);
          } else {
            console.error("Error in mapping course, module, and topic.");
          }
        } catch (error) {
          console.error("Error mapping course, module, and topic:", error);
        }
      } else {
        console.error("Error in creating topic.");
      }
    } catch (error) {
      console.error("Error creating topic:", error);
    }
  };
  const handleEditorChange = () => {
    if (editorRef.current) {
      const content = editorRef.current.getContent({ format: "text" });
      setCharCount(5000 - content.length);
    }
  };

  return (
    <div>
      <div>
        <CustomTextInput
          label="Topic Title"
          name="apaarId"
          value={title}
          allowSpaces={true}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
      </div>
      <CustomTextInput
        label="Duration"
        value={duration}
        number
        onChange={(e) => setDuration(e.target.value)}
        required
      />
      <br/>
      <br/>
      <label
        style={{
          fontSize: "18px",
          color: "black",
          padding: "0 0 5px 0",
        }}
      >
        Topic Content*&nbsp;&nbsp;&nbsp;&nbsp;
        <span style={{ fontSize: "12px" }}>
          {" "}
          (Maximum Character 5000, Remaining: {charCount})
        </span>
      </label>
      <Editor
        apiKey={ApiKey}
        onInit={(evt: any, editor: any) => (editorRef.current = editor)}
        onEditorChange={handleEditorChange}
        init={{
          plugins: [
            "anchor",
            "autolink",
            "charmap",
            "codesample",
            "emoticons",
            "image",
            "link",
            "lists",
            "media",
            "searchreplace",
            "table",
            "visualblocks",
            "wordcount",
            "checklist",
            "mediaembed",
            "casechange",
            "export",
            "formatpainter",
            "pageembed",
            "a11ychecker",
            "tinymcespellchecker",
            "permanentpen",
            "powerpaste",
            "advtable",
            "advcode",
            "editimage",
            "advtemplate",
            "ai",
            "mentions",
            "tinycomments",
            "tableofcontents",
            "footnotes",
            "mergetags",
            "autocorrect",
            "typography",
            "inlinecss",
            "markdown",
          ],
          font_family_formats: 'Poppins=Poppins;',
          content_style: `
          @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
          body { font-family: Poppins; }
      `,
          toolbar:
            "undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat",
          tinycomments_mode: "embedded",
          tinycomments_author: "Author name",
          mergetags_list: [
            { value: "First.Name", title: "First Name" },
            { value: "Email", title: "Email" },
          ],
          height: 400,
          // content_css: "default",
          // font_family_formats:"'Poppins', sans-serif"
        }}
        // initialValue="Welcome to TinyMCE!"
      />
      <Box sx={{ float: "right" }}>
        <br />
        <CustomButton
          variant="secondary"
          name={"Submit"}
          padding="8px 14px"
          onClick={logContent}
        />
      </Box>
    </div>
  );
}
