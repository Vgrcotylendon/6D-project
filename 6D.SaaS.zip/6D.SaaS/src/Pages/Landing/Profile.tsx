import React, { useEffect, useState } from "react";
import { Box } from "@mui/material";
import PersonalInfo from "../../Components/Screens/Profile/PersonalInfo";
import EducationDetails from "../../Components/Screens/Profile/EducationDetails";
import WorkExperience from "../../Components/Screens/Profile/WorkExperience";
import CustomIconButton from "../../Components/Button/CustomIconButton";
import SaveIcon from "@mui/icons-material/Save";
import EditIcon from "@mui/icons-material/Edit";
import { CustomTab, TabPanel } from "../../Components/CustomTab";

const Profile: React.FC = () => {
  const Params = new URLSearchParams(window.location.search);
  const tabValue = Params.get("tab");

  const [value, setValue] = React.useState<any>(Number(tabValue) ?? 0);
  const [check, setCheck] = useState<boolean>(false);
  const [save, setSave] = useState(true);
  const [edit, setEdit] = useState(false);
  const [trigger, setTrigger] = useState(false);
  const [isEditable, setIsEditable] = useState(false);
  const [isEditable1, setIsEditable1] = useState(false);
  const [showRequiredError, setShowRequiredError] = useState(false);

  useEffect(() => {
    const bgColors = ["#f0f0f0", "#f0f0f0", "#f0f0f0"];
    document.body.style.backgroundColor = bgColors[value];
    return () => {
      document.body.style.backgroundColor = "";
    };
  }, [value]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [value]);

  const tabLabels = ["Personal Info", "Education Details", "Work Experience"];
  const tabComponent = [
    <PersonalInfo
      save={save}
      setSave={setSave}
      edit={edit}
      setEdit={setEdit}
      trigger={trigger}
      setTrigger={setTrigger}
      isEditable={isEditable}
      setIsEditable={setIsEditable}
      isEditable1={isEditable1}
      check={check}
      showRequiredError={showRequiredError}
      setShowRequiredError={setShowRequiredError}
      setCheck={setCheck}
    />,
    <EducationDetails
      save={save}
      edit={edit}
      setEdit={setEdit}
      trigger={trigger}
      setSave={setSave}
      setTrigger={setTrigger}
      isEditable={isEditable}
      setIsEditable={setIsEditable}
      showRequiredError={showRequiredError}
      setShowRequiredError={setShowRequiredError}
    />,
    <WorkExperience
      save={save}
      setSave={setSave}
      setTrigger={setTrigger}
      trigger={trigger}
    />,
  ];

  return (
    <>
      <Box
        sx={{
          bgcolor: "background.paper",
          display: "flex",
          justifyContent: "space-between",
          flexDirection: "row",
          width: "100%",
          alignItems: "center",
          position: "fixed",
          zIndex: 10,
          height: "72px",
        }}
      >
        <Box
          sx={{
            padding: "10px 0 0 0",
          }}
        >
          <CustomTab
            tabs={tabLabels}
            value={value}
            setValue={setValue}
            setEdit={setEdit}
            setSave={setSave}
            setCheck={setCheck}
            setTrigger={setTrigger}
            save={save}
            showRequiredError={showRequiredError}
            setShowRequiredError={setShowRequiredError}
          />
        </Box>
        {value !== 2 && (
          <>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                margin: "2rem 6rem 1.5rem 0",
                justifyContent: "space-between",
              }}
            >
              <CustomIconButton
                variant="primary"
                icon={EditIcon}
                disable={edit}
                onClick={() => {
                  setIsEditable(true);
                  setIsEditable1(true);
                  setSave(false);
                  setEdit(true);
                  // setCheck(false);
                }}
                style={{ margin: "0px 5px" }}
              />
              <CustomIconButton
                variant="primary"
                icon={SaveIcon}
                disable={save}
                onClick={() => {
                  // setEdit(false);
                  // setSave(true);
                  // setIsEditable(false);
                  setTrigger(true);
                  // setCheck(false);
                }}
                style={{ margin: "0px 5px" }}
              />
            </Box>
          </>
        )}
      </Box>
      {tabComponent.map((component, index) => (
        <TabPanel value={value} index={index} key={index}>
          <br />
          <br />
          <br />
          {component}
        </TabPanel>
      ))}
    </>
  );
};

export default Profile;
