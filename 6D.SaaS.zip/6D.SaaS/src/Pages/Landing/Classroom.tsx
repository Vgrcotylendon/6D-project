import React, { useEffect, useState } from "react";
import { Box, Divider, MenuItem, Modal, Typography } from "@mui/material";
import styled from "styled-components";
import MyClassRoom from "../../Components/Screens/ClassRoom";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import { useDispatch, useSelector } from "react-redux";
import {
  changeClassRoomMID,
  changeClassRoomValue,
  ClearAnswers,
  clearGetTopicAssessmentDetails,
  FinalAssessmentTimer,
  // getAllCourseDetails,
  getAssessmentId,
  getAssessmentIndex,
  getContinueDetails,
  getEnrolledCourse,
  getFinalAccordionTask,
  getFinalAssessment,
  getFinalAssessmentAID,
  getFinalAssessmentDetails,
  getFinalAssessmentDetailsSatus,
  getFinalAssessmentIndex,
  getFinalAssessmentStatus,
  getModuleId,
  getModuleIndex,
  getModuleName,
  getModuleOrder,
  getTopicAssessmentDetails,
  getTopicId,
  getTopicIndex,
  getTopicOrder,
} from "../../Store/ClassroomSlice";
import { cookies, instance } from "../../Controller/Common";
import { RootState } from "../../Store/UserSlice";
import { useLocation } from "react-router-dom";

interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
    MID: number;
    finalAssessmentAID: number;
  };
}

const Classroom: React.FC = () => {
  const location = useLocation();
  const { courseTitle, courseID } = location.state || {};
  const [localState, setLocalState] = useState(courseID);

  const [selectedCourseTitle, setSelectedCourseTitle] = useState(
    courseTitle || ""
  );
  const value = useSelector((state: StateType) => state.classRoom.value);
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse || []
  );

  const dispatch = useDispatch();
  const style = {
    position: "fixed",
    top: 140,
    right: 100,
    // transform: "translate(-50%, -50%)",
    bgcolor: "background.paper",
    borderRadius: 1,
    p: "10px 5px",
    zIndex: 99999,
    minWidth: "700px",
  };

  const [open, setOpen] = React.useState(false);
  const [courses, setCourses] = React.useState("");
  const handleOpen = () => {
    if (
      nextPage === 2 ||
      nextPage === 3 ||
      nextPage === 4 ||
      nextPage === 5 ||
      nextPage === 6 ||
      QuestionDetails?.length > 0
    ) {
      setOpen(false);
    } else {
      setOpen(true);
    }
  };
  const handleClose = () => setOpen(false);
  const [open1, setOpen1] = useState(false);
  const [nextPage, setNextPage] = useState(0);
  const [next, setNext] = useState(0);
  const [courseDetails, setCourseDetails] = useState<any[]>([]);
  const [checked, setChecked] = useState<boolean[]>(new Array(0).fill(false));
  const [expand, setExpand] = useState<boolean>(false);
  const [topicLength, setTopicLength] = useState<number>(0);
  const [completedTopic, setCompletedTopic] = useState<number>(0);
  const userId =
    useSelector((state: RootState) => state.user.userID) ??
    cookies.get("userId");
  const [topicDetails, setTopicDetails] = useState<any[]>([]);
  const [topicContentDetails, setTopicContentDetails] = useState<any>(null);
  const [assessmentDetails, setAssessmentDetails] = useState<any[]>([]);
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [expand1, setExpand1] = useState<boolean[]>([]);
  const [selectedTopic, setSelectedTopic] = useState<any>(null);
  const [selectedTopicContent, setSelectedTopicContent] = useState<any>(null);
  const [selectedAssesment, setSelectedAssesment] = useState<any>(null);
  const [selectedFinalAssesment, setSelectedFinalAssesment] =
    useState<any>(null);
  const [hide, setHide] = useState(true);

  const [QuestionDetails, setQuestionDetails] = React.useState<any[]>([]);
  const [selectedTopicDetails, setSelectedTopicDetails] = useState<any>(null);
  const [selectedTopicIndex, setSelectedTopicIndex] = useState(0);
  const [moduleIndex, setModuleIndex] = useState(0);
  const [selectedModuleName, setSelectedModuleName] = useState<any>(null);
  const [selectedAssessmentDetails, setSelectedAssessmentDetails] =
    useState<any>(null);
  const rootCourse = Array.isArray(enrolledCourse)
    ? enrolledCourse.filter((i: any) => i.CID === value)
    : [];

  const getUserCertification = async () => {
    try {
      const response = await instance.get(
        `/6D/enRoll/getEnRollCourse-ByUId?id=${userId}`
      );
      if (response.status === 200) {
        const data = response.data.filter(
          (i: any) => i.STATUS !== "DISQUALIFIED" && i.STATUS !== "COMPLETED"
        );
        setCourses(data);
        dispatch(getEnrolledCourse(data || []));
        dispatch(
          changeClassRoomValue(data[0]?.courseDetails.CID || "not found")
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  const GetCourseDetails = async () => {
    try {
      const response = await instance.get(
        `/6D/map/getCourse-Module-ByCourseId?courseId=${
          localState || value
        }&userId=${userId}`
      );
      if (response.status === 200) {
        const data = response.data;

        if (data[0].STATUS) {
          setLocalState(null);
          dispatch(changeClassRoomMID(data[0]?.Module[0]?.MID || "not found"));
          dispatch(getFinalAssessmentStatus(data[0]?.Module));
          // dispatch(getModuleName(data[0]?.Module[0].NAME));
          dispatch(getFinalAccordionTask(data[0]?.TaskDetails));
          dispatch(getFinalAssessmentDetails(data[0]?.FinalAssessment[0]));
          dispatch(getFinalAssessmentDetailsSatus(data[0]?.FinalAssessment[0]));
          setCourseDetails(data);
          dispatch(clearGetTopicAssessmentDetails());
          dispatch(ClearAnswers());
        }
      }
    } catch (error) {
      console.error(error);
      setCourseDetails([]);
    }
  };

  const GetTopicDetails = async (moduleId: string) => {
    try {
      const response = await instance.get(
        `/6D/map/getModule-Topic-ByModuleId?moduleId=${moduleId}&userId=${userId}&courseId=${value}`
      );
      if (response.status === 200) {
        dispatch(getTopicAssessmentDetails(response.data));
        setTopicDetails(response.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  // const GetAllcourseDetails = async () => {
  //   try {
  //     const response = await instance.get(
  //       `/6D/map/new-GetCourseDetails?courseId=${
  //         topicContentDetails?.CID || value
  //       }&userId=${userId}`
  //     );
  //     if (response.status === 200) {
  //       dispatch(getAllCourseDetails(response.data));
  //       const finalAssessment = response.data[0]?.FA_Assessment[0];
  //       dispatch(getFinalAssessmentDetails(finalAssessment));
  //       dispatch(getFinalAssessmentAID(finalAssessment.AID));
  //     }
  //   } catch (error) {
  //     console.error("Error fetching next topic: ", error);
  //   }
  // };

  const GetTopicContentDetails = async (
    cid: number,
    mid: number,
    tid: number
  ) => {
    try {
      const response = await instance.get(
        `6D/Topic/getTopicDetailsByTID?TID=${tid}&CID=${cid}&MID=${mid}&UID=${userId}`
      );
      if (response.status === 200) {
        setTopicContentDetails(response.data);
        setQuestionDetails([]);
        setModuleIndex(response?.data?.moduleIndex);
        dispatch(getTopicId(response.data.TID));
        dispatch(getModuleId(response.data.MID));
        dispatch(getModuleOrder(response.data.ModuleOrder));
        dispatch(getTopicOrder(response.data.TopicOrder));
        dispatch(getAssessmentId(null));
        dispatch(getModuleName(response.data.moduleName));
      }
    } catch (error) {
      console.error(error);
    }
  };
  const GetAssessmentQuestiomDetails = async (AID: number) => {
    try {
      const response = await instance.get(
        `/6D/map/getAssessment-Question-ByAID?AID=${AID}&userId=${userId}&CID=${value}`
      );
      if (response.status === 200) {
        let data = response.data;
        setQuestionDetails(data);
        setTopicContentDetails([]);
        dispatch(getAssessmentId(response.data[0].AID));
        dispatch(getTopicId(null));
        dispatch(getModuleId(response.data[0].MID));
        dispatch(getModuleOrder(response.data[0].ModuleOrder));
        dispatch(getModuleName(response.data[0].moduleName));
        dispatch(getTopicOrder(response.data[0].TopicOrder));
      }
    } catch (error) {
      console.error(error);
    }
  };

  const GetAssessmentDetails = async (moduleId: string) => {
    try {
      const response = await instance.get(
        `/6D/map/getModule-Assessment-ByModuleId?moduleId=${moduleId}&userId=${userId}&courseId=${value}`
      );
      if (response.status === 200) {
        dispatch(getTopicAssessmentDetails(response.data));
        setAssessmentDetails(response.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleTopicDetatils = (
    content: any,
    topic: any,
    idx: number,
    module: any,
    index: number,
    cid: number,
    mid: number,
    tid: number
  ) => {
    setNextPage(1);
    setHide(false);
    setSelectedTopicIndex(tid);
    GetTopicContentDetails(cid, mid, tid);
    setSelectedTopicDetails(topic);
    setSelectedModuleName(module);
    setModuleIndex(mid);
    setSelectedTopicContent(content);
    // GetAllcourseDetails();
    setExpand(false);
  };
  const handleAssementDetails = (
    assessment: any,
    idx: number | undefined,
    module: any,
    AID: number
  ) => {
    setNextPage(2);
    setHide(false);
    GetAssessmentQuestiomDetails(AID);
    setSelectedAssessmentDetails(assessment);
    setSelectedModuleName(module);
    // GetAllcourseDetails();
    setExpand(false);
  };

  const handleExpansion = (index: number, moduleId: string) => {
    setOpen1(false);
    if (expandedIndex === index) {
      setExpandedIndex(null);
      setExpanded(null);
      dispatch(clearGetTopicAssessmentDetails());
    } else {
      dispatch(clearGetTopicAssessmentDetails());
      setExpandedIndex(index);
      GetTopicDetails(moduleId);
      GetAssessmentDetails(moduleId);
    }
  };

  const handleExpansion1 = (index: number, moduleId: string) => {
    const newExpanded = [...expand1];
    newExpanded[index] = false;
    setExpand1(newExpanded);
    setExpandedIndex(null);
    if (expanded === index) {
      setExpanded(null);
      dispatch(clearGetTopicAssessmentDetails());
    } else {
      dispatch(clearGetTopicAssessmentDetails());
      setExpanded(index);
      GetTopicDetails(moduleId);
      GetAssessmentDetails(moduleId);
    }
  };

  const handleChange = (index: number) => {
    setChecked((prevChecked) => {
      const newChecked = new Array(prevChecked.length).fill(false);
      newChecked[index] = !prevChecked[index];
      return newChecked;
    });
  };

  const ContinueToLast = async (courseId?: number | string) => {
    try {
      const response = await instance.get(
        `/6D/map/new-Continue-to-lastTopic?courseId=${
          courseId ?? value
        }&userId=${userId}`
      );
      if (response.status === 200 && response.data) {
        let data = response.data;
        dispatch(getContinueDetails(data[0]));
        if (data[0]?.assessmentType === "Final Assessment") {
          dispatch(getFinalAssessment(data));
          dispatch(getFinalAssessmentAID(data[0]?.AID));
          setQuestionDetails(data);
          setNextPage(3);
          setHide(false);
        } else if (data[0]?.AID) {
          setQuestionDetails(response.data);
          setTopicContentDetails([]);
          setQuestionDetails(data);
          dispatch(getAssessmentId(response.data[0].AID));
          dispatch(getTopicId(null));
          dispatch(getModuleId(response.data[0].MID));
          dispatch(getModuleOrder(response.data[0].ModuleOrder));
          dispatch(getModuleName(response.data[0].moduleName));
          dispatch(getTopicOrder(response.data[0].TopicOrder));
          setNextPage(2);
          setHide(false);
        } else if (data.TID) {
          setModuleIndex(response?.data?.moduleIndex);
          setTopicContentDetails(response.data);
          setQuestionDetails([]);
          dispatch(getModuleOrder(Number(response.data.ModuleOrder)));
          dispatch(getTopicOrder(Number(response.data.TopicOrder)));
          dispatch(getModuleName(response.data.moduleName));
          dispatch(getTopicId(response.data.TID));
          dispatch(getModuleId(response.data.MID));
          setNextPage(1);
          setHide(false);
        }
        data[0]?.assessmentType &&
          data[0]?.assessmentType !== "Final Assessment" &&
          setNextPage(2);
        data[0]?.assessmentType &&
          data[0]?.assessmentType !== "Final Assessment" &&
          setHide(false);
        data[0]?.assessmentType &&
          data[0]?.assessmentType === "Final Assessment" &&
          setHide(false);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const params = new URLSearchParams(window.location.search);
  const continueToLast = params.get("continueToLast");

  useEffect(() => {
    if (continueToLast) {
      ContinueToLast(continueToLast);
    }
  }, [continueToLast]);

  useEffect(() => {
    if (continueToLast && window.location.search) {
      const params = new URLSearchParams(window.location.search);
      params.delete("continueToLast");
      const newQueryString = params.toString();
      const newUrl = `${window.location.pathname}${
        newQueryString ? `?${newQueryString}` : ""
      }`;
      window.history.replaceState({}, "", newUrl);
    }
  }, [continueToLast]);

  useEffect(() => {
    setSelectedTopic(null);
    setSelectedAssesment(null);
    setSelectedFinalAssesment(null);
  }, [courseDetails]);

  useEffect(() => {
    if (userId) {
      getUserCertification();
    }
  }, [userId]);

  useEffect(() => {
    if (courseTitle) {
      const selectedCourse = enrolledCourse.find(
        (course: any) => course.courseDetails.TITLE === courseTitle
      );
      if (selectedCourse) {
        const courseId = selectedCourse.courseDetails.CID;
        dispatch(changeClassRoomValue(courseId));
      }
    }
  }, [courseTitle, dispatch, enrolledCourse]);

  useEffect(() => {
    GetCourseDetails();
  }, [value, userId]);
  useEffect(() => {
    dispatch(FinalAssessmentTimer(0));
  }, []);

  const ExpandAllModules = async () => {
    try {
      const response = await instance.get(
        `/6D/map/expandAll?courseId=${value}&userId=${userId}`
      );
      if (response.status === 200) {
        const data = response.data;
        dispatch(getTopicAssessmentDetails(response.data));
        setTopicDetails(data[0]?.topics);
        setAssessmentDetails(data[0]?.Assessment);
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (expand === true) {
      ExpandAllModules();
    }
  }, [expand]);

  return (
    <>
      {enrolledCourse.length === 0 ? (
        <NoDataBox>
          <Typography
            sx={{ fontWeight: 600, fontSize: "16px", color: "#4C2D2D" }}
          >
            Please enroll in any courses
          </Typography>
        </NoDataBox>
      ) : (
        <>
          <Modal
            open={open}
            onClose={handleClose}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          >
            <Box sx={style}>
              {enrolledCourse.length > 0 &&
                enrolledCourse.map((course: any, index: number) => (
                  <>
                    <MenuItem
                      key={index}
                      onClick={() => {
                        setExpandedIndex(null);
                        setExpanded(null);
                        setOpen1(false);
                        if (nextPage !== 2) {
                          dispatch(
                            changeClassRoomValue(course.courseDetails.CID)
                          );
                          // GetCourseDetails();
                          setSelectedCourseTitle(course.courseDetails.TITLE);
                          dispatch(getTopicIndex(0));
                          dispatch(getModuleIndex(0));
                          dispatch(getFinalAssessmentIndex(0));
                          dispatch(getAssessmentIndex(0));
                          handleClose();
                          setNextPage(0);
                          setHide(true);
                        }
                      }}
                    >
                      <Typography>{course.courseDetails?.TITLE || "not found"}</Typography>
                      
                    </MenuItem>
                    <Box
                      sx={{
                        background: "rgb(245, 245, 245)",
                        marginTop: "1px",
                        height: "0.3px",
                        width: "auto",
                      }}
                    />
                  </>
                ))}
            </Box>
          </Modal>
          <Box
            sx={{
              bgcolor: "background.paper",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-end",
              width: "100%",
              alignItems: "center",
              position: "fixed",
              zIndex: 10,
              height: "72px",
            }}
          >
            <Box
              sx={{
                pt: "15px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: "100px",
              }}
            >
              <SubBox
                onClick={handleOpen}
                sx={{
                  backgroundColor:
                    nextPage === 2 ||
                    nextPage === 3 ||
                    nextPage === 4 ||
                    nextPage === 5 ||
                    nextPage === 6 ||
                    QuestionDetails?.length > 0
                      ? "#f0f0f0"
                      : "#edf1f4",
                  cursor:
                    nextPage === 2 ||
                    nextPage === 3 ||
                    nextPage === 4 ||
                    nextPage === 5 ||
                    nextPage === 6 ||
                    QuestionDetails?.length > 0
                      ? "not-allowed"
                      : "pointer",
                }}
              >
                <Typography
                  onClick={handleOpen}
                  sx={{
                    cursor:
                      nextPage === 2 ||
                      nextPage === 3 ||
                      nextPage === 4 ||
                      nextPage === 5 ||
                      nextPage === 6 ||
                      QuestionDetails?.length > 0
                        ? "not-allowed"
                        : "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    fontWeight: 400,
                    color:
                      nextPage === 2 ||
                      nextPage === 3 ||
                      nextPage === 4 ||
                      nextPage === 5 ||
                      nextPage === 6 ||
                      QuestionDetails?.length > 0
                        ? "#939597"
                        : "#3F3F40",
                    pr: 1,
                    fontSize: "14px",
                  }}
                >
                  {selectedCourseTitle ||
                    rootCourse[0]?.courseDetails?.TITLE ||
                    "No Courses Found"}
                </Typography>
                <ArrowDropDownIcon
                  sx={{
                    ml: "40px",
                    cursor:
                      nextPage === 2 ||
                      nextPage === 3 ||
                      nextPage === 4 ||
                      nextPage === 5 ||
                      nextPage === 6 ||
                      QuestionDetails?.length > 0
                        ? null
                        : "pointer",
                    color:
                      nextPage === 2 ||
                      nextPage === 3 ||
                      nextPage === 4 ||
                      nextPage === 5 ||
                      nextPage === 6 ||
                      QuestionDetails?.length > 0
                        ? "#939597"
                        : "black",
                  }}
                  onClick={handleOpen}
                />
              </SubBox>
              <Divider
                orientation="vertical"
                variant="middle"
                flexItem
                sx={{
                  borderColor:
                    nextPage === 2 ||
                    nextPage === 3 ||
                    nextPage === 4 ||
                    nextPage === 5 ||
                    nextPage === 6 ||
                    QuestionDetails?.length > 0
                      ? "#939597"
                      : "#2A62AA",
                  marginLeft: "10px",
                }}
              />
              <Typography
                sx={{
                  fontWeight: 400,
                  fontSize: "14px",
                  color:
                    nextPage === 2 ||
                    nextPage === 3 ||
                    nextPage === 4 ||
                    nextPage === 5 ||
                    nextPage === 6 ||
                    QuestionDetails?.length > 0
                      ? "#939597"
                      : "#2A62AA",
                  margin: "10px",
                  cursor: "pointer",
                }}
              >
                Course
              </Typography>
            </Box>
          </Box>
        </>
      )}
      <br />
      <MyClassRoom
        GetCourseDetails={GetCourseDetails}
        // GetAllcourseDetails={GetAllcourseDetails}
        setExpand={setExpand}
        setExpand1={setExpand1}
        expand1={expand1}
        setExpanded={setExpanded}
        expand={expand}
        setOpen={setOpen1}
        setModuleIndex={setModuleIndex}
        GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
        open={open1}
        setNext={setNext}
        next={next}
        GetTopicContentDetails={GetTopicContentDetails}
        setSelectedTopicDetails={setSelectedTopicDetails}
        setTopicContentDetails={setTopicContentDetails}
        setQuestionDetails={setQuestionDetails}
        setAssessmentDetails={setAssessmentDetails}
        topicContentDetails={topicContentDetails}
        selectedFinalAssesment={selectedFinalAssesment}
        selectedTopic={selectedTopic}
        selectedTopicContent={selectedTopicContent}
        selectedAssesment={selectedAssesment}
        selectedTopicDetails={selectedTopicDetails}
        handleChange={handleChange}
        expanded={expanded}
        moduleIndex={moduleIndex}
        selectedTopicIndex={selectedTopicIndex}
        handleExpansion={handleExpansion}
        handleExpansion1={handleExpansion1}
        handleTopicDetatils={handleTopicDetatils}
        ContinueToLast={ContinueToLast}
        handleAssementDetails={handleAssementDetails}
        setSelectedAssessmentDetails={setSelectedAssessmentDetails}
        selectedAssessmentDetails={selectedAssessmentDetails}
        selectedModuleName={selectedModuleName}
        QuestionDetails={QuestionDetails}
        expandedIndex={expandedIndex}
        topicDetails={topicDetails}
        assessmentDetails={assessmentDetails}
        selectedCourseTitle={selectedCourseTitle}
        courseDetails={courseDetails}
        setNextPage={setNextPage}
        nextPage={nextPage}
        checked={checked}
        topicLength={topicLength}
        completedTopic={completedTopic}
        setChecked={setChecked}
        setHide={setHide}
        hide={hide}
        GetTopicDetails={GetTopicDetails}
        GetAssessmentDetails={GetAssessmentDetails}
      />
    </>
  );
};

export default Classroom;

const SubBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  width: 700px;
  align-items: center;
  background-color: #edf1f4;
  padding: 4px 8px 4px 5px;
`;

const NoDataBox = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f0f0f0;
  border-radius: 10px;
  padding: 20px;
`;
