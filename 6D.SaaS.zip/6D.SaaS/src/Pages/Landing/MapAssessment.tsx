import React, { useState, useEffect } from "react";
import {
  Grid,
  TextField,
  Checkbox,
  Autocomplete,
  FormControl,
} from "@mui/material";
import ReactHtmlParser from "react-html-parser";
import { instance } from "../../Controller/Common";
import CustomAutoComplete from "../../Components/Input/CustomAutoComplete";
import CustomButton from "../../Components/Button/CustomButton";

const MapAssessment = () => {
  const [assessmentData, setAssessmentData] = useState<any[]>([]);
  const [finalAssessmentData, setFinalAssessmentData] = useState<any[]>([]);
  const [questionData, setQuestionData] = useState<any[]>([]);
  const [selectedAssessment, setSelectedAssessment] = useState<any>(null);
  const [selectedFinalAssessment, setSelectedFinalAssessment] =
    useState<any>(null);
  const [selectedQuestion, setSelectedQuestion] = useState<string[]>([]);

  const [courseData, setCourseData] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState<{
    label: string;
    value: number;
  } | null>(null);
  const [moduleData, setModuleData] = useState([]);
  const [selectedModule, setSelectedModule] = useState<{
    label: string;
    value: number;
  } | null>(null);

  // Handle course change
  const handleCourseChange = (value: any) => {
    setSelectedCourse(value);
  };

  // Handle module change
  const handleModuleChange = (value: any) => {
    setSelectedModule(value);
  };

  // Log selected Assessment and Question
  const handleAssessmentChange = (value: any) => {
    setSelectedAssessment(value);
  };

  const handleQuestionChange = (value: { value: string; label: string }[]) => {
    const selectedIds = value.map((question) => question.value.toString());
    setSelectedQuestion(selectedIds);
  };

  // Fetch Assessments
  const GetAllAssessment = async () => {
    try {
      const response = await instance.get(`/6D/assessment/getAssessment`);
      if (response.status === 200) {
        const options = response.data.map((assessment: any) => ({
          label: assessment.NAME,
          value: assessment.AID,
        }));
        setAssessmentData(options);
      }
    } catch (error) {
      console.error("Error fetching assessments:", error);
    }
  };

  const GetAllFinalAssessment = async () => {
    try {
      const response = await instance.get(`/6D/assessment/getFinalAssessment`);
      if (response.status === 200) {
        const options = response.data.map((finalassessment: any) => ({
          label: finalassessment.NAME,
          value: finalassessment.AID,
        }));
        setFinalAssessmentData(options);
      }
    } catch (error) {
      console.error("Error fetching assessments:", error);
    }
  };
  // Fetch Questions
  const GetAllQuestion = async () => {
    try {
      const response = await instance.get(`/6D/assessment/getAllQuestion`);
      if (response.status === 200) {
        const options = response.data.map((question: any) => ({
          label: question.Question,
          value: question.QID,
        }));
        setQuestionData(options);
      }
    } catch (error) {
      console.error("Error fetching questions:", error);
    }
  };

  // Get Courses
  const GetAllCourses = async () => {
    try {
      const response = await instance.get(`/6D/Course/getAllCourse`);
      if (response.status === 200) {
        const courseOptions = response.data.map((course: any) => ({
          label: course.TITLE,
          value: course.CID,
        }));
        setCourseData(courseOptions);
      }
    } catch (error) {
      console.error(error);
    }
  };

  // Get Modules
  const GetAllModules = async () => {
    try {
      const response = await instance.get(`/6D/Module/GetAllModule`);
      if (response.status === 200) {
        const moduleOptions = response.data.map((module: any) => ({
          label: module.NAME,
          value: module.MID,
        }));
        setModuleData(moduleOptions);
      }
    } catch (error) {
      console.error(error);
    }
  };

  // Map Assessment with Question
  const handleMapAssessmentQuestion = async () => {
    if (
      !selectedAssessment ||
      !selectedQuestion ||
      !selectedCourse ||
      !selectedModule
    ) {
      alert("Please fill all the fields.");
      return;
    }

    const payload = selectedModule?.value
      ? {
          assessmentId: selectedAssessment.value,
          questionIds: selectedQuestion.toString(),
          CID: selectedCourse?.value,
          MID: selectedModule?.value,
          ModuleOrder: null,
          TID: selectedAssessment.value,
          TopicOrder: null,
          IdType: "Assessment",
        }
      : {
          assessmentId: selectedAssessment.value,
          questionIds: selectedQuestion.toString(),
          CID: selectedCourse?.value,
          MID: selectedAssessment.value,
          ModuleOrder: null,
          TID: null,
          TopicOrder: null,
          IdType: "Assessment",
        };
    try {
      const response = await instance.post(
        `/6D/assessment/map-assessment-question`,
        payload
      );
      if (response.status === 200) {
        setSelectedAssessment(null);
        setSelectedFinalAssessment(null);
        setSelectedQuestion([]);
        setSelectedModule(null);
        setSelectedCourse(null);
        alert("Assessment successfully mapped to the course and question");
      }
    } catch (error) {
      console.error("Error mapping assessment with questions:", error);
      alert("duplication of questions not allowed");
    }
  };

  useEffect(() => {
    GetAllAssessment();
    GetAllFinalAssessment();
    GetAllQuestion();
    GetAllModules();
    GetAllCourses();
  }, []);

  return (
    <div style={{ margin: "50px", marginTop: "100px" }}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={6}>
          <CustomAutoComplete
            label="Select Assessment"
            options={assessmentData}
            onChange={(_, value) => handleAssessmentChange(value)}
            value={selectedAssessment}
            required
          />
        </Grid>
        {/* <Grid item xs={12} sm={4} md={4}>
          <CustomAutoComplete
            label="Select Final Assessment"
            options={finalAssessmentData}
            onChange={(_, value) => handleFinalAssessmentChange(value)}
            value={selectedFinalAssessment}
            required
          />
        </Grid> */}
        {/* Question Selection */}
        <Grid item xs={12} sm={6} md={6}>
          <FormControl fullWidth required>
            <label
              style={{
                fontSize: "18px",
                color: "black",
                padding: "0 0 5px 0",
              }}
            >
              Select Question*
            </label>
            <Autocomplete
              id="select-question"
              options={Array.isArray(questionData) ? questionData : []}
              onChange={(_, value) => {
                handleQuestionChange(value);
              }}
              value={questionData.filter((q) =>
                selectedQuestion.includes(q.value.toString())
              )}
              multiple
              disableCloseOnSelect
              renderOption={(props, option) => {
                const selected = selectedQuestion.includes(
                  option.value.toString()
                );

                return (
                  <li {...props}>
                    <Checkbox style={{ marginRight: 8 }} checked={selected} />
                    {ReactHtmlParser(option.label)}
                  </li>
                );
              }}
              renderInput={(params) => (
                <TextField {...params} id="select-question" required />
              )}
              // renderTags={(value, getTagProps) =>
              //   value.map((option, index) => (
              //     <span {...getTagProps({ index })}>
              //       {ReactHtmlParser(option.label)}
              //     </span>
              //   ))
              // }
            />
          </FormControl>
        </Grid>

        {/* Course Selection */}
        <Grid item xs={12} sm={6} md={6}>
          <CustomAutoComplete
            label="Select Course"
            options={courseData}
            onChange={(_, value) => handleCourseChange(value)}
            value={selectedCourse}
            required
          />
        </Grid>

        {/* Module Selection */}
        <Grid item xs={12} sm={6} md={6}>
          <CustomAutoComplete
            label="Select Modules"
            options={moduleData}
            onChange={(_, value) => handleModuleChange(value)}
            value={selectedModule}
            required
          />
        </Grid>

        {/* Submit or Mapping Selection */}
        <Grid
          item
          xs={12}
          sm={6}
          md={6}
          style={{ display: "flex", marginTop: "20px" }}
        >
          <CustomButton
            variant="secondary"
            name="Map Assessment/Question"
            onClick={handleMapAssessmentQuestion}
          />
        </Grid>
      </Grid>
    </div>
  );
};

export default MapAssessment;
