import React, { useState } from "react";
import { useSelector } from "react-redux";
import { Modal, Box, Typography, TextField, Button } from "@mui/material";
import CustomButton from "../../Components/Button/CustomButton";
import { RootState } from "../../Store/UserSlice";
import { instance } from "../../Controller/Common";

interface CreateModuleProps {
  openModuleModal: boolean;
  setOpenModuleModal: React.Dispatch<React.SetStateAction<boolean>>;
  handleCloseModuleModal: () => void;
  handleOpenModuleModal: () => void;
  GetAllModules: () => void;
  GetAllCourses: () => void;
}

const CreateModuleModal: React.FC<CreateModuleProps> = ({
  openModuleModal,
  setOpenModuleModal,
  handleCloseModuleModal,
  handleOpenModuleModal,
  GetAllModules,
  GetAllCourses,
}) => {
  const userId = useSelector((state: RootState) => state.user.userID);
  const [moduleName, setModuleName] = useState<string>("");
  const [duration, setDuration] = useState<string>("");

  const CreateModule = async () => {
    if (moduleName) {
      try {
        const response = await instance.post(`/6D/Module/CreateModule`, {
          NAME: moduleName,
          AUTHOR: userId,
          DURATION: duration,
        });
        if (response.status === 200) {
          GetAllCourses();
          GetAllModules();
          handleCloseModuleModal();
          setDuration("");
          setModuleName("");
        }
      } catch (error) {
        console.error(error);
      }
    } else {
      alert("Please complete all required fields.");
    }
  };

  return (
    <Modal open={openModuleModal} onClose={handleCloseModuleModal}>
      <Box
        sx={{
          width: 400,
          bgcolor: "background.paper",
          p: 4,
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          boxShadow: 24,
        }}
      >
        <Typography variant="h6" component="h2">
          Add New Module
        </Typography>
        <TextField
          label="Module Name"
          variant="outlined"
          fullWidth
          margin="normal"
          value={moduleName}
          onChange={(e) => setModuleName(e.target.value)}
        />
        {/* <TextField
          label="Duration"
          variant="outlined"
          fullWidth
          margin="normal"
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
        /> */}
        <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
          <Button onClick={handleCloseModuleModal} sx={{ mr: 2 }}>
            Cancel
          </Button>
          <CustomButton
            variant="secondary"
            name="Submit"
            padding="8px 14px"
            onClick={CreateModule}
          />
        </Box>
      </Box>
    </Modal>
  );
};

export default CreateModuleModal;
