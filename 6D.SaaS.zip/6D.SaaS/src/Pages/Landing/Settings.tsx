import React, { useEffect } from "react";
import { Box } from "@mui/material";
import Account from "../../Components/Screens/Settings/Accounts/Index";
import MyNotification from "../../Components/Screens/Settings/Notifications/Index";
import MyPassword from "../../Components/Screens/Settings/Password/Index";
import { CustomTab, TabPanel } from "../../Components/CustomTab";
import { useSearchParams } from "react-router-dom";

const Settings: React.FC = () => {
  const [value, setValue] = React.useState(0);
  const [searchParams] = useSearchParams();

  useEffect(() => {

    const tab = searchParams.get("tab");
    if (tab === "password") {
      setValue(2);
    } else if (tab === "notification") {
      setValue(1); 
    } else {
      setValue(0); 
    }
  }, [searchParams]);

  useEffect(() => {
    const bgColors = ["#f0f0f0", "#f0f0f0", "#f0f0f0"];
    document.body.style.backgroundColor = bgColors[value];
    return () => {
      document.body.style.backgroundColor = "";
    };
  }, [value]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [value]);

  const tabLabels = ["Account", "Notification", "Password"];
  const tabComponent = [<Account />, <MyNotification />, <MyPassword />];

  return (
    <>
      <Box
        sx={{
          bgcolor: "background.paper",
          display: "flex",
          justifyContent: "space-between",
          flexDirection: "row",
          width: "100%",
          alignItems: "center",
          position: "fixed",
          zIndex: 10,
          height: "72px",
        }}
      >
        <Box sx={{ padding: "10px 0 0 0" }}>
          <CustomTab tabs={tabLabels} value={value} setValue={setValue} />
        </Box>
      </Box>
      {tabComponent.map((component, index) => (
        <TabPanel value={value} index={index} key={index}>
          <br />
          <br />
          {component}
        </TabPanel>
      ))}
    </>
  );
};

export default Settings;
