import React, { useState, useEffect } from "react";
import TopicContent from "./TopicContent";
import CustomAutoComplete from "../../Components/Input/CustomAutoComplete";
import { instance } from "../../Controller/Common";
import Grid from "@mui/material/Grid";
import {
  Typography,
  Button,
  Box,
  Modal,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  SelectChangeEvent,
} from "@mui/material";
import CustomButton from "../../Components/Button/CustomButton";
import CreateModuleModal from "./CreateModuleModal";
import UploadProfile from "../../Components/Screens/Profile/UploadProfile";

const CreateCourseAndModule = () => {
  const [courseData, setCourseData] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState<{
    label: string;
    value: number;
  } | null>(null);

  const [moduleData, setModuleData] = useState([]);
  const [selectedModule, setSelectedModule] = useState<{
    label: string;
    value: number;
  } | null>(null);

  // Modal and form state
  const [openModal, setOpenModal] = useState<boolean>(false);
  const [openModuleModal, setOpenModuleModal] = useState<boolean>(false);
  const [courseName, setCourseName] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [thumbnail, setThumbnail] = useState<string>("");
  const [duration, setDuration] = useState<string>("");
  const [availability, setAvailability] = React.useState("");
  const [author, setAuthor] = React.useState("");

  const GetAllCourses = async () => {
    try {
      const response = await instance.get(`/6D/Course/getAllCourse`);
      if (response.status === 200) {
        const courseOptions = response.data.map((course: any) => ({
          label: course.TITLE,
          value: course.CID,
        }));
        setCourseData(courseOptions);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const GetAllModules = async () => {
    try {
      const response = await instance.get(`/6D/Module/GetAllModule`);
      if (response.status === 200) {
        const moduleOptions = response.data.map((module: any) => ({
          label: module.NAME,
          value: module.MID,
        }));
        setModuleData(moduleOptions);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (event: SelectChangeEvent) => {
    setAvailability(event.target.value as string);
  };
  const handleCourseChange = (
    value: { label: string; value: number } | null
  ) => {
    setSelectedCourse(value);
  };

  const handleModuleChange = (
    value: { label: string; value: number } | null
  ) => {
    setSelectedModule(value);
  };

  const handleOpenModal = () => setOpenModal(true);
  const handleCloseModal = () => setOpenModal(false);
  // Module Function
  const handleOpenModuleModal = () => setOpenModuleModal(true);
  const handleCloseModuleModal = () => setOpenModuleModal(false);
  const [file, setFile] = useState<File | null>(null);
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      setFile(event.target.files[0]); 
    }
  };
  const CreateCourse = async () => {
    if (courseName && description  && availability && author) {
      try {
        const response = await instance.post(`/6D/Course/CreateCourse`, {
          COURSETITLE: courseName,
          DESCRIPTION: description,
          image: file,
          DURATION: duration,
          AVAILABILITY: availability,
          AUTHOR: author,
        },
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        if (response.status === 200) {
          GetAllCourses();
          GetAllModules();
          handleCloseModal();
          setDuration("");
          setThumbnail("");
          setDescription("");
          setCourseName("");
        }
      } catch (error) {
        console.error(error);
      }
    } else {
      alert("Please complete all required fields.");
    }
  };

  useEffect(() => {
    GetAllCourses();
    GetAllModules();
  }, []);
 

  return (
    <div style={{ margin: "50px", marginTop: "100px" }}>
      <CreateModuleModal
        handleOpenModuleModal={handleOpenModuleModal}
        handleCloseModuleModal={handleCloseModuleModal}
        setOpenModuleModal={setOpenModuleModal}
        openModuleModal={openModuleModal}
        GetAllModules={GetAllModules}
        GetAllCourses={GetAllCourses}
      />
      <Grid container spacing={2}>
        <Grid container spacing={2}>
          {/* Course Selection */}
          <Grid item xs={12} sm={6} md={6}>
            <CustomAutoComplete
              label="Select Course"
              options={courseData}
              onChange={(_, value) => handleCourseChange(value)}
              value={selectedCourse}
              required
            />
          </Grid>
          <Grid
            item
            xs={12}
            sm={6}
            md={6}
            style={{
              display: "flex",
              marginTop: "20px",
            }}
          >
            <CustomButton
              variant="secondary"
              name={"Add Course"}
              padding="8px 14px"
              onClick={handleOpenModal}
            />
          </Grid>
        </Grid>

        {/* Module Selection */}
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={6}>
            <CustomAutoComplete
              label="Select Modules"
              options={moduleData}
              onChange={(_, value) => handleModuleChange(value)}
              value={selectedModule}
              required
            />
          </Grid>
          <Grid
            item
            xs={12}
            sm={6}
            md={6}
            style={{
              display: "flex",
              marginTop: "20px",
            }}
          >
            <CustomButton
              variant="secondary"
              name={"Add Module"}
              padding="8px 14px"
              onClick={handleOpenModuleModal}
            />
          </Grid>
        </Grid>

        {/* Topic Content */}
        <Grid item xs={12}>
          <TopicContent
            selectedCourse={selectedCourse}
            selectedModule={selectedModule}
            setSelectedCourse={setSelectedCourse}
            setSelectedModule={setSelectedModule}
          />
        </Grid>
      </Grid>

      {/* Modal for Adding Course */}
      <Modal open={openModal} onClose={handleCloseModal}>
        <Box
          sx={{
            width: 400,
            bgcolor: "background.paper",
            p: 4,
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            boxShadow: 24,
          }}
        >
          <Typography variant="h6" component="h2">
            Add New Course
          </Typography>
          <TextField
            label="Course Name"
            variant="outlined"
            fullWidth
            margin="normal"
            value={courseName}
            onChange={(e) => setCourseName(e.target.value)}
          />
          <TextField
            label="Description"
            variant="outlined"
            fullWidth
            margin="normal"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
          {/* <TextField
            label="Thumbnail"
            variant="outlined"
            fullWidth
            margin="normal"
            value={thumbnail}
            onChange={(e) => setThumbnail(e.target.value)}
          /> */}
          <input type="file" id="fileInput" onChange={handleFileChange} />
          {/* <TextField
            label="Duration"
            variant="outlined"
            fullWidth
            margin="normal"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
          /> */}
          <TextField
            label="Author"
            variant="outlined"
            fullWidth
            margin="normal"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
          />
          <br />
          <FormControl fullWidth>
            <InputLabel id="demo-simple-select-label">Availability</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={availability}
              label="Availability"
              onChange={handleChange}
            >
              <MenuItem value={"Y"}>Yes</MenuItem>
              <MenuItem value={"N"}>No</MenuItem>
            </Select>
          </FormControl>
          <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
            <Button onClick={handleCloseModal} sx={{ mr: 2 }}>
              Cancel
            </Button>
            <CustomButton
              variant="secondary"
              name={"Submit"}
              padding="8px 14px"
              onClick={CreateCourse}
            />
          </Box>
        </Box>
      </Modal>
    </div>
  );
};

export default CreateCourseAndModule;
