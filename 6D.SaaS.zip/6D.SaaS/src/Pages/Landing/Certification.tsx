import React, { useEffect, useState } from "react";
import { Box, Typography, LinearProgress } from "@mui/material";
// import AddCircleIcon from "@mui/icons-material/AddCircle";
import WindowIcon from "@mui/icons-material/Window";
// import FilterListIcon from "@mui/icons-material/FilterList";
import FormatListBulletedIcon from "@mui/icons-material/FormatListBulleted";
// import Popover from "@mui/material/Popover";
import styled from "styled-components";
import MyCertifications from "../../Components/Screens/Certifications/MyCertifications/Index";
import CourseCatlog from "../../Components/Screens/Certifications/CourseCatlog/Index";
import CustomIconButton from "../../Components/Button/CustomIconButton";
import { CustomTab, TabPanel } from "../../Components/CustomTab";
import { cookies, instance } from "../../Controller/Common";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../Store/UserSlice";
import { getEnrolledCourse } from "../../Store/ClassroomSlice";

interface Topic {
  TID: number;
  NAME: string;
  CONTENT: string;
  CONTENT_TYPE: string;
  METADATA: string;
}

interface Module {
  MID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
  Topic: Topic[];
}
interface FinalAssessment {
  AID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
  IdType:any;
}
interface Course {
  CID: number;
  TITLE: string;
  DESCRIPTION: string;
  DURATION: number;
  THUMBNAIL: any;
  AVAILABILITY: string;
  userEnrolled: boolean;
  AUTHOR:string;
  Module: Module[];
  FinalAssessment: FinalAssessment[];
  userStatus:string;
  timespent:any;
}
interface CourseDetails {
  CID: number;
  TITLE: string;
  DESCRIPTION: string;
  DURATION: number;
  THUMBNAIL: string;
  AVAILABILITY: string;
}

interface Certification {
  UC_ID: number;
  CID: number;
  UID: number;
  STATUS: string;
  PROGRESS: number;
  ATTEMPT: number;
  ENROLLED_ON: string;
  TIME_SPENT: any;
  courseDetails: CourseDetails;
}

const Certification: React.FC = () => {
  const Params = new URLSearchParams(window.location.search);
  const tabValue = Params.get("tab");
  const [value, setValue] = React.useState(Number(tabValue) ?? 0);
  const [certificationValue, setCertificationValue] = useState(true);
  const [course, setCourse] = React.useState<Course[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [certifications, setCertifications] = React.useState<Certification[]>(
    []
  );
  const dispatch = useDispatch();
  const userId =
    useSelector((state: RootState) => state.user.userID) ||
    cookies.get("userId");

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (loading) {
      interval = setInterval(() => {
        setProgress((prev) => Math.min(prev + Math.random() * 10, 100));
      }, 100);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const GetCourse = async () => {
    const startTime = Date.now();
    // setLoading(true);
    try {
      const response = await instance.get(
        `/6D/Course/getAllCourseByUserId?userId=${userId}`
      );
      if (response.status === 200) {
        setCourse(response.data);
        setError(null);
      }
    } catch (error) {
      console.error(error);
      setError("Failed to fetch courses. Please try again later.");
    } finally {
      const fetchDuration = Date.now() - startTime;
      setTimeout(() => {
        // setLoading(false);
        setProgress(100);
      }, Math.max(1000 - fetchDuration, 0));
    }
  };

  React.useEffect(() => {
    if (userId) {
      GetCourse();
    }
  }, [userId]);

  useEffect(() => {
    setCertificationValue(true);
  }, [value]);

  useEffect(() => {
    const bgColors = certificationValue
      ? ["white", "white"]
      : ["#f0f0f0", "#f0f0f0"];
    document.body.style.backgroundColor = bgColors[value];
    return () => {
      document.body.style.backgroundColor = "";
    };
  }, [value, certificationValue]);

  const getUserCertification = async () => {
    try {
      const response = await instance.get(
        `/6D/enRoll/getEnRollCourse-ByUId?id=${userId}`
      );
      if (response.status === 200) {
        setCertifications(response.data);
        dispatch(getEnrolledCourse(response.data));
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (userId) {
      getUserCertification();
    }
  }, [userId]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [value]);

  const tabLabels = ["Course List", "Course Enrolled"];

  return (
    <>
      <Box
        sx={{
          bgcolor: "background.paper",
          display: "flex",
          justifyContent: "space-between",
          flexDirection: "row",
          width: "100%",
          alignItems: "center",
          position: "fixed",
          zIndex: 10,
          height: "72px",
          mt: 1,
        }}
      >
        <Box sx={{ padding: "10px 0 0 0" }}>
          <CustomTab tabs={tabLabels} value={value} setValue={setValue} />
        </Box>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            margin: "0.5rem 6rem 0 0",
          }}
        >
          <CustomIconButton
            variant="secondary"
            style={{ margin: "0px 5px" }}
            icon={certificationValue ? WindowIcon : FormatListBulletedIcon}
            onClick={() => setCertificationValue(!certificationValue)}
          />
        </Box>
      </Box>
      <TabPanel value={value} index={0}>
        <Box paddingTop={10}>
          {loading ? (
            <NoDataBox>
              <LinearProgress
                variant="determinate"
                value={progress}
                sx={{
                  width: "30%",
                  height: "10px",
                  borderRadius: "8px",
                  backgroundColor: "#cfcaca",
                  marginBottom: 2,
                  "& .MuiLinearProgress-bar": {
                    backgroundColor: "green",
                  },
                }}
              />
              <Typography
                sx={{ fontWeight: 600, fontSize: "16px", color: "#4C2D2D" }}
              >
                Please wait, loading...
              </Typography>
            </NoDataBox>
          ) : error ? (
            <ErrorBox>
              <Typography
                sx={{ fontWeight: 600, fontSize: "16px", color: "#ff0000" }}
              >
                {error}
              </Typography>
            </ErrorBox>
          ) : (
            //  course.length === 0 ? (
            //   <NoDataBox>
            //     <Typography
            //       sx={{ fontWeight: 600, fontSize: "16px", color: "#4C2D2D" }}
            //     >
            //       No Data Found
            //     </Typography>
            //   </NoDataBox>
            // ) : (
            course.length > 0 && (
              <CourseCatlog
                GetCourse={GetCourse}
                getUserCertification={getUserCertification}
                certificationValue={certificationValue}
                course={course}
                setValue={setValue}
              />
            )
          )}
        </Box>
      </TabPanel>
      <TabPanel value={value} index={1}>
        <Box paddingTop={10}>
          <MyCertifications
            certificationValue={certificationValue}
            certifications={certifications}
            getUserCertification={getUserCertification}
          />
        </Box>
      </TabPanel>
    </>
  );
};

export default Certification;

const NoDataBox = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  /* background-color: #f0f0f0; */
  border-radius: 10px;
  margin-top: 10rem;
  padding: 20px;
`;

const ErrorBox = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #ffe6e6;
  border-radius: 10px;
  padding: 20px;
`;
