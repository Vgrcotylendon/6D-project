import React, { useEffect } from "react";
import {Box } from "@mui/material";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import styled from "styled-components";
import { useDispatch, useSelector } from "react-redux";
import MyHome from "../../Components/Screens/Activity/MyHome";
import Dashboard from "../../Components/Screens/Activity/MyDashBoard";
import CustomIconButton from "../../Components/Button/CustomIconButton";
import { CustomTab, TabPanel } from "../../Components/CustomTab";

interface StateType {
  learning: {
    value: number;
  };
}

const modalStyle = {
  position: "absolute" as "absolute",
  top: 200,
  right: 0,
  transform: "translate(-50%, -50%)",
  bgcolor: "background.paper",
  borderRadius: 2,
  p: "10px 5px",
  zIndex: 111111,
};

const Activity: React.FC = () => {
  const [value, setValue] = React.useState(0);

  useEffect(() => {
    const bgColors = ["#f0f0f0", "#f0f0f0", "#f0f0f0", "#f0f0f0"];
    document.body.style.backgroundColor = bgColors[value];
    return () => {
      document.body.style.backgroundColor = "";
    };
  }, [value]);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [value]);

  const tabLabels = ["My Home", "My Dashboard"];
  const tabComponent = [<MyHome />, <Dashboard />];

  return (
    <>
      <Box
        sx={{
          bgcolor: "background.paper",
          display: "flex",
          justifyContent: "space-between",
          flexDirection: "row",
          width: "100%",
          alignItems: "center",
          position: "fixed",
          zIndex: 10,
          height: "72px",
        }}
      >
        <Box sx={{ padding: "10px 0 0 0" }}>
          <CustomTab tabs={tabLabels} value={value} setValue={setValue} />
        </Box>
        {/* <Box sx={{ display: "flex", alignItems: "center" }}>
          {(value === 2 || value === 3) && (
            <>
              <Typography
                onClick={handleOpen}
                sx={{
                  cursor: "pointer",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  pr: 1,
                  fontWeight:400,
                  fontSize: "14px",
                  marginTop: "10px",
                }}
              >
                {LearningCourse[LearningValue].course} &nbsp;
                <ArrowDropDownIcon sx={{ color: "#2A62AA" }} />
              </Typography>
              <Divider
                className="tab"
                sx={{ marginLeft: "20px", marginTop: "10px", color: "#2A62AA" }}
              />
            </>
          )} */}

          <IconBox>
            <CustomIconButton
              style={{ margin: "0px 5px" }}
              variant="secondary"
              icon={AddCircleIcon}
              disable
            />
          </IconBox>
        {/* </Box> */}
      </Box>
      {tabComponent.map((component, index) => (
        <TabPanel value={value} index={index} key={index}>
          <br />
          <br />
          {component}
        </TabPanel>
      ))}

      {/* <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={modalStyle}>
          {LearningCourse.map((course, index) => (
            <MenuItem
              key={index}
              onClick={() => {
                dispatch(changeLearningValue(index));
                handleClose();
              }}
            >
              {course.course}
            </MenuItem>
          ))}
        </Box>
      </Modal> */}
    </>
  );
};

export default Activity;

const IconBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 10px 90px 0 30px;
`;
