import React, { useEffect, useState } from "react";
import { Box } from "@mui/material";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import WindowIcon from "@mui/icons-material/Window";
import FilterListIcon from "@mui/icons-material/FilterList";
import FormatListBulletedIcon from "@mui/icons-material/FormatListBulleted";
import CurrentlyHiring from "../../Components/Screens/Jobs/CurrentlyHiring";
import Applications from "../../Components/Screens/Jobs/Applications";
import CustomIconButton from "../../Components/Button/CustomIconButton";
import { CustomTab, TabPanel } from "../../Components/CustomTab";

const Jobs: React.FC = () => {
  const [value, setValue] = React.useState(0);
  const [jobsValue, setJobsValue] = useState(true);

  useEffect(() => {
    setJobsValue(true);
  }, [value]);

  useEffect(() => {
    const bgColors = jobsValue ? ["white", "white"] : ["#f0f0f0", "#f0f0f0"];
    document.body.style.backgroundColor = bgColors[value];
    return () => {
      document.body.style.backgroundColor = "";
    };
  }, [value, jobsValue]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [value]);

  const tabLabels = ["Currently Hiring", "Applications"];
  const tabComponent = [
    <CurrentlyHiring jobsValue={jobsValue} />,
    <Applications jobsValue={jobsValue} />,
  ];

  return (
    <>
      <Box
        sx={{
          bgcolor: "background.paper",
          display: "flex",
          justifyContent: "space-between",
          flexDirection: "row",
          width: "100%",
          alignItems: "center",
          position: "fixed",
          zIndex: 10,
          height: "72px",
        }}
      >
        <Box sx={{ padding: "10px 0 0 0" }}>
          <CustomTab tabs={tabLabels} value={value} setValue={setValue} />
        </Box>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            margin: "0.5rem 6rem 0 0",
          }}
        >
          <CustomIconButton
            variant="secondary"
            onClick={() => setJobsValue(!jobsValue)}
            icon={jobsValue ? WindowIcon : FormatListBulletedIcon}
            style={{ margin: "0px 5px" }}
          />
          {jobsValue && (
            <CustomIconButton
              variant="secondary"
              icon={FilterListIcon}
              style={{ margin: "0px 5px" }}
            />
          )}
          <CustomIconButton
            variant="secondary"
            icon={AddCircleIcon}
            style={{ margin: "0px 5px" }}
          />
        </Box>
      </Box>
      {tabComponent.map((component, index) => (
        <TabPanel value={value} index={index} key={index}>
          <br />
          <br />
          {component}
        </TabPanel>
      ))}
    </>
  );
};

export default Jobs;
