import React, { useState, useRef } from "react";
import {
  Box,
  Grid,
  TextField,
  Modal,
  Radio,
  Checkbox,
  Typography,
  FormControl,
  Autocomplete,
} from "@mui/material";
import { Editor } from "@tinymce/tinymce-react";
import CustomAutoComplete from "../../Components/Input/CustomAutoComplete";
import CustomButton from "../../Components/Button/CustomButton";
import { useSelector } from "react-redux";
import { RootState } from "../../Store/UserSlice";
import { instance } from "../../Controller/Common";
import ReactHtmlParser from "react-html-parser";

const CreateAssessment: React.FC = () => {
  const ApiKey = process.env.REACT_APP_TINY_MCE_API_KEY;
  const userId = useSelector((state: RootState) => state.user.userID);
  const editorRef = useRef<any>(null);
  const [courseData, setCourseData] = useState<
    { label: string; value: number }[]
  >([]);
  const [selectedCourse, setSelectedCourse] = useState<{
    label: string;
    value: number;
  } | null>(null);
  const [isFinalAssessment, setIsFinalAssessment] = useState(false);
  const [isAssessmentModalOpen, setIsAssessmentModalOpen] = useState(false);
  const [isQuestionModalOpen, setIsQuestionModalOpen] = useState(false);
  const [question, setQuestion] = useState("");
  const [instruction, setInstruction] = useState("");
  const [cutoffScore, setCutoffScore] = useState("");
  const [attemptInstructions, setAttemptInstructions] = useState("");
  const [show, setShow] = useState(false);
  const [hint, setHint] = useState("");
  const [choiceForm, setChoiceForm] = useState([
    {
      Choice: "",
      IsCorrect: 0,
    },
  ]);
  const [assessmentForm, setAssessmentForm] = useState({
    name: "",
    duration: "",
  });
  const [assessmentData, setAssessmentData] = useState<any[]>([]);
  const [selectedAssessment, setSelectedAssessment] = useState<any>(null);
  const [assessmentQuestion, setAssessmentQuestion] = useState(false);
  const [selectedQuestionType, setSelectedQuestionType] = useState<any>(null);
  const [questionData, setQuestionData] = useState<any[]>([]);
  const [selectedQuestion, setSelectedQuestion] = useState<any[]>([]);
  const [selectedButtonType, setSelectedButtonType] = useState<any>(null);

  const QuestionTypeData = [
    { label: "True/False", value: "True/False" },
    { label: "Multiple Choice", value: "Multiple Choice" },
  ];

  const ButtonTypeData = [
    { label: "Single Answer", value: "Single Answer" },
    { label: "Multiple Answer", value: "Multiple Answer" },
  ];

  const handleQuestionTypeChange = (value: any) => {
    setSelectedQuestionType(value);
    setSelectedButtonType({ label: "Single Answer", value: "Single Answer" });
  };

  const handleButtonTypeChange = (value: any) => {
    setSelectedButtonType(value);
  };
  const handleOpenFinalAssessmentModal = () => {
    setIsAssessmentModalOpen(true);
  };
  const handleCloseAssessmentModal = () => setIsAssessmentModalOpen(false);
  const handleOpenQuestionModal = () => {
    setIsQuestionModalOpen(true);
    setAssessmentQuestion(false);
  };
  const handleCloseQuestionModal = () => setIsQuestionModalOpen(false);

  const handleAddChoice = () => {
    setChoiceForm([...choiceForm, { Choice: "", IsCorrect: 0 }]);
  };

  const handleRadioChange = (index: number) => {
    const updatedChoices = choiceForm.map((choice, i) => ({
      ...choice,
      IsCorrect: i === index ? 1 : 0,
    }));
    setChoiceForm(updatedChoices);
  };
  const GetAllCourses = async () => {
    try {
      const response = await instance.get(`/6D/Course/getAllCourse`);
      if (response.status === 200) {
        const courseOptions = response.data.map((course: any) => ({
          label: course.TITLE,
          value: course.CID,
        }));
        setCourseData(courseOptions);
      }
    } catch (error) {
      console.error(error);
    }
  };
  const handleCheckboxChange = (index: number) => {
    const updatedChoices = choiceForm.map((choice, i) => ({
      ...choice,
      IsCorrect:
        i === index ? (choice.IsCorrect === 1 ? 0 : 1) : choice.IsCorrect,
    }));
    setChoiceForm(updatedChoices);
  };

  const handleAssessmentSubmit = () => {
    if (isFinalAssessment) {
      CreateFinalAssessment();
    } else {
      CreateAssessment();
    }
    setAssessmentForm({ name: "", duration: "" });
    handleCloseAssessmentModal();
  };
  const handleQuestionChange = (value: { value: any; label: any }[]) => {
    const selectedIds = value.map((question) => question.value);
    setSelectedQuestion(selectedIds);
  };

  const handleAssessmentChange = (value: any) => {
    setSelectedAssessment(value);
  };

  const handleOpenAssessmentQuestion = () => {
    setAssessmentQuestion(true);
    setIsQuestionModalOpen(false);
  };

  const CreateAssessment = async () => {
    if (!assessmentForm.name || !assessmentForm.duration || !userId) {
      alert("Please complete all required fields: Name and Duration.");
      return;
    }
    try {
      const response = await instance.post(`/6D/assessment/createAssessment`, {
        NAME: assessmentForm.name,
        DURATION: assessmentForm.duration,
        AUTHOR: userId,
        STATUS: "Not Started",
      });
      if (response.status === 200) {
        alert("Assessment Successfully Created");
      }
    } catch (error) {
      console.error("Error fetching assessments:", error);
    }
  };
  const GetAllQuestion = async () => {
    try {
      const response = await instance.get(`/6D/assessment/getAllQuestion`);
      if (response.status === 200) {
        const options = response.data.map((question: any) => ({
          label: question.Question,
          value: question.QID,
        }));
        setQuestionData(options);
      }
    } catch (error) {
      console.error("Error fetching questions:", error);
    }
  };
  const GetAllAssessment = async () => {
    try {
      const response = await instance.get(`/6D/assessment/getAssessment`);
      if (response.status === 200) {
        const options = response.data.map((assessment: any) => ({
          label: assessment.NAME,
          value: assessment.AID,
        }));
        setAssessmentData(options);
      }
      setSelectedCourse(null);
      setSelectedQuestion([]);
      setInstruction("");
      setCutoffScore("");
      setAttemptInstructions("");
    } catch (error) {
      console.error("Error fetching assessments:", error);
    }
  };
  const CreateFinalAssessment = async () => {
    if (!selectedCourse || selectedQuestion.length === 0 || !cutoffScore) {
      alert("Please fill in all required fields.");
      return;
    }
    try {
      const response = await instance.post(
        `/6D/assessment/map-finalAssessment`,
        {
          CID: selectedCourse?.value,
          AID: selectedQuestion,
          cut_off_score: cutoffScore,
          assessment_instructions: instruction,
          attempt_instructions: attemptInstructions,
        }
      );
      if (response.status === 200) {
        alert("Final Assessment Successfully Created");
      }
      setSelectedCourse(null);
      setSelectedQuestion([]);
      setIsFinalAssessment(false);
    } catch (error) {
      console.error("Error fetching assessments:", error);
    }
  };
  //Create Question
  const handleCreateQuestion = async () => {
    const correctAnswers = choiceForm
      .filter((choice) => choice.IsCorrect === 1)
      .map((choice) => `${choice.Choice}`)
      .join(",");

    const dataToSubmit = {
      Choices: choiceForm,
      CorrectAnswer: correctAnswers,
    };

    if (!question || !correctAnswers) {
      alert("Please complete all required fields.");
      return;
    }

    try {
      const response = await instance.post(`/6D/assessment/createQuestion`, {
        Question: question,
        Type:
          // selectedButtonType.value === null
          //   ? "Single Answer"
          //   :
          selectedButtonType.value,
        QuestionType: selectedQuestionType.value,
        Choices: dataToSubmit.Choices,
        CorrectAnswer: dataToSubmit.CorrectAnswer,
        Hint: "",
      });

      if (response.status === 200) {
        handleCloseQuestionModal();
        setSelectedButtonType(null);
        setSelectedQuestionType(null);
        setIsQuestionModalOpen(false);
        setHint("");
        setChoiceForm([
          {
            Choice: "",
            IsCorrect: 0,
          },
        ]);
        setQuestion("");
        alert("Question Successfully Created");
      }
    } catch (error) {
      console.error("Error fetching assessments:", error);
    }
  };

  const handleMapAssessmentQuestion = async () => {
    if (!selectedAssessment || !selectedQuestion) {
      alert("Please select the assessment, question, and course fields.");
      return;
    }
    try {
      const response = await instance.post(
        `/6D/assessment/add-questionForAssessment`,
        {
          AID: selectedAssessment.value,
          QID: selectedQuestion,
        }
      );
      if (response.status === 200) {
        setSelectedAssessment(null);
        setSelectedQuestion([]);
        alert("Assessment successfully mapped to the course and question");
      }
    } catch (error) {
      console.error("Error mapping assessment with questions:", error);
    }
  };

  React.useEffect(() => {
    GetAllCourses();
    GetAllAssessment();
    GetAllQuestion();
  }, []);

  return (
    <>
      <div style={{ margin: "50px", marginTop: "100px" }}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={4} md={4}>
            <CustomButton
              variant="secondary"
              name="Add Assessment"
              onClick={handleOpenFinalAssessmentModal}
            />
          </Grid>

          <Grid item xs={12} sm={4} md={4}>
            <CustomButton
              variant="secondary"
              name="Add Question"
              onClick={handleOpenQuestionModal}
            />
          </Grid>
          <Grid item xs={12} sm={4} md={4}>
            <CustomButton
              variant="secondary"
              name="Add Assessment Question"
              onClick={handleOpenAssessmentQuestion}
            />
          </Grid>
        </Grid>
        {/* Modal for Add Assessment */}
        <Modal
          open={isAssessmentModalOpen}
          onClose={handleCloseAssessmentModal}
        >
          <Box
            style={{
              padding: "20px",
              backgroundColor: "white",
              margin: "100px auto",
              width: "600px",
            }}
          >
            <h3>Add Assessment</h3>
            <TextField
              label="Assessment Name"
              fullWidth
              value={assessmentForm.name}
              onChange={(e) =>
                setAssessmentForm({ ...assessmentForm, name: e.target.value })
              }
              margin="normal"
            />
            <TextField
              label="Duration"
              fullWidth
              value={assessmentForm.duration}
              onChange={(e) =>
                setAssessmentForm({
                  ...assessmentForm,
                  duration: e.target.value,
                })
              }
              margin="normal"
            />
            <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
              <CustomButton
                name="Cancel"
                onClick={handleCloseAssessmentModal}
                style={{ mr: 2 }}
              />
              <CustomButton name="Submit" onClick={handleAssessmentSubmit} />
            </Box>
          </Box>
        </Modal>
        {/* Show for Add Question */}
        {isQuestionModalOpen && (
          <Box sx={{ marginTop: "20px" }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={12} md={12}>
                <h3>Add Question</h3>
              </Grid>
              <Grid item xs={12} sm={6} md={6}>
                <CustomAutoComplete
                  label="Select Question Type"
                  options={QuestionTypeData}
                  onChange={(_, value) => handleQuestionTypeChange(value)}
                  value={selectedQuestionType}
                  required
                />
              </Grid>
              {/* {selectedQuestionType?.label === "Multiple Choice" && ( */}
              <Grid item xs={12} sm={6} md={6}>
                <CustomAutoComplete
                  label="Select Button Type"
                  options={ButtonTypeData}
                  onChange={(_, value) => handleButtonTypeChange(value)}
                  value={selectedButtonType}
                  disabled={selectedQuestionType?.value === "True/False"}
                  required
                />
              </Grid>
              {/* )} */}
              <Grid item xs={12} sm={6} md={6}>
                <Box sx={{ marginTop: "20px" }}>
                  <TextField
                    id="outlined-basic"
                    label="Enter Hints"
                    variant="outlined"
                    fullWidth
                    value={hint}
                    onChange={(e) => {
                      setHint(e.target.value);
                    }}
                  />
                </Box>
              </Grid>

              <Grid item xs={12} sm={12} md={12}>
                <h4>Create Question</h4>
                <Editor
                  apiKey={ApiKey}
                  onInit={(evt: any, editor: any) =>
                    (editorRef.current = editor)
                  }
                  init={{
                    plugins: [
                      "anchor",
                      "autolink",
                      "charmap",
                      "codesample",
                      "emoticons",
                      "image",
                      "link",
                      "lists",
                      "media",
                      "searchreplace",
                      "table",
                      "visualblocks",
                      "wordcount",
                      "checklist",
                      "mediaembed",
                      "casechange",
                      "export",
                      "formatpainter",
                      "pageembed",
                      "a11ychecker",
                      "tinymcespellchecker",
                      "permanentpen",
                      "powerpaste",
                      "advtable",
                      "advcode",
                      "editimage",
                      "advtemplate",
                      "ai",
                      "mentions",
                      "tinycomments",
                      "tableofcontents",
                      "footnotes",
                      "mergetags",
                      "autocorrect",
                      "typography",
                      "inlinecss",
                      "markdown",
                    ],
                    font_family_formats: 'Poppins=Poppins;',
                    content_style: `
                    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
                    body { font-family: Poppins; }
                    `,
                    toolbar:
                      "undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat",
                    tinycomments_mode: "embedded",
                    tinycomments_author: "Author name",
                    mergetags_list: [
                      { value: "First.Name", title: "First Name" },
                      { value: "Email", title: "Email" },
                    ],
                    height: 400,
                    content_css: "default",
                  }}
                  onEditorChange={setQuestion}
                />
              </Grid>
              {/* Render Choices */}
              {selectedQuestionType?.label === "True/False" && (
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 2,
                    marginBottom: 2,
                  }}
                >
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Radio
                      checked={choiceForm[0].IsCorrect === 1}
                      onChange={() => {
                        const updatedChoices = [
                          { Choice: "True", IsCorrect: 1 },
                          { Choice: "False", IsCorrect: 0 },
                        ];
                        setChoiceForm(updatedChoices);
                      }}
                    />
                    <Typography>True</Typography>
                  </Box>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Radio
                      checked={choiceForm[1]?.IsCorrect === 1}
                      onChange={() => {
                        const updatedChoices = [
                          { Choice: "True", IsCorrect: 0 },
                          { Choice: "False", IsCorrect: 1 },
                        ];
                        setChoiceForm(updatedChoices);
                      }}
                    />
                    <Typography>False</Typography>
                  </Box>
                </Box>
              )}
              {selectedQuestionType?.label === "Multiple Choice" && (
                <>
                  {choiceForm.map((choice, index) => (
                    <Grid container spacing={2} key={index}>
                      <Grid item xs={12} sm={6} md={6}>
                        <Editor
                          apiKey={ApiKey}
                          onInit={(evt: any, editor: any) =>
                            (editorRef.current = editor)
                          }
                          init={{
                            plugins: [
                              "anchor",
                              "autolink",
                              "charmap",
                              "codesample",
                              "emoticons",
                              "image",
                              "link",
                              "lists",
                              "media",
                              "searchreplace",
                              "table",
                              "visualblocks",
                              "wordcount",
                              "checklist",
                              "mediaembed",
                              "casechange",
                              "export",
                              "formatpainter",
                              "pageembed",
                              "a11ychecker",
                              "tinymcespellchecker",
                              "permanentpen",
                              "powerpaste",
                              "advtable",
                              "advcode",
                              "editimage",
                              "advtemplate",
                              "ai",
                              "mentions",
                              "tinycomments",
                              "tableofcontents",
                              "footnotes",
                              "mergetags",
                              "autocorrect",
                              "typography",
                              "inlinecss",
                              "markdown",
                            ],
                            font_family_formats: 'Poppins=Poppins;',
                            content_style: `
                            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
                            body { font-family: Poppins; }
                            `,
                            toolbar:
                              "undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat",
                            tinycomments_mode: "embedded",
                            tinycomments_author: "Author name",
                            mergetags_list: [
                              { value: "First.Name", title: "First Name" },
                              { value: "Email", title: "Email" },
                            ],
                            height: 400,
                            content_css: "default",
                          }}
                          onEditorChange={(content) =>
                            setChoiceForm((prev) =>
                              prev.map((c, i) =>
                                i === index ? { ...c, Choice: content } : c
                              )
                            )
                          }
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={6}>
                        {selectedButtonType &&
                        selectedButtonType.value === "Multiple Answer" ? (
                          <Box sx={{ display: "flex" }}>
                            <Checkbox
                              checked={choice.IsCorrect === 1}
                              onChange={() => handleCheckboxChange(index)}
                            />
                            <Typography>Correct Answer</Typography>
                          </Box>
                        ) : (
                          <Box sx={{ display: "flex" }}>
                            <Radio
                              checked={choice.IsCorrect === 1}
                              onChange={() => handleRadioChange(index)}
                            />
                            <Typography>Correct Answer</Typography>
                          </Box>
                        )}
                      </Grid>
                    </Grid>
                  ))}
                </>
              )}
              {selectedQuestionType?.label === "Multiple Choice" && (
                <Grid item xs={12} sm={6} md={6}>
                  <CustomButton
                    name="Add Choice"
                    onClick={handleAddChoice}
                    fullWidth
                  />
                </Grid>
              )}
              <Grid item xs={12} sm={12} md={12}>
                <CustomButton
                  name="Submit"
                  onClick={handleCreateQuestion}
                  style={{ marginTop: "100px" }}
                  fullWidth
                />
              </Grid>
            </Grid>
          </Box>
        )}
        {assessmentQuestion && (
          <>
            <div style={{ margin: "50px", marginTop: "100px" }}>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6} md={6}>
                  <CustomAutoComplete
                    label="Select Assessment"
                    options={assessmentData}
                    onChange={(_, value) => handleAssessmentChange(value)}
                    value={selectedAssessment}
                    required
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={6}>
                  <FormControl fullWidth required>
                    <label
                      style={{
                        fontSize: "18px",
                        color: "black",
                        padding: "0 0 5px 0",
                      }}
                    >
                      Select Question*
                    </label>
                    <Autocomplete
                      id="select-question"
                      options={Array.isArray(questionData) ? questionData : []}
                      onChange={(_, value) => {
                        handleQuestionChange(value);
                      }}
                      value={questionData.filter((q) =>
                        selectedQuestion.includes(q.value)
                      )}
                      multiple
                      disableCloseOnSelect
                      renderOption={(props, option) => {
                        const selected = selectedQuestion.includes(
                          option.value
                        );

                        return (
                          <li {...props}>
                            <Checkbox
                              style={{ marginRight: 8 }}
                              checked={selected}
                            />
                            {ReactHtmlParser(option.label)}
                          </li>
                        );
                      }}
                      renderInput={(params) => (
                        <TextField {...params} id="select-question" required />
                      )}
                    />
                  </FormControl>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sm={6}
                  md={6}
                  style={{ display: "flex", marginTop: "20px" }}
                >
                  <CustomButton
                    variant="secondary"
                    name="Map Assessment/Question"
                    onClick={handleMapAssessmentQuestion}
                  />
                </Grid>
              </Grid>
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default CreateAssessment;
