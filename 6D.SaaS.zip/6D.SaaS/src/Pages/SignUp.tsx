import { Box, Container, Grid } from "@mui/material";
import React, { useState } from "react";
import CreatePassword from "../Components/Screens/SignUp/CreatePassword";
import SignUpForm from "../Components/Screens/SignUp/SignUpForm";
import Information from "../Components/Screens/SignUp/Information";
import Verify from "../Components/Screens/SignUp/Verify";
import YellowCard from "../Components/Card/YellowCard";
import TermsModal from "../Components/Screens/SignIn/TermsModal";
import PolicyModal from "../Components/Screens/SignIn/PolicyModal";
 
export default function SignUp() {
  const [email, setEmail] = useState<string>("");
  const [mobileNumber, setMobileNumber] = useState<string>("");
  const [val, setVal] = useState<number>(0);
  const [fromSignUp, setFromSignUp] = useState<boolean>(false);
 
  const [openPolicy, setOpenPolicy] = useState(false);
  const [openTerms, setOpenTerms] = useState(false);
  const handleCloseTerms = () => setOpenTerms(false);
  const handleClosePolicy = () => setOpenPolicy(false);
  const height = window.innerHeight;
  const MarginPercent = (80 / height) * 100;
  const MarginTopPercent = (152 / height) * 100;

  const marginTop = (MarginTopPercent / 100) * height;
  const marginBottom = (MarginPercent / 100) * height;
  const maxheight = height - (marginTop + marginBottom);

  return (
    <>
      {(openTerms === true || openPolicy === true) && (
        <>
          {" "}
          {openTerms === true && (
            <TermsModal
              maxheight={maxheight}
              height={height}
              marginTop={marginTop}
              marginBottom={marginBottom}
              handleCloseTerms={handleCloseTerms}
            />
          )}
          {openPolicy === true && (
            <PolicyModal
              maxheight={maxheight}
              height={height}
              marginTop={marginTop}
              marginBottom={marginBottom}
              handleClosePolicy={handleClosePolicy}
            />
          )}
        </>
      )}
      {openTerms === false && openPolicy === false && (
        <Container
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "100vh",
            margin: "auto",
          }}
        >
          <Grid
            container
            spacing={8}
            paddingLeft={10}
            paddingRight={10}
            paddingTop={7}
            sx={{
              // minHeight: "75%",
              display: "flex",
              justifyContent: "space-evenly",
              alignItems: "center",
              // padding: "25px 50px",
            }}
          >
            <Grid
              item
              xs={6}
              sx={{ display: { xs: "none", sm: "none", md: "block" } }}
            >
              <YellowCard />
            </Grid>
 
            <Grid item xs={12} sm={6}>
              {val === 0 && (
                <SignUpForm
                  email={email}
                  mobileNumber={mobileNumber}
                  setEmail={setEmail}
                  setMobileNumber={setMobileNumber}
                  setVal={setVal}
                  setOpenTerms={setOpenTerms}
                  setOpenPolicy={setOpenPolicy}
                  setFromSignUp={setFromSignUp}
                />
              )}
              {val === 1 && (
                <Verify
                  setVal={setVal}
                  value={
                    mobileNumber ? "Phone Number" : email ? "Email Address" : ""
                  }
                  email={email}
                  mobileNumber={mobileNumber}
                  setEmail={setEmail}
                  setMobileNumber={setMobileNumber}
                  fromSignUp={fromSignUp}
                  setFromSignUp={setFromSignUp}
                  // value={verifyValue}
                />
              )}
              {val === 2 && mobileNumber ? (
                <Information />
              ) : val === 2 && email ? (
                <CreatePassword setVal={setVal} email={email} />
              ) : null}
              {val === 3 && <Information />}
            </Grid>
          </Grid>
        </Container>
      )}
    </>
  );
}