declare module "react-html-parser" {
  export default function ReactHtmlParser(html: string): JSX.Element[];
}
