import React, { ReactNode, useEffect, useState } from "react";
import {
  BrowserRouter,
  Navigate,
  Route,
  Routes,
  useLocation,
  useNavigate,
} from "react-router-dom";
import Landing from "../Pages/Landing";
import MyAppBar from "../Components/Bar/MyAppBar";
import Profile from "../Pages/Landing/Profile";
import Jobs from "../Pages/Landing/Jobs";
import Activity from "../Pages/Landing/Activity";
import Settings from "../Pages/Landing/Settings";
import Classroom from "../Pages/Landing/Classroom";
import Certification from "../Pages/Landing/Certification";
import SignUp from "../Pages/SignUp";
import SignIn from "../Pages/SignIn";
import { useDispatch, useSelector } from "react-redux";
import { setPrevious } from "../Store/TourSlice";
import { RootState } from "../Store/UserSlice";
import { cookies } from "../Controller/Common";
import CreateCourseAndModule from "../Pages/Landing/CreateCourseAndModule";
import CreateAssessment from "../Pages/Landing/CreateAssessment";
import MapAssessment from "../Pages/Landing/MapAssessment";
import CreateFinalAssessment from "../Pages/Landing/CreateFinalAssessment";

interface ProtectProps {
  children: ReactNode;
}

const Nav = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [current, setCurrent] = useState("");

  useEffect(() => {
    if (location.pathname === "/landing") {
      navigate("/landing/activity");
    }
    if (location.pathname === "/") {
      navigate("/signup");
    }
  }, [location, navigate]);

  useEffect(() => {
    setCurrent(location.pathname);
    dispatch(setPrevious(current));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  return null;
};

const Protect: React.FC<ProtectProps> = ({ children }) => {
  const auth = useSelector((state: RootState) => state.user.isAuth);
  const token = cookies.get("token");

  return auth || token ? <>{children}</> : <Navigate to="/signin" />;
};

export default function MyRoutes() {
  return (
    <>
      <BrowserRouter>
        <Nav />
        <MyAppBar />
        <Routes>
          <Route path="signup" element={<SignUp />} />
          <Route path="signin" element={<SignIn />} />
          <Route
            path="/landing"
            element={
              <Protect>
                <Landing />
              </Protect>
            }
          >
            <Route path="activity" element={<Activity />} />
            <Route path="profile" element={<Profile />} />
            <Route path="settings" element={<Settings />} />
            <Route path="certification" element={<Certification />} />
            <Route path="classroom" element={<Classroom />} />
            <Route path="jobs" element={<Jobs />} />
            <Route
              path="CreateCourseAndModule"
              element={<CreateCourseAndModule />}
            />
            <Route path="CreateAssessment" element={<CreateAssessment />} />
            <Route path="CreateFinalAssessment" element={<CreateFinalAssessment />} />
            <Route path="MapAssessment" element={<MapAssessment />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}
