import { createSlice } from "@reduxjs/toolkit";

interface UserState {
  userID: string;
  userName: string;
  email: string;
  mobile: string;
  error: string;
  loading: boolean;
  isAuth: boolean;
  profile: boolean;
  authType:string;
}

export interface RootState {
  user: UserState;
  // Add other slices of state here
}
const initialState = {
  userName: null,
  userID: null,
  email: null,
  mobile: null,
  error: null,
  profile: null,
  loading: false,
  isAuth: false,
  authType:null,
};

const UserSlice = createSlice({
  name: "User",
  initialState,
  reducers: {
    StartSignIn(state) {
      state.userID = null;
      state.userName = null;
      state.email = null;
      state.mobile = null;
      state.loading = true;
      state.isAuth = false;
      state.error = null;
      state.authType = null;
    },
    SignInSuccess(state, action) {
      state.userID = action.payload.userId;
      state.userName = action.payload.userName;
      state.email = action.payload.email || null;
      state.mobile = action.payload.mobile || null;
      state.isAuth = true;
      state.loading = false;
      state.error = null;
      state.authType = action.payload.accountOrigin;
    },
    SignInFailed(state, action) {
      state.userID = null;
      state.userName = null;
      state.email = null;
      state.mobile = null;
      state.loading = false;
      state.isAuth = false;
      state.error = action.payload;
      state.authType = null;
    },
    StartSignOut(state) {
      state.userID = null;
      state.userName = null;
      state.email = null;
      state.mobile = null;
      state.loading = false;
      state.isAuth = false;
      state.authType = null;
    },
    UpdateProfile(state, action) {
      state.profile = action.payload;
    },
  },
});

export default UserSlice.reducer;
export const {
  SignInSuccess,
  StartSignIn,
  SignInFailed,
  StartSignOut,
  UpdateProfile,
} = UserSlice.actions;
