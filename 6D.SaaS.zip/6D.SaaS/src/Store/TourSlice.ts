import { createSlice } from "@reduxjs/toolkit";
const initialState = {
  value: 0,
  previousPage: "",
};
const TourSlice = createSlice({
  name: "tour",
  initialState,
  reducers: {
    ChangeTourValue(state, action) {
      state.value = action.payload;
    },
    setPrevious(state, action) {
      state.previousPage = action.payload;
    },
  },
});

export default TourSlice.reducer;
export const { ChangeTourValue, setPrevious } = TourSlice.actions;
