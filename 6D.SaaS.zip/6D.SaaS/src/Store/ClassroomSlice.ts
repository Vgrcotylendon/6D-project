import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  value: 0,
  MID: null,
  AID: null,
  enrolledCourse: [],
  topic: [],
  assessmentQuestion: [],
  assessmentIndex: null,
  topicIndex: null,
  module: [],
  moduleIndex: null,
  finalAssessment: [],
  finalAssessmentIndex: null,
  finalAssessmentAID: null,
  finalAssessmentDetails: {},
  finalAssessmentAttempt: 1,
  finalAssessmentQuestionDetails: [],
  finalAssessmentStatus: [],
  AccordionTask: [],
  allCourseDetails: [],
  continueButtonDetails: [],
  moduleId: null,
  assessmentId: null,
  topicId: null,
  moduleName: null,
  topicDetails: [],
  assessmentDetails: [],
  topicAssessmentDetails: [] as any[],
  TopicOrder: null,
  ModuleOrder: null,
  finalAssessmentDetailsStatus: {},
  Answers: {} as any,
  NewSelectedAnswers: {} as any,
  SubmittedAnswers: {} as any,
  timer: 0,
};

const ClassroomSlice = createSlice({
  name: "classroom",
  initialState,
  reducers: {
    changeClassRoomValue(state, action) {
      state.value = action.payload;
    },
    changeClassRoomMID(state, action) {
      state.MID = action.payload;
    },
    changeClassRoomAID(state, action) {
      state.AID = action.payload;
    },
    getEnrolledCourse(state, action) {
      state.enrolledCourse = action.payload;
    },
    getTopic(state, action) {
      state.topic = action.payload;
    },
    getAssesment(state, action) {
      state.assessmentQuestion = action.payload;
    },
    getAssessmentIndex(state, action) {
      state.assessmentIndex = action.payload;
    },
    getTopicIndex(state, action) {
      state.topicIndex = action.payload;
    },
    getModule(state, action) {
      state.module = action.payload;
    },
    getModuleIndex(state, action) {
      state.moduleIndex = action.payload;
    },
    getFinalAssessment(state, action) {
      state.finalAssessment = action.payload;
    },
    getFinalAssessmentIndex(state, action) {
      state.finalAssessmentIndex = action.payload;
    },
    getFinalAssessmentAID(state, action) {
      state.finalAssessmentAID = action.payload;
    },
    getFinalAssessmentDetails(state, action) {
      state.finalAssessmentDetails = action.payload;
    },
    getFinalAssessmentDetailsSatus(state, action) {
      state.finalAssessmentDetailsStatus = action.payload;
    },
    getFinalAssessmentAttempt(state, action) {
      state.finalAssessmentAttempt = action.payload;
    },
    ClearFinalAssessmentAttempt(state) {
      state.finalAssessmentAttempt = 1;
    },
    getFinalAssessmentQuestionDetails(state, action) {
      state.finalAssessmentQuestionDetails = action.payload;
    },
    getFinalAssessmentStatus(state, action) {
      state.finalAssessmentStatus = action.payload;
    },
    getFinalAccordionTask(state, action) {
      state.AccordionTask = action.payload;
    },
    getAllCourseDetails(state, action) {
      state.allCourseDetails = action.payload;
    },
    getContinueDetails(state, action) {
      state.continueButtonDetails = action.payload;
    },
    getModuleId(state, action) {
      state.moduleId = action.payload;
    },
    getTopicId(state, action) {
      state.topicId = action.payload;
    },
    getTopicOrder(state, action) {
      state.TopicOrder = action.payload;
    },
    getModuleOrder(state, action) {
      state.ModuleOrder = action.payload;
    },
    getAssessmentId(state, action) {
      state.assessmentId = action.payload;
    },
    getModuleName(state, action) {
      state.moduleName = action.payload;
    },
    getTopicAssessmentDetails(state, action) {
      state.topicAssessmentDetails = [
        ...state.topicAssessmentDetails,
        ...action.payload,
      ].sort((a: any, b: any) => a.TopicOrder - b.TopicOrder);
    },
    clearGetTopicAssessmentDetails(state) {
      state.topicAssessmentDetails = [];
    },
    GetAnswers(state, action) {
      const choice = action.payload.choice;
      const questionIndex = action.payload.questionIndex;
      const isMultiple = action.payload.isMultiple;

      const currentSelections = state.Answers[questionIndex] || [];
      const updatedSelections = isMultiple
        ? currentSelections.includes(choice)
          ? currentSelections.filter((c: any) => c !== choice)
          : [...currentSelections, choice]
        : choice;

      state.Answers[questionIndex] = updatedSelections;
    },
    GetSumitted(state, action) {
      const choice = action.payload.choice;
      const questionIndex = action.payload.questionIndex;
      const isMultiple = action.payload.isMultiple;

      const currentSelections = state.SubmittedAnswers[questionIndex] || [];
      const updatedSelections = isMultiple
        ? currentSelections.includes(choice)
          ? currentSelections.filter((c: any) => c !== choice)
          : [...currentSelections, choice]
        : choice;

      state.SubmittedAnswers[questionIndex] = updatedSelections;
    },
    ClearAnswers(state) {
      state.Answers = {};
      state.SubmittedAnswers = {};
    },
    GetNewSelectedAnswers(state, action) {
      state.NewSelectedAnswers = action.payload;
    },
    FinalAssessmentTimer(state, action) {
      state.timer = action.payload;
    },
    CleaRassessmentTimer(state) {
      state.timer = 0;
    },
  },
});

export default ClassroomSlice.reducer;
export const {
  changeClassRoomAID,
  changeClassRoomMID,
  changeClassRoomValue,
  getEnrolledCourse,
  getTopic,
  getTopicIndex,
  getModule,
  getModuleIndex,
  getAssessmentIndex,
  getAssesment,
  getFinalAssessment,
  getFinalAssessmentIndex,
  getFinalAssessmentAID,
  getFinalAssessmentDetails,
  getFinalAssessmentAttempt,
  ClearFinalAssessmentAttempt,
  getFinalAssessmentQuestionDetails,
  getFinalAssessmentStatus,
  getFinalAccordionTask,
  getAllCourseDetails,
  getContinueDetails,
  getModuleId,
  getTopicId,
  getAssessmentId,
  getModuleName,
  getTopicAssessmentDetails,
  clearGetTopicAssessmentDetails,
  getModuleOrder,
  getTopicOrder,
  getFinalAssessmentDetailsSatus,
  ClearAnswers,
  GetNewSelectedAnswers,
  GetSumitted,
  GetAnswers,
  FinalAssessmentTimer,
  CleaRassessmentTimer,
} = ClassroomSlice.actions;
