import { configureStore } from "@reduxjs/toolkit";
import TourSlice from "./TourSlice";
import ClassroomSlice from "./ClassroomSlice";
import LearningSlice from "./LearningSlice";
import UserSlice from "./UserSlice";
export const store = configureStore({
  reducer: {
    tour: TourSlice,
    classRoom: ClassroomSlice,
    learning: LearningSlice,
    user: UserSlice
  },
});
