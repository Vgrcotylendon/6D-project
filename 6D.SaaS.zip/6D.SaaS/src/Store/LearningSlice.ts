import { createSlice } from "@reduxjs/toolkit";

const initialState = { value: 0 };
const LearningSlice = createSlice({
  name: "learning",
  initialState,
  reducers: {
    changeLearningValue(state, action) {
        state.value = action.payload;
      },
  },
});
export const {changeLearningValue}=LearningSlice.actions
export default LearningSlice.reducer