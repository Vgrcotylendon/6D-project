import axios from "axios";
import Cookies from "universal-cookie";
import { SignInSuccess, UpdateProfile } from "../Store/UserSlice";

const BaseUrl = process.env.REACT_APP_BASE_SERVER_URI

// const BaseUrl = "http://192.168.1.11:8081";

const ImageUrl = `${BaseUrl}/6D/`;
const cookies = new Cookies();

const instance = axios.create({
  baseURL: BaseUrl,
});
instance.interceptors.request.use(
  (config) => {
    const token = cookies.get("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const Verify_Token = async (dispatch: any, navigate: any) => {
  const token = cookies.get("token");

  if (!token) {
    navigate("/signin");
    return false;
  }

  try {
    const response = await instance.get("/6D/auth/verify-token");
    if (response.status === 200) {
      dispatch(SignInSuccess(response.data.user.USER));
      dispatch(UpdateProfile(`${ImageUrl}${response.data.user.USER.profile}`));
      cookies.set("userId", response.data.user.USER.userId);

      return true;
    } else {
      navigate("/signin");
      return false;
    }
  } catch (error) {
    console.error("Token verification failed:", error);
    navigate("/signin");
    return false;
  }
};

const GetAcessToken = async () => {
  const refreshToken = cookies.get("refreshToken");
  const userId = cookies.get("userId");

  if (!refreshToken || !userId) {
    return false;
  }

  try {
    const response = await instance.post("/6D/auth/getme", {
      refreshToken,
      userId,
    });

    if (response.status === 200) {
      cookies.set("token", response.data.AccessToken);
      return true;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Failed to get access token:", error);
    return false;
  }
};

export { instance, BaseUrl, ImageUrl, cookies, Verify_Token, GetAcessToken };
