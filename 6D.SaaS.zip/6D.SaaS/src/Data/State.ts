export const StateList = [
  {
    id: 1,
    name: "India",
    States: [
      {
        id: 4023,
        name: "Andaman and Nicobar Islands",
        state_code: "AN",
      },
      {
        id: 4017,
        name: "Andhra Pradesh",
        state_code: "AP",
      },
      {
        id: 4024,
        name: "Arunachal Pradesh",
        state_code: "AR",
      },
      {
        id: 4027,
        name: "Assam",
        state_code: "AS",
      },
      {
        id: 4037,
        name: "Bihar",
        state_code: "BR",
      },
      {
        id: 4031,
        name: "Chandigarh",
        state_code: "CH",
      },
      {
        id: 4040,
        name: "Chhattisgarh",
        state_code: "CT",
      },
      {
        id: 4033,
        name: "Dadra and Nagar Haveli and Daman and Diu",
        state_code: "DH",
      },
      {
        id: 4021,
        name: "Delhi",
        state_code: "DL",
      },
      {
        id: 4009,
        name: "Goa",
        state_code: "GA",
      },
      {
        id: 4030,
        name: "Gujarat",
        state_code: "GJ",
      },
      {
        id: 4007,
        name: "Haryana",
        state_code: "HR",
      },
      {
        id: 4020,
        name: "Himachal Pradesh",
        state_code: "HP",
      },
      {
        id: 4029,
        name: "Jammu and Kashmir",
        state_code: "JK",
      },
      {
        id: 4025,
        name: "Jharkhand",
        state_code: "JH",
      },
      {
        id: 4026,
        name: "Karnataka",
        state_code: "KA",
      },
      {
        id: 4028,
        name: "Kerala",
        state_code: "KL",
      },
      {
        id: 4852,
        name: "Ladakh",
        state_code: "LA",
      },
      {
        id: 4019,
        name: "Lakshadweep",
        state_code: "LD",
      },
      {
        id: 4039,
        name: "Madhya Pradesh",
        state_code: "MP",
      },
      {
        id: 4008,
        name: "Maharashtra",
        state_code: "MH",
      },
      {
        id: 4010,
        name: "Manipur",
        state_code: "MN",
      },
      {
        id: 4006,
        name: "Meghalaya",
        state_code: "ML",
      },
      {
        id: 4036,
        name: "Mizoram",
        state_code: "MZ",
      },
      {
        id: 4018,
        name: "Nagaland",
        state_code: "NL",
      },
      {
        id: 4013,
        name: "Odisha",
        state_code: "OR",
      },
      {
        id: 4011,
        name: "Puducherry",
        state_code: "PY",
      },
      {
        id: 4015,
        name: "Punjab",
        state_code: "PB",
      },
      {
        id: 4014,
        name: "Rajasthan",
        state_code: "RJ",
      },
      {
        id: 4034,
        name: "Sikkim",
        state_code: "SK",
      },
      {
        id: 4035,
        name: "Tamil Nadu",
        state_code: "TN",
      },
      {
        id: 4012,
        name: "Telangana",
        state_code: "TG",
      },
      {
        id: 4038,
        name: "Tripura",
        state_code: "TR",
      },
      {
        id: 4022,
        name: "Uttar Pradesh",
        state_code: "UP",
      },
      {
        id: 4016,
        name: "Uttarakhand",
        state_code: "UT",
      },
      {
        id: 4853,
        name: "West Bengal",
        state_code: "WB",
      },
    ],
  },
];
