import WorkspacePremiumOutlinedIcon from "@mui/icons-material/WorkspacePremiumOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import AssessmentIcon from "@mui/icons-material/Assessment";
import TopicIcon from "@mui/icons-material/Topic";
import MergeIcon from "@mui/icons-material/Merge";
import AccountCircleOutlinedIcon from "@mui/icons-material/AccountCircleOutlined";
// import WorkOutlineOutlinedIcon from "@mui/icons-material/WorkOutlineOutlined";
import LocalLibraryOutlinedIcon from "@mui/icons-material/LocalLibraryOutlined";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";

export const DrawerList = [
  {
    icon: NotificationsNoneIcon,
    name: "Dashboard",
    value: 1,
    navigate: "/landing/activity",
  },
  {
    icon: WorkspacePremiumOutlinedIcon,
    name: "Courses",
    value: 2,
    navigate: "/landing/certification",
  },
  {
    icon: LocalLibraryOutlinedIcon,
    name: "Classroom",
    value: 3,
    navigate: "/landing/classroom",
  },
  // {
  //   icon: WorkOutlineOutlinedIcon,
  //   name: "Jobs",
  //   value: 4,
  //   navigate: "/landing/jobs",
  // },
  {
    icon: AccountCircleOutlinedIcon,
    name: "Profile",
    value: 5,
    navigate: "/landing/profile",
  },
  {
    icon: SettingsOutlinedIcon,
    name: "Settings",
    value: 6,
    navigate: "/landing/settings",
  },
  {
    icon: TopicIcon,
    name: "Create Content",
    value: 7,
    navigate: "/landing/CreateCourseAndModule",
  },
  {
    icon: AssessmentIcon,
    name: "Create Assessment",
    value: 8,
    navigate: "/landing/CreateAssessment",
  },
  {
    icon: AssessmentIcon,
    name: "Create Final Assessment",
    value: 9,
    navigate: "/landing/CreateFinalAssessment",
  },
  {
    icon: MergeIcon,
    name: "Map Assessment",
    value: 10,
    navigate: "/landing/MapAssessment",
  },
];

export const TourData = [
  {
    value: 1,
    head: "Activity",
    content: [
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
    ],
  },
  {
    value: 2,
    head: "certification",
    content: [
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
    ],
  },
  {
    value: 3,
    head: "Classroom",
    content: [
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
    ],
  },
  {
    value: 4,
    head: "Jobs",
    content: [
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
    ],
  },
  {
    value: 5,
    head: "Profile",
    content: [
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
    ],
  },
  {
    value: 6,
    head: "Settings",
    content: [
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
    ],
  },
];

interface Course {
  id: number;
  CourseTitle: string;
  estimatedTime: string;
  status: string;
  modules: any;
}

