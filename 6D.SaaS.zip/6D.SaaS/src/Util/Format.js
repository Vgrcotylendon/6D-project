const formattedDate = (value) => {
  const dateObj = new Date(value);
  const day = dateObj.getUTCDate();
  const month = dateObj.toLocaleString("default", { month: "long" });
  const year = dateObj.getUTCFullYear();
  const formattedDate = `${day} ${month.slice(0, 3)} ${year}`;
  return formattedDate;
};

const formattedMinutes = (value) => {
  const hours = Math.floor(value / 60);
  const minutes = value % 60;
  return `${hours} hr${hours !== 1 ? "s" : ""} ${minutes} min${
    minutes !== 1 ? "s" : ""
  }`;
};

export { formattedDate, formattedMinutes };
