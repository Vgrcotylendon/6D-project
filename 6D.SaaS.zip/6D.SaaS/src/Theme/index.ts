import { createTheme } from "@mui/material";

export const Theme = createTheme({
  palette: {
    secondary: {
      main: "#E5EDF3",
    },
    success: {
      main: "#48A055",
    },
    warning: {
      main: "#EF5C00",
    },

    action: { active: "#919599" },

    info: {
      main: "#2A62AA",
      light: "#E7EEF3",
    },
  },
  components: {
    //------------------MuiTypography
    MuiTypography: {
      styleOverrides: {
        root: {
          fontFamily: "Poppins",
          "&.BarProfile": {
            color: "#3F3F40",
            fontSize: "14px",
            fontWeight: "300",
            marginLeft: "5px",
          },
          "&.NavTP": {
            color: "#3F3F40",
            fontSize: "20px",
            fontWeight: "200",
          },
          "&.drawer": {
            fontSize: "12px",
            // marginTop: "1px",
          },
          "&.drawerHoverColor": {
            color: "#2A62AA",
          },
          "&.drawerColor": {
            color: "#919599",
          },
          "&.tourModalHead": {
            fontSize: "12px",
            fontWeight: "700",
          },
          "&.tourModal": {
            fontSize: "10px",
            fontWeight: "400",
          },

          "&.tourModalIcons": {
            fontWeight: "500",
            fontSize: "14px",
            padding: "0 5px 0 0",
          },
          "&.welcomeHead": {
            fontSize: "16px",
            fontWeight: "700",
          },
          "&.welcomeSub": {
            fontSize: "12px",
            fontWeight: "500",
          },
          "&.Activity": {
            fontSize: "16px",
            fontWeight: "600",
            margin: "10px",
          },
          "&.update": {
            color: "#EF5C00",
            fontSize: "12px",
            fontWeight: "700",
          },
          "&.getUpdate": {
            color: "#3F3F40",
            fontSize: "12px",
            fontWeight: "700",
          },
          "&.getBody,&.verifyBody": {
            color: "#000000",
            fontSize: "12px",
            fontWeight: "400",
          },
          "&.progress": {
            color: "#000000",
            fontSize: "12px",
            fontWeight: "400",
          },
          "&.courseName": {
            fontSize: "14px",
            fontWeight: "400",
          },
          "&.flex": {
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          },
          "&.viewMore": {
            fontSize: "10px",
            color: "#3F3F40",
            fontWeight: "400",
            cursor: "pointer",
          },
          "&.ApplyNowHead , &.myCertifyHead": {
            fontSize: "14px",
            fontWeight: "400",
            width: "50%",
            color: "#3F3F40",
          },
          "&.ApplyNow &.myCertify": {
            fontSize: "14px",
            fontWeight: "400",
            color: "#656566",
          },
          "&.ApplyPosition": {
            fontSize: "12px",
            fontWeight: "400",
            padding: "5px 10px",
            "&.intern": {
              backgroundColor: "#FFE6F2",
            },
            "&.partTime": {
              backgroundColor: "#EEE6FF",
            },
            "&.fullTime": {
              backgroundColor: "#E6FAFA",
            },
            "&.contract": {
              backgroundColor: "#F5F5F5",
            },
          },
          "&.Signinto": {
            fontSize: "14px",
            marginTop: "18px",
            color: "#376CAF",
            fontWeight: "bold",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          },

          "&.span": {
            display: "block",
            width: "25px",
            height: "2px",
            borderRadius: "3px",

            marginBottom: "5px",
            "&.white": {
              backgroundColor: "#ffffff",
            },
            "&.grey": {
              backgroundColor: "#9C9CA4",
            },
          },
          "&.sidebar-module": {
            fontSize: "12px",
            fontWeight: 400,
            "&.-black": {
              color: "#000000",
            },
            "&.sidebar-module-white": {
              color: "#fff",
            },
          },
          "&.sidebar-module1": {
            fontSize: "10px",
            fontWeight: 400,
            "&.-black1": {
              color: "#000000",
            },
            "&.sidebar-module-white1": {
              color: "#fff",
            },
          },
          "&.welcome-title": {
            fontSize: "14px",
            fontWeight: "700",
          },
          "&.welcome-content": {
            fontSize: "14px",
          },
          "&.transcript": {
            fontSize: "12px",
            padding: "10px",
          },
          "&.applicationModal": {
            display: "flex",
            alignItems: "center",
            "&.normal": {
              fontSize: "12px",
            },
          },
          "&.bold": {
            fontSize: "12px",
            fontWeight: "700",
          },
          "&.bold14": {
            fontSize: "14px",
            fontWeight: "700",
          },
          "&.small": {
            fontSize: "10px",
          },
          "&.tourCheckbox": {
            display: "flex",
            alignItems: "center",
            justifyContent: "end",
            fontSize: "12px",
            fontWeight: "600",
          },
        },
      },
    },
    MuiInputBase: {
      styleOverrides: {
        root: {
          fontFamily: "poppins",
          "&.OTP": {
            width: "35px",
            height: "35px",
            margin: "5px",
            border: "1px solid",
            borderRadius: "4px",
            "&.base": {
              borderColor: "#c9cacb",
              backgroundColor: "#ffffff",
            },
            "&.success": {
              borderColor: "#95c69d",
              backgroundColor: "#e3ece5",
            },
            "&.error": {
              borderColor: "#D77C89",
              backgroundColor: "#EFDFE1",
            },
          },
          "&.experienceTextArea": {
            "&.bold": {
              fontWeight: "700",
            },
            "&.italic": {
              fontStyle: "italic",
            },
          },
          "&.InputField": { fontSize: "12px" },
        },
      },
    },
    MuiAutocomplete: {
      styleOverrides: {
        listbox: {
          "& .MuiAutocomplete-option": {
            fontFamily: "Poppins", // Your desired font
          },
          fontFamily: "Poppins", // Set your desired font
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          fontFamily: "poppins",
          "&.ROOT": {
            cursor: "pointer",
            boxShadow: "none",
            textTransform: "none",
            fontSize: "14px",
            fontWeight: "400",
            // gap: "8px",
            borderRadius: "6px",
            "&.disable": {
              color: "#939597",
              backgroundColor: "#edf1f4",
              border: "2px solid  #edf1f4",
            },
            "&.primary": {
              color: "white",
              backgroundColor: "#2A62AA",
              "&:hover": {
                color: "#2A62AA",
                backgroundColor: "#EDF1F4",
                border: `2px solid #EDF1F4`,
                boxShadow: "none",
              },

              border: `2px solid #fff`,
              "&:active": {
                border: `2px solid #2A62AA`,
                backgroundColor: "#fff",
                boxShadow: "none",
              },
            },
            "&.secondary": {
              color: "#2A62AA",
              backgroundColor: "#E7EEF3",
              border: "2px solid  #E7EEF3",
              "&:hover": {
                border: "2px solid  #2A62AA",
              },
              "&:active": {
                color: "#fff",
                backgroundColor: "#2A62AA",
                border: "2px solid  #2A62AA",
              },
            },
          },
          "&.ROOT1": {
            cursor: "pointer",
            boxShadow: "none",
            textTransform: "none",
            fontSize: "14px",
            fontWeight: "400",
            // gap: "8px",
            borderRadius: "6px",
            "&.disable": {
              color: "#939597",
              backgroundColor: "#F2F2F2",
              border: "2px solid  #F2F2F2",
            },
            "&.primary": {
              color: "white",
              backgroundColor: "#3F3F40",
              "&:hover": {
                color: "#3F3F40",
                backgroundColor: "#F2F2F2",
                border: `2px solid #F2F2F2`,
                boxShadow: "none",
              },

              border: `2px solid #fff`,
              "&:active": {
                border: `2px solid #3F3F40`,
                backgroundColor: "#FFFFFF",
                boxShadow: "none",
              },
            },
            "&.secondary": {
              color: "#3F3F40",
              backgroundColor: "#E5E5E5",
              border: "2px solid  #E5E5E5",
              "&:hover": {
                border: "2px solid  #3F3F40",
              },
              "&:active": {
                color: "#fff",
                backgroundColor: "#3F3F40",
                border: "2px solid  #3F3F40",
              },
            },
          },
          "&.tourModal": {
            textTransform: "none",
            fontWeight: "700",
          },
          "&.tourModalButtonSmall": {
            textTransform: "none",
            fontWeight: "300",
            fontSize: "12px",
            cursor: "pointer",
            color: "#2A62AA",
          },
          "&.addExperience": {
            backgroundColor: "#fff",
            textTransform: "none",
            color: "#3F3F40",
            fontWeight: 400,
            fontSize: "14px",
            boxShadow: "none",
            border: "1px solid #fff",
            "&:hover": {
              border: "1px solid #2A62AA",
              backgroundColor: "#fff",
              boxShadow: "none",
            },
            "&.active": { backgroundColor: "#2A62AA" },
            "&.disable": {
              color: "#939597",
              backgroundColor: "#EDF1F4",
              border: "2px solid  #EDF1F4",
            },
          },
        },
      },
    },
    MuiIconButton: {
      styleOverrides: {
        root: {
          "&.ROOT": {
            cursor: "pointer",
            "&.disable": {
              color: "#939597",
              backgroundColor: "#edf1f4",
              border: "2px solid  #edf1f4",
            },
            "&.secondary": {
              color: "#2A62AA",
              backgroundColor: "#E7EEF3",
              border: "2px solid  #E7EEF3",
              "&:hover": { border: "2px solid  #2A62AA" },
              "&:active": {
                color: "#fff",
                backgroundColor: "#2A62AA",
                border: "2px solid  #2A62AA",
              },
            },
            "&.primary": {
              color: "#E7EEF3",
              backgroundColor: "#2A62AA",
              border: "2px solid  #2A62AA",
              "&:hover": {
                color: "#2A62AA",
                border: "2px solid  #2A62AA",
                backgroundColor: "#E7EEF3",
              },
              "&:active": {
                color: "#2A62AA",
                backgroundColor: "#fff",
                border: "2px solid  #2A62AA",
              },
            },
          },
          "&.verifyNav": {
            backgroundColor: "#EF5C00",
            "&:hover": { backgroundColor: "#EF5C00" },
            width: 50,
            height: 50,
            color: "white",
            fontSize: "25px",
            cursor: "pointer",
          },
          "&.getting": {
            backgroundColor: "transparent",
            "&:hover": { backgroundColor: "transparent" },
            width: 50,
            height: 50,
            color: "#3F3F40",
            fontSize: "25px",
          },
          "&.getCertified": {
            backgroundColor: "transparent",
            "&:hover": { backgroundColor: "transparent" },
            width: 12,
            height: 12,
            color: "#2A62AA",
            borderColor: "#2A62AA",
            border: "1px solid",
            fontSize: "25px",
          },
          "&.right": {
            backgroundColor: "transparent",
            "&:hover": { backgroundColor: "transparent" },
            width: 10,
            height: 10,
            fontSize: "10px",
          },
          "&.Certify": {
            fontSize: "12px",
          },
          "&.sidebar-downArrrow": {
            color: "#CAD8EA",
            width: 20,
            height: 20,
            margin: "-5px 0 0 0 ",
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          "&.tourModalCard": {
            backgroundColor: "#EDF1F4",
            height: "100%",
            width: "100%",
          },
          "&.sidebar-classroom": {
            padding: "15px",
            borderRadius: "7px",
            margin: "3px 5px",
            "&.background-blue": {
              backgroundColor: "#2A62AA",
            },
            "&.background-white": {
              backgroundColor: "#E5EDF3",
            },
          },
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          "&.tourModalPaper": {
            borderRadius: 5,
            border: "none",
            backgroundColor: "#ffffff",
            maxHeight: "auto",
            maxWidth: 280,
            position: "absolute",
            padding: "10px",
            "&.minus": {
              display: "none",
            },
            "&.zero": {
              right: 35,
              bottom: 50,
            },
            "&.one": {
              left: 100,
              top: 75,
            },
            "&.two": {
              left: 100,
              top: 150,
            },
            "&.three": {
              left: 100,
              top: 220,
            },
            "&.four": {
              left: 100,
              top: 288,
            },
            "&.five": {
              left: 100,
              top: 360,
            },
            "&.six": {
              left: 100,
              top: 435,
            },
          },
        },
      },
    },
    //-------------------------------MuiGrid
    MuiGrid: {
      styleOverrides: {
        root: {
          "&.flexColumn": {
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            paddingTop: 64,
            backgroundColor: "#E5EDF3",
            minHeight: "100vh",
          },

          "&.Drawer": {
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            padding: 8,
            color: "#919599",
            overflow: "hidden",
            maxWidth: 80,
            minWidth: 80,
            minHeight: 72,
            cursor: "pointer",
            marginTop: 8,
            "&.focus": {
              borderLeft: "4px solid #2A62AA",
              borderRadius: "1px 0 0 1px",
              marginLeft: 1,
              color: "#2A62AA",
            },
            "&.hover": {
              "&:hover": { backgroundColor: "#ffffff" },
            },
            "&.tourHover": {
              backgroundColor: "#ffffff",
            },
          },
        },
      },
    },
    //------------------------------MuiIcon
    MuiIcon: {
      styleOverrides: {
        root: {
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          "&.blue": { color: "#2A62AA" },
        },
      },
    },
    //----------------------------MuiAvatar
    MuiAvatar: {
      styleOverrides: {
        root: {
          cursor: "pointer",
          "&.BarAvatar": {
            width: 38,
            height: 38,
          },
        },
      },
    },
    //MuiToolbar
    MuiToolbar: {
      styleOverrides: {
        root: {
          backgroundColor: "#e5edf3",
          width: "99%",
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          padding: "0 50px",
        },
      },
    },
    //MuiAppBar
    MuiAppBar: {
      styleOverrides: {
        root: {
          zIndex: 9999,
          boxShadow: "none",
          backgroundColor: "#e5edf3",
        },
      },
    },
    //MuiDivider
    MuiDivider: {
      styleOverrides: {
        root: {
          "&.tourModal": {
            width: "100%",
            border: "1px solid #ffffff",
          },
          "&.Vertical": {
            borderRightWidth: 0.5,
            height: "25px",
            marginRight: "15px",
            marginLeft: "10px",
            borderColor: "#919599",
            textOrientation: "vertical",
          },
          "&.tab": {
            borderRightWidth: 0.5,
            height: "25px",
            marginLeft: "auto",
            borderColor: "#2A62AA",
            textOrientation: "vertical",
          },
        },
      },
    },
    MuiDrawer: {
      styleOverrides: {
        root: {
          "&.Side": {
            zIndex: 10,
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          width: "100%",
        },
        select: {
          height: "50px",
          minHeight: "50px",
          backgroundColor: "white",
          borderRadius: "7px",
          border: "1px solid #939597",
          padding: "0 10px",
          alignContent: "center",
          fontSize: "16px",
        },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: {
          fontFamily: "poppins",
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: {
          fontFamily: "poppins",
        },
      },
    },
  },
});
