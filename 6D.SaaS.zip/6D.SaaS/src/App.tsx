import { ThemeProvider } from "@mui/material";
import { Theme } from "./Theme";
import MyRoutes from "./Routes";

function App() {
  return (
    <ThemeProvider theme={Theme}>
      <MyRoutes />
    </ThemeProvider>
  );
}

export default App;
