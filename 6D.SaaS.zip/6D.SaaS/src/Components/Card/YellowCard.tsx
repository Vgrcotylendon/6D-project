import { Box, Card, Grid, Typography } from "@mui/material";
import Girl from "../../Assets/girlImage.jpg";
import Carousel1 from "../../Assets/CaroselImage1.png";
import Carousel2 from "../../Assets/CaroselImage2.png";
import React, { useState, useEffect } from "react";
import YellowCardSkeleton from "../Skeleton/YellowCardSkeleton";

export default function YellowCard() {
  const [loaded, setLoaded] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const images = [Girl, Carousel1, Carousel2];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [images.length]);

  return (
    <>
      <Grid>
        <Card
          elevation={0}
          sx={{
            borderRadius: 2,
            padding: "none",
            overflowY: "hidden",
            maxHeight: "100%",
            height: 560,
            position: "relative",
          }}
        >
          {!loaded && <YellowCardSkeleton />}
          <img
            src={images[currentImageIndex]}
            loading="lazy"
            alt="slider"
            style={{
              width: "100%",
              transform: " translate(-2px,120px) scale(1.8)",
            }}
            onLoad={() => setLoaded(true)}
            onError={() => setLoaded(true)}
          />
          {loaded && (
            <>
              <Box
                sx={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  background:
                    "linear-gradient(0deg, rgb(0,0,0,0.8) 0%, rgb(0,0,0,0.2) 70%,rgb(255,255,255,0.1) 100%)",
                  zIndex: 10,
                }}
              />
              <Box
                sx={{
                  position: "absolute",
                  bottom: -35,
                  left: 0,
                  zIndex: 11,
                }}
              >
                <Box sx={{ p: 6, pb: 10 }}>
                  <Typography
                    color={"secondary"}
                    sx={{ fontWeight: "700", fontSize: "75px" }}
                  >
                    get
                  </Typography>
                  <Typography
                    color={"secondary"}
                    sx={{ fontWeight: "250", fontSize: "20px", ml: 9, mt: -3 }}
                  >
                    TRAINED <br />
                    CERTIFIED <br />
                    PLACED
                  </Typography>
                  <Typography
                    color={"secondary"}
                    sx={{ fontWeight: "400", fontSize: "10px", mt: 4 }}
                  >
                    Master the Skills that matter, earn industry-recognized
                    certifications, and step in to your dream career with 6D
                    Learning.
                  </Typography>
                  <br />
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      width: 90,
                      mt: 1,
                    }}
                  >
                    {images.map((_, index) => (
                      <Typography
                        key={index}
                        className={
                          index === currentImageIndex
                            ? "span white"
                            : "span grey"
                        }
                        sx={{
                          height: 10,
                          width: 10,
                          borderRadius: "50%",
                          backgroundColor:
                            index === currentImageIndex ? "white" : "grey",
                        }}
                      />
                    ))}
                  </Box>
                </Box>
              </Box>
            </>
          )}
        </Card>
      </Grid>
    </>
  );
}
