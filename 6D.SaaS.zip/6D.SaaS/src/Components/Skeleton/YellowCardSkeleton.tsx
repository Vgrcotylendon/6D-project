import { Skeleton } from "@mui/material";
import React from "react";

const YellowCardSkeleton = () => {
  return (
    <Skeleton
      variant="rectangular"
      animation="wave"
      sx={{
        borderRadius: 2,
        height: '100%',
      }}
    />
  );
};

export default YellowCardSkeleton;
