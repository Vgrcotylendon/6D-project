import React, { useRef, useState } from "react";
import Slider from "react-slick";
import ArrowCircleUpIcon from "@mui/icons-material/ArrowCircleUp";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

interface CarouselProps {
  children: React.ReactNode[];
  slidesToShow: number;
  slidesToScroll: number;
}

const SlickCarousel: React.FC<CarouselProps> = ({
  children,
  slidesToShow,
  slidesToScroll,
}) => {
  const sliderRef = useRef<Slider>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const settings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: slidesToShow,
    slidesToScroll: slidesToScroll,
    nextArrow: (
      <ArrowCircleUpIcon
        sx={{
          color:
            currentSlide === children.length - slidesToShow
              ? "#ccc"
              : "#666666",
          transform: "rotate(90deg)",
          mr: -5,
          "&:hover": {
            color:
              currentSlide === children.length - slidesToShow
                ? "#ccc"
                : "#666666",
          },
          cursor:
            currentSlide === children.length - slidesToShow
              ? "not-allowed"
              : "pointer",
        }}
        onClick={() => {
          if (currentSlide < children.length - slidesToShow) {
            sliderRef.current?.slickNext();
          }
        }}
      />
    ),
    prevArrow: (
      <ArrowCircleUpIcon
        sx={{
          color: currentSlide === 0 ? "#ccc" : "#666666",
          transform: "rotate(-90deg)",
          ml: -5,
          "&:hover": { color: currentSlide === 0 ? "#ccc" : "#666666" },
          cursor: currentSlide === 0 ? "not-allowed" : "pointer",
        }}
        onClick={() => {
          if (currentSlide > 0) {
            sliderRef.current?.slickPrev();
          }
        }}
      />
    ),
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: false,
          dots: false,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          initialSlide: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
    beforeChange: (oldIndex: number, newIndex: number) => {
      setCurrentSlide(newIndex);
    },
  };
  return (
    <>
      <Slider {...settings}>
        {React.Children.map(children, (child, index) => (
          <div key={index} style={{ padding: "0 10px" }}>
            {child}
          </div>
        ))}
      </Slider>
    </>
  );
};

export default SlickCarousel;
