import { IconButton } from "@mui/material";
import React from "react";
import clsx from "clsx";

type CustomIconButtonProps = {
  onClick?: () => void;
  icon: React.ElementType;
  width?: number;
  height?: number;
  iconSize?:number;
  padding?:string|number;
  style?: any;
  variant?: string;
  disable?: boolean;
};

const CustomIconButton: React.FC<CustomIconButtonProps> = ({
  icon: IconComponent,
  onClick,
  width,
  height,
  iconSize,
  style,
  padding,
  variant,
  disable,
}) => {
  return (
    <IconButton
      className={clsx("ROOT", {
        disable,
        primary: !disable && variant === "primary",
        secondary: !disable && variant === "secondary",
      })}
      onClick={onClick}
      disabled={disable}
      sx={{
        ...style,
        width: width ?? 8,
        height: height ?? 8,
        borderRadius: 1,
        padding: padding ?? 2.5,
      }}
    >
      <IconComponent sx={{
          fontSize: iconSize ?? Math.min(width ?? 40, height ?? 40) / 2,
        }}
/>
    </IconButton>
  );
};

export default CustomIconButton;
