import { Button, CircularProgress } from "@mui/material";
import React from "react";
import clsx from "clsx";

type CustomButtonProps = {
  name: string;
  onClick?: () => void;
  disabled?: boolean;
  variant?:string;
  style?: any;
  loading?: boolean;
  endIcon?:any;
  startIcon?:any;
  padding?: string | number;
};
const CustomButton1: React.FC<CustomButtonProps> = ({
  name,
  onClick,
  disabled,
  loading,
  padding,
  variant,
  style,
  endIcon,
  startIcon
}) => {

  return (
    <Button
      variant="contained"
      className={clsx("ROOT1", {
        disable:disabled,
        primary: !disabled && variant === "primary",
        secondary: !disabled && variant === "secondary",
      })}
      onClick={onClick}
      sx={{
        ...style,
        padding: padding ?? "10px 46px",
      }}
      disabled={disabled}
      endIcon={endIcon}
      startIcon={startIcon}
    >
      {name}&nbsp;
      {loading && (
        <CircularProgress
          color="secondary"
          sx={{
            "&:hover": {
              color: "#2A62AA",
              bgcolor: "#EDF1F4",
              border: `2px solid #EDF1F4`,
              boxShadow: "none",
            },
          }}
          size={12}
          thickness={5}
        />
      )}
    </Button>
  );
};

export default CustomButton1;
