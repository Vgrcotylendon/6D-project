import { Drawer, Grid, Icon, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import clsx from "clsx";
import { useLocation, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { DrawerList } from "../../Data";

interface StateType {
  tour: {
    value: number;
    previousPage: string;
  };
}

export default function Drawers() {
  const navigate = useNavigate();
  const location = useLocation();
  const path = location.pathname;
  const Tour = useSelector((state: StateType) => state.tour.value);
  const LastViewed = useSelector((state: StateType) => state.tour.previousPage);

  const [value, setValue] = useState(Tour);
  const [isHovered, setIsHovered] = useState<number | boolean>(false);

  const handleMouseEnter = (index: number) => {
    setIsHovered(index);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  const handleChange = (navigatePath: string) => {
    navigate(navigatePath);
  };
  useEffect(() => {
    setValue(Tour - 1);
  }, [Tour]);

  return (
    <>
      <Drawer variant="permanent" className="Side">
        <Grid container className="flexColumn">
          {DrawerList.map((i, index) => (
            <Grid
              key={index}
              item
              className={clsx("Drawer", {
                focus: path === i.navigate,
                hover: path !== i.navigate,
                tourHover:
                  path === "/landing/activity" &&
                  LastViewed === "/signup" &&
                  value === index,
              })}
              onMouseEnter={() => handleMouseEnter(index)}
              onMouseLeave={handleMouseLeave}
              onClick={() => handleChange(i.navigate)}
            >
              <Icon>
                <i.icon
                  color={
                    path === i.navigate ||
                    isHovered === index ||
                    (path === "/landing/activity" &&
                      LastViewed === "/signup" &&
                      value === index)
                      ? "info"
                      : "action"
                  }
                  sx={{ fontSize: "24px" }}
                />
              </Icon>
              <Typography
                variant="body1"
                className={clsx({
                  drawer: path === i.navigate || path !== i.navigate, 
                  drawerHoverColor:
                    (path !== i.navigate && isHovered === index) ||
                    (path === "/landing/activity" &&
                      LastViewed === "/signup" &&
                      value === index),
                })}
              >
                {i.name}
              </Typography>
            </Grid>
          ))}
        </Grid>
      </Drawer>
    </>
  );
}
