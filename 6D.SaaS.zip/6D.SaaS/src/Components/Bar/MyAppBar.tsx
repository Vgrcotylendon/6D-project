import { AppBar, Box, Divider, Toolbar, Typography } from "@mui/material";
import React from "react";
import styled from "styled-components";
import { useLocation, useNavigate } from "react-router-dom";
import Profile from "./Profile";
import SearchField from "../Input/SearchField";
import Logo from "../../Assets/Logo6D.png";

export default function MyAppBar() {
  const location = useLocation();
  const navigate = useNavigate();
  const shouldShowSearchAndProfile =
    location.pathname !== "/" &&
    location.pathname !== "/signin" &&
    location.pathname !== "/signup";
  return (
    <AppBar>
      <Toolbar sx={{height:"72px"}}>
        <NavBox>
          {/* <Typography className="Nav6D">6D</Typography> */}
          <img
            src={Logo}
            alt="6D Logo"
            width="48px"
            height="40px"
            onClick={() => 
              shouldShowSearchAndProfile ?
              navigate("/landing/activity")
              :navigate("/")}
            style={{ cursor: "pointer" }}
          />
          <Divider className="Vertical" />
          <Typography className="NavTP">Learning</Typography>
        </NavBox>
        {shouldShowSearchAndProfile && (
          <>
            <SearchField />
            <Profile />
          </>
        )}
      </Toolbar>
    </AppBar>
  );
}
const NavBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100px;
  /* margin: 0 0 0 px; */
`;
