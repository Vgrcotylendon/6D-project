import {
  Avatar,
  Badge,
  Box,
  Button,
  Divider,
  IconButton,
  Typography,
} from "@mui/material";
import React from "react";
import LogoutIcon from "@mui/icons-material/Logout";
// import avatarImage from "../../Assets/avatarImage.png";
import styled from "styled-components";
import Popover from "@mui/material/Popover";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import WorkIcon from "@mui/icons-material/Work";
import WorkspacePremiumOutlinedIcon from "@mui/icons-material/WorkspacePremiumOutlined";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import OrangeDot from "../../Assets/orangeDot.png";
import CustomIconButton from "../Button/CustomIconButton";
import { useDispatch, useSelector } from "react-redux";
import { RootState, StartSignOut } from "../../Store/UserSlice";
import { instance, cookies } from "../../Controller/Common";
import { useNavigate } from "react-router-dom";

const NavBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 230px;
  margin-right: 20px;
`;
const CustomBox = styled(Box)`
  display: flex;
  align-items: center;
  gap: 5px;
`;
const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  padding: 15px;
`;
const TitleBox = styled(Box)`
  display: flex;
  justify-content: flex-end;
  padding: 10px 0 10px 10px;
`;
const ColorBox = styled(Box)`
  display: flex;
  flex-direction: row;
  background-color: #f0f0f0;
  border-radius: 5px;
  padding: 10px;
`;
const IconBox = styled(Box)`
  display: flex;
  padding: 15px;
  justify-content: center;
  border-radius: 5px;
  background-color: #cee6f0;
`;
const InfoBox = styled(Box)`
  display: flex;
  flex-direction: row;
  width: 25rem;
  justify-content: space-between;
  padding: 5px 5px 5px 10px;
`;
const NotifyBox = styled(Box)`
  display: flex;
  flex-direction: column;
`;
export default function Profile() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(
    null
  );

  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    if (!anchorEl) {
      setAnchorEl(event.currentTarget);
    } else {
      handleClose();
    }
  };
  const SignOut = async () => {
    try {
      const response = await instance.post("/6D/auth/signout");
      if (response.status === 200) {
        cookies.remove("token");
        cookies.remove("refreshToken");
        cookies.remove("temp");
        navigate("/signin");
        dispatch(StartSignOut());
      }
    } catch (error) {
      console.error(error);
    }
  };

  const open = Boolean(anchorEl);
  const id = open ? "simple-popover" : undefined;
  const Profile = useSelector((state: RootState) => state.user.profile);
  const userName = useSelector((state: RootState) => state.user.userName);
  return (
    <NavBox>
      <CustomBox>
        <Badge
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "right",
          }}
          badgeContent=" "
          overlap="circular"
          color="success"
          sx={{
            "& .MuiBadge-badge": {
              width: 10, // Adjust the width
              height: 10, // Adjust the height
              minWidth: 10, // Ensure it doesn't stretch
              minHeight: 10, // Ensure it doesn't stretch
              borderRadius: "50%", // Keep it circular
            },
          }}
        >
          <Avatar src={`${Profile}`} className="BarAvatar" />
        </Badge>
        <Typography className="BarProfile">{userName}</Typography>
      </CustomBox>

      <IconButton aria-describedby={id} onClick={handleClick}>
        <Badge color="error" overlap="circular" badgeContent={3}>
          <NotificationsNoneIcon color="info" width="24px" height="24px" />
        </Badge>
      </IconButton>

      <Popover
        sx={{ zIndex: 11000 }}
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
      >
        <MainBox>
          <TitleBox>
            <Button sx={{ textTransform: "none", color: "black" }}>
              Mark All Read
            </Button>
          </TitleBox>
          <ColorBox>
            <IconBox>
              <WorkIcon sx={{ color: "info.main", fontSize: "40px" }} />
            </IconBox>
            <NotifyBox>
              <InfoBox>
                <Typography sx={{ fontWeight: "bold" }}>New Job</Typography>
                <Typography sx={{ fontSize: "12px", color: " #969595" }}>
                  2 days ago
                </Typography>
              </InfoBox>
              <InfoBox>
                <Typography sx={{ fontSize: "14px", color: " #0f0e0e" }}>
                  SBC posted a new job. check it out.
                </Typography>
                <img src={OrangeDot} alt="icon" width={20} height={20} />
              </InfoBox>
            </NotifyBox>
          </ColorBox>
          <Divider sx={{ marginTop: "8px", marginBottom: "8px" }} />
          <ColorBox>
            <IconBox>
              <WorkspacePremiumOutlinedIcon
                sx={{ color: "info.main", fontSize: "40px" }}
              />
            </IconBox>
            <NotifyBox>
              <InfoBox>
                <Typography sx={{ fontWeight: "bold" }}>New Course</Typography>
                <Typography sx={{ fontSize: "12px", color: " #969595" }}>
                  4 hrs ago
                </Typography>
              </InfoBox>
              <InfoBox>
                <Typography sx={{ fontSize: "14px", color: " #0f0e0e" }}>
                  SBC added new course. check it out.
                </Typography>
                <img src={OrangeDot} alt="icon" width={20} height={20} />
              </InfoBox>
            </NotifyBox>
          </ColorBox>
          <Divider sx={{ marginTop: "8px", marginBottom: "8px" }} />
          <ColorBox>
            <IconBox>
              <AccountCircleIcon
                sx={{ color: "info.main", fontSize: "40px" }}
              />
            </IconBox>
            <NotifyBox>
              <InfoBox>
                <Typography sx={{ fontWeight: "bold" }}>
                  Complete Profile
                </Typography>
                <Typography sx={{ fontSize: "12px", color: " #969595" }}>
                  2 days ago
                </Typography>
              </InfoBox>
              <InfoBox>
                <Typography sx={{ fontSize: "14px", color: " #0f0e0e" }}>
                  Complete your profile to get full access.
                </Typography>
                <img src={OrangeDot} alt="icon" width={20} height={20} />
              </InfoBox>
            </NotifyBox>
          </ColorBox>
        </MainBox>
      </Popover>
      <CustomIconButton
        variant="secondary"
        icon={LogoutIcon}
        iconSize={25}
        onClick={() => SignOut()}
      />
    </NavBox>
  );
}
