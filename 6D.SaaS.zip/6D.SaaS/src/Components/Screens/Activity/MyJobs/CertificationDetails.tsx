import {
  Box,
  Card,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import React from "react";
import styled from "styled-components";
import TimelapseIcon from "@mui/icons-material/Timelapse";
import VerifiedIcon from "@mui/icons-material/Verified";

interface Certification {
  courseName: string;
  attempt: number;
  submissionDate: string;
  Action: string;
  status: string;
  progress: number;
  Modules: {
    pendingModule: number | null;
    timeToComplete: number | null;
    completeModule: number | null;
    timeSpent: number | null;
  };
  Exercises: {
    pendingExercise: number | null;
    timeToComplete: number | null;
    completeExercise: number | null;
    timeSpent: number | null;
  };
}

interface CertificationProps {
  data: Certification[];
}

const CertificationDetails: React.FC<CertificationProps> = ({ data }) => {
  return (
    <MainBox>
      <MainCard>
        <TextBox>
          <Typography className="Activity">
            6DAP-001SC-Application Status:
          </Typography>
          <Typography sx={{ color: "green" }}>InProgress</Typography>
        </TextBox>
        <TableBox>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <StyledTableCell>Certificate Title</StyledTableCell>
                  <StyledTableCell>Certification Status</StyledTableCell>
                  <StyledTableCell>Attempt</StyledTableCell>
                  <StyledTableCell>Submission Date</StyledTableCell>
                  <StyledTableCell>Action</StyledTableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.map((item: Certification, index: number) => (
                  <TableRow key={index}>
                    <TableCell sx={{ borderColor: "#eceaea" }}>
                      {item.courseName}
                    </TableCell>
                    <TableCell align="center" sx={{ borderColor: "#eceaea" }}>
                      {(item.status === "Certified" && (
                        <IconButton
                          className="Certify"
                          sx={{ color: "#48A055" }}
                        >
                          <VerifiedIcon sx={{ width: 16 }} /> &nbsp;
                          {item.status}
                        </IconButton>
                      )) ||
                        (item.status === "InProgress" && (
                          <IconButton
                            className="Certify"
                            sx={{ color: "#ef5c00" }}
                          >
                            <TimelapseIcon sx={{ width: 16 }} /> &nbsp;{" "}
                            {item.status}
                          </IconButton>
                        ))}
                    </TableCell>
                    <TableCell align="center" sx={{ borderColor: "#eceaea" }}>
                      {item.attempt}
                    </TableCell>
                    <TableCell align="center" sx={{ borderColor: "#eceaea" }}>
                      {item.submissionDate}
                    </TableCell>
                    <TableCell
                      align="center"
                      sx={{ borderColor: "#eceaea", color: "blue" }}
                    >
                      {item.Action}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </TableBox>
      </MainCard>
    </MainBox>
  );
};

export default CertificationDetails;

const MainBox = styled(Box)`
  display: flex;
  width: 100%;
  border: 2px solid white;
  border-radius: 3px;
  padding: 15px;
  border-color: 2px Solid;
`;

const MainCard = styled(Card)`
  box-shadow: none !important;
  display: flex;
  width: 100%;
  flex-direction: column;
  padding: 40px 20px 20px 20px;
`;

const TextBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
`;

const TableBox = styled(Box)`
  display: flex;
  padding: 0 20px 20px 20px;
`;
const StyledTableCell = styled(TableCell)`
  background-color: #f5f5f5;
  border: none;
  font-weight: 700;
  font-size: 16px;
`;
