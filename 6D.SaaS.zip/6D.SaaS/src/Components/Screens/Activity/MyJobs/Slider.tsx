import React from "react";
import {
  Box,
  Typography,
  Grid,
  Card,
  Divider,
  IconButton,
  LinearProgress,
} from "@mui/material";
import styled from "styled-components";
import TimelapseIcon from "@mui/icons-material/Timelapse";
import VerifiedIcon from "@mui/icons-material/Verified";
import SlickCarousel from "../../../SlickCarousel";

interface Certification {
  courseName: string;
  attempt: number;
  submissionDate: string;
  Action: string;
  status: string;
  progress: number;
  Modules: {
    pendingModule: number | null;
    timeToComplete: number | null;
    completeModule: number | null;
    timeSpent: number | null;
  };
  Exercises: {
    pendingExercise: number | null;
    timeToComplete: number | null;
    completeExercise: number | null;
    timeSpent: number | null;
  };
}

interface CertificationProps {
  data: Certification[];
}

const SliderCard: React.FC<CertificationProps> = ({ data }) => {
  return (
    <>
      <MainBox>
        <SubBox>
          <SlickCarousel slidesToShow={2} slidesToScroll={1}>
            {data.map((i, j) => (
              <InprogressBox key={j}>
                <Box>
                  <Typography className="Activity">{i.courseName}</Typography>
                  <ProgressCard>
                    {(i.status === "Certified" && (
                      <IconButton className="Certify" sx={{ color: "#48A055" }}>
                        <VerifiedIcon sx={{ width: 16 }} /> &nbsp;
                        {i.status}
                      </IconButton>
                    )) ||
                      (i.status === "InProgress" && (
                        <IconButton
                          className="Certify"
                          sx={{ color: "#ef5c00" }}
                        >
                          <TimelapseIcon sx={{ width: 16 }} /> &nbsp; {i.status}
                        </IconButton>
                      ))}
                    <CustomLinear
                      variant="determinate"
                      color="secondary"
                      value={i.progress}
                      sx={{
                        "& .MuiLinearProgress-bar": {
                          backgroundColor:
                            i.progress === 100 ? "#48bf19" : "#ef5c00",
                        },
                      }}
                    />
                    &nbsp;
                    <Typography className="progress">{i.progress}%</Typography>
                  </ProgressCard>
                  <ChildBox>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={6} md={6}>
                        <Typography sx={{ marginBottom: "5px" }}>
                          Modules
                        </Typography>
                        <MainCard>
                          <CardBox>
                            <CompleteBox>
                              <Typography
                                sx={{
                                  color:
                                    i.Modules.completeModule === null
                                      ? "#ef5c00"
                                      : "green",
                                  fontSize: "25px",
                                }}
                              >
                                {i.Modules.completeModule === null
                                  ? i.Modules.pendingModule
                                  : i.Modules.completeModule}
                              </Typography>
                              <Typography
                                sx={{ fontSize: "14px", color: "#646362" }}
                              >
                                {i.Modules.completeModule === null
                                  ? "Pending Modules"
                                  : "Completed Modules"}
                              </Typography>
                            </CompleteBox>
                            <Divider sx={{ background: "green" }} />
                            <TimeBox>
                              <Typography
                                sx={{
                                  color: "#A41DF7",
                                  fontSize: "25px",
                                }}
                              >
                                {i.Modules.timeToComplete === null
                                  ? i.Modules.timeSpent
                                  : i.Modules.timeToComplete}
                              </Typography>
                              <Typography
                                sx={{ fontSize: "14px", color: "#646362" }}
                              >
                                {i.Modules.timeToComplete === null
                                  ? "Total Time Spent(min)"
                                  : "Time to Complete(min)"}
                              </Typography>
                            </TimeBox>
                            <CustomDivider />
                          </CardBox>
                        </MainCard>
                      </Grid>
                      <Grid item xs={12} sm={6} md={6}>
                        <CertifiedBox>
                          <Typography sx={{ marginBottom: "5px" }}>
                            Exercise
                          </Typography>
                          <CertifiedCard>
                            <CardBox>
                              <CompleteBox>
                                <Typography
                                  sx={{
                                    color:
                                      i.Exercises.pendingExercise === null
                                        ? "green"
                                        : "#ef5c00",
                                    fontSize: "25px",
                                  }}
                                >
                                  {i.Exercises.pendingExercise === null
                                    ? i.Exercises.completeExercise
                                    : i.Exercises.pendingExercise}
                                </Typography>
                                <Typography
                                  sx={{ fontSize: "14px", color: "#646362" }}
                                >
                                  {i.Exercises.pendingExercise === null
                                    ? "Completed Exercises"
                                    : "Pending Exercises"}
                                </Typography>
                              </CompleteBox>
                              <Divider sx={{ background: "green" }} />
                              <TimeBox>
                                <Typography
                                  sx={{
                                    color: "#A41DF7",
                                    fontSize: "25px",
                                  }}
                                >
                                  {i.Exercises.timeToComplete === null
                                    ? i.Exercises.timeSpent
                                    : i.Exercises.timeToComplete}
                                </Typography>
                                <Typography
                                  sx={{ fontSize: "14px", color: "#646362" }}
                                >
                                  {i.Exercises.timeToComplete === null
                                    ? "Time Spent(min)"
                                    : "Time to Complete(min)"}
                                </Typography>
                              </TimeBox>
                              <CustomDivider />
                            </CardBox>
                          </CertifiedCard>
                        </CertifiedBox>
                      </Grid>
                    </Grid>
                  </ChildBox>
                </Box>
              </InprogressBox>
            ))}
          </SlickCarousel>
        </SubBox>
      </MainBox>
    </>
  );
};

export default SliderCard;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  margin-top: 3rem;
  margin-bottom: 2rem;
`;
const SubBox = styled(Box)`
  display: flex;
  width: 100%;
  border: 2px solid white;
  border-radius: 3px;
  padding: 8px;
  flex-direction: column;
`;

const InprogressBox = styled(Box)`
  margin: 15px;
  /* min-width: 550px; */
  width: 90%;
  border: 2px solid white;
  border-radius: 7px;
  padding: 10px;
  margin-top: 10px;
`;

const ChildBox = styled(Box)`
  display: flex;
  flex-direction: row;
  width: 100%;
  margin-top: 15px;
`;

const MainCard = styled(Card)`
  box-shadow: none !important;
  padding: 16px;
  border-radius: 3px;
`;

const CardBox = styled(Box)`
  display: flex;
  flex-direction: column;
`;

const CompleteBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 8px;
  justify-content: space-between;
`;

const TimeBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 5px;
  justify-content: space-between;
`;

const CustomDivider = styled(Divider)`
  background: #a41df7;
  margin-top: 5px;
`;

const CertifiedBox = styled(Box)`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const CertifiedCard = styled(Card)`
  box-shadow: none !important;
  padding: 16px;
  border-radius: 3px;
`;

const ProgressCard = styled(Card)`
  box-shadow: none !important;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-evenly;
  padding: 8px;
  border-radius: 3px;
`;

const CustomLinear = styled(LinearProgress)`
  padding: 2px;
  width: 100%;
  margin: 5px;
  border-radius: 7px;
  margin-left: 10px;
  /* & .MuiLinearProgress-bar {
    background-color: #ef5c00;
  } */
`;
