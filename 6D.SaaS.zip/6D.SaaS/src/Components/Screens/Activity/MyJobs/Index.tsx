import { Box, Container } from "@mui/material";
import React from "react";
import styled from "styled-components";
import CertificationDetails from "./CertificationDetails";
import SliderCard from "./Slider";

interface Certification {
  courseName: string;
  attempt: number;
  submissionDate: string;
  Action: string;
  status: string;
  progress: number;
  Modules: {
    pendingModule: number | null;
    timeToComplete: number | null;
    completeModule: number | null;
    timeSpent: number | null;
  };
  Exercises: {
    pendingExercise: number | null;
    timeToComplete: number | null;
    completeExercise: number | null;
    timeSpent: number | null;
  };
}

const MyJobs: React.FC = () => {
  const List: Certification[] = [
    {
      courseName: "6DLVI-001 Leadership and Initiative",
      attempt: 1,
      submissionDate: "15/5/2024",
      Action: "-",
      status: "Certified",
      progress: 100,
      Modules: {
        pendingModule: null,
        timeToComplete: null,
        completeModule: 4,
        timeSpent: 140,
      },
      Exercises: {
        pendingExercise: null,
        timeToComplete: null,
        completeExercise: 12,
        timeSpent: 80,
      },
    },
    {
      courseName: "6DLVI-003 Digital Literacy",
      attempt: 2,
      submissionDate: "01/5/2024",
      Action: "Resume",
      status: "InProgress",
      progress: 60,
      Modules: {
        pendingModule: 4,
        timeToComplete: 40,
        completeModule: null,
        timeSpent: null,
      },
      Exercises: {
        pendingExercise: 6,
        timeToComplete: 30,
        completeExercise: null,
        timeSpent: null,
      },
    },
    {
      courseName:
        "6DLVI-005 Communication Skills (Listening, Written & Verbal)",
      attempt: 1,
      submissionDate: "05/5/2024",
      Action: "Resume",
      status: "InProgress",
      progress: 40,
      Modules: {
        pendingModule: 4,
        timeToComplete: 40,
        completeModule: null,
        timeSpent: null,
      },
      Exercises: {
        pendingExercise: 6,
        timeToComplete: 30,
        completeExercise: null,
        timeSpent: null,
      },
    },
  ];

  return (
    <Container maxWidth="lg">
      <MainBox>
        <CertificationDetails data={List} />
        <SliderCard data={List} />
      </MainBox>
    </Container>
  );
};

export default MyJobs;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  margin-top: 5rem;
`;
