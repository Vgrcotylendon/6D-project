import React from "react";
import { Box, Typography, Grid, Card, Divider,LinearProgress, } from "@mui/material";
import styled from "styled-components";
import IconImage from "../../../../Assets/Vector.svg";
import { useSelector } from "react-redux";

interface Inprogressive {
  course: string;
  completed: string;
  pending: string;
  progress: number;
  timespent: number;
  module: string;
}

interface  StateType {
  learning: {
    value: number;
  };
}
interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
  };
}

interface InprogressProps {
  SliderModal: Inprogressive[];
}
const ModuleCount: React.FC<InprogressProps> = () => {
  const value = useSelector((state: StateType) => state.classRoom.value);
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse
  );
  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);
  return (
    <>
      <InprogressBox>
        <Box>
          <Box sx={{ marginBottom: "18px", marginTop: "18px" }}>
            <Typography className="Activity">
            {rootCourse[0]?.courseDetails?.TITLE || "not found"}
            </Typography>
          </Box>
          <ChildBox>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={4} md={4}>
                <MainCard>
                  <CardBox>
                    <CompleteBox>
                      <Typography
                        sx={{
                          color: "green",
                          fontSize: "25px",
                        }}
                      >
                        {/* {i.completed} */}
                        {"2"}
                      </Typography>
                      <Typography sx={{ fontSize: "14px", color: "#646362" }}>
                        Completed Modules
                      </Typography>
                    </CompleteBox>
                    <Divider sx={{ background: "green" }} />
                    <PendingBox>
                      <Typography
                        sx={{
                          color: "#F95F12",
                          fontSize: "25px",
                        }}
                      >
                        {/* {i.pending} */}
                        {"15"}
                      </Typography>
                      <Typography sx={{ fontSize: "14px", color: "#646362" }}>
                        Pending Modules
                      </Typography>
                    </PendingBox>
                    <Divider sx={{ background: "#F95F12" }} />
                    <TimeBox>
                      <Typography
                        sx={{
                          color: "#A41DF7",
                          fontSize: "25px",
                        }}
                      >
                        {/* {i.timespent} */}
                        {"140"}
                      </Typography>
                      <Typography sx={{ fontSize: "14px", color: "#646362" }}>
                        Time Spent(min)
                      </Typography>
                    </TimeBox>
                    <CustomDivider sx={{ marginBottom: "10px" }} />
                  </CardBox>
                </MainCard>
              </Grid>
              <Grid item xs={12} sm={4} md={4}>
                <MainCard>
                  <CardBox>
                    <CompleteBox>
                      <Typography
                        sx={{
                          color: "green",
                          fontSize: "25px",
                        }}
                      >
                        {/* {i.completed} */}
                        {"2"}
                      </Typography>
                      <Typography sx={{ fontSize: "14px", color: "#646362" }}>
                        Completed Exercises
                      </Typography>
                    </CompleteBox>
                    <Divider sx={{ background: "green" }} />
                    <PendingBox>
                      <Typography
                        sx={{
                          color: "#F95F12",
                          fontSize: "25px",
                        }}
                      >
                        {/* {i.pending} */}
                        {"15"}
                      </Typography>
                      <Typography sx={{ fontSize: "14px", color: "#646362" }}>
                        Pending Exercises
                      </Typography>
                    </PendingBox>
                    <Divider sx={{ background: "#F95F12" }} />
                    <TimeBox>
                      <Typography
                        sx={{
                          color: "#A41DF7",
                          fontSize: "25px",
                        }}
                      >
                        {/* {i.timespent} */}
                        {"140"}
                      </Typography>
                      <Typography sx={{ fontSize: "14px", color: "#646362" }}>
                        Time Spent(min)
                      </Typography>
                    </TimeBox>
                    <CustomDivider sx={{ marginBottom: "10px" }} />
                  </CardBox>
                </MainCard>
              </Grid>
              <Grid item xs={12} sm={4} md={4}>
                <ProgressBox>
                  <ProgressCard>
                    <Box
                      sx={{ backgroundColor: "#f0f0f0", borderRadius: "8px" ,display:"flex"}}
                    >
                      <LinearBox>
                      <CustomLinear
                        variant="determinate"
                        color="secondary"
                        value={100}
                        sx={{
                          "& .MuiLinearProgress-bar": {
                            backgroundColor:"#BF1932",
                          },
                        }}
                      />
                      &nbsp;
                      <Typography className="progress">
                        {100}%
                      </Typography>
                      </LinearBox>
                    </Box>
                    <Typography
                      sx={{ fontSize: "16px", fontWeight: 700, padding: "7px" }}
                    >
                      Resume Learning
                    </Typography>
                    <ModuleBox>
                      <SubModuleBox>
                        <SolidBox />
                        <TextModBox>
                          {/* {i.module} */}
                          {"Module 1/2"}
                        </TextModBox>
                        <Icon2Box>
                          <img src={IconImage} alt="icon" />
                        </Icon2Box>
                      </SubModuleBox>
                    </ModuleBox>
                  </ProgressCard>
                </ProgressBox>
              </Grid>
            </Grid>
          </ChildBox>
        </Box>
      </InprogressBox>
      {/* ))} */}
    </>
  );
};

export default ModuleCount;

const InprogressBox = styled(Box)`
  margin: 15px;
  border: 2px solid white;
  border-radius: 7px;
  padding: 10px;
  margin-top: 10px;
`;

const ChildBox = styled(Box)`
  display: flex;
  flex-direction: row;
  width: 100%;
`;

const MainCard = styled(Card)`
  box-shadow: none !important;
  padding: 14px;
  border-radius: 3px;
`;

const CardBox = styled(Box)`
  display: flex;
  flex-direction: column;
`;

const CompleteBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 8px;
  justify-content: space-between;
`;

const PendingBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 8px;
  justify-content: space-between;
`;

const TimeBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 5px;
  margin-top: 5px;
  justify-content: space-between;
`;

const CustomDivider = styled(Divider)`
  background: #a41df7;
  margin-top: 5px;
`;

const ProgressBox = styled(Box)`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const ProgressCard = styled(Card)`
  box-shadow: none !important;
  padding: 16px;
  border-radius: 3px;
`;

const LinearBox = styled(Box)`
  display: flex;
  padding: 15px;
  margin-top: 12px;
  align-items: center;
  width: 100%;
`;

const ModuleBox = styled(Box)`
  background-color: #f0f0f0;
  border-radius: 7px;
  padding: 10px;
  margin-top: 5px;
  margin-bottom: 12px;
`;

const SubModuleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;

const SolidBox = styled(Box)`
  border: 2px solid #3c88b5;
  height: 30px; /* Add px unit */
  width: 5px; /* Add px unit */
  border-radius: 4px;
  background-color: #3c88b5;
`;

const TextModBox = styled(Box)`
  color: #3c88b5;
  align-content: center;
`;

const Icon2Box = styled(Box)`
  justify-content: center;
  display: flex;
  padding: 6px;
  border-radius: 50%;
  background: #3c88b5;
`;
const CustomLinear = styled(LinearProgress)`
  padding: 2px;
  width: 100%;
  margin: 5px;
  border-radius: 7px;
  /* & .MuiLinearProgress-bar {
    background-color: #ef5c00;
  } */
`;