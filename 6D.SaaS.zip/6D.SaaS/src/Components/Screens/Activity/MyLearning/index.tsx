import {
  Box,
  Grid,
  Container,
  Typography,
  Divider,
  Modal,
  MenuItem,
} from "@mui/material";
import styled from "styled-components";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import BarCharts from "../MyDashBoard/BarCharts";
import ModuleCount from "./ModuleCount";
import CertificationProgressCard from "./CertificationProgressCard";
import { useDispatch, useSelector } from "react-redux";
import { changeClassRoomValue, getEnrolledCourse,} from "../../../../Store/ClassroomSlice";
import { useEffect, useState } from "react";
import { instance } from "../../../../Controller/Common";
import { RootState } from "../../../../Store/UserSlice";

interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
  };
}

interface InprogressAllData {
  course: string;
  completed: string;
  pending: string;
  progress: number;
  timespent: number;
  module: string;
}

const SliderModal: InprogressAllData[] = [
  {
    course: "6GU-001 Leadership and Initiative",
    completed: "5",
    pending: "6",
    progress: 100,
    timespent: 113,
    module: "Module 3/1.3",
  },
  {
    course: "6GU-002 Professionalism and Work Ethics",
    completed: "2",
    pending: "3",
    progress: 1,
    timespent: 100,
    module: "Module 11/12.4",
  },
  {
    course: "6GU-003 Digital Literacy",
    completed: "3",
    pending: "1",
    progress: 20,
    timespent: 90,
    module: "Module 5/5.2",
  },
  {
    course: "6GU-005 Communication Skills (Listening, Written & Verbal)",
    completed: "7",
    pending: "4",
    progress: 40,
    timespent: 119,
    module: "Module 1/1.2",
  },
  {
    course: "6GU-004 Basic IT Skills",
    completed: "4",
    pending: "5",
    progress: 1,
    timespent: 120,
    module: "Module 7/7.2",
  },
];
const style = {
  position: "absolute" as "absolute",
  top: 300,
  right: 0,
  transform: "translate(-50%, -50%)",
  bgcolor: "background.paper",
  borderRadius: 2,
  p: "10px 5px",
  zIndex: 19999,
};
const MyLearning: React.FC = () => {

  const [courses, setCourses] = useState("");
  const userId = useSelector((state: RootState) => state.user.userID);
  const value = useSelector((state: StateType) => state.classRoom.value);
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse || []
  );

  const getUserCertification = async () => {
    try {
      const response = await instance.get(
        `/6D/enRoll/getEnRollCourse-ByUId?id=${userId}`
      );
      if (response.status === 200) {
        setCourses(response.data);
        dispatch(getEnrolledCourse(response.data || []));
        dispatch(
          changeClassRoomValue(
            response.data[0]?.courseDetails.CID || "not found"
          )
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (userId) {
      getUserCertification();
    }
  }, [userId]);

  const dispatch = useDispatch();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);

  return (
    <>
      <Container maxWidth="xl">
        <MainBox>
          <Modal
            open={open}
            onClose={handleClose}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          >
            <Box sx={style}>
              {enrolledCourse?.map((course: any, index: number) => (
                <MenuItem
                  key={index}
                  onClick={() => {
                    dispatch(changeClassRoomValue(course.courseDetails.CID));
                    handleClose();
                  }}
                >
                  {course.courseDetails?.TITLE || "not found"}
                </MenuItem>
              ))}
            </Box>
          </Modal>
            <Grid  xs={6} md={6} display={"flex"} justifyContent={"end"}>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "flex-end",
                  padding: "5px",
                  width:"700px",
                  backgroundColor: "white",
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    justifyContent: "space-between",
                  }}
                >
                  <SubBox onClick={handleOpen}>
                    <Typography
                      onClick={handleOpen}
                      sx={{
                        cursor: "pointer",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        fontWeight: 400,
                        color: "#3F3F40",
                        pr: 1,
                        fontSize: "14px",
                      }}
                    >
                      {rootCourse[0]?.courseDetails?.TITLE || "not found"}
                     </Typography>
                     <ArrowDropDownIcon   cursor={"pointer"} onClick={handleOpen}/>
                  </SubBox>
                  <Divider
                    orientation="vertical"
                    variant="middle"
                    flexItem
                    sx={{ borderColor: "#2A62AA", marginLeft: "10px" }}
                  />
                  <Typography
                    sx={{
                      fontWeight: 400,
                      fontSize: "14px",
                      color: "#2A62AA",
                      margin: "10px",
                      cursor: "pointer",
                    }}
                  >
                    Course
                  </Typography>
                </Box>
              </Box>
            </Grid>
          <br />  <br />
          <Sub1Box>
            <Grid container spacing={6}>
              <Grid item xs={12} sm={7}>
                <ModuleCount SliderModal={SliderModal} />
              </Grid>
              <Grid item xs={12} sm={5}>
                <BarCharts />
              </Grid>
            </Grid>
          </Sub1Box>
          <Box sx={{ padding: "0 15px 0 15px" }}>
            <CertificationProgressCard />
          </Box>
        </MainBox>
      </Container>
    </>
  );
};

export default MyLearning;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  margin-top: 4rem;
`;

const Sub1Box = styled(Box)`
  display: flex;
  flex-direction: row;
`;

const SubBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content:space-between;
  background-color: #edf1f4;
  width:600px;
  cursor:pointer;
  padding: 4px 8px 4px 5px;
`;
