import React from "react";
import {
  Typography,
  Table,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableBody,
  LinearProgress,
  Box,
  Card
} from "@mui/material";
import styled from "styled-components";
import { useSelector } from "react-redux";

interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
  };
}

const CertificationProgressCard: React.FC = () => {
  const head = [
    "Attempts Token",
    "Last Attempt Score",
    "Cut-Off Score",
    "Certification Level"
  ];
  const number = [1, 2, 3, 4, 5];
  const head2 = ["Course Exam Attempt", "Score", "Time Taken (min)", "Completed On"];

  const tableData = [
    {
      attempt: 1,
      startDate: 1,
      progress: "90",
      status: 35,
      timeSpent: "certification of completion",
    },
  ];
  const tableData2 = [
    {
      module: 1,
      exercise: "65",
      attempt: 35,
      timeSpent: "10 may 2024",
    },
    {
      module: 2,
      exercise: "70",
      attempt: 50,
      timeSpent: "12 june 2024",
    },
  ];

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const value = useSelector((state: StateType) => state.classRoom.value);
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse
  );
  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      <MainCard>
        <Box sx={{display:"flex",justifyContent:"center",alignItems:"center",paddingBottom:"20px"}}>
          <Typography className="Activity">{rootCourse[0]?.courseDetails?.TITLE || "not found"}</Typography>
        </Box>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                {head.map((item, index) => (
                  <TableCell
                    align="center"
                    sx={{
                      bgcolor: "#F5F5F5",
                      // minWidth: 200,
                      border: "none",
                    }}
                  >
                    {item}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {tableData.map((item, index) => (
                <TableRow>
                  <TableCell align="center" sx={{ borderColor: "#fdfcfc" }}>
                    {item.startDate}
                  </TableCell>
                  <TableCell align="center" sx={{ borderColor: "#fdfcfc" }}>
                 {item.progress}
                  </TableCell>
                  <TableCell align="center" sx={{ borderColor: "#fdfcfc" }}>
                 {item.status}
                  </TableCell>
                  <TableCell align="center" sx={{ borderColor: "#fdfcfc" }}>
                    {item.timeSpent}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <br />
        {/* <Box sx={{ width: "100%", display: "flex", justifyContent: "center" }}>
          <Button
            variant="contained"
            onClick={handleClick}
            sx={{ textTransform: "none", backgroundColor: " #3c88b5" }}
          >
            Attempt 1 &nbsp; &nbsp; &nbsp; &nbsp; <ArrowDropDownIcon />
          </Button>
          <Backdrop
            sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
            open={open}
            onClick={handleClose}
          >
            <Popover
              id={id}
              sx={{ borderRadius: "5px" }}
              open={open}
              anchorEl={anchorEl}
              onClose={handleClose}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "right",
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "right",
              }}
            >
              <PopoverBox>
                <TextBox>
                  {number.map((e, i) => (
                    <Box key={i} sx={{ width: "100%" }}>
                      <MenuItem sx={{ padding: "2px 65px" }}>{e}</MenuItem>
                      {i < number.length - 1 && (
                        <Divider
                          sx={{
                            background: "#e0dcdc",
                            height: "0.5px",
                          }}
                        />
                      )}
                    </Box>
                  ))}
                </TextBox>
              </PopoverBox>
            </Popover>
          </Backdrop>
        </Box> */}

        <br />
        <Box sx={{ padding: "10px 100px 0 100px" }}>
          <TableContainer>
            <Table >
              <TableHead>
                <TableRow>
                  {head2.map((item, index) => (
                    <TableCell
                      align={item === "Exercise" ? "left" : "center"}
                      sx={{
                        bgcolor: "#F5F5F5",
                        minWidth: 200,
                        border: "none",
                      }}
                    >
                      {item}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {tableData2.map((item, index) => (
                  <TableRow>
                    <TableCell align="center" sx={{ borderColor: "#fdfcfc" }}>
                      {item.module}
                    </TableCell>
                    <TableCell align="center" sx={{ borderColor: "#fdfcfc" }}>
                      {item.exercise}
                    </TableCell>
                    <TableCell align="center" sx={{ borderColor: "#fdfcfc" }}>
                      {item.attempt}
                    </TableCell>
                    <TableCell align="center" sx={{ borderColor: "#fdfcfc" }}>
                      {item.timeSpent}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </MainCard>
    </>
  );
};

export default CertificationProgressCard;

const MainCard = styled(Card)`
  box-shadow: none !important;
  padding: 30px;
  display: flex;
  flex-direction: column;
  margin-top: 2rem;
  margin-bottom: 2rem;
`;
