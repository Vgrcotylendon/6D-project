import React, { useState, MouseEvent, useRef } from "react";
import { Box, Typography,Grid,Card ,Divider} from "@mui/material";
import WorkspacePremiumOutlinedIcon from "@mui/icons-material/WorkspacePremiumOutlined";
import styled from "styled-components";
import CustomLinearProgress from "../MyDashBoard/LinearProgress";

interface progresslider {
    course: string;
    completed: string;
    pending: string;
    progress: number;
    timespent: number;
  }
  
  interface InprogressSliderProps {
    SliderModal: progresslider[];
  }
  const ProgressiveSlider: React.FC<InprogressSliderProps> = ({ SliderModal }) => {
  const boxRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const handleMouseDown = (e: MouseEvent<HTMLDivElement>) => {
    if (boxRef.current) {
      setIsDragging(true);
      setStartX(e.pageX - boxRef.current.offsetLeft);
      setScrollLeft(boxRef.current.scrollLeft);
    }
  };

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!isDragging || !boxRef.current) return;
    const x = e.pageX - boxRef.current.offsetLeft;
    const walk = (x - startX) * 2; 
    boxRef.current.scrollLeft = scrollLeft - walk;
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };
  return (
    <>
    <MainBox>
      <SubBox>
      <SliderBox ref={boxRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {SliderModal.map((i, j) => (
            <MapBox key={j}>
              <Box>
                  <Typography className="Activity">
                    {i.course}
                  </Typography>
                  <CountBox>
                    <Grid container spacing={1}>
                    <Grid item xs={12} sm={6} md={6}>
                    <MainCard>
                     <CardBox>
                            <CompleteBox>
                              <Typography
                                sx={{
                                  color: "green",
                                  fontSize: "25px",
                                }}
                              >
                                {i.completed}
                              </Typography>
                              <Typography
                                sx={{ fontSize: "14px", color: "#646362" }}
                              >
                                Completed Modules
                              </Typography>
                            </CompleteBox>
                            <Divider sx={{ background: "green" }} />
                            <PendingBox>
                              <Typography
                                sx={{
                                  color: "#F95F12",
                                  fontSize: "25px",
                                }}
                              >
                                {i.pending}
                              </Typography>
                              <Typography
                                sx={{ fontSize: "14px", color: "#646362" }}
                              >
                                Pending Modules
                              </Typography>
                            </PendingBox>
                            <TimeBox>
                              <Typography
                                sx={{
                                  color: "blue",
                                  fontSize: "25px",
                                }}
                              >
                                {i.timespent}
                              </Typography>
                              <Typography
                                sx={{ fontSize: "14px", color: "#646362" }}
                              >
                                Time Spent(min)
                              </Typography>
                            </TimeBox>
                            <Divider
                              sx={{
                                background: "blue",
                                marginTop: "5px",
                              }}
                            />
                          </CardBox>
                        </MainCard>
                      </Grid>
                      <Grid item xs={12} sm={6} md={6}>
                        <CertifiedBox>
                          <CertifedCard>
                            <TextBox>
                              <Typography
                                sx={{
                                  fontSize: "14px",
                                  color: "black",
                                  fontWeight: "600"
                                }}
                              >
                                Certification  <br />Progress
                                
                              </Typography>
                              <IconBox>
                                <WorkspacePremiumOutlinedIcon
                                  style={{ color: "white" }}
                                />
                              </IconBox>
                            </TextBox>
                            <LinearBox>
                              <CustomLinearProgress progress={i.progress} />
                            </LinearBox>
                          </CertifedCard>
                        </CertifiedBox>
                      </Grid>
                      </Grid>
                    </CountBox>
                </Box>
              </MapBox>
          ))}
        </SliderBox>
      </SubBox>
    </MainBox>
  </>
  )
}

export default ProgressiveSlider

const MainBox = styled(Box)`
  display: flex;
  flex-direction:column;
  margin-top: 2rem;
  margin-bottom: 2rem;
`;
const SubBox = styled(Box)`
  display:flex;
  width: 100%;
  border:2px solid white;
  border-radius:3px;
  padding:10px;
  flex-direction:column;
`;
const SliderBox = styled(Box)`
  display: flex;
  overflow: auto;
  user-select: none;
  margin-right: 30px;
  &::-webkit-scrollbar {
    display: none;
  }
  -ms-overflow-style: none;  
  scrollbar-width: none;
`;

const MapBox = styled(Box)`
  margin: 15px; 
  min-width: 490px; 
  border: 2px solid white;
  border-radius: 7px;
  padding: 10px;
  margin-top: 10px;
`;
const CountBox = styled(Box)`
  display:flex;
  flex-direction:row;
  width: 100%;
`;
const MainCard = styled(Card)`
  box-shadow: none !important;
  padding: 14px;
  border-radius: 3px;
`;
const CardBox = styled(Box)` 
  display:flex; 
  flex-direction: column;
`;
const CompleteBox = styled(Box)` 
  display:flex;
  align-items:center;
  padding:8px;
  justify-content:space-between;
`;
const PendingBox = styled(Box)`
  display:flex;
  align-items:center;
  padding:8px;
  justify-content:space-between;
`;
const TimeBox = styled(Box)`
  display: flex;
  align-items:center;
  padding: 5px;
  justify-content: space-between;
`;
const CertifiedBox = styled(Box)` 
display:flex;
flex-direction: column;
width:100%;
`;
const CertifedCard = styled(Card)` 
  box-shadow: none !important;
  padding: 16px;
  border-radius:3px;
`;
const TextBox = styled(Box)` 
  display: flex;
  justify-content:space-between;
  align-items:center;
`;
const IconBox = styled(Box)` 
  justify-content:center;
  display: flex;
  padding: 8px;
  border-radius: 50%;
  background: green;
`;
const LinearBox = styled(Box)`
  display:flex;
  padding:10px;
  margin-top:12px;
  align-items:center;
  width: 100%;
`;