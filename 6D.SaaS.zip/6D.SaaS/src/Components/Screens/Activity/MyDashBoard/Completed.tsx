import React, { useState, ChangeEvent, MouseEvent, useRef } from "react";
import { Box, Typography, Grid, Card, Divider } from "@mui/material";
import styled from "styled-components";
import WorkspacePremiumOutlinedIcon from "@mui/icons-material/WorkspacePremiumOutlined";
import CustomLinearProgress from "./LinearProgress";

interface SliderModel {
  course: string;
  finishedItems: string;
  pending: string;
  progress: number;
  timespent: number;
}

const sliderModels: SliderModel[] = [
  {
    course: "6GU-001 Leadership and Initiative",
    finishedItems: "6",
    pending: "0",
    progress: 100,
    timespent: 116,
  },
];

const Completed: React.FC = () => {
  const [selectedValue, setSelectedValue] = useState<string>("default");
  const boxRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const handleChange = (event: ChangeEvent<HTMLSelectElement>) => {
    setSelectedValue(event.target.value);
  };

  const handleMouseDown = (e: MouseEvent<HTMLDivElement>) => {
    if (boxRef.current) {
      setIsDragging(true);
      setStartX(e.pageX - boxRef.current.offsetLeft);
      setScrollLeft(boxRef.current.scrollLeft);
    }
  };

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!isDragging || !boxRef.current) return;
    const x = e.pageX - boxRef.current.offsetLeft;
    const walk = (x - startX) * 2;
    boxRef.current.scrollLeft = scrollLeft - walk;
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <MainBox>
      <SubBox>
        <DropDownBox>
          <select
            value={selectedValue}
            onChange={handleChange}
            style={{
              minWidth: "170px",
              borderColor: "white",
              padding: "8px",
            }}
          >
            <option value="default" disabled>
              Completed
            </option>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
            <option value="option3">Option 3</option>
          </select>
        </DropDownBox>
        <CountBox
          ref={boxRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {sliderModels.map((i, j) => (
            <CompletedBox key={j}>
              <Box>
                <Typography className="Activity">{i.course}</Typography>
                <SubCompletedBox>
                  <Grid container spacing={1}>
                    <Grid item xs={12} sm={6} md={6}>
                      <MainCard>
                        <MainCardBox>
                          <CardBox>
                            <Typography  sx={{color: "green",fontSize: "25px"}}>
                              {i.finishedItems}
                            </Typography>
                            <Typography sx={{fontSize: "14px",color: "#646362"}}>
                              Completed Modules
                            </Typography>
                          </CardBox>
                          <Divider sx={{ background: "green" }} />
                          <PendingBox>
                            <Typography sx={{color:"#f95f12",fontSize: "25px"}}>
                              {i.pending}
                            </Typography>
                            <Typography sx={{fontSize: "14px",color:"#646362"}}>
                              Pending Modules
                            </Typography>
                          </PendingBox>
                          <TimeBox>
                            <Typography sx={{color: "blue",fontSize: "25px"}}>
                              {i.timespent}
                            </Typography>
                            <Typography sx={{fontSize: "14px",color: "#646362"}}>
                              Time Spent(min)
                            </Typography>
                          </TimeBox>
                          <CustomDivider />
                        </MainCardBox>
                      </MainCard>
                    </Grid>
                    <Grid item xs={12} sm={6} md={6}>
                      <CertificationBox>
                        <CertificationCard>
                          <TextBox>
                          <Typography
                          sx={{
                            fontSize: "14px",
                            color: "black",
                            fontWeight: "600",
                           }}>
                              Certification <br /> Progress
                            </Typography>
                            <IconBox>
                              <WorkspacePremiumOutlinedIcon
                                style={{ color: "white" }}
                              />
                            </IconBox>
                          </TextBox>
                          <ProgressBox>
                            <CustomLinearProgress progress={i.progress} />
                          </ProgressBox>
                        </CertificationCard>
                      </CertificationBox>
                    </Grid>
                  </Grid>
                </SubCompletedBox>
              </Box>
            </CompletedBox>
          ))}
        </CountBox>
      </SubBox>
    </MainBox>
  );
};

export default Completed;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  margin-bottom: 2rem;
`;

const SubBox = styled(Box)`
  display: flex;
  width: 100%;
  border: 2px solid white;
  border-radius: 3px;
  padding: 8px;
  flex-direction: column;
`;

const DropDownBox = styled(Box)`
  display: flex;
  padding: 10px 30px 10px 10px;
  justify-content: flex-end;
`;

const CountBox = styled(Box)`
  display: flex;
  overflow: auto;
  margin-right: 4px;
  &::-webkit-scrollbar {
    display: none;
  }
  -ms-overflow-style: none;
  scrollbar-width: none;
`;

const CompletedBox = styled(Box)`
  margin: 2px;
  min-width: 490px;
  border: 2px solid white;
  border-radius: 7px;
  padding: 10px;
  margin-top: 10px;
`;

const SubCompletedBox = styled(Box)`
  display: flex;
  flex-direction: row;
  width: 100%;
`;

const MainCard = styled(Card)`
  box-shadow: none !important;
  padding: 14px;
  border-radius: 3px;
`;

const CardBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 8px;
  justify-content: space-between;
`;

const MainCardBox = styled(Box)`
  display: flex;
  flex-direction: column;
`;

const PendingBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 8px;
  justify-content: space-between;
`;

const TimeBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 5px;
  justify-content: space-between;
`;

const CustomDivider = styled(Divider)`
  background: blue;
  margin-top: 5px;
`;

const CertificationBox = styled(Box)`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const CertificationCard = styled(Card)`
  box-shadow: none !important;
  padding: 16px;
  border-radius: 3px;
`;

const TextBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const IconBox = styled(Box)`
  justify-content: center;
  display: flex;
  padding: 8px;
  border-radius: 50%;
  background: green;
`;

const ProgressBox = styled(Box)`
  display: flex;
  padding: 10px;
  margin-top: 12px;
  align-items: center;
  width: 100%;
`;
