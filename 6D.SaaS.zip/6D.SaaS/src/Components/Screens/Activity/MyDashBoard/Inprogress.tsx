import React, {
  useState,
  Dispatch,
  SetStateAction,
  useRef,
} from "react";
import {
  Box,
  Typography,
  Grid,
  Card,
  Divider,
  LinearProgress,
  Modal,
  MenuItem,
} from "@mui/material";
import WorkspacePremiumOutlinedIcon from "@mui/icons-material/WorkspacePremiumOutlined";
import styled from "styled-components";
import IconImage from "../../../../Assets/Vector.svg";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import SlickCarousel from "../../../SlickCarousel";
import { useDispatch } from "react-redux";
import { changeClassRoomValue } from "../../../../Store/ClassroomSlice";
import { useNavigate } from "react-router-dom";

interface Inprogressive {
  course: string;
  completed: string;
  pending: string;
  progress: number;
  timespent: number;
  module: string;
  courseId?: number;
  courseStatus: string;
}

interface InprogressProps {
  SliderModel: Inprogressive[];
  setSelectedValue: Dispatch<SetStateAction<string>>;
  setSliderModel: Dispatch<SetStateAction<any>>;
  selectedValue: any;
  GetSliderModelCount: (status: string) => void;
}
const dropdownOptions = [
  { value: "InProgress", label: "In Progress" },
  { value: "COMPLETED", label: "Certified" },
  { value: "DisQualified", label: "DisQualified" },
];
const style = {
  position: "absolute",
  bgcolor: "white",
  borderRadius: 1,
  p: "10px 5px",
  zIndex: 99999,
  minWidth: "210px",
};
const Inprogress: React.FC<InprogressProps> = ({
  SliderModel,
  selectedValue,
  setSelectedValue,
  setSliderModel,
  GetSliderModelCount,
}) => {
  const [open, setOpen] = React.useState(false);
  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const [modalPosition, setModalPosition] = useState({ top: 0, left: 0 });

  const handleChange = (value: string) => {
    setSelectedValue(value);
    GetSliderModelCount(value);
    setSliderModel([]);
    handleClose();
  };
  const handleClose = () => setOpen(false);
  const handleOpen = () => {
    if (dropdownRef.current) {
      const rect = dropdownRef.current.getBoundingClientRect();
      setModalPosition({ top: rect.bottom, left: rect.left });
    }
    setOpen(true);
  };

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const HandleModule = (TITLE: string, id: number, status: string) => {
    if (status === "InProgress") {
      dispatch(changeClassRoomValue(id));
      navigate(`/landing/classroom?continueToLast=${id}`, {
        state: { courseTitle: TITLE },
      });
    } else if (status === "Not Started") {
      navigate(`/landing/classroom`, {
        state: { courseTitle: TITLE, CourseID: id },
      });
      dispatch(changeClassRoomValue(id));
    }
  };
  const CustomLinear = styled(LinearProgress)<{ value: any }>(
    ({ theme, value }) => ({
      padding: "2px",
      width: "100%",
      borderRadius: "7px",
      "& .MuiLinearProgress-bar": {
        backgroundColor: value === "100" ? "#48A055" : "#ef5c00",
      },
    })
  );

  return (
    <>
      <MainBox>
        <SubBox>
          <DropDownBox>
            <Modal
              open={open}
              onClose={handleClose}
              aria-labelledby="modal-modal-title"
              aria-describedby="modal-modal-description"
            >
              <Box
                sx={{
                  ...style,
                  top: modalPosition.top,
                  left: modalPosition.left,
                }}
              >
                {dropdownOptions.map((option) => (
                  <MenuItem
                    key={option.value}
                    onClick={() => handleChange(option.value)}
                  >
                    <Typography>{option.label}</Typography>
                  </MenuItem>
                ))}
              </Box>
            </Modal>
            <Box sx={{ position: "relative" }}>
              <Box
                ref={dropdownRef}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  width: "200px",
                  backgroundColor: "#ffffff",
                  padding: "4px 8px",
                  border: "1px solid #ddd",
                  borderRadius: "4px",
                  cursor: "pointer",
                }}
                onClick={handleOpen}
              >
                {/* <SubBox2
                onClick={handleOpen}
              > */}
                <Typography
                  onClick={handleOpen}
                  sx={{
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    fontWeight: 400,
                    color: "#3F3F40",
                    pr: 1,
                    fontSize: "14px",
                  }}
                >
                  {selectedValue === "COMPLETED" ? "Certified" : selectedValue}
                </Typography>
                <ArrowDropDownIcon
                  sx={{
                    ml: "40px",
                    cursor: "pointer",
                    color: "black",
                  }}
                  onClick={handleOpen}
                />
                {/* </SubBox2> */}
              </Box>
            </Box>
          </DropDownBox>
          {!SliderModel.length ? (
            <Typography style={{ textAlign: "center" }}>
              No Data Found
            </Typography>
          ) : (
            <>
              <SlickCarousel slidesToShow={2} slidesToScroll={2}>
                {SliderModel.map((i, j) => (
                  <InprogressBox key={j}>
                    <Box>
                      <Typography className="Activity">{i.course}</Typography>
                      <ChildBox>
                        <Grid container spacing={1}>
                          <Grid item xs={12} sm={6} md={6}>
                            <MainCard>
                              <CardBox>
                                <CompleteBox>
                                  <Typography
                                    sx={{
                                      color: "green",
                                      fontSize: "25px",
                                    }}
                                  >
                                    {i.completed}
                                  </Typography>
                                  <Typography
                                    sx={{ fontSize: "14px", color: "#646362" }}
                                  >
                                    Completed Modules
                                  </Typography>
                                </CompleteBox>
                                <Divider sx={{ background: "green" }} />
                                <PendingBox>
                                  <Typography
                                    sx={{
                                      color: "#F95F12",
                                      fontSize: "25px",
                                    }}
                                  >
                                    {i.pending}
                                  </Typography>
                                  <Typography
                                    sx={{ fontSize: "14px", color: "#646362" }}
                                  >
                                    Pending Modules
                                  </Typography>
                                </PendingBox>
                                <Divider sx={{ background: "#F95F12" }} />
                                <TimeBox>
                                  <Typography
                                    sx={{
                                      color: "#A41DF7",
                                      fontSize: "25px",
                                    }}
                                  >
                                    {i.timespent}
                                  </Typography>
                                  <Typography
                                    sx={{ fontSize: "14px", color: "#646362" }}
                                  >
                                    Time Spent(min)
                                  </Typography>
                                </TimeBox>
                                <CustomDivider />
                              </CardBox>
                            </MainCard>
                          </Grid>
                          <Grid item xs={12} sm={6} md={6}>
                            <CertifiedBox>
                              <CertifiedCard>
                                <TextBox>
                                  <Typography
                                    sx={{
                                      fontSize: "14px",
                                      color: "black",
                                      fontWeight: "600",
                                    }}
                                  >
                                    Certification <br /> Progress
                                  </Typography>
                                  <IconBox>
                                    <WorkspacePremiumOutlinedIcon
                                      style={{ color: "white" }}
                                    />
                                  </IconBox>
                                </TextBox>
                                <LinearBox>
                                  <CustomLinear
                                    variant="determinate"
                                    color="secondary"
                                    value={i.progress}
                                  />
                                  &nbsp;
                                  <Typography className="progress">
                                    {Math.round(i.progress)}%
                                  </Typography>
                                  {/* <CustomLinearProgress progress={i.progress} /> */}
                                </LinearBox>
                              </CertifiedCard>
                              <Box
                                sx={{
                                  border: "2px solid white",
                                  borderRadius: "7px",
                                  padding: "10px",
                                  marginTop: "8px",
                                  cursor: 
                                  selectedValue === "COMPLETED" || selectedValue === "DisQualified" 
                                    ? "default" 
                                    : "pointer",
                                }}
                                onClick={() => {
                                  if (selectedValue === "InProgress") {
                                    HandleModule(
                                      i.course,
                                      Number(i?.courseId),
                                      i?.courseStatus
                                    );
                                  }
                                }}
                              >
                                <SubModuleBox>
                                  <SolidBox />
                                  <TextModBox>{i.module}</TextModBox>
                                  <Icon2Box>
                                    <img src={IconImage} alt="icon" />
                                  </Icon2Box>
                                </SubModuleBox>
                              </Box>
                            </CertifiedBox>
                          </Grid>
                        </Grid>
                      </ChildBox>
                    </Box>
                  </InprogressBox>
                ))}
              </SlickCarousel>
            </>
          )}
        </SubBox>
      </MainBox>
    </>
  );
};

export default Inprogress;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  margin-top: 2rem;
  margin-bottom: 2rem;
`;
const SubBox = styled(Box)`
  display: flex;
  width: 100%;
  border: 2px solid white;
  border-radius: 3px;
  padding: 8px;
  flex-direction: column;
`;

const DropDownBox = styled(Box)`
  display: flex;
  padding: 10px 30px 10px 10px;
  justify-content: flex-end;
`;

const InprogressBox = styled(Box)`
  margin: 15px;
  /* min-width: 490px; */
  width: 90%;
  border: 2px solid white;
  border-radius: 7px;
  padding: 10px;
  margin-top: 10px;
`;

const ChildBox = styled(Box)`
  display: flex;
  flex-direction: row;
  width: 100%;
`;

const MainCard = styled(Card)`
  box-shadow: none !important;
  padding: 14px;
  border-radius: 3px;
`;

const CardBox = styled(Box)`
  display: flex;
  flex-direction: column;
`;

const CompleteBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 8px;
  justify-content: space-between;
`;

const PendingBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 8px;
  justify-content: space-between;
`;

const TimeBox = styled(Box)`
  display: flex;
  align-items: center;
  padding: 5px;
  justify-content: space-between;
`;

const CustomDivider = styled(Divider)`
  background: #a41df7;
  margin-top: 5px;
`;

const CertifiedBox = styled(Box)`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const CertifiedCard = styled(Card)`
  box-shadow: none !important;
  padding: 16px;
  border-radius: 3px;
`;

const TextBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const IconBox = styled(Box)`
  justify-content: center;
  display: flex;
  padding: 8px;
  border-radius: 50%;
  background: #f95f12;
`;

const LinearBox = styled(Box)`
  display: flex;
  padding: 10px;
  margin-top: 12px;
  align-items: center;
`;

const SubModuleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;

const SolidBox = styled(Box)`
  border: 2px solid #3c88b5;
  height: 25px; /* Add px unit */
  width: 4px; /* Add px unit */
  border-radius: 5px;
  background-color: #3c88b5;
`;

const TextModBox = styled(Box)`
  color: #3c88b5;
  align-content: center;
`;

const Icon2Box = styled(Box)`
  justify-content: center;
  display: flex;
  padding: 6px;
  border-radius: 50%;
  background: #3c88b5;
`;

