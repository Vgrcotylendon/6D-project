import React from "react";
import {
  Box,
  Typography,
  LinearProgress as MuiLinearProgress,
  linearProgressClasses,
} from "@mui/material";
import { styled } from "@mui/material/styles";

interface LinearProgressProps {
  progress: number;
}

const BorderLinearProgress = styled(MuiLinearProgress)<{ value: number }>(
  ({ theme, value }) => ({
    height: 10,
    width: 150,
    borderRadius: 3,
    [`&.${linearProgressClasses.colorPrimary}`]: {
      backgroundColor:
        theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
    },
    [`& .${linearProgressClasses.bar}`]: {
      backgroundColor: value === 1 ? "blue" : value === 100 ? "green" : "red",
    },
  })
);

const CustomLinearProgress: React.FC<LinearProgressProps> = ({ progress }) => {
  const progressValue = progress;

  return (
    <MainBox>
      <BorderLinearProgress variant="determinate" value={progressValue} />
      <Typography
        sx={{
          fontSize: "12px",
          marginLeft: "8px",
          color: "#8B8D8F",
        }}
      >
        {progressValue}%
      </Typography>
    </MainBox>
  );
};

export default CustomLinearProgress;

const MainBox = styled(Box)`
  display:flex;
  align-items:center;
  justify-content:left;
 `;