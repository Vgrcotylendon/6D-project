import { Typography, Grid, Box } from "@mui/material";
import { BarChart } from "@mui/x-charts";
import React from "react";
import styled from "styled-components";

interface SeriesData {
  data: number[];
  stack: string;
  label: string;
  color: string;
}

const BarCharts: React.FC = () => {
  const series: SeriesData[] = [
    {
      data: [3, 4, 1, 6, 5],
      stack: "A",
      label: "Study",
      color: "#384A93",
    },
    {
      data: [4, 3, 1, 5, 8],
      stack: "A",
      label: "Activities",
      color: "#FB4E17",
    },
  ];

  return (
    <>
      <Typography className="Activity">Study Time</Typography>
      <Grid container spacing={6}>
        <Grid item xs={12} sm={8}>
          <ChartBox>
            <BarChart
              xAxis={[
                {
                  scaleType: "band",
                  data: ["Jun", "Jul", "Aug", "Sept", "Oct"],
                  disableLine: true,
                  disableTicks: true,
                },
              ]}
              grid={{ horizontal: true }}
              sx={{
                ".MuiChartsGrid-line": {
                  stroke: "rgba(0, 0, 0, 0.2)",
                  strokeDasharray: "5 5",
                  strokeWidth: 1,
                },
              }}
              yAxis={[
                {
                  disableLine: true,
                  tickSize: 0,
                },
              ]}
              series={series}
              borderRadius={5}
              height={250}
              legend={{ hidden: true }}
            />
          </ChartBox>
        </Grid>
        <Grid item xs={12} sm={4}>
          <GridBox>
            <LabelBox>
              <BlueBox/>
              &nbsp;&nbsp;<p style={{fontFamily:"poppins"}}>Topics</p>
            </LabelBox>
            <LabelBox>
              <RedBox/>
              &nbsp;&nbsp; <p style={{fontFamily:"poppins"}}>Assessments</p>
            </LabelBox>
          </GridBox>
        </Grid>
      </Grid>
    </>
  );
};

export default BarCharts;

const ChartBox = styled(Box)`
  width: 100%;
  box-shadow: none !important;
  background-color: white;
  border-radius: 5px;
`;

const GridBox = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin-top: 50px;
`;

const LabelBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
`;
const BlueBox = styled(Box)`
  height: 20px;
  width: 20px;
  border-radius: 3px;
  background-color: #384A93;
`;
const RedBox = styled(Box)`
  height: 20px;
  width: 20px;
  border-radius: 3px;
  background-color: #FB4E17;
`;