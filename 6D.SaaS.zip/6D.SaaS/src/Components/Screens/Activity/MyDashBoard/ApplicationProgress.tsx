import React from "react";
import { Box, Card, Typography, Divider } from "@mui/material";
import styled from "styled-components";

interface Application {
  title: string | null;
  status: "InProgress" | "Submitted" | "DisQualified" | null;
  icon: React.ReactNode | null;
}

interface ApplicationProgressProps {
  applications: Application[];
}

const ApplicationProgress: React.FC<ApplicationProgressProps> = ({
  applications,
}) => {
  return (
    <MainCard>
      {applications.map((application, index) => (
        <React.Fragment key={application.title}>
          <MainBox>
            <TitleTypography>
              {application.title === null ? "-" : application.title}
            </TitleTypography>
            <SubBox>
              {application.icon === null ? "-" : application.icon}
              <Typography
                sx={{
                  fontSize: "12px",
                  marginLeft: "8px",
                  color:
                    application.status === "InProgress"
                      ? "#F95F12"
                      : application.status === "Submitted"
                      ? "green"
                      : application.status === null
                      ? "white"
                      : "red",
                }}
              >
                {application.status === null ? "-" : application.status}
              </Typography>
            </SubBox>
          </MainBox>
          {index !== applications.length - 1 && <Divider />}
        </React.Fragment>
      ))}
    </MainCard>
  );
};

export default ApplicationProgress;

const MainCard = styled(Card)`
  margin-top: 10px;
  padding: 8px;
  box-shadow: none !important;
`;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin: 12px;
`;

const TitleTypography = styled(Typography)`
  font-size: 14px;
  color: #8b8d8f;
`;

const SubBox = styled(Box)`
  display: flex;
  align-items: center;
`;
