import React from "react";
import { Box, Typography, Divider } from "@mui/material";
import styled from "styled-components";
import LinearProgress from "./LinearProgress";

interface Certification {
  course: string;
  progress: number;
}

interface CertificationProps {
  certification: Certification[];
}

const CertificationProgress: React.FC<CertificationProps> = ({
  certification,
}) => {

  return (
    <div>
      {certification?.map((e, i) => (
        <React.Fragment key={i}>
          <MainBox>
            <Box sx={{ width: "80%" }}>
              <CertifyTypography>{e.course}</CertifyTypography>
            </Box>
            <Box sx={{ width: "20%" }}>
              <LinearProgress progress={e.progress} />
            </Box>
          </MainBox>
          {i !== certification.length - 1 && <Divider />}
        </React.Fragment>
      ))}
    </div>
  );
};

export default CertificationProgress;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: row;
  margin: 10.5px;
  width: 100%;
`;

const CertifyTypography = styled(Typography)`
  font-size: 14px;
  color: #8b8d8f;
`;
