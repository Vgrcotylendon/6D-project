import React, { useEffect, useState } from "react";
import {Box,Grid,Container} from "@mui/material";
import styled from "styled-components";
import BarCharts from "./BarCharts";
import CourseCount from "./CourseCount";
import Inprogress from "./Inprogress";
import { cookies, instance } from "../../../../Controller/Common";
import { RootState } from "../../../../Store/UserSlice";
import { useSelector } from "react-redux";

interface InprogressData {
  courseId: number;
  course: string;
  completed: string;
  pending: string;
  progress: number;
  timespent: number;
  module: string;
  courseStatus: string;
}

const Dashboard: React.FC = () => {
  const userId =
    useSelector((state: RootState) => state.user.userID) ??
    cookies.get("userId");
  const [sliderModel, setSliderModel] = useState<InprogressData[]>([]);
  const [selectedValue, setSelectedValue] = useState<string>("InProgress");

  const GetSliderModelCount = async (status: any) => {
    try {
      const response = await instance.get(
        `6D/activity/myDashboardModuleCount?userId=${userId}&status=${status}`
      );

      if (response.status === 200 && Array.isArray(response.data)) {
        const transformedData: InprogressData[] = response.data.map(
          (course: any) => ({
            courseId: course.courseId,
            course: course.course,
            completed: course.completed,
            pending: course.pending,
            progress: course.courseProgress,
            timespent: course.timespent,
            courseStatus: course.courseStatus,
            module: `Module ${course.completed}/${course.totalModules}`,
          })
        );
        if (!response.data.length) {
          setSliderModel([]);
        } else if (response.data.length) {
          setSliderModel(transformedData);
        }
      }
    } catch (error) {
      console.error("Error fetching slider model count:", error);
    }
  };

  useEffect(() => {
    GetSliderModelCount(selectedValue);
  }, [userId, selectedValue]);

  return (
    <Container sx={{ maxWidth: "70%" }}>
      <MainBox>
        <Box sx={{ display: "flex", flexDirection: "row" }}>
          <Grid container spacing={6}>
            <Grid item xs={12} sm={6}>
              <BorderBox>
                <BarCharts />
              </BorderBox>
            </Grid>
            <Grid item xs={12} sm={6}>
              <CourseCount />
            </Grid>
          </Grid>
        </Box>
        <ApplicationBox>
          {/* <Grid container spacing={6}>
            <Grid item xs={12} sm={12}>
              <StyledBox>
                <HeadBox>
                  <Typography className="Activity">
                    Certification Progress
                  </Typography>
                  <IconBox>
                    <IconButton size="small">
                      <OpenInFullIcon color="primary" />
                    </IconButton>
                  </IconBox>
                </HeadBox>
                <CertificationCard>
                  <CertificationProgress certification={certification} />
                </CertificationCard>
              </StyledBox>
            </Grid> */}
          {/* <Grid item xs={12} sm={5}>
              <StyledBox>
                <HeadTextBox>
                  <Typography className="Activity">
                    My Job Applications Progress
                  </Typography>
                  <HeadIconBox>
                    <IconButton size="small">
                      <OpenInFullIcon color="primary" />
                    </IconButton>
                  </HeadIconBox>
                </HeadTextBox>
                <ApplicationProgress applications={applications} />
              </StyledBox>
            </Grid> */}
          {/* </Grid> */}
        </ApplicationBox>
        <Inprogress
          SliderModel={sliderModel}
          setSliderModel={setSliderModel}
          setSelectedValue={setSelectedValue}
          selectedValue={selectedValue}
          GetSliderModelCount={GetSliderModelCount}
        />
        {/* <Completed /> */}
      </MainBox>
    </Container>
  );
};

export default Dashboard;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  margin-top: 4rem;
`;

const ApplicationBox = styled(Box)`
  display: flex;
  flex-direction: row;
  margin-top: 2rem;
`;

const BorderBox = styled(Box)`
  display: flex;
  width: 100%;
  flex-direction: column;
  border: 2px solid white;
  border-radius: 3px;
  padding: 8px;
`;
