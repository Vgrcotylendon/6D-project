import React, { useEffect, useState } from "react";
import { Box, Grid, Typography, Card, Divider } from "@mui/material";
import LocalLibraryOutlinedIcon from "@mui/icons-material/LocalLibraryOutlined";
import WorkspacePremiumOutlinedIcon from "@mui/icons-material/WorkspacePremiumOutlined";
import AccessAlarmsIcon from "@mui/icons-material/AccessAlarms";
import styled from "styled-components";
import { cookies, instance } from "../../../../Controller/Common";
import { useSelector } from "react-redux";
import { RootState } from "../../../../Store/UserSlice";

interface CardData {
  title: string;
  value: string;
  color: string;
  icon: JSX.Element;
}

const CourseCount: React.FC = () => {
  const userId =
    useSelector((state: RootState) => state.user.userID) ??
    cookies.get("userId");
  const [count, setCount] = useState({
    Enrolled: 0,
    InProgress: 0,
    DisQualified: 0,
    Certified: 0,
    TimeSpent: 0,
  });

  const cards: CardData[] = [
    {
      title: "Enrolled",
      value: count.Enrolled.toString(),
      color: "#646362",
      icon: (
        <LocalLibraryOutlinedIcon
          style={{ color: "white", fontSize: "30px" }}
        />
      ),
    },
    {
      title: "InProgress",
      value: count.InProgress.toString(),
      color: "#F95F12",
      icon: (
        <LocalLibraryOutlinedIcon
          style={{ color: "white", fontSize: "30px" }}
        />
      ),
    },
    {
      title: "Time Spent(min)",
      value:Math.round(count.TimeSpent).toString(),
      color: "#6E47DC",
      icon: <AccessAlarmsIcon style={{ color: "white", fontSize: "30px" }} />,
    },
    {
      title: "DisQualified",
      value: count.DisQualified.toString(),
      color: "#DC4747",
      icon: (
        <LocalLibraryOutlinedIcon
          style={{ color: "white", fontSize: "30px" }}
        />
      ),
    },
    {
      title: "Certified",
      value: count.Certified.toString(),
      color: "#3C88B5",
      icon: (
        <WorkspacePremiumOutlinedIcon
          style={{ color: "white", fontSize: "30px" }}
        />
      ),
    },
  ];

  const GetActivityCount = async () => {
    try {
      const response = await instance.get(
        `6D/activity/myDashboardCount?userId=${userId}`
      );

      if (response.status === 200) {
        setCount(response.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    GetActivityCount();
  }, []);

  return (
    <>
      <Grid container spacing={2}>
        {cards.map((card, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <MainCard>
              <HeadBox>
                <Typography sx={{ fontSize: "16px", color: card.color }}>
                  {card.title.split(" ").map((part, i) => (
                    <React.Fragment key={i}>
                      {i > 0 && <br />} {part}
                    </React.Fragment>
                  ))}
                </Typography>
                <Box
                  sx={{
                    justifyContent: "center",
                    display: "flex",
                    padding: "7px",
                    borderRadius: "50%",
                    background: card.color,
                  }}
                >
                  {card.icon}
                </Box>
              </HeadBox>
              <Typography
                sx={{
                  color: card.color,
                  fontSize: "25px",
                  marginTop: "15px",
                }}
              >
                {card.value}
              </Typography>
              <Divider
                sx={{
                  background: card.color,
                  marginTop: "10px",
                  marginBottom: "8px",
                  height: "1px",
                }}
              />
            </MainCard>
          </Grid>
        ))}
      </Grid>
    </>
  );
};

export default CourseCount;

const MainCard = styled(Card)`
  box-shadow: none !important;
  padding: 12px;
  border-radius: 5px;
`;

const HeadBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
