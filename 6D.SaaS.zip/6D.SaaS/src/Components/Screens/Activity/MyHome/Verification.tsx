import React from "react";
import OpenInNewIcon from "@mui/icons-material/OpenInNew";
import { Box, Grid, IconButton, Typography } from "@mui/material";
import styled from "styled-components";
import { useNavigate } from "react-router-dom";

const Verification = () => {
  const List = ["Adhaar ID"];
  const navigate = useNavigate();
  return (
    <BorderBox>
      <Grid xs={12}>
        <Typography className="Activity">Verification Pending to</Typography>
      </Grid>
      <Box sx={{ display: "flex" }}>
        {List.map((i, j) => (
          <WhiteBox key={j}>
            <Box>
              <Typography className="update">UPDATE</Typography>
              <Typography className="verifyBody">{i}</Typography>
            </Box>
            <IconButton
              className="verifyNav"
              onClick={() => navigate("/landing/profile")}
            >
              <OpenInNewIcon />
            </IconButton>
          </WhiteBox>
        ))}
      </Box>
    </BorderBox>
  );
};

export default Verification;
const BorderBox = styled(Box)`
  // height: 100%;
  border: 2px solid white;
  border-radius: 3px;
  padding: 15px;
`;
const WhiteBox = styled(Box)`
  background-color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px;
  margin: 10px;
  border-radius: 7px;
  /* min-width: 40%; */
  width: 100%;
`;
