import { Typography, Box, IconButton } from "@mui/material";
import OpenInNewIcon from "@mui/icons-material/OpenInNew";
import React from "react";
import styled from "styled-components";
import { useNavigate } from "react-router-dom";

type WelcomeProps = {
  firstName?: string;
  educationDetails: boolean;
  profile: boolean;
};

export default function GetStarted({
  firstName,
  educationDetails,
  profile,
}: WelcomeProps) {
  const navigate = useNavigate();

  return (
    <>
      {/* {!profile && !educationDetails && ( */}
        <BorderBox>
          <Typography className="Activity">Getting Started</Typography>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            {!profile && (
              <CustomBox>
                <GreyBox>
                  <Box>
                    <Typography className="getUpdate">UPDATE</Typography>
                    <Typography className="getBody">
                      {"Personal Info"}
                    </Typography>
                  </Box>
                  <IconButton className="getting">
                    <OpenInNewIcon
                      onClick={() => navigate("/landing/profile")}
                    />
                  </IconButton>
                </GreyBox>
              </CustomBox>
            )}
            {!educationDetails && (
              <CustomBox>
                <GreyBox>
                  <Box>
                    <Typography className="getUpdate">UPDATE</Typography>
                    <Typography className="getBody">
                      {"Education Details"}
                    </Typography>
                  </Box>
                  <IconButton className="getting">
                    <OpenInNewIcon
                      onClick={() => navigate("/landing/profile?tab=1")}
                    />
                  </IconButton>
                </GreyBox>
              </CustomBox>
            )}
          </Box>
        </BorderBox>
      {/* )} */}
    </>
  );
}

const CustomBox = styled(Box)`
  background-color: white;
  //   padding: 15px;
  margin-bottom: 10px;
  border-radius: 7px;
  width: 100%;
`;
const GreyBox = styled(Box)`
  background-color: #f5f5f5;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  border-radius: 7px;
  margin: 10px;
`;

const BorderBox = styled(Box)`
  // height: 100%;
  border: 2px solid white;
  border-radius: 3px;
  padding: 15px;
`;
