import { Box, Container, Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import Welcome from "./Welcome";
import GetStarted from "./GetStarted";
import GetCertified from "./GetCertified";
import { useSelector } from "react-redux";
import { RootState } from "../../../../Store/UserSlice";
import { cookies, instance } from "../../../../Controller/Common";

const MyHome = () => {
  const [firstName, setFirstName] = useState();
  const [profile, setProfile] = useState(false);
  const [educationDetails, setEducationDetails] = useState(false);
  const userId =
    useSelector((state: RootState) => state.user.userID) ??
    cookies.get("userId");

  const GetProfile = async () => {
    try {
      const response = await instance.get(`6D/user/getUserProfile/${userId}`);
      const data = response.data;
      const hasProfileValue =
        data && data.FIRST_NAME && data.EMAIL && data.PHONE_NUMBER;
      if (hasProfileValue) {
        cookies.set("FirstName", data.FIRST_NAME);
        setFirstName(data.FIRST_NAME);
        setProfile(true);
      } else {
        setProfile(false);
      }
    } catch (error) {
      console.error(error);
    }
  };
  const getEducation = async () => {
    try {
      const response = await instance.get(
        `/6D/education/getUserEducation/${userId}`
      );
      const data = response.data;
      const hasEducationValue =
        data && data.INSTITUTION_NAME;
      if (hasEducationValue) {
        cookies.set("FirstName", data.INSTITUTION_NAME);
        setEducationDetails(true);
      } else {
        setEducationDetails(false);
      }
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    GetProfile();
    getEducation();
  }, []);

  return (
    <>
      <Container sx={{ maxWidth: "80%" }}>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            marginTop: "4rem",
          }}
        >
          <Grid container spacing={4}>
            {educationDetails && profile ?(
            <Grid item xs={12} md={12}>
              <Welcome firstName={firstName} educationDetails={educationDetails} profile={profile}/>
            </Grid>
            ):(
              <Grid item xs={12} md={8}>
              <Welcome firstName={firstName} educationDetails={educationDetails} profile={profile}/>
            </Grid>
            )}
            <Grid
              item
              xs={12}
              md={4}
              sx={{ display: "flex", flexDirection: "column" }}
            >
               {(!profile || !educationDetails)  &&(
               <GetStarted profile={profile} educationDetails={educationDetails} />
               )}
              {/* <Verification /> */}
              {/* <br />
              <br /> */}
              {/* {!educationDetails && <EducationDetailVerification/>} */}
            </Grid>
          </Grid>
          <br />
          <GetCertified />
          {/* <ApplyNow /> */}
        </Box>
      </Container>
    </>
  );
};

export default MyHome;
