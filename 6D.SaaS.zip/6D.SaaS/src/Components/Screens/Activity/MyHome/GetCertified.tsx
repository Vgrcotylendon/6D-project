import { Box,Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import PlayCircleOutlineRoundedIcon from "@mui/icons-material/PlayCircleOutlineRounded";
import styled from "styled-components";
import SlickCarousel from "../../../SlickCarousel";
import { cookies, instance } from "../../../../Controller/Common";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { RootState } from "../../../../Store/UserSlice";
interface CertificationType {
  AVAILABILITY: string;
  CID: number;
  DURATION: number;
  MID: number;
  TITLE: string;
  id: number;
  timespent:any;
}

const GetCertified: React.FC = () => {
  const userId =
    useSelector((state: RootState) => state.user.userID) ??
    cookies.get("userId");
  const [Certification, setCertification] = useState<CertificationType[]>([]);
  const Navigate = useNavigate();

  const formattedDuration = (duration: string | number) => {
    const totalMinutes = Number(duration);
    
    const hours = Math.floor(totalMinutes / 60);
    const minutes = Math.floor(totalMinutes % 60);
    
    if (hours > 0) {
      return `${hours} hrs ${minutes} min`;
    } else {
      return `0 hrs ${minutes} min`;
    }
  };
  const carouselSettings = (() => {
    const courseCount = Certification.length;
    
    if (courseCount <= 3) {
      return {
        slidesToShow: courseCount,
        slidesToScroll: courseCount,
        centerMode: courseCount % 2 !== 0,
        centerPadding: courseCount === 1 ? '0px' : '50px'
      };
    }
    
    return {
      slidesToShow: 3,
      slidesToScroll: 3,
      centerMode: false,
      centerPadding: '50px'
    };
  })();


  const GetCertification = async () => {
    try {
      const response = await instance.get(
        `/6D/Course/getAllCourseWithStatus?UID=${userId}`
      );
      if (response.status === 200) {
        const data = response.data.filter(
          (i: any) => i.enrolled !== "Y" && i.AVAILABILITY === "Y"
        );
        const sortedData = data.sort(
          (a: CertificationType, b: CertificationType) =>
            a.TITLE.localeCompare(b.TITLE)
        );
        setCertification(data);
      }
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    GetCertification();
  }, []);

  return (
    <BorderBox>
      {Array.isArray(Certification) && Certification.length > 0 ? (
        <>
          <Typography className="Activity">Get Certified</Typography>
          <SlickCarousel
            {...carouselSettings}
          >
            {Certification?.sort((a, b) => a.TITLE.localeCompare(b.TITLE)).map(
              (item, index) => (
                <Box
                  key={index}
                  sx={{
                    mr: "auto",
                    ml: "auto",
                    display: "flex",
                    justifyContent: "center",
                  }}
                >
                  <CourseBox>
                    <CourseNameBox>
                      <Typography
                        className="courseName"
                        color="info.main"
                        sx={{
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          cursor:"pointer"
                        }}
                        onClick={() => Navigate("/landing/certification")}
                      >
                        {item.TITLE}
                      </Typography>
                      <PlayCircleOutlineRoundedIcon
                        style={{
                          color: "#2A62AA",
                          fontSize: "18px",
                          cursor: "pointer",
                        }}
                        onClick={() => Navigate("/landing/certification")}
                      />
                    </CourseNameBox>
                    <DetailBox>
                      <Detailed>
                        <Typography className="courseName">
                          Course Length
                        </Typography>
                        <Typography className="courseName">
                          {formattedDuration(item.timespent)}
                        </Typography>
                      </Detailed>
                      <Detailed>
                        <Typography className="courseName">
                          Course Availability
                        </Typography>
                        <Typography
                          className="courseName flex"
                          sx={{
                            border: "1px solid #f0f0f0",
                            textAlign: "center",
                            color: item.AVAILABILITY === "Y" ? "green" : "red",
                          }}
                        >
                          <Box
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                            }}
                          >
                            {item.AVAILABILITY === "Y" ? (
                              <CheckCircleIcon
                                style={{ color: "green", fontSize: "18px" }}
                              />
                            ) : (
                              <CancelIcon
                                style={{ color: "red", fontSize: "18px" }}
                              />
                            )}
                            &nbsp;&nbsp;&nbsp;
                            {item.AVAILABILITY === "Y" ? "Yes" : "No"}
                          </Box>
                        </Typography>
                      </Detailed>
                    </DetailBox>
                  </CourseBox>
                </Box>
              )
            )}
          </SlickCarousel>

          <Typography
            align="right"
            className="viewMore"
            onClick={() => Navigate("/landing/certification")}
          >
            view more
          </Typography>
        </>
      ) : (
        <Typography
          sx={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          No Data Found
        </Typography>
      )}
    </BorderBox>
  );
};

export default GetCertified;

const CourseBox = styled(Box)`
  background-color: white;
  padding: 15px;
  margin: 15px;
  width: 90%;
  /* min-width: 400px; */
  border-radius: 7px;
`;
const CourseNameBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 5px 0 20px 0;
`;

const DetailBox = styled(Box)`
  background-color: #f5f5f5;
  padding: 10px;
  border-radius: 7px;
`;

const Detailed = styled(Box)`
  display: flex;
  justify-content: space-between;
  padding: 4px;
`;
const BorderBox = styled(Box)`
  display: flex;
  height: 100%;
  border: 2px solid white;
  flex-direction: column;
  border-radius: 3px;
  padding: 15px 15px 15px 15px;
  margin-bottom: 30px;
`;
