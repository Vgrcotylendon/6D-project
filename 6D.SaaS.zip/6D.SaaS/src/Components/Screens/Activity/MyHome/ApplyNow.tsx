import { Box, IconButton, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import styled from "styled-components";
import clsx from "clsx";
import SlickCarousel from "../../../SlickCarousel";
import { instance } from "../../../../Controller/Common";
import { formattedDate } from "../../../../Util/Format";

interface Detail {
  head: string;
  child: React.ReactNode;
}
interface Job {
  job_name: string;
  hiring_company: string;
  work_location: string;
  submission_date: string;
  hiring_date: string;
  stipend: string;
  employment_type: "Internship" | "Part Time" | "Full Time";
}

export default function ApplyNow() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const GetJobs = async () => {
    try {
      const response = await instance.get("/6D/jobDetails/GetJobDetails");
      if (response.status === 200) {
        const jobData = Array.isArray(response.data) ? response.data : [];
        setJobs(jobData);
      } else {
        setError("Failed to fetch job details.");
      }
    } catch (error) {
      setError("An error occurred while fetching job details.");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    GetJobs();
  }, []);

  const Details: React.FC<Detail> = ({ head, child }) => (
    <DetailBox>
      <Typography className="ApplyNowHead">{head}</Typography>
      <Typography className="ApplyNow">{child}</Typography>
    </DetailBox>
  );

  if (loading) return <Typography>Loading...</Typography>;
  if (error) return <Typography>{error}</Typography>;

  return (
    <>
      <BorderBox>
        {jobs.length !== 0 ? (
          <>
            <Typography className="Activity">Apply Now</Typography>
            <SlickCarousel slidesToShow={2} slidesToScroll={1}>
              {jobs.map((job, index) => (
                <Box key={index} sx={{ mr: "auto", ml: "auto" }}>
                  <CourseBox>
                    <CourseNameBox>
                      <Typography className="courseName" color="info.main">
                        {job.job_name}
                      </Typography>
                      <IconButton className="getCertified">
                        <ChevronRightIcon />
                      </IconButton>
                    </CourseNameBox>
                    <DBox>
                      <Details
                        head="Hiring Company"
                        child={job.hiring_company}
                      />
                      <Details head="Work Location" child={job.work_location} />
                      <Details
                        head="Submission Deadline"
                        child={formattedDate(job.submission_date)}
                      />
                      <Details
                        head="Hiring Date"
                        child={formattedDate(job.hiring_date)}
                      />
                      <Details head="Stipend (per month)" child={job.stipend} />
                      <Details
                        head="Hiring Position"
                        child={
                          <Typography
                            className={clsx("ApplyPosition", {
                              intern: job.employment_type === "Internship",
                              partTime: job.employment_type === "Part Time",
                              fullTime: job.employment_type === "Full Time",
                            })}
                          >
                            {job.employment_type}
                          </Typography>
                        }
                      />
                    </DBox>
                  </CourseBox>
                </Box>
              ))}
            </SlickCarousel>

            <Typography align="right" className="viewMore">
              view more
            </Typography>
          </>
        ) : (
          <Typography
            sx={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            No Data Found
          </Typography>
        )}
      </BorderBox>
    </>
  );
}

const BorderBox = styled(Box)`
  display: flex;
  height: 100%;
  border: 2px solid white;
  flex-direction: column;
  border-radius: 3px;
  padding: 15px;
  margin: 30px 0;
`;

const CourseBox = styled(Box)`
  background-color: white;
  padding: 15px;
  margin: 15px;
  width: 90%;
  min-width: 300px; /* Adjusted for better responsiveness */
  border-radius: 7px;
`;

const CourseNameBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background-color: #f5f5f5;
  border-radius: 7px;
`;

const DetailBox = styled(Box)`
  width: 100%;
  display: flex;
  padding: 3px;
`;

const DBox = styled(Box)`
  padding: 5px;
`;
