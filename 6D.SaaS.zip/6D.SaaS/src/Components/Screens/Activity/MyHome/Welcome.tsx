import { Box, Typography } from "@mui/material";
import React from "react";
import styled from "styled-components";

type WelcomeProps = {
   firstName?: string;
   educationDetails:boolean;
   profile:boolean;
};

const Welcome = ({ firstName,educationDetails, profile}: WelcomeProps) => {
  return (
    <>
      <WelcomeBox>
        <Typography className="welcomeHead">Welcome to 6D Learning!</Typography>
        <br />
        <Typography color="info.main" className="welcomeSub" fontSize={"14px"}>
          Dear{" "}
          {firstName
            ? (firstName as string).charAt(0).toUpperCase() +
              (firstName as string).slice(1)
            : "User"}
          ,
        </Typography>
        <Typography color="info.main" className="welcomeSub">
          Congratulations on taking the first step toward an exciting and
          impactful learning journey with 6D Learning LMS! We’re thrilled to
          have you on board as you embark on a path of discovery, growth, and
          innovation.
          <br />
        </Typography>

        <br />
        <Typography className="welcomeHead">What to Expect:</Typography>
        <ul>
          <li>
            <Typography className="welcomeHead">
              Personalized Learning:
            </Typography>
            <Typography className="welcomeSub" color="info.main">
              Tailor your learning experience with courses that match your goals
              and interests.
            </Typography>
          </li>
          <li>
            <Typography className="welcomeHead">
              Interactive Content:
            </Typography>
            <Typography className="welcomeSub" color="info.main">
              Engage with a variety of multimedia content, practical
              assignments, and real-world case studies.
            </Typography>
          </li>
          <li>
            <Typography className="welcomeHead">Certification:</Typography>{" "}
            <Typography className="welcomeSub" color="info.main">
              Earn certifications that not only enhance your knowledge but also
              add value to your academic and professional credentials.
            </Typography>
          </li>
        </ul>
      </WelcomeBox>
    </>
  );
};

export default Welcome;
const WelcomeBox = styled(Box)`
  background-color: white;
  padding: 30px;
 border-radius: 5px;
 `;
