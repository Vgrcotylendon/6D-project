import React from "react";
import { Box, IconButton, Typography,Grid } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import styled from "styled-components";
import CustomButton from "../../../Button/CustomButton";

interface jobs {
  id: number;
  jobTitle: string;
  hiringCompany: string;
  workLocation: string;
  stipend: string;
  hiringPosition: string;
  submission: string;
  hiringDate: string;
}
interface CourseProps {
  selectedJobs: jobs | null;
  handleClose: () => void;
}

const HiringModal: React.FC<CourseProps> = ({ selectedJobs, handleClose }) => {
  if (!selectedJobs) {
    return null;
  }

  return (
    <MainBox>
      <IconBox>
        <IconButton
          size="small"
          onClick={() => {
            handleClose();
          }}
          sx={{ position: "absolute", top: 10, right: 10 }}
        >
          <CloseIcon />
        </IconButton>
      </IconBox>
      <Typography sx={{ fontWeight: 600, marginBottom: "12px" }}>
        {selectedJobs.jobTitle}
      </Typography>
      <Box sx={{maxHeight:430,overflowY:"auto",marginBottom:"15px"}}>
      <ModalBox>
        <Typography sx={{ fontWeight: "bold" }}>About Company</Typography>
        <p style={{ fontFamily: "poppins" }}>
          It was popularised in the 1960s with the release of Letraset sheets
          containing Lorem Ipsum passages, and more recently with desktop
          publishing software like Aldus PageMaker including versions of Lorem
          Ipsum.
        </p>
        <Box sx={{ marginTop: "5px" }}>
          <Typography sx={{ fontWeight: "bold" }}>Role Description</Typography>
          <p style={{ fontFamily: "poppins" }}>
            It was popularised in the 1960s with the release of Letraset sheets
            containing Lorem Ipsum passages, and more recently with desktop
            publishing software like Aldus PageMaker including versions of Lorem
            Ipsum.
          </p>
        </Box>
        <Box sx={{ marginTop: "5px" }}>
          <Typography sx={{ fontWeight: "bold" }}>Responsibilities</Typography>
          <ul>
            <li style={{fontFamily:"poppins"}}>
              {" "}
              It was popularised in the 1960s with the release of Letraset
              sheets containing Lorem Ipsum passages, and more recently{" "}
            </li>
            <li style={{fontFamily:"poppins"}}>
              {" "}
              It was popularised in the 1960s with the release of Letraset
              sheets containing Lorem Ipsum passages, and more recently{" "}
            </li>
          </ul>
        </Box>
      </ModalBox>
      <PrequisteBox>
      <Typography sx={{ fontWeight: "bold" }}>
        Pre-requisite Certifications
      </Typography>
      <ItemBox>
       <Grid container spacing={2}>
        <Grid item xs={6} sm={6}>
        <ul>
          <li style={{fontFamily:"poppins"}}>6DLVI-001 Leadership and Initiative</li>
          <li style={{fontFamily:"poppins"}}>6DLVI-003 Digital Literacy</li>
          <li style={{fontFamily:"poppins"}}>6DLVI-005 Communication Skills (Listening, Written & Verbal)</li>
        </ul>
        </Grid>
        </Grid>
      </ItemBox>
    </PrequisteBox>
      <LengthBox>
        <Typography sx={{ fontWeight:600 }}>Stipend &nbsp;
          <span style={{fontWeight:"normal", color:"#7e7979",fontFamily:"poppins"}}>{selectedJobs.stipend}{"Per month"}</span>
          </Typography>
        <Typography sx={{ fontWeight:600 }}>
          Location &nbsp;
          <span style={{fontWeight:"normal", color:"#7e7979",fontFamily:"poppins"}}>{selectedJobs.workLocation}</span>
          </Typography>
        <Typography sx={{ fontWeight:600 }}>Work &nbsp;
        <span style={{fontWeight:"normal", color:"#7e7979",fontFamily:"poppins"}}>{selectedJobs.hiringPosition}</span>
       </Typography>
        <Typography sx={{ fontWeight:600 }}>No.of position &nbsp;
        <span style={{fontWeight:"normal", color:"#7e7979",fontFamily:"poppins"}}>{"20"}</span>
        </Typography>
        <Typography sx={{ fontWeight:600 }}>Position &nbsp;
           <span style={{fontWeight:"normal", color:"#7e7979",fontFamily:"poppins"}}>{selectedJobs.hiringPosition}</span>
        </Typography>
        <Typography sx={{ fontWeight:600 }}>Last Submission Date &nbsp;
        <span style={{fontWeight:"normal", color:"#7e7979",fontFamily:"poppins"}}>{selectedJobs.submission}</span>
        </Typography>
      </LengthBox>
      </Box>
      <ButtonBox>
        <CustomButton
          variant="primary"
          name={"Apply"}
          padding={"6px 12px"}
        />
      </ButtonBox>
    </MainBox>
  );
};

export default HiringModal;

const MainBox = styled(Box)`
  max-height: 550;
  overflow: auto;
  padding: 20px;
`;

const IconBox = styled(Box)`
  display: flex;
  justify-content: flex-end;
`;

const ModalBox = styled(Box)`
  background-color: #f0f0f0;
  display: flex;
  flex-direction: column;
  padding: 12px;
  border-radius: 5px;
`;

const LengthBox = styled(Box)`
  display: flex;
  flex-direction: row;
  padding: 30px 0 0 0 ;
  justify-content:space-between;
  align-items: center;
`;

const ButtonBox = styled(Box)`
  display: flex;
  justify-content: flex-end;
`;

const PrequisteBox = styled(Box)`
  background-color: #edf2f5;
  display: flex;
  flex-direction: column;
  padding: 12px;
  border-radius: 5px;
  margin-top: 10px;
  align-items: flex-start;
`;

const ItemBox = styled(Box)`
  display: flex;
  width:100%;
`;
