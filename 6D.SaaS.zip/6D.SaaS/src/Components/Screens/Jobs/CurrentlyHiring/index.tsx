import * as React from "react";
import CustomModal from "../../../Modal/CustomModal";
import HiringTable from "./HiringTable";
import HiringCard from "./HiringCard";
import HiringModal from "./HiringModal";

interface jobs {
  id: number;
  jobTitle: string;
  hiringCompany: string;
  workLocation: string;
  stipend: string;
  hiringPosition: string;
  submission: string;
  hiringDate: string;
}

interface toogle {
  jobsValue: boolean;
}
const CurrentlyHiring: React.FC<toogle> = ({ jobsValue }) => {
  const [selectedJobs, setSelectedJobs] = React.useState<jobs | null>(null);
  const [open, setOpen] = React.useState(false);

  const handleOpen = (jobs: jobs) => {
    setSelectedJobs(jobs);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedJobs(null);
  };
  const joblist: jobs[] = [
    {
      id: 1,
      jobTitle: "6DWRK-001 Shift Chemist",
      hiringCompany: "ABC Med Ltd",
      workLocation: "Hydrebad",
      stipend: "₹25k",
      hiringPosition: "Internship",
      submission: "5 oct 2024",
      hiringDate: "5 Nov 2024",
    },
    {
      id: 2,
      jobTitle: "6DWRK-002 Visual Inspector",
      hiringCompany: "Ankurash",
      workLocation: "Ahmedabad",
      stipend: "₹25k",
      hiringPosition: "Part Time",
      submission: "5 oct 2024",
      hiringDate: "5 Nov 2024",
    },
    {
      id: 3,
      jobTitle: "6DWRK-003 Warehouse Inspector",
      hiringCompany: "Medplus",
      workLocation: "Chennai",
      stipend: "₹20k",
      hiringPosition: "Full Time",
      submission: "TBD",
      hiringDate: "TBD",
    },
    {
      id: 4,
      jobTitle: "6DWRK-004 PO & PS Assistant",
      hiringCompany: "Reddiss",
      workLocation: "New Delhi",
      stipend: "₹25k",
      hiringPosition: "Contract",
      submission: "15 Sep 2024",
      hiringDate: "15 oct 2024",
    },
    {
      id: 5,
      jobTitle: "6DWRK-005 QA Analyst",
      hiringCompany: "ABC Med Ltd",
      workLocation: "Hydrebad",
      stipend: "₹25k",
      hiringPosition: "Internship",
      submission: "TBD",
      hiringDate: "TBD",
    },
    {
      id: 6,
      jobTitle: "6DWRK-006 Warehouse Operator",
      hiringCompany: "Ankurash",
      workLocation: "Ahmedabad",
      stipend: "₹25k",
      hiringPosition: "Contract",
      submission: "TBD",
      hiringDate: "TBD",
    },
    {
      id: 7,
      jobTitle: "6DWRK-007 QA Manager",
      hiringCompany: "Medplus",
      workLocation: "Chennai",
      stipend: "₹25k",
      hiringPosition: "Part Time",
      submission: "TBD",
      hiringDate: "TBD",
    },
    {
      id: 8,
      jobTitle: "6DWRK-008 Packers",
      hiringCompany: "Reddiss",
      workLocation: "New Delhi",
      stipend: "₹20k",
      hiringPosition: "Full Time",
      submission: "15 Jun 2024",
      hiringDate: "15 Jun 2024",
    },
  ];

  return (
    <>
      <CustomModal
        open={open}
        handleClose={() => handleClose()}
        sx={{ width: "70%", height: "auto", mt: 5}}
        child={
          <HiringModal selectedJobs={selectedJobs} handleClose={handleClose} />
        }
      />
      {jobsValue ? (
        <HiringTable joblist={joblist} handleModal={handleOpen} />
      ) : (
        <HiringCard joblist={joblist} handleModal={handleOpen} />
      )}
    </>
  );
};

export default CurrentlyHiring;
