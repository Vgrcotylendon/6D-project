import React, { useMemo, useState } from "react";
import Table from "@mui/material/Table";
import { styled } from "@mui/material/styles";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import PlayCircleOutlineRoundedIcon from "@mui/icons-material/PlayCircleOutlineRounded";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Checkbox from "@mui/material/Checkbox";
import {
  Box,
  Typography,
  IconButton,
  FormControlLabel,
} from "@mui/material";
import CustomButton from "../../../Button/CustomButton";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "#f0f0f0",
    color: "#5F5E5B",
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const label = { inputProps: { "aria-label": "Checkbox demo" } };

interface jobsHiring {
  id: number;
  jobTitle: string;
  hiringCompany: string;
  workLocation: string;
  stipend: string;
  hiringPosition: string;
  submission: string;
  hiringDate: string;
}
interface jobsprops {
  joblist: jobsHiring[];
  handleModal: (jobs: jobsHiring) => void;
}

const parseDate = (dateStr: string): Date => {
  if (dateStr === "TBD" || !dateStr) {
    return new Date(0); // Consider "TBD" as the earliest possible date
  }
  const [day, month, year] = dateStr.split(" ");
  const monthIndex = new Date(`${month} 1`).getMonth();
  return new Date(parseInt(year), monthIndex, parseInt(day));
};

const parseStipend = (stipendStr: string): number => {
  let numericValue = stipendStr.replace(/[^0-9kK]/g, "");
  if (numericValue.includes("k") || numericValue.includes("K")) {
    numericValue = numericValue.replace(/[kK]/g, "");
    return parseFloat(numericValue) * 1000;
  }
  return parseFloat(numericValue);
};

const HiringTable: React.FC<jobsprops> = ({ joblist, handleModal }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const jobsPerPage = 5;
  const [isReversed, setIsReversed] = useState(false);
  const [isReverseOrder, setIsReverseOrder] = useState(false);
  const [isReverseLocation, setIsReverseLocation] = useState(false);
  const [isReverseStipend, setIsReverseStipend] = useState(false);
  const [isSortDate, setIsSortDate] = useState(false);
  const [isHiringDate, setIsHiringDate] = useState(false);
  const [isSortPosition, setIsSortPosition] = useState(false);
  const [hiringFilter, setHiringFilter] = React.useState<
    null | "Internship" | "Part Time" | "Contract" | "Full Time"
  >(null);

  const handleJobTitle = () => {
    setIsReversed(!isReversed);
    setIsReverseOrder(false);
    setIsReverseLocation(false);
    setIsReverseStipend(false);
    setHiringFilter(null);
    setIsSortPosition(false);
    setIsSortDate(false);
    setIsHiringDate(false);
  };

  const handleJobCompany = () => {
    setIsReverseOrder(!isReverseOrder);
    setIsReversed(false);
    setIsReverseLocation(false);
    setIsReverseStipend(false);
    setHiringFilter(null);
    setIsSortPosition(false);
    setIsSortDate(false);
    setIsHiringDate(false);
  };

  const handleJobLocation = () => {
    setIsReverseLocation(!isReverseLocation);
    setIsReversed(false);
    setIsReverseOrder(false);
    setIsReverseStipend(false);
    setHiringFilter(null);
    setIsSortPosition(false);
    setIsSortDate(false);
    setIsHiringDate(false);
  };

  const handleJobStipend = () => {
    setIsReverseStipend(!isReverseStipend);
    setIsReversed(false);
    setIsReverseOrder(false);
    setIsReverseLocation(false);
    setHiringFilter(null);
    setIsSortPosition(false);
    setIsSortDate(false);
    setIsHiringDate(false);
  };

  const handleJobPosition = () => {
    setIsSortPosition(!isSortPosition);
    setIsReversed(false);
    setIsReverseOrder(false);
    setIsReverseLocation(false);
    setHiringFilter(null);
    setIsReverseStipend(false);
    setIsSortDate(false);
    setIsHiringDate(false);
  };

  const handleJobDate = () => {
    setIsSortDate(!isSortDate);
    setIsReversed(false);
    setIsReverseOrder(false);
    setIsReverseLocation(false);
    setHiringFilter(null);
    setIsReverseStipend(false);
    setIsSortPosition(false);
    setIsHiringDate(false);
  };

  const handleJobHiringDate = () => {
    setIsHiringDate(!isHiringDate);
    setIsReversed(false);
    setIsReverseOrder(false);
    setIsReverseLocation(false);
    setHiringFilter(null);
    setIsReverseStipend(false);
    setIsSortPosition(false);
    setIsSortDate(false);
  };

  const handleHiringPositionChange = (
    hiringPosition: "Internship" | "Part Time" | "Contract" | "Full Time"
  ) => {
    setHiringFilter(hiringFilter === hiringPosition ? null : hiringPosition);
  };

  const currentJobsList = useMemo(() => {
    let hiringJobs = [...joblist];
    if (isReversed) {
      hiringJobs.reverse();
    }
    if (isReverseOrder) {
      hiringJobs.sort((a, b) => a.hiringCompany.localeCompare(b.hiringCompany));
    }
    if (isReverseLocation) {
      hiringJobs.sort((a, b) => a.workLocation.localeCompare(b.workLocation));
    }
    if (isReverseStipend) {
      hiringJobs.sort(
        (a, b) => parseStipend(a.stipend) - parseStipend(b.stipend)
      );
    }
    if (hiringFilter) {
      hiringJobs.sort((a, b) => (a.hiringPosition === hiringFilter ? -1 : 1));
    }
    if (isSortDate) {
      hiringJobs.sort(
        (a, b) =>
          parseDate(a.submission).getTime() - parseDate(b.submission).getTime()
      );
    }
    if (isHiringDate) {
      hiringJobs.sort(
        (a, b) =>
          parseDate(a.hiringDate).getTime() - parseDate(b.hiringDate).getTime()
      );
    }
    return hiringJobs;
  }, [
    joblist,
    isReversed,
    isReverseOrder,
    isReverseLocation,
    isReverseStipend,
    hiringFilter,
    isSortDate,
    isHiringDate,
  ]);

  const indexOfLastJob = currentPage * jobsPerPage;
  const indexOfFirstJob = indexOfLastJob - jobsPerPage;
  const currentJobs = currentJobsList.slice(indexOfFirstJob, indexOfLastJob);

  const totalPages = Math.ceil(joblist.length / jobsPerPage);

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  const renderPageNumbers = (totalPages: number): JSX.Element[] => {
    const pageNumbers: JSX.Element[] = [];

    const firstRange = 3;
    const lastRange = 3;

    for (let i = 1; i <= Math.min(firstRange, totalPages); i++) {
      pageNumbers.push(
        <Typography sx={{ marginLeft: "20px" }} key={i}>
          {i}
        </Typography>
      );
    }

    if (totalPages > firstRange + lastRange) {
      pageNumbers.push(
        <Typography sx={{ marginLeft: "40px" }} key="ellipsis-start">
          ...
        </Typography>
      );
    }

    const startLastRange = Math.max(totalPages - lastRange + 1, firstRange + 1);
    for (let i = startLastRange; i <= totalPages; i++) {
      pageNumbers.push(
        <Typography sx={{ marginLeft: "40px" }} key={i}>
          {i}
        </Typography>
      );
    }
    return pageNumbers;
  };

  return (
    <>
      <MainBox>
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
            <TableHead>
              <TableRow>
                <StyledTableCell
                  sx={{ borderLeft: "1px solid #d6d6d3", width: "20px" }}
                >
                  <Box sx={{ padding: "30px 0 10px 0" }}>
                    <Checkbox {...label} />
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
                >
                  <HeaderBox>
                    Job
                    <br /> Title
                    <IconButton onClick={handleJobTitle}>
                      <KeyboardArrowDownIcon
                        sx={{
                          color: isReversed ? "#919599" : "#929396",
                          transform: isReversed ? "rotate(180deg)" : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </HeaderBox>
                </StyledTableCell>
                <StyledTableCell
                  sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
                >
                  <HeaderBox>
                    Hiring
                    <br /> Company
                    <IconButton onClick={handleJobCompany}>
                      <KeyboardArrowDownIcon
                        sx={{
                          color: isReverseOrder ? "#919599" : "#929396",
                          transform: isReverseOrder ? "rotate(180deg)" : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </HeaderBox>
                </StyledTableCell>
                <StyledTableCell
                  sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
                >
                  <HeaderBox>
                    Work <br />
                    Location
                    <IconButton onClick={handleJobLocation}>
                      <KeyboardArrowDownIcon
                        sx={{
                          color: isReverseLocation ? "#919599" : "#929396",
                          transform: isReverseLocation
                            ? "rotate(180deg)"
                            : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </HeaderBox>
                </StyledTableCell>
                <StyledTableCell
                  sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
                >
                  <HeaderBox>
                    Stipend <br />
                    Per month
                    <IconButton onClick={handleJobStipend}>
                      <KeyboardArrowDownIcon
                        sx={{
                          color: isReverseStipend ? "#919599" : "#929396",
                          transform: isReverseStipend
                            ? "rotate(180deg)"
                            : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </HeaderBox>
                </StyledTableCell>
                <StyledTableCell
                  sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
                >
                  <HeaderBox>
                    Hiring <br />
                    Position
                    <IconButton onClick={handleJobPosition}>
                      <KeyboardArrowDownIcon
                        sx={{
                          color: isSortPosition ? "#919599" : "#929396",
                          transform: isSortPosition ? "rotate(180deg)" : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </HeaderBox>
                  {isSortPosition && (
                    <StatusBox>
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={hiringFilter === "Internship"}
                            onChange={() =>
                              handleHiringPositionChange("Internship")
                            }
                          />
                        }
                        label="Internship"
                      />
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={hiringFilter === "Part Time"}
                            onChange={() =>
                              handleHiringPositionChange("Part Time")
                            }
                          />
                        }
                        label="Part Time"
                      />
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={hiringFilter === "Contract"}
                            onChange={() =>
                              handleHiringPositionChange("Contract")
                            }
                          />
                        }
                        label="Contract"
                      />
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={hiringFilter === "Full Time"}
                            onChange={() =>
                              handleHiringPositionChange("Full Time")
                            }
                          />
                        }
                        label="Full Time"
                      />
                    </StatusBox>
                  )}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
                >
                  <HeaderBox>
                    Submission <br />
                    Date
                    <IconButton onClick={handleJobDate}>
                      <KeyboardArrowDownIcon
                        sx={{
                          color: isSortDate ? "#919599" : "#929396",
                          transform: isSortDate ? "rotate(180deg)" : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </HeaderBox>
                </StyledTableCell>
                <StyledTableCell
                  sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
                >
                  <HeaderBox>
                    Hiring <br />
                    Date
                    <IconButton onClick={handleJobHiringDate}>
                      <KeyboardArrowDownIcon
                        sx={{
                          color: isHiringDate ? "#919599" : "#929396",
                          transform: isHiringDate ? "rotate(180deg)" : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </HeaderBox>
                </StyledTableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {currentJobs.map((jobs: jobsHiring) => (
                <TableRow key={jobs.id}>
                  <TableCell sx={{ border: "1px solid #f0f0f0" }}>
                    <Checkbox {...label} />
                  </TableCell>
                  <TableCell
                    align="left"
                    sx={{
                      border: "1px solid #f0f0f0",
                      color: "info.main",
                      cursor: "pointer",
                    }}
                  >
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "start",
                        cursor: "pointer",
                      }}
                      onClick={() => handleModal(jobs)}
                    >
                      {jobs.jobTitle}&nbsp;&nbsp;
                      <PlayCircleOutlineRoundedIcon
                        style={{ color: "info.main", fontSize: "18px" }}
                      />
                    </Box>
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid #f0f0f0",
                      textAlign: "center",
                      color: "#5F5E5B",
                    }}
                  >
                    {jobs.hiringCompany}
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid #f0f0f0",
                      textAlign: "center",
                      color: "#5F5E5B",
                    }}
                  >
                    {jobs.workLocation}
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid #f0f0f0",
                      textAlign: "center",
                      color: "#5F5E5B",
                    }}
                  >
                    {jobs.stipend}
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid #f0f0f0",
                      textAlign: "center",
                      color: "#5F5E5B",
                    }}
                  >
                    <Typography
                      sx={{
                        borderRadius: "4px",
                        bgcolor:
                          jobs.hiringPosition === "Internship"
                            ? "#FFE6F2"
                            : jobs.hiringPosition === "Part Time"
                            ? "#EEE6FF"
                            : jobs.hiringPosition === "Full Time"
                            ? "#E6FAFA"
                            : jobs.hiringPosition === "Contract"
                            ? "#F5F5F5"
                            : undefined,
                        padding: "5px 5px",
                      }}
                    >
                      {jobs.hiringPosition}
                    </Typography>
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid #f0f0f0",
                      textAlign: "center",
                      color: "#5F5E5B",
                    }}
                  >
                    {jobs.submission}
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid #f0f0f0",
                      textAlign: "center",
                      color: "#5F5E5B",
                    }}
                  >
                    {jobs.hiringDate}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            margin: "20px",
          }}
        >
          <CustomButton
          variant="secondary"
          name={"Previous"}
          padding={"8px 14px"}
          startIcon={<ArrowBackIcon />}
          onClick={handlePreviousPage}
          disabled={currentPage === 1}
        />
          {/* <Typography>
            Page {currentPage} of {totalPages}
          </Typography> */}
          <Box sx={{ display: "flex", alignItems: "center" }}>
            {renderPageNumbers(totalPages)}
          </Box>
          <CustomButton
          variant="secondary"
          name={"Next"}
          padding={"8px 14px"}
          endIcon={<ArrowForwardIcon />}
          onClick={handleNextPage}
          disabled={currentPage === totalPages}
        />
        </Box>
      </MainBox>
    </>
  );
};

export default HiringTable;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  height: 88vh;
  justify-content: space-between;
`;
const HeaderBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content:space-between;
  padding:30px 0 10px 0;
  line-height: 1.5;
`;
const StatusBox = styled(Box)`
  display:flex;
  align-items: center;
  flex-direction: row;
  justify-content:space-evenly;
`;
