import { Container, Grid, Box, Typography, IconButton } from "@mui/material";
import React,{useState} from "react";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { styled } from "@mui/system";
import clsx from "clsx";
import CustomButton from "../../../Button/CustomButton";

interface jobs {
  id: number;
  jobTitle: string;
  hiringCompany: string;
  workLocation: string;
  stipend: string;
  hiringPosition: string;
  submission: string;
  hiringDate: string;
}
interface Detail {
  head: string;
  child: React.ReactNode;
}
interface jobsprops {
  joblist: jobs[];
  handleModal: (jobs: jobs) => void;
}

const HiringCard: React.FC<jobsprops> = ({ joblist, handleModal }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const jobsPerPage = 4;

  const indexOfLastJob = currentPage * jobsPerPage;
  const indexOfFirstJob = indexOfLastJob - jobsPerPage;
  const currentJobs = joblist.slice(indexOfFirstJob, indexOfLastJob);

  const totalPages = Math.ceil(joblist.length / jobsPerPage);

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage -1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };
  const renderPageNumbers = (totalPages: number): JSX.Element[] => {
    const pageNumbers: JSX.Element[] = [];
    
    const firstRange = 3;
    const lastRange = 3;

    for (let i = 1; i <= Math.min(firstRange, totalPages); i++) {
        pageNumbers.push(
            <Typography sx={{ marginLeft: "20px" }} key={i}>
                {i}
            </Typography>
        );
    }

    if (totalPages > firstRange + lastRange) {
        pageNumbers.push(
            <Typography sx={{ marginLeft: "40px" }} key="ellipsis-start">
                ...
            </Typography>
        );
    }

    const startLastRange = Math.max(totalPages - lastRange + 1, firstRange + 1);
    for (let i = startLastRange; i <= totalPages; i++) {
        pageNumbers.push(
            <Typography sx={{ marginLeft: "40px" }} key={i}>
                {i}
            </Typography>
        );
    }
    return pageNumbers;
};
  const Details: React.FC<Detail> = ({ head, child }) => {
    return (
      <DetailBox>
        <Typography className="ApplyNowHead">{head}</Typography>

        {head === "Hiring Position" ? (
          child
        ) : (
          <Typography className="ApplyNow ">{child}</Typography>
        )}
      </DetailBox>
    );
  };

  return (
    <Container maxWidth="xl">
      <CustomBox sx={{ marginTop: 8, marginBottom: 8 }}>
        <Grid container spacing={4}>
          {currentJobs.map((jobs) => (
            <Grid item xs={6}>
              <CourseBox>
                <CourseNameBox onClick={() => handleModal(jobs)}>
                  <Typography className="courseName" color="info.main">
                    {jobs.jobTitle}
                  </Typography>
                  <IconButton className="getCertified">
                    <ChevronRightIcon />
                  </IconButton>
                </CourseNameBox>
                <DBox>
                  <Details head={"Hiring Company"} child={jobs.jobTitle} />
                  <Details head={"Work Location"} child={jobs.hiringCompany} />
                  <Details head={"Work Location"} child={jobs.workLocation} />
                  <Details
                    head={"Submission Deadline"}
                    child={jobs.submission}
                  />
                  <Details head={"Hiring Date"} child={jobs.hiringDate} />
                  <Details head={"Stipend (per month)"} child={jobs.stipend} />
                  <Details
                    head={"Hiring Position"}
                    child={
                      <Typography
                        className={clsx("ApplyPosition", {
                          intern: jobs.hiringPosition === "Internship",
                          partTime: jobs.hiringPosition === "Part Time",
                          fullTime: jobs.hiringPosition === "Full Time",
                          contract: jobs.hiringPosition === "Contract",
                        })}
                      >
                        {jobs.hiringPosition}
                      </Typography>
                    }
                  />
                </DBox>
              </CourseBox>
            </Grid>
          ))}
        </Grid>
      </CustomBox>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "20px",
        }}
      >
        <CustomButton
          variant="secondary"
          name={"Previous"}
          padding={"8px 14px"}
          startIcon={<ArrowBackIcon />}
          onClick={handlePreviousPage}
          disabled={currentPage === 1}
        />
        {/* <Typography>
          Page {currentPage} of {totalPages}
        </Typography> */}
         <Box sx={{ display: "flex", alignItems: "center" }}>{renderPageNumbers(totalPages)}</Box>
        <CustomButton
          variant="secondary"
          name={"Next"}
          padding={"8px 14px"}
          endIcon={<ArrowForwardIcon />}
          onClick={handleNextPage}
          disabled={currentPage === totalPages}
        />
      </Box>
    </Container>
  );
};

export default HiringCard;

const CustomBox = styled(Box)`
  border: 2px solid white;
  border-radius: 3px;
  display: flex;
  height: 100%;
  padding: 30px;
`;

const CourseBox = styled(Box)`
  background-color: white;
  padding: 15px;
  /* margin: 15px; */
  width: 95%;
  min-width: 400px;
  border-radius: 7px;
`;
const CourseNameBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background-color: #f5f5f5;
  border-radius: 7px;
`;
const DetailBox = styled(Box)`
  width: 100%;
  display: flex;
  padding: 3px;
`;
const DBox = styled(Box)`
  padding: 5px;
`;
