import {
  FormControlLabel,
  IconButton,
  Table,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import TableBody from "@mui/material/TableBody";
import { tableCellClasses } from "@mui/material/TableCell";
import TimelapseIcon from "@mui/icons-material/Timelapse";
import VerifiedIcon from "@mui/icons-material/Verified";
import CancelIcon from "@mui/icons-material/Cancel";
import DoDisturbOnIcon from "@mui/icons-material/DoDisturbOn";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import PlayCircleOutlineRoundedIcon from "@mui/icons-material/PlayCircleOutlineRounded";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import Paper from "@mui/material/Paper";
import Checkbox from "@mui/material/Checkbox";
import { Box } from "@mui/material";
import React, { useState } from "react";
import CustomButton from "../../../Button/CustomButton";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "#f0f0f0",
    color: "#5F5E5B",
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));
const label = { inputProps: { "aria-label": "Checkbox demo" } };

interface job {
  applicationId: string;
  status: string;
  submissionDate: string;
  daysToSubmit: string;
  jobTitle: string;
  hiringPosition: string;
  appliedDate: string;
  hiringStatus: string;
}

interface applicationProps {
  data: job[];
  handleModal: any;
}

const ApplicationTable: React.FC<applicationProps> = ({
  data,
  handleModal,
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const applicationPerPage = 5;
  const [isReversed, setIsReversed] = useState(false);
  const [isSortStatus, setIsSortStatus] = useState(false);
  const [statusFilter, setStatusFilter] = React.useState<
    null | "InProgress" | "Submitted" | "DisQualified"
  >(null);
  const [isSortDate, setIsSortDate] = useState(false);
  const [isSortDays, setIsSortDays] = useState(false);
  const [isReverseJob, setIsReverseJob] = useState(false);
  const [isSortHiring, setIsSortHiring] = useState(false);
  const [isSortApplyDate, setIsSortApplyDate] = useState(false);
  const [hiringFilter, setHiringFilter] = React.useState<
    null | "Internship" | "Part Time" | "Contract" | "Full Time"
  >(null);
  const [isSortHiringStatus, setIsSortHiringSatus] = useState(false);
  const [hiringSatusFilter, setHiringstatusFilter] = React.useState<
    null | "Open" | "Closed" 
  >(null);

  const handleTitleReverse = () => {
    setIsReversed(!isReversed);
    setIsSortStatus(false);
    setStatusFilter(null);
    setIsSortDate(false);
    setIsSortDays(false);
    setIsReverseJob(false);
    setIsSortHiring(false);
    setHiringFilter(null);
    setIsSortApplyDate(false);
    setIsSortHiringSatus(false);
    setHiringstatusFilter(null);
  };

  const handleStatus = () => {
    setIsSortStatus(!isSortStatus);
    setIsReversed(false);
    setStatusFilter(null);
    setIsSortDate(false);
    setIsSortDays(false);
    setIsReverseJob(false);
    setIsSortHiring(false);
    setHiringFilter(null);
    setIsSortApplyDate(false);
    setIsSortHiringSatus(false);
    setHiringstatusFilter(null);
  };

  const handleStatusFilterChange = (
    status: "InProgress" | "Submitted" | "DisQualified"
  ) => {
    setStatusFilter(statusFilter === status ? null : status);
  };

  const parseDate = (dateStr: string): Date => {
    if (!dateStr) return new Date(0);
    const [day, month, year] = dateStr.split(" ");
    const monthIndex = new Date(`${month} 1`).getMonth();
    return new Date(parseInt(year), monthIndex, parseInt(day));
  };

  const parseDaysToSubmit = (daysStr: string): number => {
    return parseInt(daysStr.split(" ")[0], 10);
  };

  const handleFilterDate = () => {
    setIsSortDate(!isSortDate);
    setIsReversed(false);
    setStatusFilter(null);
    setIsSortStatus(false);
    setIsSortDays(false);
    setIsReverseJob(false);
    setIsSortHiring(false);
    setHiringFilter(null);
    setIsSortApplyDate(false);
    setIsSortHiringSatus(false);
    setHiringstatusFilter(null);
  };

  const handleSortDays = () => {
    setIsSortDays(!isSortDays);
    setIsReversed(false);
    setStatusFilter(null);
    setIsSortStatus(false);
    setIsSortDate(false);
    setIsReverseJob(false);
    setIsSortHiring(false);
    setHiringFilter(null);
    setIsSortApplyDate(false);
    setIsSortHiringSatus(false);
    setHiringstatusFilter(null);
  };

  const handleReverseJobs = () => {
    setIsReverseJob(!isReverseJob);
    setIsReversed(false);
    setStatusFilter(null);
    setIsSortStatus(false);
    setIsSortDate(false);
    setIsSortDays(false);
    setIsSortHiring(false);
    setHiringFilter(null);
    setIsSortApplyDate(false);
    setIsSortHiringSatus(false);
    setHiringstatusFilter(null);
  };

  const handleHiringFilterChange = (
    hiringPosition: "Internship" | "Part Time" | "Contract" | "Full Time"
  ) => {
    setHiringFilter(hiringFilter === hiringPosition ? null : hiringPosition);
  };

  const handleHiringFilter = () => {
    setIsSortHiring(!isSortHiring);
    setIsReversed(false);
    setIsSortStatus(false);
    setStatusFilter(null);
    setHiringFilter(null);
    setIsSortDate(false);
    setIsSortDays(false);
    setIsReverseJob(false);
    setIsSortApplyDate(false);
    setIsSortHiringSatus(false);
    setHiringstatusFilter(null);
  };

  const handleSortAppliedDate = () => {
    setIsSortApplyDate(!isSortApplyDate);
    setIsReversed(false);
    setIsSortStatus(false);
    setStatusFilter(null);
    setHiringFilter(null);
    setIsSortDate(false);
    setIsSortDays(false);
    setIsReverseJob(false);
    setIsSortHiring(false);
    setIsSortHiringSatus(false);
    setHiringstatusFilter(null);
  };

const handleHiringStatus = () =>{
  setIsSortHiringSatus(!isSortHiringStatus);
  setIsReversed(false);
  setIsSortStatus(false);
  setStatusFilter(null);
  setHiringFilter(null);
  setIsSortDate(false);
  setIsSortDays(false);
  setIsReverseJob(false);
  setIsSortHiring(false);
  setHiringstatusFilter(null);
  setIsSortApplyDate(false);
}

const handleHiringSatusChange = (
  hiringStatus:  "Open" | "Closed" 
) => {
  setHiringstatusFilter(hiringSatusFilter === hiringStatus ? null : hiringStatus);
};

  const handleOpen = () => {
    handleModal();
  };
  
  const ApplicationDataList = React.useMemo(() => {
    let dataList = [...data];
    if (isReversed) {
      dataList.reverse();
    }
    if (isReverseJob) {
      dataList.reverse();
    }
    if (statusFilter) {
      dataList.sort((a, b) => (a.status === statusFilter ? -1 : 1));
    }
    if (hiringFilter) {
      dataList.sort((a, b) => (a.hiringPosition === hiringFilter ? -1 : 1));
    }
    if (hiringSatusFilter) {
      dataList.sort((a, b) => (a.hiringStatus === hiringSatusFilter ? -1 : 1));
    }
    if (isSortDate) {
      dataList.sort(
        (a, b) =>
          parseDate(a.submissionDate).getTime() -
          parseDate(b.submissionDate).getTime()
      );
    }
    if (isSortApplyDate) {
      dataList.sort(
        (a, b) =>
          parseDate(a.appliedDate).getTime() -
          parseDate(b.appliedDate).getTime()
      );
    }
    if (isSortDays) {
      dataList.sort(
        (a, b) =>
          parseDaysToSubmit(a.daysToSubmit) - parseDaysToSubmit(b.daysToSubmit)
      );
    }
    return dataList;
  }, [
    data,
    isReversed,
    statusFilter,
    isSortDate,
    isSortDays,
    isReverseJob,
    hiringFilter,
    isSortApplyDate,
    hiringSatusFilter
  ]);

  const indexOfLastJob = currentPage * applicationPerPage;
  const indexOfFirstJob = indexOfLastJob - applicationPerPage;
  const currentApplication = ApplicationDataList.slice(indexOfFirstJob, indexOfLastJob);

  const totalPages = Math.ceil(data.length / applicationPerPage);

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  const renderPageNumbers = (totalPages: number): JSX.Element[] => {
    const pageNumbers: JSX.Element[] = [];

    const firstRange = 3;
    const lastRange = 3;

    for (let i = 1; i <= Math.min(firstRange, totalPages); i++) {
      pageNumbers.push(
        <Typography sx={{ marginLeft: "20px" }} key={i}>
          {i}
        </Typography>
      );
    }

    if (totalPages > firstRange + lastRange) {
      pageNumbers.push(
        <Typography sx={{ marginLeft: "40px" }} key="ellipsis-start">
          ...
        </Typography>
      );
    }

    const startLastRange = Math.max(totalPages - lastRange + 1, firstRange + 1);
    for (let i = startLastRange; i <= totalPages; i++) {
      pageNumbers.push(
        <Typography sx={{ marginLeft: "40px" }} key={i}>
          {i}
        </Typography>
      );
    }
    return pageNumbers;
  };

  return (
    <MainBox>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
          <TableHead>
            <TableRow>
              <StyledTableCell
                sx={{ borderLeft: "1px solid #d6d6d3", width: "20px" }}
              >
                <Box sx={{ padding:"30px 0 10px 0"}}>
                <Checkbox {...label} />
                </Box>
              </StyledTableCell>
              <StyledTableCell
                sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
              >
                <ApplicationBox>
                  Application
                  <br /> ID
                  <IconButton onClick={handleTitleReverse}>
                    <KeyboardArrowDownIcon
                      sx={{
                        color: isReversed ? "#919599" : "#929396",
                        transform: isReversed ? "rotate(180deg)" : "none",
                        transition: "transform 0.2s ease",
                      }}
                    />
                  </IconButton>
                </ApplicationBox>
              </StyledTableCell>

              <StyledTableCell
                sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
              >
                <ApplicationBox>
                  Application <br />
                  Status
                  <IconButton onClick={handleStatus}>
                    <KeyboardArrowDownIcon
                      sx={{
                        color: isSortStatus ? "#919599" : "#929396",
                        transform: isSortStatus ? "rotate(180deg)" : "none",
                        transition: "transform 0.2s ease",
                      }}
                    />
                  </IconButton>
                </ApplicationBox>
                {isSortStatus && (
                  <StatusBox>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={statusFilter === "Submitted"}
                          onChange={() => handleStatusFilterChange("Submitted")}
                        />
                      }
                      label="Submitted"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={statusFilter === "DisQualified"}
                          onChange={() =>
                            handleStatusFilterChange("DisQualified")
                          }
                        />
                      }
                      label="DisQualified"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={statusFilter === "InProgress"}
                          onChange={() =>
                            handleStatusFilterChange("InProgress")
                          }
                        />
                      }
                      label="InProgress"
                    />
                  </StatusBox>
                )}
              </StyledTableCell>
              <StyledTableCell
                sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
              >
                <ApplicationBox >
                  Submission <br />
                  Date
                  <IconButton onClick={handleFilterDate}>
                    <KeyboardArrowDownIcon
                      sx={{
                        color: isSortDate ? "#919599" : "#929396",
                        transform: isSortDate ? "rotate(180deg)" : "none",
                        transition: "transform 0.2s ease",
                      }}
                    />
                  </IconButton>
                </ApplicationBox>
              </StyledTableCell>
              <StyledTableCell
                sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
              >
                <ApplicationBox >
                  Days to <br />
                  Submission
                  <IconButton onClick={handleSortDays}>
                    <KeyboardArrowDownIcon
                      sx={{
                        color: isSortDays ? "#919599" : "#929396",
                        transform: isSortDays ? "rotate(180deg)" : "none",
                        transition: "transform 0.2s ease",
                      }}
                    />
                  </IconButton>
                </ApplicationBox>
              </StyledTableCell>
              <StyledTableCell
                sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
              >
                <ApplicationBox>
                  Job <br />
                  Title
                  <IconButton onClick={handleReverseJobs}>
                    <KeyboardArrowDownIcon
                      sx={{
                        color: isReverseJob ? "#919599" : "#929396",
                        transform: isReverseJob ? "rotate(180deg)" : "none",
                        transition: "transform 0.2s ease",
                      }}
                    />
                  </IconButton>
                </ApplicationBox>
              </StyledTableCell>
              <StyledTableCell
                sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
              >
                <ApplicationBox >
                  Hiring <br />
                  Position
                  <IconButton onClick={handleHiringFilter}>
                    <KeyboardArrowDownIcon
                      sx={{
                        color: isSortHiring ? "#919599" : "#929396",
                        transform: isSortHiring ? "rotate(180deg)" : "none",
                        transition: "transform 0.2s ease",
                      }}
                    />
                  </IconButton>
                </ApplicationBox>
                {isSortHiring && (
                  <StatusBox >
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={hiringFilter === "Internship"}
                          onChange={() =>
                            handleHiringFilterChange("Internship")
                          }
                        />
                      }
                      label="Internship"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={hiringFilter === "Part Time"}
                          onChange={() => handleHiringFilterChange("Part Time")}
                        />
                      }
                      label="Part Time"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={hiringFilter === "Contract"}
                          onChange={() => handleHiringFilterChange("Contract")}
                        />
                      }
                      label="Contract"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={hiringFilter === "Full Time"}
                          onChange={() => handleHiringFilterChange("Full Time")}
                        />
                      }
                      label="Full Time"
                    />
                  </StatusBox>
                )}
              </StyledTableCell>
              <StyledTableCell
                sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
              >
                <ApplicationBox>
                  Applied <br />
                  Date
                  <IconButton onClick={handleSortAppliedDate}>
                    <KeyboardArrowDownIcon
                      sx={{
                        color: isSortApplyDate ? "#919599" : "#929396",
                        transform: isSortApplyDate ? "rotate(180deg)" : "none",
                        transition: "transform 0.2s ease",
                      }}
                    />
                  </IconButton>
                </ApplicationBox>
              </StyledTableCell>
              <StyledTableCell
                sx={{ borderLeft: "1px solid #d6d6d3", cursor: "pointer" }}
              >
                <ApplicationBox >
                  Hiring <br />
                  Status
                  <IconButton onClick={handleHiringStatus}>
                    <KeyboardArrowDownIcon
                      sx={{
                        color: isSortHiringStatus ? "#919599" : "#929396",
                        transform: isSortHiringStatus ? "rotate(180deg)" : "none",
                        transition: "transform 0.2s ease",
                      }}
                    />
                  </IconButton>
                </ApplicationBox>
                {isSortHiringStatus && (
                  <StatusBox>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={hiringSatusFilter === "Open"}
                          onChange={() => handleHiringSatusChange("Open")}
                        />
                      }
                      label="Open"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={hiringSatusFilter === "Closed"}
                          onChange={() =>
                            handleHiringSatusChange("Closed")
                          }
                        />
                      }
                      label="Closed"
                    />
                   </StatusBox>
                )}
              </StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {currentApplication.map((item, index) => (
              <TableRow key={index}>
                <TableCell sx={{ border: "1px solid #f0f0f0" }}>
                  <Checkbox {...label} />
                </TableCell>
                <TableCell
                  align="left"
                  sx={{
                    border: "1px solid #f0f0f0",
                    color: "info.main",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "start",
                      cursor: "pointer",
                    }}
                    onClick={() => handleOpen()}
                  >
                    {item.applicationId}&nbsp;&nbsp;
                    <PlayCircleOutlineRoundedIcon
                      style={{ color: "info.main", fontSize: "18px" }}
                    />
                  </Box>
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid #f0f0f0",
                    textAlign: "center",
                    color: "#5F5E5B",
                  }}
                >
                  {(item.status === "Submitted" && (
                    <IconButton className="Certify" sx={{ color: "#48A055" }}>
                      <VerifiedIcon sx={{ width: 16 }} /> &nbsp;{item.status}
                    </IconButton>
                  )) ||
                    (item.status === "DisQualified" && (
                      <IconButton className="Certify" sx={{ color: "#BF1932" }}>
                        <CancelIcon sx={{ width: 16 }} /> &nbsp; {item.status}
                      </IconButton>
                    )) ||
                    (item.status === "InProgress" && (
                      <IconButton className="Certify" sx={{ color: "#ef5c00" }}>
                        <TimelapseIcon sx={{ width: 16 }} /> &nbsp;{" "}
                        {item.status}
                      </IconButton>
                    ))}
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid #f0f0f0",
                    textAlign: "center",
                    color: "#5F5E5B",
                  }}
                >
                  {item.submissionDate}
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid #f0f0f0",
                    textAlign: "center",
                    color: "#5F5E5B",
                  }}
                >
                  {item.daysToSubmit}
                </TableCell>

                <TableCell
                  sx={{
                    border: "1px solid #f0f0f0",
                    textAlign: "left",
                    color: "info.main"
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "start",
                      cursor: "pointer",
                    }}
                    onClick={() => handleOpen()}
                  >
                  {item.jobTitle}
                  &nbsp;&nbsp;
                    <PlayCircleOutlineRoundedIcon
                      style={{ color: "info.main", fontSize: "18px" }}
                    />
                    </Box>
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid #f0f0f0",
                    textAlign: "center",
                    color: "#5F5E5B",
                  }}
                >
                  {" "}
                  <Typography
                    sx={{
                      borderRadius:"4px",
                      bgcolor:
                        item.hiringPosition === "Internship"
                          ? "#FFE6F2"
                          : item.hiringPosition === "Part Time"
                          ? "#EEE6FF"
                          : item.hiringPosition === "Full Time"
                          ? "#E6FAFA"
                          : item.hiringPosition === "Contract"
                          ? "#F5F5F5"
                          : undefined,
                      padding: "5px 5px",
                    }}
                  >
                    {item.hiringPosition}
                  </Typography>
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid #f0f0f0",
                    textAlign: "center",
                    color: "#5F5E5B",
                  }}
                >
                  {item.appliedDate}
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid #f0f0f0",
                    textAlign: "center",
                    color: "#5F5E5B",
                  }}
                >
                  {(item.hiringStatus === "Open" && (
                    <IconButton className="Certify" sx={{ color: "#48A055" }}>
                      <CheckCircleIcon sx={{ width: 16 }} /> &nbsp;Open
                    </IconButton>
                  )) ||
                    (item.hiringStatus === "Closed" && (
                      <IconButton className="Certify" sx={{ color: "#BF1932" }}>
                        <DoDisturbOnIcon sx={{ width: 16 }} /> &nbsp;Closed
                      </IconButton>
                    ))}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            margin: "20px",
          }}
        >
         <CustomButton
          variant="secondary"
          name={"Previous"}
          padding={"8px 14px"}
          startIcon={<ArrowBackIcon />}
          onClick={handlePreviousPage}
          disabled={currentPage === 1}
        />
          {/* <Typography>
            Page {currentPage} of {totalPages}
          </Typography> */}
          <Box sx={{ display: "flex", alignItems: "center" }}>
            {renderPageNumbers(totalPages)}
          </Box>
          <CustomButton
          variant="secondary"
          name={"Next"}
          padding={"8px 14px"}
          endIcon={<ArrowForwardIcon />}
          onClick={handleNextPage}
          disabled={currentPage === totalPages}
        />
        </Box>
    </MainBox>
  );
};

export default ApplicationTable;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  height:88vh;
  justify-content: space-between;
`;
const ApplicationBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding:30px 0 10px 0;
  line-height:1.5;
`;
const StatusBox = styled(Box)`
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-evenly;
`;