import { Container, Grid, Box, Typography, IconButton } from "@mui/material";
import React, { useState } from "react";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import TimelapseIcon from "@mui/icons-material/Timelapse";
import VerifiedIcon from "@mui/icons-material/Verified";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import DoDisturbOnIcon from "@mui/icons-material/DoDisturbOn";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import CancelIcon from "@mui/icons-material/Cancel";
import { styled } from "@mui/system";
import clsx from "clsx";
import CustomButton from "../../../Button/CustomButton";

interface job {
  applicationId: string;
  status: string;
  submissionDate: string;
  daysToSubmit: string;
  jobTitle: string;
  hiringPosition: string;
  appliedDate: string;
  hiringStatus: string;
}

interface applicationProps {
  data: job[];
  handleModal: any;
}
interface Detail {
  head: string;
  child: React.ReactNode;
}

const ApplicationCard: React.FC<applicationProps> = ({ data, handleModal }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const applicationPerPage = 4;

  const indexOfLastJob = currentPage * applicationPerPage;
  const indexOfFirstJob = indexOfLastJob - applicationPerPage;
  const currentApplication = data.slice(indexOfFirstJob, indexOfLastJob);

  const totalPages = Math.ceil(data.length / applicationPerPage);

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage -1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };
  const renderPageNumbers = (totalPages: number): JSX.Element[] => {
    const pageNumbers: JSX.Element[] = [];
    
    const firstRange = 3;
    const lastRange = 3;

    for (let i = 1; i <= Math.min(firstRange, totalPages); i++) {
        pageNumbers.push(
            <Typography sx={{ marginLeft: "20px" }} key={i}>
                {i}
            </Typography>
        );
    }

    if (totalPages > firstRange + lastRange) {
        pageNumbers.push(
            <Typography sx={{ marginLeft: "40px" }} key="ellipsis-start">
                ...
            </Typography>
        );
    }

    const startLastRange = Math.max(totalPages - lastRange + 1, firstRange + 1);
    for (let i = startLastRange; i <= totalPages; i++) {
        pageNumbers.push(
            <Typography sx={{ marginLeft: "40px" }} key={i}>
                {i}
            </Typography>
        );
    }
    return pageNumbers;
};


  const Details: React.FC<Detail> = ({ head, child }) => {
    return (
      <DetailBox>
        <Typography className="ApplyNowHead">{head}</Typography>

        {head === "Hiring Position" ? (
          child
        ) : (
          <Typography className="ApplyNow ">{child}</Typography>
        )}
      </DetailBox>
    );
  };

  return (
    <Container maxWidth="xl">
      <CustomBox sx={{ marginTop: 8, marginBottom: 8 }}>
        <Grid container spacing={4}>
          {currentApplication.map((jobs) => (
            <Grid item xs={6}>
              <CourseBox>
                <CourseNameBox onClick={() => handleModal(jobs)}>
                  <Typography className="courseName" color="info.main">
                    {jobs.applicationId}
                  </Typography>
                  <IconButton className="getCertified">
                    <ChevronRightIcon />
                  </IconButton>
                </CourseNameBox>
                <DBox>
                  <Details
                    head={"Hiring Company"}
                    child={
                      (jobs.status === "Submitted" && (
                        <IconButton
                          className="Certify"
                          sx={{ color: "#48A055" }}
                        >
                          <VerifiedIcon sx={{ width: 16 }} /> &nbsp;Submitted
                        </IconButton>
                      )) ||
                      (jobs.status === "DisQualified" && (
                        <IconButton
                          className="Certify"
                          sx={{ color: "#BF1932" }}
                        >
                          <CancelIcon sx={{ width: 16 }} /> &nbsp; DisQualified
                        </IconButton>
                      )) ||
                      (jobs.status === "InProgress" && (
                        <IconButton
                          className="Certify"
                          sx={{ color: "#ef5c00" }}
                        >
                          <TimelapseIcon sx={{ width: 16 }} /> &nbsp; In
                          Progress
                        </IconButton>
                      ))
                    }
                  />
                  <Details head={"Work Location"} child={jobs.daysToSubmit} />
                  <Details head={"Work Location"} child={jobs.submissionDate} />
                  <Details
                    head={"Submission Deadline"}
                    child={jobs.appliedDate}
                  />
                  <Details head={"Hiring Date"} child={jobs.jobTitle} />
                  <Details
                    head={"Hiring Position"}
                    child={
                      <Typography
                        className={clsx("ApplyPosition", {
                          intern: jobs.hiringPosition === "Internship",
                          partTime: jobs.hiringPosition === "Part Time",
                          fullTime: jobs.hiringPosition === "Full Time",
                          contract: jobs.hiringPosition === "Contract",
                        })}
                      >
                        {jobs.hiringPosition}
                      </Typography>
                    }
                  />
                  <Details
                    head={"Hiring Date"}
                    child={
                      (jobs.hiringStatus === "Open" && (
                        <IconButton
                          className="Certify"
                          sx={{ color: "#48A055" }}
                        >
                          <CheckCircleIcon sx={{ width: 16 }} /> &nbsp;Open
                        </IconButton>
                      )) ||
                      (jobs.hiringStatus === "Closed" && (
                        <IconButton
                          className="Certify"
                          sx={{ color: "#BF1932" }}
                        >
                          <DoDisturbOnIcon sx={{ width: 16 }} /> &nbsp;Closed
                        </IconButton>
                      ))
                    }
                  />
                </DBox>
              </CourseBox>
            </Grid>
          ))}
        </Grid>
      </CustomBox>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "20px",
        }}
      >
        <CustomButton
          variant="secondary"
          name={"Previous"}
          padding={"8px 14px"}
          startIcon={<ArrowBackIcon />}
          onClick={handlePreviousPage}
          disabled={currentPage === 1}
        />
        {/* <Typography>
          Page {currentPage} of {totalPages}
        </Typography> */}
         <Box sx={{ display: "flex", alignItems: "center" }}>{renderPageNumbers(totalPages)}</Box>
        <CustomButton
          variant="secondary"
          name={"Next"}
          padding={"8px 14px"}
          endIcon={<ArrowForwardIcon />}
          onClick={handleNextPage}
          disabled={currentPage === totalPages}
        />
      </Box>
    </Container>
  );
};

export default ApplicationCard;

const CustomBox = styled(Box)`
  border: 2px solid white;
  border-radius: 3px;
  display: flex;
  height: 100%;
  padding: 30px;
`;

const CourseBox = styled(Box)`
  background-color: white;
  padding: 15px;
  /* margin: 15px; */
  width: 95%;
  min-width: 400px;
  border-radius: 7px;
`;
const CourseNameBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background-color: #f5f5f5;
  border-radius: 7px;
`;
const DetailBox = styled(Box)`
  width: 100%;
  display: flex;
  padding: 3px;
`;
const DBox = styled(Box)`
  padding: 5px;
`;
