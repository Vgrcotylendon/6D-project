import React from "react";
import {
  Typography,
  Table,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableBody,
  Box,
  IconButton,
  Button,
} from "@mui/material";
import TimelapseIcon from "@mui/icons-material/Timelapse";
import VerifiedIcon from "@mui/icons-material/Verified";
import CloseIcon from "@mui/icons-material/Close";
import styled from "styled-components";

interface applicationProps {
  handleClose: any;
}

const ApplicationModal: React.FC<applicationProps> = ({ handleClose }) => {
  const head2 = [
    "Certificate Title",
    "Certification Status",
    "Attempt",
    "Submission Date",
    "Action",
  ];

  const tableData2 = [
    {
      title: "6DLVI-001 Leadership and Initiative",
      status: "Certified",
      attempt: 1,
      submissionDate: "05/10/2024",
      action: "",
    },
    {
      title: "6DLVI-005 Communication Skills (Listening, Written & Verbal)",
      status: "InProgress",
      attempt: 1,
      submissionDate: "05/10/2024",
      action: "Resume",
    },
    {
      title: "6DLVI-003 Digital Literacy",
      status: "InProgress",
      attempt: 2,
      submissionDate: "05/10/2024",
      action: "Resume",
    },
  ];

  return (
    <MainBox>
      <IconBox>
        <IconButton
          onClick={handleClose}
          sx={{ position: "absolute", top: 10, right: 10 }}
        >
          <CloseIcon />
        </IconButton>
      </IconBox>
      <PaddingBox>
        <Typography align="left" className="applicationModal">
          <Typography className="applicationModal normal">
            Application ID
          </Typography>{" "}
          &nbsp;&nbsp;
          <Typography className="bold">6DAP-001SC</Typography>
        </Typography>
        <br />
        <Typography align="left" className="applicationModal">
          <Typography className="applicationModal normal">Job Title</Typography>{" "}
          &nbsp;&nbsp;
          <Typography className="bold">6DWRK-001 Shift Chemist</Typography>
        </Typography>
      </PaddingBox>
      <br />
      <Box
        padding={2}
        sx={{ border: "10px solid #F5F5F5", borderRadius: "7px" }}
      >
        <Typography align="left" className="applicationModal">
          <Typography className="bold">Application Status:</Typography>
          <Typography className="bold" sx={{ color: "#48A055" }}>
            InProgress
          </Typography>
        </Typography>
        <br />

        <TableContainer sx={{ overflowY: "auto", maxHeight: 250 }}>
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                {head2.map((item, index) => (
                  <TableCell
                    align={item === "Certificate Title" ? "left" : "center"}
                    sx={{
                      bgcolor: "#F5F5F5",
                      // minWidth: 200,
                      border: "none",
                    }}
                  >
                    <Typography className="bold"> {item}</Typography>
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {tableData2.map((item, index) => (
                <TableRow>
                  <TableCell align="left" sx={{}}>
                    {item.title}
                  </TableCell>
                  <TableCell align="center" sx={{}}>
                    {(item.status === "Certified" && (
                      <IconButton
                        className="Certify"
                        sx={{ color: "#48A055", fontFamily: "poppins" }}
                      >
                        <VerifiedIcon sx={{ width: 16 }} /> &nbsp;Certified
                      </IconButton>
                    )) ||
                      (item.status === "InProgress" && (
                        <IconButton
                          className="Certify"
                          sx={{ color: "#ef5c00", fontFamily: "poppins" }}
                        >
                          <TimelapseIcon sx={{ width: 16 }} /> &nbsp; In
                          Progress
                        </IconButton>
                      ))}
                  </TableCell>
                  <TableCell align="center">{item.attempt}</TableCell>
                  <TableCell align="center">{item.submissionDate}</TableCell>
                  <TableCell align="center">
                    <Button size="small" sx={{ padding: 0 }}>
                      {item.action}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </MainBox>
  );
};

export default ApplicationModal;

const IconBox = styled(Box)`
  display: flex;
  justify-content: flex-end;
`;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  padding: 20px;
`;

const PaddingBox = styled(Box)`
  padding: 40px 40px 0 40px;
`;
