import React from "react";
import CustomModal from "../../../Modal/CustomModal";
import ApplicationCard from "./ApplicationCard";
import ApplicationTable from "./ApplicationTable";
import ApplicationModal from "./ApplicationModal";

interface toogle {
  jobsValue: boolean;
}

const Applications: React.FC<toogle> = ({ jobsValue }) => {
  const data = [
    {
      applicationId: "6DAP-001SC",
      status: "InProgress",
      submissionDate: "05 Oct 2024",
      daysToSubmit: "103 days",
      jobTitle: "6DWRK-001 Shift Chemist",
      hiringPosition: "Internship",
      appliedDate: "",
      hiringStatus: "Open",
    },
    {
      applicationId: "6DAP-001V1",
      status: "Submitted",
      submissionDate: "05 Oct 2024",
      daysToSubmit: "103 days",
      jobTitle: "6DWRK-002 Visual Inspector",
      hiringPosition: "Part Time",
      appliedDate: "25 sep 2024",
      hiringStatus: "Open",
    },
    {
      applicationId: "6DAP-002PA",
      status: "InProgress",
      submissionDate: "15 Jun 2024",
      daysToSubmit: "82 days",
      jobTitle: "6DWRK-008 Packers",
      hiringPosition: "Contract",
      appliedDate: "",
      hiringStatus: "Open",
    },
    {
      applicationId: "6DAP-003PP",
      status: "DisQualified",
      submissionDate: "15 May 2024",
      daysToSubmit: "0 days",
      jobTitle: "6DWRK-004 PO & PS Assistant",
      hiringPosition: "Internship",
      appliedDate: "",
      hiringStatus: "Closed",
    },
  ];

  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <>
      <CustomModal
        open={open}
        handleClose={() => handleClose()}
        child={<ApplicationModal handleClose={()=>handleClose()}/>}
        sx={{ width: "70%", height: "auto", mt: 5}}
      />
      {jobsValue ? (
        <ApplicationTable data={data} handleModal={() => handleOpen()} />
      ) : (
        <ApplicationCard data={data} handleModal={() => handleOpen()} />
      )}
       
    </>
  );
};

export default Applications;
