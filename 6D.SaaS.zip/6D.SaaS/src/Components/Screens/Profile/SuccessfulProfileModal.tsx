import { Box, Typography } from "@mui/material";
import React from "react";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";

interface progressTypes {
  progress: number;
  show1: boolean;
}
const SuccessfulProfileModal: React.FC<progressTypes> = () => {
  return (
    <Box sx={{ padding: "20px" }}>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: "#f0f0f0",
          borderRadius: "10px",
          padding: "20px",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            backgroundColor: "#FFFFFf",
            borderRadius: "10px",
            padding: "20px",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
            <>
              <CheckCircleIcon sx={{ fontSize: "40px", color: "green" }} />
              <br />
              <Typography sx={{ fontWeight: "bold", color: "info.main" }}>
                ...Information Updated Successfully...
              </Typography>
            </>
        </Box>
      </Box>
    </Box>
  );
};

export default SuccessfulProfileModal;

// const CustomLinear = styled(LinearProgress)`
//   padding: 2px;
//   width: 100%;
//   height: 80px;
//   margin: 5px;
//   border-radius: 7px;
//   & .MuiLinearProgress-bar {
//     background-color: #ef5c00;
//   }
// `;
