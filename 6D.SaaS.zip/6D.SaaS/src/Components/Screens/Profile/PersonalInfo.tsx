import {
  Avatar,
  Box,
  Checkbox,
  Container,
  Grid,
  IconButton,
  LinearProgress,
  Typography,
} from "@mui/material";
import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import ErrorIcon from "@mui/icons-material/Error";
import CustomTextInput from "../../Input/CustomTextInput";
import MailIcon from "@mui/icons-material/Mail";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import InsertLinkIcon from "@mui/icons-material/InsertLink";
import styled from "styled-components";
import CustomAutoComplete, { OptionType } from "../../Input/CustomAutoComplete";
import { StateList } from "../../../Data/State";
import CustomDatePicker from "../../Input/CustomDatePicker";
import dayjs, { Dayjs } from "dayjs";
import { GridTypo } from "../../Input/InputField";
import CloudUploadOutlinedIcon from "@mui/icons-material/CloudUploadOutlined";
import CustomModal from "../../Modal/CustomModal";
import UploadProfile from "./UploadProfile";
import { useDispatch, useSelector } from "react-redux";
import { RootState, UpdateProfile } from "../../../Store/UserSlice";
import { cookies, ImageUrl, instance } from "../../../Controller/Common";
import SuccessfulProfileModal from "./SuccessfulProfileModal";
import FillModal from "./FillModal";

interface FormState {
  aadhaarId: string;
  apaarId: string;
  firstName: string;
  middleName: string;
  lastName: string;
  gender: string;
  dob: Dayjs | null;
  nationality: string;
  phoneNumber: string;
  email: string;
  linkedIn: string;
  permanentAddress: {
    country: any;
    state: string;
    city: string;
    addressLine1: any;
    addressLine2: any;
    pincode: string;
  };
  mailingAddress: {
    country: any;
    state: string;
    city: string;
    addressLine1: any;
    addressLine2: any;
    pincode: string;
  };
}
interface profileTypes {
  save: boolean;
  edit: boolean;
  setEdit: Dispatch<SetStateAction<boolean>>;
  setTrigger: Dispatch<SetStateAction<boolean>>;
  setSave: Dispatch<SetStateAction<boolean>>;
  trigger: boolean;
  isEditable: boolean;
  setIsEditable: Dispatch<SetStateAction<boolean>>;
  isEditable1: boolean;
  check: boolean;
  setCheck: Dispatch<SetStateAction<boolean>>;
  showRequiredError: boolean;
  setShowRequiredError: Dispatch<SetStateAction<boolean>>;
}
interface Country {
  name: {
    common: string;
  };
  cca2: string;
}
const PersonalInfo: React.FC<profileTypes> = ({
  save,
  setSave,
  setTrigger,
  setEdit,
  trigger,
  isEditable,
  setIsEditable,
  showRequiredError,
  setShowRequiredError,
  check,
  setCheck,
}) => {
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(true);
  const [link, setLink] = useState(false);
  const [emailErr, setEmailErr] = useState(false);
  const [adharErr, setAdharErr] = useState(false);
  const [phoneErr, setPhoneErr] = useState(false);
  const [open1, setOpen1] = useState(false);
  const [open, setOpen] = useState(false);
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [progress, setProgress] = React.useState(0);
  const [gender, setGender] = React.useState<OptionType | null>(null);
  const [state, setState] = React.useState<OptionType | null>(null);
  const [error, setError] = useState("");
  const [error1, setError1] = useState(false);
  const [mailingState, setMailingState] = React.useState<OptionType | null>(
    null
  );
  const [newReadOnly, setNewReadOnly] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [form, setForm] = useState<FormState>({
    aadhaarId: "",
    apaarId: "",
    firstName: "",
    middleName: "",
    lastName: "",
    gender: "",
    dob: null,
    nationality: "Indian",
    phoneNumber: "",
    email: "",
    linkedIn: "",
    permanentAddress: {
      country: { label: "India", value: 1 },
      state: "",
      city: "",
      addressLine1: "",
      addressLine2: "",
      pincode: "",
    },
    mailingAddress: {
      country: { label: "India", value: 1 },
      state: "",
      city: "",
      addressLine1: "",
      addressLine2: "",
      pincode: "",
    },
  });

  const [country, setCountry] = useState<OptionType | null>({
    label: "India",
    value: 1,
  });
  const [mailingCountry, setMailingCountry] = React.useState<OptionType | null>(
    { label: "India", value: 1 }
  );

  // ---------------------------------------------------------------------------------------------------------

  const [CountryData, setCountryData] = useState<OptionType[]>([
    { label: "India", value: 1 },
  ]);
  const [countryCode, setCountryCode] = useState("091");
  const [CodeErr, setCodeErr] = useState(false);
  const [localPhoneNumber, setLocalPhoneNumber] = useState("");

  const getAllCountries = async () => {
    try {
      const response = await fetch("https://restcountries.com/v3.1/all");
      const data: Country[] = await response.json();
      const indiaData = data.find((country) => country.name.common === "India");
      const indiaOption = indiaData
        ? {
            label: "India",
            value: indiaData.cca2,
          }
        : {
            label: "India",
            value: "IN",
          };
      const countries = [
        indiaOption,
        ...data
          .filter((country) => country.name.common !== "India")
          .map((country) => ({
            label: country.name.common,
            value: country.cca2,
          })),
      ].sort((a, b) => a.label.localeCompare(b.label));

      setCountryData(countries);
      setForm((prev) => ({
        ...prev,
        permanentAddress: {
          ...prev.permanentAddress,
          country: "India",
        },
        mailingAddress: {
          ...prev.mailingAddress,
          country: "India",
        },
      }));
    } catch (error) {
      console.error("Error fetching country names:", error);
    }
  };

  const getStatesByCountryId = (name: any) => {
    return StateList.filter((i) => i.name === name).flatMap((i) =>
      i.States.map(({ name, id }) => ({ label: name, value: id }))
    );
  };

  const StatesforPermanent = getStatesByCountryId(country?.label);

  const StatesforMailing = getStatesByCountryId(mailingCountry?.label);

  const genderOptions = [
    { value: 0, label: "Male" },
    { value: 1, label: "Female" },
    { value: 2, label: "Others" },
  ];

  // ---------------------------------------------------------------------------------------------------------

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLink(false);
    setAdharErr(false);
    setEmailErr(false);
    setError("")
    const { name, value } = e.target;
    const updatedValue = value.charAt(0).toUpperCase() + value.slice(1);
    if (name.startsWith("permanentAddress")) {
      const field = name.replace("permanentAddress.", "");
      setForm((prev) => ({
        ...prev,
        permanentAddress: { ...prev.permanentAddress, [field]: updatedValue },
      }));
    } else if (name.startsWith("mailingAddress")) {
      const field = name.replace("mailingAddress.", "");
      setForm((prev) => ({
        ...prev,
        mailingAddress: { ...prev.mailingAddress, [field]: updatedValue },
      }));
    } else {
      setForm((prev) => ({ ...prev, [name]: updatedValue }));
    }
  };

  // -------------------------------------------------------------------------------------------------------

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError("")
    if (mobileNumber) return;

    setPhoneErr(false);
    setCodeErr(false);
    const { name, value } = e.target;

    if (name === "countryCode") {
      const numericValue = value.replace(/[^0-9]/g, "");
      if (numericValue.length <= 3) {
        setCountryCode(numericValue);
        const newPhoneNumber = numericValue + localPhoneNumber;
        setForm((prev) => ({
          ...prev,
          phoneNumber: newPhoneNumber,
        }));
      }
    } else if (name === "phoneNumber") {
      const numericValue = value.replace(/[^0-9]/g, "");
      if (numericValue.length <= 10) {
        setLocalPhoneNumber(numericValue);
        const newPhoneNumber = countryCode + numericValue;
        setForm((prev) => ({
          ...prev,
          phoneNumber: newPhoneNumber,
        }));
      }
    }
  };

  const formatPhoneNumber = (phoneNumber: string) => {
    const code = phoneNumber.slice(0, 3);
    const number = phoneNumber.slice(3);
    return { code, number };
  };

  const populatePhoneNumber = (phoneNumber: string | undefined) => {
    if (phoneNumber) {
      const { code, number } = formatPhoneNumber(phoneNumber);
      setCountryCode(code);
      setLocalPhoneNumber(number);
    }
  };

  // ---------------------------------------------------------------------------------------------------------------

  const handleDateChange = (date: Dayjs | null) => {
    if (!date || !date.isValid()) {
      setError("Please enter a complete date (DD/MM/YYYY)");
      setError("");
      setError1(false);
      setForm((prev) => ({ ...prev, dob: null }));
      return;
    }

    // Check if date string is complete (has day, month, and year)
    const dateStr = date.format("DD/MM/YYYY");
    if (dateStr.includes("_") || dateStr.length !== 10) {
      setError("Please enter a complete date (DD/MM/YYYY)");
      setError("");
      setError1(false);
      setForm((prev) => ({ ...prev, dob: null }));
      return;
    }
    if (date && (date.isSame(dayjs(), "day") || date.isAfter(dayjs()))) {
      setError("Date of Birth cannot be today or in the future.");
      setError1(true);
      setForm((prev) => ({ ...prev, dob: null }));
      return;
    }
    setError("");
    setError1(false);
    setForm((prev) => ({ ...prev, dob: date }));
  };

  const handleGender = (
    event: React.ChangeEvent<{}>,
    newValue: OptionType | null
  ) => {
    setGender(newValue);
    setForm((prev) => ({
      ...prev,
      gender: newValue?.label || "",
    }));
  };

  const handleCountry = (
    event: React.ChangeEvent<{}>,
    newValue: OptionType | null
  ) => {
    setCountry(newValue);
    setForm((prev) => ({
      ...prev,
      permanentAddress: {
        ...prev.permanentAddress,
        country: newValue?.label ? newValue?.label : "",
      },
    }));

    if (newValue?.label === "India") {
      setState(null);
    } else {
      setState(null);
      setForm((prev) => ({
        ...prev,
        permanentAddress: {
          ...prev.permanentAddress,
          state: "",
        },
      }));
    }
  };

  const handleState = (
    event: React.ChangeEvent<{}>,
    newValue: OptionType | null
  ) => {
    setState(newValue);
    setForm((prev) => ({
      ...prev,
      permanentAddress: {
        ...prev.permanentAddress,
        state: newValue?.label || "",
      },
    }));
  };

  const handleMailingCountry = (
    event: React.ChangeEvent<{}>,
    newValue: OptionType | null
  ) => {
    setMailingCountry(newValue);
    setForm((prev) => ({
      ...prev,
      mailingAddress: {
        ...prev.mailingAddress,
        country: newValue?.label ? newValue?.label : "",
      },
    }));
    if (newValue?.label === "India") {
      setMailingState(null);
    } else {
      setMailingState(null);
      setForm((prev) => ({
        ...prev,
        mailingAddress: {
          ...prev.mailingAddress,
          state: "",
        },
      }));
    }
  };

  const handleMailingState = (
    event: React.ChangeEvent<{}>,
    newValue: OptionType | null
  ) => {
    setMailingState(newValue);
    setForm((prev) => ({
      ...prev,
      mailingAddress: { ...prev.mailingAddress, state: newValue?.label || "" },
    }));
  };

  // -------------------------------------------------------------------------------------------
  const userId =
    useSelector((state: RootState) => state.user.userID) ??
    cookies.get("userId");
  const mobileNumber = useSelector((state: RootState) => state.user.mobile);
  const EMAILID = useSelector((state: RootState) => state.user.email);
  const isIndiaSelected = country?.label === "India";
  const isIndiaSelectedforMailing = mailingCountry?.label === "India";
  const [imageUrl, setImageUrl] = useState("");

  const SaveProfile = async () => {
    const isValidLinkedIn =
      form.linkedIn &&
      /^(https?:\/\/)?(www\.)?linkedin\.com\/.*$/i.test(form.linkedIn);
    const isValidEmail =
      form.email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/i.test(form.email);
    const correctCountryCode =
      countryCode.length === 3 ? countryCode : countryCode.padStart(3, "0");

    const fullPhoneNumber =
      mobileNumber || correctCountryCode + localPhoneNumber;

    const isValidNumber = mobileNumber ? true : localPhoneNumber.length === 10;
    const isValidAadhaar = form.aadhaarId && form.aadhaarId.length === 12;
    if (
      // !form.aadhaarId ||
      !form.firstName ||
      !form.lastName ||
      !form.dob ||
      !form.gender ||
      (!mobileNumber && !isValidNumber) ||
      (!EMAILID && !isValidEmail) ||
      !isValidLinkedIn ||
      form.nationality === "" ||
      !form.permanentAddress.addressLine1 ||
      !form.permanentAddress.city ||
      !form.permanentAddress.country ||
      !form.permanentAddress.pincode ||
      !form.permanentAddress.state ||
      (check === true &&
        (!form.mailingAddress.addressLine1 ||
          !form.mailingAddress.city ||
          !form.mailingAddress.country ||
          !form.mailingAddress.pincode ||
          !form.mailingAddress.state ||
          null))
    ) {
      if (!isValidLinkedIn && form.linkedIn) {
        setLink(true);
      }
      if (!isValidEmail && form.email) {
        setEmailErr(true);
      }
      // if (!isValidAadhaar && form.aadhaarId) {
      //   setAdharErr(true);
      // }
      if (!isValidNumber) {
        setPhoneErr(true);
      }
      setTrigger(false);
      setOpen1(true);
      setShowRequiredError(true);
      setError("");
      return;
    }
    try {
      const response = await instance.post(
        `6D/user/createUserProfile`,
        {
          image: file,
          UID: userId,
          "6DWORKS_ID": userId,
          FIRST_NAME: form.firstName,
          LAST_NAME: form.lastName,
          MIDDLE_NAME: form.middleName,
          IS_VERIFIED: true,
          AVATAR_PUB_ID: userId,
          ROLE: "student",
          AADAAR_ID: form.aadhaarId || null,
          APAAR_ID: form.apaarId || null,
          DATE_OF_BIRTH: form.dob,
          GENDER: form.gender,
          NATIONALITY: form.nationality,
          PHONE_NUMBER: fullPhoneNumber,
          EMAIL: EMAILID || form.email,
          LINKEDIN: form.linkedIn,
          MAILING_ADDRESS_LINE_1: form.mailingAddress.addressLine1,
          MAILING_ADDRESS_LINE_2: form.mailingAddress.addressLine2,
          MAILING_ADDRESS_CITY: form.mailingAddress.city,
          MAILING_ADDRESS_STATE: form.mailingAddress.state,
          MAILING_ADDRESS_COUNTRY: mailingCountry?.label,
          MAILING_ADDRESS_PINCODE: form.mailingAddress.pincode,
          PERMANENT_ADDRESS_LINE_1: form.permanentAddress.addressLine1,
          PERMANENT_ADDRESS_LINE_2: form.permanentAddress.addressLine2,
          PERMANENT_ADDRESS_CITY: form.permanentAddress.city,
          PERMANENT_ADDRESS_STATE: form.permanentAddress.state,
          PERMANENT_ADDRESS_COUNTRY: country?.label,
          PERMANENT_ADDRESS_PINCODE: form.permanentAddress.pincode,
          IS_ADDRESS_SAME: !check,
        },
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if (response.status === 200) {
        GetProfile();
        setIsEditable(false);
        setOpen(false);
        setSave(true);
        setTrigger(false);
        // setShow(true);
        setEdit(false);
        // setShow1(true);
        setError1(false);
        setPhoneErr(false);
        setCheck(false);
        setCodeErr(false);
        setAdharErr(false);
        setEmailErr(false);
        setLink(false);
        setError1(false);
        setError("");
      }
    } catch (error) {
      console.error("Error saving profile:", error);
      alert("There was an error saving your profile. Please try again.");
    }
  };

  const GetProfile = async () => {
    // const interval = setInterval(() => {
    //   setProgress((prevProgress) => {
    //     if (prevProgress < 90) {
    //       return prevProgress + 10;
    //     }
    //     return prevProgress;
    //   });
    // }, 100);
    try {
      const response = await instance.get(`6D/user/getUserProfile/${userId}`);
      if (response.status === 200) {
        const data = response.data;
        setNewReadOnly(response.data?.message);
        if (data.IS_ADDRESS_SAME === "false") {
          setCheck(true);
        } else {
          setCheck(false);
        }
        cookies.set("FirstName", response.data.FIRST_NAME);
        setImageUrl(`${ImageUrl}${data.AVATAR_URL}`);
        dispatch(UpdateProfile(`${ImageUrl}${data.AVATAR_URL}`));
        genderOptions.forEach(
          (i) =>
            i.label === data.GENDER &&
            setGender({ label: i.label, value: i.value })
        );
        CountryData.forEach(
          (i) =>
            i.label === data.PERMANENT_ADDRESS_COUNTRY &&
            setCountry({ label: i.label, value: i.value })
        );
        CountryData.forEach(
          (i) =>
            i.label === data.MAILING_ADDRESS_COUNTRY &&
            setMailingCountry({ label: i.label, value: i.value })
        );

        const permanentStates = getStatesByCountryId(
          data.PERMANENT_ADDRESS_COUNTRY
        );
        const mailingStates = getStatesByCountryId(
          data.MAILING_ADDRESS_COUNTRY
        );

        permanentStates.forEach(
          (i) =>
            i.label === data.PERMANENT_ADDRESS_STATE &&
            setState({ label: i.label, value: i.value })
        );
        mailingStates.forEach(
          (i) =>
            i.label === data.MAILING_ADDRESS_STATE &&
            setMailingState({ label: i.label, value: i.value })
        );
        if (mobileNumber || data.PHONE_NUMBER) {
          populatePhoneNumber(mobileNumber || data.PHONE_NUMBER);
        }
        setForm((prev) => ({
          ...prev,
          aadhaarId: data.AADAAR_ID,
          // apaarId: data.APAAR_ID || "",
          firstName: data.FIRST_NAME,
          middleName: data.FIRST_NAME
            ? data.MIDDLE_NAME || null
            : data.MIDDLE_NAME
            ? data.MIDDLE_NAME
            : undefined,
          lastName: data.LAST_NAME,
          gender: data.GENDER,
          dob: data.DATE_OF_BIRTH ? dayjs(data.DATE_OF_BIRTH) : null,
          nationality: data.NATIONALITY ? data.NATIONALITY : "Indian",
          phoneNumber: mobileNumber || data.PHONE_NUMBER || "",
          email: data.EMAIL,
          linkedIn: data.LINKEDIN,
          permanentAddress: {
            ...form.permanentAddress,
            country: data.PERMANENT_ADDRESS_COUNTRY
              ? data.PERMANENT_ADDRESS_COUNTRY
              : "India",
            state: data.PERMANENT_ADDRESS_STATE,
            city: data.PERMANENT_ADDRESS_CITY,
            addressLine1: data.PERMANENT_ADDRESS_LINE_1,
            addressLine2: data.PERMANENT_ADDRESS_LINE_2,
            pincode: data.PERMANENT_ADDRESS_PINCODE,
          },
          mailingAddress: {
            ...form.mailingAddress,

            country: data.MAILING_ADDRESS_COUNTRY
              ? data.MAILING_ADDRESS_COUNTRY
              : "India",
            state: data.PERMANENT_ADDRESS_STATE
              ? data.MAILING_ADDRESS_STATE || null
              : data.MAILING_ADDRESS_STATE
              ? data.MAILING_ADDRESS_STATE
              : undefined,
            city: data.MAILING_ADDRESS_CITY,
            addressLine1: data.MAILING_ADDRESS_LINE_1,
            addressLine2: data.MAILING_ADDRESS_LINE_2,
            pincode: data.MAILING_ADDRESS_PINCODE,
          },
        }));
        setCountry({
          label: data.PERMANENT_ADDRESS_COUNTRY
            ? data.PERMANENT_ADDRESS_COUNTRY
            : "India",
          value: 1,
        });
        setMailingCountry({
          label: data.MAILING_ADDRESS_COUNTRY
            ? data.MAILING_ADDRESS_COUNTRY
            : "India",
          value: 1,
        });
      }
      // setLoading(false);
    } catch (error) {
      console.error(error);
    } 
    // finally {
    //   clearInterval(interval);
    //   setProgress(100);
    // }
  };

  const handleCheckChange = () => {
    if (check) {
      setCheck(false);
    } else {
      setCheck(true);
    }
  };

  React.useEffect(() => {
    if (file) {
      const previewUrl = URL.createObjectURL(file);
      setImageUrl(previewUrl);
    }
  }, [file]);

  useEffect(() => {
    if (trigger === true) {
      SaveProfile();
    }
  }, [trigger]);

  useEffect(() => {
    if (file) {
      setOpen(false);
    }
  }, [file]);

  useEffect(() => {
    GetProfile();
  }, []);

  useEffect(() => {
    getAllCountries();
  }, []);

  return (
    <>
      <CustomModal
        open={open}
        handleClose={() => setOpen(false)}
        sx={{ minWidth: "35%", padding: 5 }}
        child={
          <UploadProfile file={file} setFile={setFile} setOpen={setOpen} />
        }
      />
      {/* {loading ? (
        <NoDataBox>
          <LinearProgress
            variant="determinate"
            value={progress}
            sx={{
              width: "30%",
              height: "10px",
              borderRadius: "8px",
              backgroundColor: "#cfcaca",
              marginBottom: 2,
              "& .MuiLinearProgress-bar": {
                backgroundColor: "green",
              },
            }}
          />
          <Typography
            sx={{ fontWeight: 600, fontSize: "16px", color: "#4C2D2D" }}
          >
            Please wait, loading...
          </Typography>
        </NoDataBox>
      ) : ( */}
        <StyledContainer maxWidth="xl">
          <Grid container>
            <Grid item xs={12} sm={6} md={4}>
              <AvatarBox>
                <Box sx={{ position: "relative" }}>
                  <Avatar
                    sx={{ width: 130, height: 130 }}
                    src={imageUrl}
                  ></Avatar>
                  <IconButton
                    sx={{
                      position: "absolute",
                      bottom: 0,
                      right: 0,
                      bgcolor: "white",
                      color: "black",
                      "&:hover": { bgcolor: "white", color: "black" },
                    }}
                    disabled={save}
                    // readonly={save}
                    onClick={() => setOpen(true)}
                  >
                    <CloudUploadOutlinedIcon />
                  </IconButton>
                </Box>
                <TextBox>
                  <GridTypo sx={{ fontWeight: "700" }}>
                    Profile Picture
                  </GridTypo>
                  <GridTypo sx={{ fontSize: "16px" }}>
                    300 x 300 and max 2MB
                  </GridTypo>
                </TextBox>
              </AvatarBox>
            </Grid>
            <WhiteGrid
              item
              xs={12}
              md={8}
              paddingTop={3}
              paddingBottom={3}
              paddingRight={-1}
              sx={{ mt: { xs: 1.5 } }}
            >
              <Grid container>
                <Grid item xs={12} sm={6} md={6}>
                  <CustomTextInput
                    label="Aadhaar ID"
                    name="aadhaarId"
                    value={form.aadhaarId ? undefined : undefined}
                    onChange={handleChange}
                    // required
                    // adhaar
                    // helper
                    disabled
                    // helperText={adharErr ? "Enter Valid Adhar":null}
                    // isEditable={isEditable}
                    // showRequiredError={showRequiredError}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={6}>
                  <CustomTextInput
                    label="APAAR ID"
                    name="apaarId"
                    value={form.apaarId ? undefined : undefined}
                    onChange={handleChange}
                    // required
                    // apaar
                    disabled
                    // isEditable={isEditable}
                  />
                </Grid>
              </Grid>
            </WhiteGrid>
          </Grid>
          <br />
          <WhiteGrid container>
            <Box sx={{ display: "flex", flexDirection: "row", width: "100%" }}>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="First Name"
                  name="firstName"
                  value={form.firstName}
                  onChange={handleChange}
                  required
                  allowSpaces
                  helper
                  textOnly
                  // disabled={save}
                  readonly={save}
                  isEditable={isEditable}
                  showRequiredError={showRequiredError}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Middle Name"
                  name="middleName"
                  value={form.middleName}
                  allowSpaces
                  onChange={handleChange}
                  textOnly
                  // disabled={save}
                  readonly={save}
                  isEditable={isEditable}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Last Name"
                  name="lastName"
                  value={form.lastName}
                  onChange={handleChange}
                  required
                  allowSpaces={true}
                  helper
                  textOnly
                  // disabled={save}
                  readonly={save}
                  isEditable={isEditable}
                  showRequiredError={showRequiredError}
                />
              </Grid>
            </Box>
            <br />
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                width: "100%",
                marginTop: "18px",
              }}
            >
              <Grid item xs={12} sm={6} md={4}>
                <CustomAutoComplete
                  label="Gender"
                  options={genderOptions}
                  onChange={handleGender}
                  value={gender}
                  required
                  helper
                  // disabled={save}
                  readOnly={save}
                  showRequiredError={showRequiredError}
                  isEditable={isEditable}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomDatePicker
                  label="Date of Birth"
                  required
                  value={form.dob}
                  name="dob"
                  maxDate={dayjs().subtract(1, "day")}
                  onChange={handleDateChange}
                  helper
                  // disabled={save}
                  readOnly={save}
                  showRequiredError={showRequiredError}
                  isEditable={isEditable}
                  helperText={error}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Nationality"
                  name="nationality"
                  value={form.nationality}
                  onChange={handleChange}
                  // required
                  allowSpaces
                  textOnly
                  // disabled={save}
                  readonly={save}
                  isEditable={isEditable}
                  helperText={
                    form.nationality === "" ? "Nationality required" : null
                  }
                  showRequiredError={showRequiredError}
                />
              </Grid>
            </Box>
          </WhiteGrid>
          <br />
          <WhiteGrid container>
            <Grid item xs={6} sm={1} md={1}>
              <CustomTextInput
                label="Phone*"
                name="countryCode"
                value={countryCode}
                onChange={handlePhoneChange}
                helper
                // disabled={save}
                readonly={save}
                helperText={CodeErr ? "Enter 3 digit code" : null}
                isEditable={mobileNumber ? false : isEditable}
                showRequiredError={showRequiredError}
              />
            </Grid>
            <Grid item xs={6} sm={4} md={3} marginTop="24px">
              <CustomTextInput
                label=""
                name="phoneNumber"
                value={localPhoneNumber}
                onChange={handlePhoneChange}
                helper
                // isMobileNo
                // required
                // readonly={mobileNumber}
                icon={LocalPhoneIcon}
                // disabled={save}
                readonly={save}
                helperText={phoneErr ? "Enter Valid Phone Number" : null}
                isEditable={mobileNumber ? false : isEditable}
                showRequiredError={showRequiredError}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <CustomTextInput
                label="Email Address"
                name="email"
                value={EMAILID || form.email}
                onChange={handleChange}
                isEmail
                required
                helper
                // readonly={EMAILID}
                icon={MailIcon}
                // disabled={save}
                readonly={save}
                isEditable={EMAILID ? false : isEditable}
                helperText={emailErr ? "Please enter valid email" : null}
                showRequiredError={showRequiredError}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <CustomTextInput
                label="LinkedIn Profile"
                name="linkedIn"
                value={form.linkedIn}
                onChange={handleChange}
                required
                helper
                isURL
                icon={InsertLinkIcon}
                // disabled={save}
                readonly={save}
                helperText={link ? "Please enter valid linkedin" : null}
                isEditable={isEditable}
                showRequiredError={showRequiredError}
              />
            </Grid>
          </WhiteGrid>
          <br />
          <WhiteGrid container>
            <Grid xs={12} sx={{ padding: 2, pb: 3 }}>
              <Typography className="bold14">Permanent Address</Typography>
            </Grid>
            <Box sx={{ display: "flex", flexDirection: "row", width: "100%" }}>
              <Grid item xs={12} sm={6} md={4}>
                <CustomAutoComplete
                  label="Country"
                  options={CountryData}
                  onChange={handleCountry}
                  value={country}
                  required
                  helper
                  // disabled={save}
                  readOnly={save}
                  showRequiredError={showRequiredError}
                  isEditable={isEditable}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                {isIndiaSelected ? (
                  <CustomAutoComplete
                    label="State"
                    options={isIndiaSelected ? StatesforPermanent : []}
                    onChange={handleState}
                    value={state}
                    required={isIndiaSelected}
                    helper
                    // disabled={save}
                    readOnly={save}
                    showRequiredError={showRequiredError}
                    isEditable={isEditable}
                  />
                ) : (
                  <CustomTextInput
                    label="State"
                    name="permanentAddress.state"
                    value={form.permanentAddress.state}
                    onChange={handleChange}
                    required
                    allowSpaces
                    helper
                    textOnly
                    // disabled={save}
                    readonly={save}
                    isEditable={isEditable}
                    showRequiredError={showRequiredError}
                  />
                )}
              </Grid>

              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="City"
                  name="permanentAddress.city"
                  value={form.permanentAddress.city}
                  onChange={handleChange}
                  required
                  allowSpaces
                  helper
                  textOnly
                  // disabled={save}
                  readonly={save}
                  isEditable={isEditable}
                  showRequiredError={showRequiredError}
                />
              </Grid>
            </Box>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                width: "100%",
                marginTop: "15px",
              }}
            >
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Address Line 1"
                  name="permanentAddress.addressLine1"
                  value={form.permanentAddress.addressLine1}
                  onChange={handleChange}
                  required
                  allowSpaces
                  helper
                  // disabled={save}
                  readonly={save}
                  isEditable={isEditable}
                  showRequiredError={showRequiredError}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Address Line 2"
                  name="permanentAddress.addressLine2"
                  value={form.permanentAddress.addressLine2}
                  onChange={handleChange}
                  allowSpaces
                  // disabled={save}
                  readonly={save}
                  isEditable={isEditable}
                  // showRequiredError={showRequiredError}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Pincode"
                  name="permanentAddress.pincode"
                  value={form.permanentAddress.pincode}
                  onChange={handleChange}
                  required
                  helper
                  pincode
                  // disabled={save}
                  readonly={save}
                  isEditable={isEditable}
                  showRequiredError={showRequiredError}
                />
              </Grid>
            </Box>
          </WhiteGrid>
          <br />
          <WhiteGrid container>
            <Grid xs={12} sx={{ padding: 2, pb: 3 }}>
              <Typography
                className="bold14"
                sx={{ display: "flex", alignItems: "center" }}
              >
                {" "}
                <Checkbox
                  checked={check}
                  onChange={handleCheckChange}
                  sx={{
                    color: "#656566",
                    "&.Mui-checked": {
                      color: "#656566",
                    },
                  }}
                  disabled={save}
                  // readonly={save}
                />{" "}
                Mailing Address (if different)
              </Typography>
            </Grid>
            <Box sx={{ display: "flex", flexDirection: "row", width: "100%" }}>
              <Grid item xs={12} sm={6} md={4}>
                <CustomAutoComplete
                  label="Country"
                  options={CountryData}
                  onChange={handleMailingCountry}
                  value={mailingCountry}
                  required
                  // disabled={!check}
                  readOnly={save || !check}
                  helper
                  isEditable={check && isEditable}
                  showRequiredError={(check && !save) && showRequiredError}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                {isIndiaSelectedforMailing ? (
                  <CustomAutoComplete
                    label="State"
                    options={isIndiaSelectedforMailing ? StatesforMailing : []}
                    onChange={handleMailingState}
                    value={mailingState}
                    required
                    // disabled={
                    //   !check && newReadOnly === "failed to fetch details"
                    // }
                    readOnly={!check || save}
                    helper
                    isEditable={check && isEditable}
                    showRequiredError={(check && !save) && showRequiredError}
                  />
                ) : (
                  <CustomTextInput
                    label="State"
                    name="mailingAddress.state"
                    value={form.mailingAddress.state}
                    onChange={handleChange}
                    required
                    allowSpaces
                    helper
                    textOnly
                    // disabled={save || !check}
                    readonly={!check || save}
                    isEditable={check && isEditable}
                    showRequiredError={(check && !save) && showRequiredError}
                  />
                )}
              </Grid>

              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="City"
                  name="mailingAddress.city"
                  value={form.mailingAddress.city}
                  onChange={handleChange}
                  required
                  allowSpaces
                  helper
                  textOnly
                  // disabled={save || !check}
                  readonly={!check || save}
                  isEditable={check && isEditable}
                  showRequiredError={(check && !save) && showRequiredError}
                />
              </Grid>
            </Box>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                width: "100%",
                marginTop: "15px",
              }}
            >
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Address Line 1"
                  name="mailingAddress.addressLine1"
                  value={form.mailingAddress.addressLine1}
                  onChange={handleChange}
                  required
                  allowSpaces
                  helper
                  // disabled={save || !check}
                  readonly={!check || save}
                  isEditable={(check && !save) && isEditable}
                  showRequiredError={(check && !save) && showRequiredError}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Address Line 2"
                  name="mailingAddress.addressLine2"
                  value={form.mailingAddress.addressLine2}
                  onChange={handleChange}
                  // disabled={save || !check}
                  readonly={!check || save}
                  allowSpaces
                  isEditable={(check && !save) && isEditable}
                  // required
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Pincode"
                  name="mailingAddress.pincode"
                  value={form.mailingAddress.pincode}
                  onChange={handleChange}
                  required
                  allowSpaces
                  helper
                  pincode
                  // disabled={save || !check}
                  readonly={!check || save}
                  isEditable={check && isEditable}
                  showRequiredError={(check && !save) && showRequiredError}
                />
              </Grid>
            </Box>
          </WhiteGrid>
          <br />
          <br />
        </StyledContainer>
      {/* )} */}
      <CustomModal
        open={show}
        handleClose={() => setShow(false)}
        sx={{ minWidth: "35%", padding: 5 }}
        child={<SuccessfulProfileModal progress={progress} show1={show1} />}
      />
      <CustomModal
        open={open1}
        handleClose={() => setOpen1(false)}
        // sx={{ minWidth: "35%", padding: 5 }}
        child={<FillModal setOpen1={setOpen1} />}
      />
    </>
  );
};

export default PersonalInfo;

const StyledContainer = styled(Container)`
  padding: 25px;
  margin: 30px;
`;
const NoDataBox = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  /* background-color: #f0f0f0; */
  border-radius: 10px;
  margin-top: 10rem;
  padding: 20px;
`;
const WhiteGrid = styled(Grid)`
  border: 2px solid white;
  border-radius: 7px;
  display: flex;
  flex-direction: column;
  padding: 20px;
`;

const AvatarBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: start;
  margin-left: 25px;
`;

const TextBox = styled(Box)`
  margin-left: 40px;
`;
