import { Box, Typography, IconButton } from "@mui/material";
import React from "react";
import CloseIcon from "@mui/icons-material/Close";
import CustomButton from "../../Button/CustomButton";

interface fillProps {
  setOpen1: React.Dispatch<React.SetStateAction<boolean>>;
  trigger?:boolean;
  setTrigger?: React.Dispatch<React.SetStateAction<boolean>>;
}

const FillModal: React.FC<fillProps> = ({ setOpen1, trigger, setTrigger }) => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        backgroundColor: "#eff4f7",
        borderRadius: "10px",
        padding: "30px",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <IconButton
        size="small"
        onClick={() => setOpen1(false)}
        sx={{ position: "absolute", top: 4, right: 4 }}
      >
        <CloseIcon />
      </IconButton>

      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: "#FFFFFf",
          borderRadius: "10px",
          padding: "20px",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Typography sx={{ fontWeight: 600, color: "info.main", p: "20px" }}>
          Incomplete Information
        </Typography>
        <Box
          sx={{
            backgroundColor: "#cac7c7",
            height: "0.5px",
            width: "700px",
          }}
        />
        <Typography
          sx={{ fontWeight: 400, color: "#636060", p: "20px", width: "700px" }}
        >
          Please fill all mandatory fields before saving . Required fields
          are marked with an asterisk(*).Ensure all necessary information is
          provided to proceed.
        </Typography>
        <Box
          sx={{
            backgroundColor: "#646262",
            height: "0.3px",
            width: "700px",
          }}
        />
        <Box sx={{ marginTop: "10px" }}>
          <CustomButton
            name="OK"
            variant="primary"
            onClick={() =>{setOpen1(false); setTrigger && setTrigger(false)} }
          />
        </Box>
      </Box>
    </Box>
  );
};

export default FillModal;

