import { Box, IconButton, Typography } from "@mui/material";
import React from "react";
// import styled from "styled-components";
import CloseIcon from "@mui/icons-material/Close";
import CustomButton from "../../Button/CustomButton";

interface popupTypes {
  setShowExperience: (value: boolean) => void;
  handleDelete: any;
}
const DeleteExperinceModal: React.FC<popupTypes> = ({
  handleDelete,
  setShowExperience,
}) => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        backgroundColor: "#eeeeee",
        borderRadius: "10px",
        padding: "40px",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <IconButton
        size="small"
        onClick={() => setShowExperience(false)}
        sx={{ position: "absolute", top: 10, right: 10 }}
      >
        <CloseIcon />
      </IconButton>

      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: "#FFFFFf",
          borderRadius: "10px",
          padding: "20px",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Typography
          sx={{ fontWeight: 600, fontSize: "16px", color: "#112e5a" }}
        >
          Confirm Deletion
        </Typography>
        <br />
        <Box
          sx={{
            backgroundColor: "#cac7c7",
            height: "0.5px",
            width: "500px",
          }}
        />
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
            alignItems: "center",
            padding: "20px 10px 20px 10px",
          }}
        >
          <Typography
            sx={{ fontWeight: 400, fontSize: "14px", color: "#4b4d4e" }}
          >
            Are you sure you want to delete this item?
          </Typography>
          <Typography
            sx={{ fontWeight: 400, fontSize: "14px", color: "#4b4d4e" }}
          >
            This action cannot be undone
          </Typography>
        </Box>
        <Box
          sx={{
            backgroundColor: "#494646",
            height: "0.5px",
            width: "500px",
          }}
        />
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            padding: "10px 0px 10px 0px",
            width: "100%",
          }}
        >
          <CustomButton
            name={"Cancel"}
            variant="secondary"
            onClick={() => setShowExperience(false)}
          />
          <CustomButton
            name={"Delete"}
            variant="primary"
            onClick={handleDelete}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default DeleteExperinceModal;
