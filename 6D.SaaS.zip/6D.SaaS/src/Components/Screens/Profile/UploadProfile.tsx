import React from "react";
import { Box, IconButton, Typography } from "@mui/material";
import CloudUploadOutlinedIcon from "@mui/icons-material/CloudUploadOutlined";
import styled from "styled-components";
import CloseIcon from "@mui/icons-material/Close";

interface UploadProps {
  setFile: any;
  file: any;
  setOpen: any;
}

const UploadProfile: React.FC<UploadProps> = ({ file, setFile, setOpen }) => {
  // const [file, setFile] = useState<File | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      setFile(event.target.files[0]); // Store the file object
    }
  };

  return (
    <>
      <IconButton
        sx={{ position: "absolute", right: 18, top: 20 }}
        onClick={() => setOpen(false)}
      >
        <CloseIcon />
      </IconButton>
      <Box sx={{ bgcolor: "#EDF1F4", padding: 3 }}>
        <Typography sx={{ fontSize: "16px", fontWeight: "bold" }}>
          Media Upload
        </Typography>
        <br />
        <Typography sx={{ fontSize: "14px" }}>Add your file here.</Typography>
        <br />
        <FileBox>
          <Box>
            <input
              type="file"
              style={{ display: "none" }}
              id="fileInput"
              onChange={handleFileChange}
            />
            <IconButton
              component="span"
              onClick={() => document.getElementById("fileInput")?.click()}
            >
              <CloudUploadOutlinedIcon
                style={{ fontSize: "50px", color: "#2a62aa" }}
              />
            </IconButton>
          </Box>
          {file ? (
            <Typography sx={{ color: "black", fontSize: "12px" }}>
              {file.name} {/* Display the file name */}
            </Typography>
          ) : (
            <Typography sx={{ color: "black", fontSize: "16px" }}>
              Drag your file or{" "}
              <span style={{ color: "#2a62aa", fontWeight: "bold" }}>
                browse
              </span>
            </Typography>
          )}
          <br />
          <Typography sx={{ fontSize: "16px", color: "#686a6b" }}>
            Maximum 10 MB files are allowed
          </Typography>
        </FileBox>
        <br />
        <Typography sx={{ fontSize: "14px" }}>
          Only support .jpg, .svg and .png files
        </Typography>
      </Box>
    </>
  );
};

export default UploadProfile;

const FileBox = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  border: 1px dashed #2a62aa;
  background-color: #fff;
  border-radius: 7px;
  color: #7e7979;
  margin-top: 5px;
  height: 15rem;
  padding: 10px;
`;
