import {
  Container,
  Grid,
  Typography,
  Box,
} from "@mui/material";
import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import styled from "styled-components";
import CustomTextInput from "../../Input/CustomTextInput";
import CustomAutoComplete, { OptionType } from "../../Input/CustomAutoComplete";
// import MailIcon from "@mui/icons-material/Mail";
// import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import CustomDatePicker from "../../Input/CustomDatePicker";
import { StateList } from "../../../Data/State";
import dayjs, { Dayjs } from "dayjs";
import { instance } from "../../../Controller/Common";
import { useSelector } from "react-redux";
import { RootState } from "../../../Store/UserSlice";
import CustomModal from "../../Modal/CustomModal";
import SuccessfulProfileModal from "./SuccessfulProfileModal";
import FillModal from "./FillModal";

interface education {
  institutionName: string;
  joiningDate: Dayjs | null;
  country: string;
  state: string;
  city: string;
  addressLine1: string;
  addressLine2: string;
  pincode: string;
  firstName: string;
  email: string;
  phoneNumber: string;
  fieldOfStudy: string;
}
interface options {
  academicYear: OptionType | null;
  currentSemester: OptionType | null;
  country: OptionType | null;
  state: OptionType | null;
}

const DummyOptions = [
  { value: 0, label: "1st Year" },
  { value: 1, label: "2nd Year" },
  { value: 2, label: "3rd Year" },
  { value: 3, label: "4th Year" },
];

const DummySemseterOptions = [
  { value: 0, label: "1st Semester" },
  { value: 1, label: "2nd Semester" },
  { value: 2, label: "3rd Semester" },
  { value: 3, label: "4th Semester" },
  { value: 4, label: "5th Semester" },
  { value: 5, label: "6th Semester" },
  { value: 6, label: "7th Semester" },
  { value: 7, label: "8th Semester" },
];

interface educationTypes {
  save: boolean;
  edit: boolean;
  setSave: Dispatch<SetStateAction<boolean>>;
  setEdit: Dispatch<SetStateAction<boolean>>;
  setTrigger: Dispatch<SetStateAction<boolean>>;
  trigger: boolean;
  isEditable: boolean;
  setIsEditable: Dispatch<SetStateAction<boolean>>;
  showRequiredError: boolean;
  setShowRequiredError: Dispatch<SetStateAction<boolean>>;
}

const EducationDetails: React.FC<educationTypes> = ({
  save,
  setSave,
  setEdit,
  setTrigger,
  trigger,
  showRequiredError,
  setShowRequiredError,
  isEditable,
  setIsEditable,
}) => {
  const [countries, setCountries] = useState<OptionType[]>([]);
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(true);
  const [show1, setShow1] = useState(false);
  const [open1, setOpen1] = useState(false);
  const [progress, setProgress] = React.useState(0);
  const [error, setError] = useState("");
  const [education, setEducation] = useState<education>({
    institutionName: "",
    fieldOfStudy: "",
    joiningDate: null,
    country: "",
    state: "",
    city: "",
    addressLine1: "",
    addressLine2: "",
    pincode: "",
    firstName: "",
    email: "",
    phoneNumber: "",
  });
  const [option, setOption] = useState<options>({
    academicYear: { label: "", value: null },
    currentSemester: { label: "", value: null },
    country: { label: "India", value: "" },
    state: { label: "", value: "" },
  });

  const getCountries = async () => {
    try {
      const response = await instance.get("https://restcountries.com/v3.1/all");
      const countryList = response.data
        .map((country: any) => ({
          label: country.name.common,
          value: country.cca2,
        }))
        .sort((a: { label: string }, b: { label: string }) =>
          a.label.localeCompare(b.label)
        );
      setCountries(countryList);
    } catch (error) {
      console.error("Error fetching countries:", error);
    }
  };
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const updatedValue = value.charAt(0).toUpperCase() + value.slice(1);
    setEducation((prev) => ({ ...prev, [name]: updatedValue }));
  };

  const handleDateChange = (date: Dayjs | null) => {
    if (date && (date.isSame(dayjs(), "day") || date.isAfter(dayjs()))) {
      setError("Joining date cannot be today or in the future.");
      setEducation((prev) => ({ ...prev, joiningDate: null }));
      return;
    }
    setError("");
    setEducation((prev) => ({ ...prev, joiningDate: date }));
  };

  const getIndianStates = () => {
    const india = StateList.find((country) => country.name === "India");
    return india
      ? india.States.map(({ name, id }) => ({ label: name, value: id }))
      : [];
  };
  const States = getIndianStates();
  const handleOptions = (
    event: React.ChangeEvent<{}>,
    newValue: OptionType | null,
    field: keyof options
  ) => {
    if (field === "country") {
      setOption((prev) => ({
        ...prev,
        country: newValue,
        state: { label: "", value: null },
      }));
      setEducation((prev) => ({
        ...prev,
        state: "",
      }));
    } else {
      setOption((prev) => ({ ...prev, [field]: newValue }));
    }
  };

  const userId = useSelector((state: RootState) => state.user.userID);

  const validateFields = (): boolean => {
    const {
      institutionName,
      fieldOfStudy,
      joiningDate,
      city,
      state,
      addressLine1,
      pincode,
    } = education;

    const isStateFilled =
      option.country?.label === "India" ? option.state?.label : education.state;

    if (
      !fieldOfStudy ||
      !option.academicYear?.label ||
      !option.currentSemester?.label ||
      !institutionName ||
      !joiningDate ||
      !option.country?.label ||
      !isStateFilled ||
      !pincode ||
      !city ||
      !addressLine1
    ) {
      return false;
    }

    return true;
  };
  const UpdateEducation = async () => {
    if (!validateFields()) {
      setOpen1(true);
      setTrigger(false);
      setShowRequiredError(true);
      setError("");
      return;
    }
    try {
      const response = await instance.post(
        "/6D/education/createUserEducation",
        {
          MAJOR: education.fieldOfStudy,
          GRADUATION_YEAR: option.academicYear?.label,
          TERM: option.currentSemester?.label,
          UID: userId,
          INSTITUTION_ID: 1,
          INSTITUTION_NAME: education.institutionName,
          DOJ: education.joiningDate,
          PLACEMENT_CELL_CO_ID: null,
          COUNTRY: option.country?.label,
          STATE: option.state?.label || education.state,
          CITY: education.city,
          ADDRESS_LINE_1: education.addressLine1,
          ADDRESS_LINE_2: education.addressLine2 || null,
          PINCODE: education.pincode,
        }
      );
      if (response.status === 200) {
        setIsEditable(false);
        // setShow(true);
        setTrigger(false);
        setSave(true);
        setEdit(false);
        // setTimeout(() => {
        //   setShow(false);
        // }, 1000);
      }
      getEducation();
    } catch (error) {
      console.error(error);
    }
  };

  const getEducation = async () => {
    // const interval = setInterval(() => {
    //   setProgress((prevProgress) => {
    //     if (prevProgress < 90) {
    //       return prevProgress + 10;
    //     }
    //     return prevProgress;
    //   });
    // }, 100);
    try {
      const response = await instance.get(
        `/6D/education/getUserEducation/${userId}`
      );
      const data = response.data;
      if (response.status === 200) {
        setEducation((prev) => ({
          ...prev,
          institutionName: data.INSTITUTION_NAME,
          joiningDate: dayjs(data.DOJ),
          city: data.CITY,
          fieldOfStudy: data.MAJOR,
          addressLine1: data.ADDRESS_LINE_1,
          addressLine2: data.ADDRESS_LINE_2 || null,
          pincode: data.PINCODE,
          state: data.STATE,
          firstName: "",
          email: "",
          phoneNumber: "",
        }));
      }
      setOption((prev) => ({
        ...prev,
        academicYear: { label: data.GRADUATION_YEAR, value: 0 },
        currentSemester: { label: data.TERM, value: 0 },
        country: { label: data.COUNTRY, value: 1 },
        state: { label: data.STATE, value: 0 },
      }));
      // setLoading(false);
    } catch (error) {
      // setLoading(false);
      console.error(error);
    } 
    // finally {
    //   clearInterval(interval);
    //   setProgress(100);
    // }
  };
  useEffect(() => {
    getEducation();
  }, [userId]);

  useEffect(() => {
    if (trigger === true) {
      UpdateEducation();
    }
  }, [trigger]);

  useEffect(() => {
    getCountries();
  }, []);

  return (
    <>
      <CustomModal
        open={open1}
        handleClose={() => setOpen1(false)}
        sx={{ minWidth: "35%", padding: 5 }}
        child={<FillModal setOpen1={setOpen1} />}
      />
      <br />
      {/* {loading ? (
        <NoDataBox>
          <LinearProgress
            variant="determinate"
            value={progress}
            sx={{
              width: "30%",
              height: "10px",
              borderRadius: "8px",
              backgroundColor: "#cfcaca",
              marginBottom: 2,
              "& .MuiLinearProgress-bar": {
                backgroundColor: "green",
              },
            }}
          />
          <Typography
            sx={{ fontWeight: 600, fontSize: "16px", color: "#4C2D2D" }}
          >
            Please wait, loading...
          </Typography>
        </NoDataBox>
      ) : ( */}
        <StyledContainer maxWidth="xl">
          <WhiteGrid container>
            <Grid xs={12} sm={6} md={4}>
              <CustomTextInput
                label="Major/Field of Study"
                name="fieldOfStudy"
                value={education.fieldOfStudy}
                onChange={handleChange}
                required
                helper
                allowSpaces
                textOnly
                readonly={save}
                isEditable={isEditable}
                showRequiredError={showRequiredError}
              />
            </Grid>
            <Grid xs={12} sm={6} md={4}>
              <CustomAutoComplete
                label="Academic Year/Grade level"
                value={option.academicYear?.label ? option.academicYear : null}
                onChange={(e, newValue) =>
                  handleOptions(e, newValue, "academicYear")
                }
                options={DummyOptions}
                helper
                required
                readOnly={save}
                showRequiredError={showRequiredError}
                isEditable={isEditable}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <CustomAutoComplete
                label="Current Term/Semester"
                value={
                  option.currentSemester?.label ? option.currentSemester : null
                }
                onChange={(e, newValue) =>
                  handleOptions(e, newValue, "currentSemester")
                }
                options={DummySemseterOptions}
                helper
                required
                readOnly={save}
                showRequiredError={showRequiredError}
                isEditable={isEditable}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <CustomTextInput
                label="Institution Name"
                name="institutionName"
                value={education.institutionName}
                onChange={handleChange}
                required
                textOnly
                helper
                allowSpaces
                readonly={save}
                isEditable={isEditable}
                showRequiredError={showRequiredError}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <CustomDatePicker
                label="Date of Joining"
                value={education.joiningDate}
                onChange={handleDateChange}
                required
                helper
                readOnly={save}
                showRequiredError={showRequiredError}
                isEditable={isEditable}
              />
              {error && (
                <div style={{ color: "red", fontSize: "12px" }}>{error}</div>
              )}
            </Grid>
          </WhiteGrid>
          <br />
          <WhiteGrid container>
            <Grid xs={12} sx={{ padding: 2, pb: 3 }}>
              <Typography className="bold14">Institution Address</Typography>
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <CustomAutoComplete
                label="country"
                name="country"
                value={option.country}
                options={countries}
                onChange={(e, newValue) =>
                  handleOptions(e, newValue, "country")
                }
                helper
                required
                readOnly={save}
                showRequiredError={showRequiredError}
                isEditable={isEditable}
              />
            </Grid>

            <Grid item xs={12} sm={6} md={4}>
              {option.country?.label === "India" ? (
                <CustomAutoComplete
                  label="State"
                  name="state"
                  value={option.state?.label ? option.state : null}
                  options={States}
                  onChange={(e, newValue) =>
                    handleOptions(e, newValue, "state")
                  }
                  helper
                  required
                  readOnly={save || option.country?.label !== "India"}
                  showRequiredError={showRequiredError}
                  isEditable={isEditable}
                />
              ) : (
                <CustomTextInput
                  label="State"
                  name="state"
                  value={education.state}
                  onChange={handleChange}
                  required
                  helper
                  allowSpaces
                  textOnly
                  readonly={save}
                  isEditable={isEditable}
                  showRequiredError={showRequiredError}
                />
              )}
            </Grid>

            <Grid item xs={12} sm={6} md={4}>
              <CustomTextInput
                label="City"
                name="city"
                value={education.city}
                onChange={handleChange}
                required
                helper
                allowSpaces
                textOnly
                readonly={save}
                isEditable={isEditable}
                showRequiredError={showRequiredError}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <CustomTextInput
                label="Address Line 1"
                name="addressLine1"
                value={education.addressLine1}
                onChange={handleChange}
                required
                helper
                allowSpaces
                readonly={save}
                isEditable={isEditable}
                showRequiredError={showRequiredError}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <CustomTextInput
                label="Address Line 2"
                name="addressLine2"
                value={education.addressLine2}
                onChange={handleChange}
                allowSpaces
                readonly={save}
                isEditable={isEditable}
                // showRequiredError={showRequiredError}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <CustomTextInput
                label="Pincode"
                name="pincode"
                value={education.pincode}
                onChange={handleChange}
                required
                helper
                pincode
                readonly={save}
                isEditable={isEditable}
                showRequiredError={showRequiredError}
              />
            </Grid>
          </WhiteGrid>
          <br />
        </StyledContainer>
      {/* )} */}
      <br />
      <CustomModal
        open={show}
        handleClose={() => setShow(false)}
        sx={{ minWidth: "35%", padding: 5 }}
        child={<SuccessfulProfileModal progress={progress} show1={show1} />}
      />
    </>
  );
};

export default EducationDetails;
const StyledContainer = styled(Container)`
  padding: 25px;
`;

const WhiteGrid = styled(Grid)`
  border: 2px solid white;
  border-radius: 7px;
  display: flex;
  padding: 20px;
`;
