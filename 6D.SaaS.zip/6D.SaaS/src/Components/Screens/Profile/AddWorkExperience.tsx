import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import { Box, Button, Grid } from "@mui/material";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import SaveIcon from "@mui/icons-material/Save";
import DeleteIcon from "@mui/icons-material/Delete";
import dayjs, { Dayjs } from "dayjs";
import { useSelector } from "react-redux";
import { RootState } from "../../../Store/UserSlice";
import CustomTextInput from "../../Input/CustomTextInput";
import CustomDatePicker from "../../Input/CustomDatePicker";
import CustomTextArea from "../../Input/CustomTextArea";
import SkillsInput from "../../Input/SkillsInput";
import CustomIconButton from "../../Button/CustomIconButton";
import styled from "styled-components";
import CustomAutoComplete from "../../Input/CustomAutoComplete";
import { instance } from "../../../Controller/Common";
import CustomModal from "../../Modal/CustomModal";
import SuccessfulProfileModal from "./SuccessfulProfileModal";
import FillModal from "./FillModal";
import DeleteModal from "./DeleteModal";

interface Experience {
  id: string;
  company: string;
  employmentType: string;
  jobTitle: string;
  duration: string;
  startDate: Dayjs | null;
  endDate: Dayjs | null;
  about: string;
  skills: string[];
  disable: boolean;
}

interface AddExperienceTypes {
  save: boolean;
  setSave: Dispatch<SetStateAction<boolean>>;
  getWorkExperience: () => void;
  onOpen: (Eid: number) => void;
  setShowExperience1: Dispatch<SetStateAction<boolean>>;
  active: any;
  setDisAbleExpand: Dispatch<SetStateAction<boolean>>;
  trigger: boolean;
  setTrigger: Dispatch<SetStateAction<boolean>>;
}

const AddWorkExperience: React.FC<AddExperienceTypes> = ({
  getWorkExperience,
  save,
  setSave,
  onOpen,
  setShowExperience1,
  setDisAbleExpand,
  active,
  trigger,
  setTrigger,
}) => {
  const userId = useSelector((state: RootState) => state.user.userID);
  const [experience, setExperience] = useState<Experience | null>(null);
  const [showDateError, setShowDateError] = useState<string>("");
  const [showDateError1, setShowDateError1] = useState<string>("");
  const [showExperience, setShowExperience] = useState(false);
  const [showRequiredError, setShowRequiredError] = useState(false);
  const [progress, setProgress] = useState(0);
  const [show, setShow] = useState(false);
  const [open1, setOpen1] = useState(false);
  const [open, setOpen] = useState(false);

  const EType = [
    { value: 0, label: "Full-time" },
    { value: 1, label: "Part-time" },
    { value: 2, label: "Contract" },
    { value: 3, label: "Internship" },
    { value: 4, label: "Volunteer" },
    { value: 5, label: "Temporary" },
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, name } = e.target;
    const updatedValue = value.charAt(0).toUpperCase() + value.slice(1);
    setExperience((prev) => (prev ? { ...prev, [name]: updatedValue } : null));
  };

  const handleAutoCompleteChange = (
    event: React.ChangeEvent<{}>,
    newValue: { value: number; label: string } | null
  ) => {
    setExperience((prev) =>
      prev ? { ...prev, employmentType: newValue?.label || "" } : null
    );
  };

  const handleDateChange = (date: Dayjs | null, name: string) => {
    setShowDateError("");
    setShowDateError1("");
    setExperience((prev) => {
      if (!prev) return null;

      const today = dayjs();
      const isFutureDate = date && date.isAfter(today);

      if (name === "startDate") {
        if (!date || !date.isValid()) {
          setShowDateError(
            "Please select a valid start date (day, month, year)."
          );
          return { ...prev, startDate: null };
        }
        const startDateThreshold = dayjs("1900-01-01");
        if (date.isBefore(startDateThreshold)) {
          setShowDateError("Start date cannot be before January 1, 1900.");
          return { ...prev, startDate: null };
        }
        if (isFutureDate) {
          setShowDateError("Start date cannot be in the future.");
          return { ...prev, [name]: null };
        }

        // const durationMonths = date ? today.diff(date, "month") : 0;
        // const durationText =
        //   durationMonths === 0
        //     ? "0 months"
        //     : `${durationMonths} month${durationMonths === 1 ? "" : "s"}`;

        setShowDateError("");
        return {
          ...prev,
          startDate: date,
          endDate: null,
          // duration: durationText,
        };
      }

      if (name === "endDate") {
        if (!date || !date.isValid()) {
          setShowDateError1(
            "Please select a valid end date (day, month, year)."
          );
          return { ...prev, [name]: null };
        }

        if (!prev.startDate) {
          setShowDateError1("Please select a start date first.");
          return prev;
        }
        if (isFutureDate) {
          setShowDateError1("End date cannot be in the future.");
          return { ...prev, [name]: null };
        }
        if (date && prev.startDate && date.isBefore(prev.startDate)) {
          setShowDateError1("End date cannot be before the start date.");
          return { ...prev, [name]: null };
        }
        if (date && prev.startDate && date.isSame(prev.startDate, "day")) {
          setShowDateError1("End date cannot be the same as start date.");
          return { ...prev, [name]: null };
        }

        // let durationMonths = 0;
        // if (prev.startDate && date) {
        //   durationMonths = date.diff(prev.startDate, "month");
        // } else if (prev.startDate) {
        //   durationMonths = today.diff(prev.startDate, "month");
        // }

        // const durationText =
        //   durationMonths === 0
        //     ? "0 months"
        //     : `${durationMonths} month${durationMonths === 1 ? "" : "s"}`;

        setShowDateError1("");
        return {
          ...prev,
          endDate: date,
          // duration: durationText,
        };
      }

      return prev;
    });
  };

  const handleAddSkill = (skill: string) => {
    setExperience((prev) =>
      prev ? { ...prev, skills: [...prev.skills, skill] } : null
    );
  };

  const handleDeleteSkill = (index: number) => {
    setExperience((prev) =>
      prev
        ? {
            ...prev,
            skills: prev.skills.filter((_, i) => i !== index),
          }
        : null
    );
  };

  const AddExperience = () => {
    setShowExperience1(false);
    setShowExperience(true);
    setDisAbleExpand(true);
    setSave(false);
    setExperience({
      id: userId,
      company: "",
      employmentType: "",
      jobTitle: "",
      duration: "",
      startDate: null,
      endDate: null,
      about: "",
      skills: [],
      disable: true,
    });
  };
  const CreateWorkExperience = async () => {
    if (!experience) return;
    const {
      company,
      employmentType,
      jobTitle,
      duration,
      startDate,
      endDate,
      about,
      skills,
    } = experience;

    let durationInMonths:string
    const start =
    startDate && dayjs(startDate).isValid() ? dayjs(startDate) : dayjs();
  const end = endDate && dayjs(endDate).isValid() ? dayjs(endDate) : dayjs();

  if (!start.isValid() || !end.isValid()) {
    console.error("Invalid start or end date:", startDate, endDate);
    return;
  }

  let years = end.diff(start, "year");
  const adjustedStartForMonths = start.add(years, "year");
  let months = end.diff(adjustedStartForMonths, "month");
  const adjustedStartForDays = adjustedStartForMonths.add(months, "month");
  let days = end.diff(adjustedStartForDays, "day");
  durationInMonths =`${years},${months},${days}`
    if (
      !userId ||
      !company ||
      !employmentType ||
      !jobTitle ||
      !durationInMonths ||
      !startDate ||
      !about ||
      !skills.length
    ) {
      setOpen1(true);
      setShowRequiredError(true);
      return;
    }
    if (showDateError1 || showDateError) {
      setOpen1(true);
      return;
    }
    let timer: any;

    try {
      const response = await instance.post("/6D/experience/createExperience", {
        UID: userId,
        COMPANY_NAME: company,
        EMPLOYMENT_TYPE: employmentType,
        JOB_TITLE: jobTitle,
        DURATION: durationInMonths,
        START_DATE: dayjs(startDate),
        END_DATE: dayjs(endDate),
        ROLE_DESCRIPTION: about,
        SKILLS: skills,
      });

      if (response.status === 200) {
        setExperience(null);
        setShowExperience(false);
        getWorkExperience();
        setSave(true);
        setDisAbleExpand(false);
      }
    } catch (error) {
      console.error(error);
    } finally {
      clearInterval(timer);
    }
  };

  useEffect(() => {
    if (trigger === true) {
      CreateWorkExperience();
    }
  }, [trigger]);
  
  const calculateDateDifference = (
    startDate: Dayjs | null,
    endDate: Dayjs | null = dayjs()
  ) => {
    const start =
      startDate && dayjs(startDate).isValid() ? dayjs(startDate) : dayjs();
    const end = endDate && dayjs(endDate).isValid() ? dayjs(endDate) : dayjs();

    if (!start.isValid() || !end.isValid()) {
      console.error("Invalid start or end date:", startDate, endDate);
      return;
    }

    let years = end.diff(start, "year");
    const adjustedStartForMonths = start.add(years, "year");
    let months = end.diff(adjustedStartForMonths, "month");
    const adjustedStartForDays = adjustedStartForMonths.add(months, "month");
    let days = end.diff(adjustedStartForDays, "day");

    const yearString = years > 0 ? `${years} year${years > 1 ? "s" : ""}` : "";
    const monthString =
      months > 0 ? `${months} month${months > 1 ? "s" : ""}` : "";
    const dayString = days > 0 ? `${days} day${days > 1 ? "s" : ""}` : "";

    const result = [yearString, monthString, dayString]
      .filter((str) => str)
      .join(" ");

    setExperience((prev: any) => ({
      ...prev,
      duration: result,
    }));
  };

  useEffect(() => {
    if (experience?.startDate) {
      calculateDateDifference(
        experience?.startDate ?? null,
        experience?.endDate
      );
    }
  }, [experience?.startDate, experience?.endDate]);

  return (
    <>
      <CustomModal
        open={show}
        handleClose={() => setShow(false)}
        sx={{ minWidth: "35%", padding: 5 }}
        child={<SuccessfulProfileModal progress={progress} show1={show} />}
      />
      <CustomModal
        open={open1}
        handleClose={() => setOpen1(false)}
        sx={{ minWidth: "35%", padding: 5 }}
        child={
          <FillModal
            setOpen1={setOpen1}
            trigger={trigger}
            setTrigger={setTrigger}
          />
        }
      />
      <CustomModal
        open={open}
        handleClose={() => setOpen(false)}
        sx={{ minWidth: "35%", padding: 5 }}
        child={
          <DeleteModal
            setShowExperience={setShowExperience}
            setOpen={setOpen}
            setSave={setSave}
            setDisAbleExpand={setDisAbleExpand}
          />
        }
      />
      {/* Add Work Experience Button */}
      <Box sx={{ float: "right" }}>
        <Button
          variant="contained"
          className="addExperience"
          onClick={AddExperience}
          disabled={active.length > 0 || showExperience}
        >
          <AddCircleIcon
            color={showExperience || active.length > 0 ? "disabled" : "info"}
          />
          &nbsp; Add Work Experience
        </Button>
      </Box>
      {/* Work Experience Form */}
      {showExperience && experience && (
        <>
          <br />
          <br />
          <WhiteGridWrapper>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Company"
                  name="company"
                  value={experience.company ? experience.company : undefined}
                  onChange={handleChange}
                  required
                  allowSpaces
                  textOnly
                  helper
                  isEditable
                  showRequiredError={showRequiredError}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomAutoComplete
                  label="Employment Type"
                  options={EType}
                  value={EType.find(
                    (option) => option.label === experience.employmentType
                  )}
                  onChange={handleAutoCompleteChange}
                  helper
                  isEditable
                  required
                  showRequiredError={showRequiredError}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Job Title"
                  name="jobTitle"
                  value={experience.jobTitle ? experience.jobTitle : undefined}
                  onChange={handleChange}
                  required
                  allowSpaces
                  helper
                  textOnly
                  isEditable
                  showRequiredError={showRequiredError}
                />
              </Grid>

              <Grid item xs={12} sm={6} md={4}>
                <CustomDatePicker
                  label="Start Date"
                  name="startDate"
                  value={experience.startDate}
                  maxDate={dayjs().subtract(1, "day")}
                  onChange={(date) => handleDateChange(date, "startDate")}
                  required
                  helper
                  // isEditable={experience.startDate ? true : false}
                  isEditable
                  showRequiredError={showRequiredError}
                  helperText={showDateError}
                />
                {/* {showDateError && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {showDateError}
                  </p>
                )} */}
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomDatePicker
                  label="End Date"
                  name="endDate"
                  maxDate={dayjs().subtract(1, "day")}
                  minDate={
                    experience.startDate
                      ? dayjs(experience.startDate).add(1, "day")
                      : undefined
                  }
                  value={experience.endDate}
                  onChange={(date) => handleDateChange(date, "endDate")}
                  // isEditable={experience.endDate ? true : false}
                  isEditable
                  helper
                  helperText={showDateError1}
                  // disabled={!experience.startDate}
                />
                {/* {showDateError1 && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {showDateError1}
                  </p>
                )} */}
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <CustomTextInput
                  label="Duration"
                  name="duration"
                  value={experience.duration ? experience.duration : undefined}
                  onChange={handleChange}
                  readonly
                  isEditable
                />
              </Grid>
              <Grid item xs={12}>
                <CustomTextArea
                  id="textArea"
                  label="Tell us about the Role"
                  name="about"
                  placeholder="Enter your description here..."
                  value={experience.about}
                  onChange={handleChange}
                  required
                  helper
                  showRequiredError={showRequiredError}
                />
              </Grid>
              <Grid item xs={12}>
                <SkillsInput
                  id={"skills"}
                  label="Preferred Skills"
                  name="skills"
                  skills={experience.skills}
                  onDeleteSkill={handleDeleteSkill}
                  onAddSkill={handleAddSkill}
                  required
                  helper
                  showRequiredError={showRequiredError}
                />
              </Grid>
              <Grid item xs={12}>
                <Box sx={{ float: "right" }}>
                  <ButtonBox>
                    <CustomIconButton
                      variant="primary"
                      iconSize={20}
                      icon={DeleteIcon}
                      onClick={() => setOpen(true)}
                    />
                    &nbsp; &nbsp;
                    <CustomIconButton
                      variant="primary"
                      iconSize={20}
                      icon={SaveIcon}
                      onClick={CreateWorkExperience}
                    />
                  </ButtonBox>
                </Box>
              </Grid>
            </Grid>
          </WhiteGridWrapper>
        </>
      )}
    </>
  );
};

export default AddWorkExperience;

const WhiteGridWrapper = styled.div`
  border: 2px solid white;
  border-radius: 7px;
  padding: 30px;
  margin-top: 20px;
`;

const ButtonBox = styled(Box)`
  display: flex;
  flex-direction: row;
  padding: 5px;
  border-radius: 5px;
  background-color: #ffffff;
`;
