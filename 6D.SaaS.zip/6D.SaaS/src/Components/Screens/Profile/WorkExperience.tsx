import {
  Box,
  Container,
  Grid,
  Button,
  Typography,
  LinearProgress,
} from "@mui/material";
import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import styled from "styled-components";
import CustomTextInput from "../../Input/CustomTextInput";
import CustomAutoComplete, { OptionType } from "../../Input/CustomAutoComplete";
import CustomDatePicker from "../../Input/CustomDatePicker";
import DeleteIcon from "@mui/icons-material/Delete";
import ExpandCircleDownIcon from "@mui/icons-material/ExpandCircleDown";
import ExpandLessRoundedIcon from "@mui/icons-material/ExpandLessRounded";
import dayjs, { Dayjs } from "dayjs";
import CustomTextArea from "../../Input/CustomTextArea";
import SkillsInput from "../../Input/SkillsInput";
import EditNoteIcon from "@mui/icons-material/EditNote";
import CustomIconButton from "../../Button/CustomIconButton";
import SaveIcon from "@mui/icons-material/Save";
import { instance } from "../../../Controller/Common";
import { useSelector } from "react-redux";
import { RootState } from "../../../Store/UserSlice";
import CustomModal from "../../Modal/CustomModal";
import DeleteExperinceModal from "./DeleteExperienceModal.tsx";
import AddWorkExperience from "./AddWorkExperience";
import SuccessfulProfileModal from "./SuccessfulProfileModal";
import AlertCompleteModal from "../../CustomTab/AlertCompleteModal";
import FillModal from "./FillModal";

const EType = [
  { value: 0, label: "Full-time" },
  { value: 1, label: "Part-time" },
  { value: 2, label: "Contract" },
  { value: 3, label: "Internship" },
  { value: 4, label: "Volunteer" },
  { value: 5, label: "Temporary" },
];

interface workExperienceTypes {
  save: boolean;
  trigger: boolean;
  setTrigger: Dispatch<SetStateAction<boolean>>;
  setSave: Dispatch<SetStateAction<boolean>>;
}

const WorkExperience: React.FC<workExperienceTypes> = ({
  save,
  setSave,
  trigger,
  setTrigger,
}) => {
  const userId = useSelector((state: RootState) => state.user.userID);
  const [experienceData, setExperienceData] = useState<any[]>([]);
  const [showExperience, setShowExperience] = useState(false);
  const [error, setError] = useState("");
  const [error1, setError1] = useState("");
  const [error3, setError3] = useState("");
  const [progress, setProgress] = useState(0);
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);
  const [enable, setEnable] = useState(true);
  const [showRequiredError, setShowRequiredError] = useState(false);
  const [isEditable, setIsEditable] = useState(false);
  const [isDisabled, setIsDisabled] = useState(false);
  const [active, setActive] = useState<number[]>([]);
  const [disAbleExpand, setDisAbleExpand] = useState(false);
  const [disableOtherActions, setDisableOtherActions] = useState<{
    [key: number]: boolean;
  }>({});

  const getWorkExperience = async () => {
    try {
      const response = await instance.get(
        `/6D/experience/getExperience?id=${userId}`
      );
      const data = response.data;

      if (response.status === 200) {
        const sortedData = data.sort(
          (a: any, b: any) =>
            new Date(b.START_DATE).getTime() - new Date(a.START_DATE).getTime()
        );
        setExperienceData(sortedData);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleDelete = async () => {
    if (!deleteExperienceId) return;
    try {
      const response = await instance.delete(
        `/6D/experience/deleteExperience?id=${deleteExperienceId}`
      );
      if (response.status === 200) {
        setExpandedExperience((prev) => {
          const newState = { ...prev };
          delete newState[deleteExperienceId];
          return newState;
        });
        setSave(true);
        setDisAbleExpand(false);
        setEnable(true);
        setShowExperience(false);
        setError("");
        setError1("");
        setError3("");
        getWorkExperience();
        setActive([]);
        setIsEditable(false);
        setTrigger(false);
        setNewEID(null);
        setDisableOtherActions({});
        setEditExperience({});
        setSubmitEnabled({});
      }
    } catch (error) {
      console.error("Error deleting experience", error);
    } finally {
      setDeleteExperienceId(null);
    }
  };

  useEffect(() => {
    getWorkExperience();
  }, []);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    EID: number
  ) => {
    const { value, name } = e.target;
    setExperienceData((prev) =>
      prev.map((exp) => (exp.EID === EID ? { ...exp, [name]: value } : exp))
    );
  };

  const handleEmployee = (
    event: React.ChangeEvent<{}>,
    newValue: OptionType | null,
    EID: number
  ) => {
    const type = newValue?.label;
    setExperienceData((prev) =>
      prev.map((exp) =>
        exp.EID === EID ? { ...exp, EMPLOYMENT_TYPE: type } : exp
      )
    );
  };

  const handleDateChange = (date: Dayjs | null, name: string, EID: number) => {
    setError("");
    setError1("");
    setError3("");
    setExperienceData((prev) =>
      prev.map((exp) => {
        if (exp.EID === EID) {
          let updatedExperience = { ...exp };

          if (name === "START_DATE") {
            updatedExperience = {
              ...updatedExperience,
              [name]: date,
              // END_DATE: null,
              DURATION: 0,
            };
          } else {
            updatedExperience = {
              ...updatedExperience,
              [name]: date,
            };
          }

          const startDate = updatedExperience.START_DATE
            ? dayjs(updatedExperience.START_DATE)
            : null;
          const endDate = updatedExperience.END_DATE
            ? dayjs(updatedExperience.END_DATE)
            : null;
          const today = dayjs();

          // Calculate duration
          if (startDate) {
            if (endDate) {
              const durationInMonths = endDate.diff(startDate, "month");
              updatedExperience.DURATION =
                durationInMonths < 0 ? 0 : durationInMonths;
            } else {
              const durationInMonths = today.diff(startDate, "month");
              updatedExperience.DURATION =
                durationInMonths < 0 ? 0 : durationInMonths;
            }
          } else {
            updatedExperience.DURATION = 0;
          }

          return updatedExperience;
        }
        return exp;
      })
    );
  };

  const handleManualDateChange = (
    date: Dayjs | null,
    name: string,
    EID: number
  ) => {
    setError1("");
    setError3("");

    if (!date) {
      setExperienceData((prev) =>
        prev.map((exp) =>
          exp.EID === EID
            ? {
                ...exp,
                [name]: null,
                DURATION: 0,
              }
            : exp
        )
      );
      return;
    }
    if (!date.isValid() || date.format("YYYY-MM-DD") === "Invalid Date") {
      if (name === "START_DATE") {
        setError1("Please enter a complete date with day, month, and year");
      } else {
        setError3("Please enter a complete date with day, month, and year");
      }
      return;
    }
    const minDate = dayjs("1900-01-01");
    if (date.isBefore(minDate)) {
      if (name === "START_DATE") {
        setError1("Date cannot be earlier than 1900");
      } else {
        setError3("Date cannot be earlier than 1900");
      }
      return;
    }
    const today = dayjs();
    const experience = experienceData.find((exp) => exp.EID === EID);
    if (name === "START_DATE") {
      if (date && date.isAfter(today)) {
        setError1("Start date cannot be a future date");
        setExperienceData((prev) =>
          prev.map((exp) =>
            exp.EID === EID
              ? {
                  ...exp,
                  START_DATE: null,
                  END_DATE: null,
                  DURATION: 0,
                }
              : exp
          )
        );
        return;
      }

      if (
        experience?.END_DATE &&
        date &&
        dayjs(experience.END_DATE).isBefore(date)
      ) {
        setError3("End date cannot be before start date");
        setExperienceData((prev) =>
          prev.map((exp) =>
            exp.EID === EID
              ? {
                  ...exp,
                  START_DATE: date,
                  END_DATE: null,
                  DURATION: 0,
                }
              : exp
          )
        );
        return;
      }
    }

    if (name === "END_DATE") {
      // Validate end date
      if (!experience?.START_DATE) {
        setError3("Please select a start date first");
        return;
      }

      if (date && date.isAfter(today)) {
        setError3("End date cannot be a future date");
        setExperienceData((prev) =>
          prev.map((exp) =>
            exp.EID === EID ? { ...exp, END_DATE: null, DURATION: 0 } : exp
          )
        );
        return;
      }

      const startDate = dayjs(experience.START_DATE);
      if (date && date.isBefore(startDate)) {
        setError3("End date cannot be before start date");
        setExperienceData((prev) =>
          prev.map((exp) =>
            exp.EID === EID ? { ...exp, END_DATE: null, DURATION: 0 } : exp
          )
        );
        return;
      }

      if (date && date.isSame(startDate, "day")) {
        setError3("End date cannot be the same as start date");
        setExperienceData((prev) =>
          prev.map((exp) =>
            exp.EID === EID ? { ...exp, END_DATE: null, DURATION: 0 } : exp
          )
        );
        return;
      }
    }

    handleDateChange(date, name, EID);
  };

  const handleDeleteSkill = (skillIndex: number, EID: number) => {
    setExperienceData((prev) =>
      prev.map((exp) => {
        if (exp.EID === EID) {
          const updatedSkills = [...exp.SKILLS];
          updatedSkills.splice(skillIndex, 1);
          return { ...exp, SKILLS: updatedSkills };
        }
        return exp;
      })
    );
  };

  const handleAddSkill = (skill: string, EID: number) => {
    setExperienceData((prev) =>
      prev.map((exp) =>
        exp.EID === EID ? { ...exp, SKILLS: [...exp.SKILLS, skill] } : exp
      )
    );
  };

  const [expandedExperience, setExpandedExperience] = useState<{
    [key: number]: boolean;
  }>({});
  const [editExperience, setEditExperience] = useState<{
    [key: number]: boolean;
  }>({});
  const [submitEnabled, setSubmitEnabled] = useState<{
    [key: number]: boolean;
  }>({});
  const [deleteExperienceId, setDeleteExperienceId] = useState<number | null>(
    null
  );

  const handleClickExpand = (EID: number, type: string) => {
    if (type === "UP") {
      setActive([]);
    } else {
      setActive((prevActive) =>
        prevActive.includes(EID)
          ? prevActive.filter((id) => id !== EID)
          : [...prevActive, EID]
      );
    }

    const isAnyEditing = Object.values(editExperience).some(
      (editing) => editing
    );
    if (isAnyEditing) {
      setShow2(true);
      return;
    }

    setExpandedExperience((prev) => {
      const newExpandedState = { ...prev, [EID]: !prev[EID] };
      Object.keys(newExpandedState).forEach((key) => {
        const experienceID = Number(key);
        if (experienceID !== EID) {
          newExpandedState[experienceID] = false;
        }
      });
      return newExpandedState;
    });
    setSubmitEnabled({ [EID]: false });
    setEditExperience({ [EID]: false });
  };

  const handleEdit = (EID: number) => {
    setSave(false);
    setEnable(false);
    setActive([]);
    setDisAbleExpand(true);
    setActive((prevActive) =>
      prevActive.includes(EID)
        ? prevActive.filter((id) => id !== EID)
        : [...prevActive, EID]
    );
    const isAnyEditing = Object.values(editExperience).some(
      (editing) => editing
    );

    if (isAnyEditing) {
      setShow2(true);
      return;
    }
    setIsEditable(true);
    setExpandedExperience({ [EID]: true });
    setSubmitEnabled({ [EID]: true });
    setEditExperience({ [EID]: true });
    setEnable(false);
    const newDisableState = experienceData.reduce((acc, exp) => {
      acc[exp.EID] = exp.EID !== EID;
      return acc;
    }, {});
  
    setDisableOtherActions(newDisableState);
  };

  const [newEID, setNewEID] = useState(null);

  const handleSubmit = async (EID: number) => {
    if (!EID) return;
    const filteredExperience = experienceData.find((exp) => exp.EID === EID);
    if (!filteredExperience) return;
    const requiredFields = [
      filteredExperience.COMPANY_NAME,
      filteredExperience.EMPLOYMENT_TYPE,
      filteredExperience.JOB_TITLE,
      // filteredExperience.DURATION,
      filteredExperience.START_DATE,
      filteredExperience.ROLE_DESCRIPTION,
    ];
    if (requiredFields.some((field) => !field) || error3 !== "") {
      setShowRequiredError(true);
      setShow1(true);
      setTrigger(false);
      return;
    }
    if (error || error1 || error3) {
      setShow1(true);
      setTrigger(false);
      return false;
    }
    try {
      const response = await instance.put(
        `/6D/experience/updateExperience?id=${EID}`,
        {
          UID: userId,
          COMPANY_NAME: filteredExperience.COMPANY_NAME,
          EMPLOYMENT_TYPE: filteredExperience.EMPLOYMENT_TYPE,
          JOB_TITLE: filteredExperience.JOB_TITLE,
          DURATION: filteredExperience.DURATION,
          START_DATE: dayjs(filteredExperience.START_DATE),
          END_DATE: dayjs(filteredExperience.END_DATE),
          ROLE_DESCRIPTION: filteredExperience.ROLE_DESCRIPTION,
          SKILLS: filteredExperience.SKILLS,
        }
      );

      if (response.status === 200) {
        setSave(true);
        setDisAbleExpand(false);
        setEnable(true);
        setSubmitEnabled({ [EID]: false });
        setEditExperience({ [EID]: false });
        setExpandedExperience({ [EID]: false });
        setShowExperience(false);
        setError("");
        setError1("");
        setError3("");
        getWorkExperience();
        setActive([]);
        setIsEditable(false);
        setTrigger(false);
        setNewEID(null);
        setDisableOtherActions({});
        setEditExperience({});
        setSubmitEnabled({});
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (trigger === true && newEID) {
      handleSubmit(newEID);
    }
  }, [trigger, newEID]);

  const handlePopup = (EID: number) => {
    setDeleteExperienceId(EID);
    setShowExperience(true);
  };

  const handleFalse = (EID: number) => {
    setShowExperience(false);
    setSubmitEnabled({ [EID]: false });
    setEditExperience({ [EID]: false });
    setExpandedExperience({ [EID]: false });
    setDisableOtherActions((prev) => {
      const newState = { ...prev };
      Object.keys(newState).forEach((key) => {
        const experienceID = Number(key);
        if (experienceID !== EID) {
          newState[experienceID] = false;
        }
      });
      return newState;
    });
  };

  const newDuration = (value: string) => {
    const newArray = value?.split(",").map((str) => str.trim());

    const years = Number(newArray[0] || 0);
    const months = Number(newArray[1] || 0);
    const days = Number(newArray[2] || 0);

    const yearString = years > 0 ? `${years} year${years > 1 ? "s" : ""}` : "";
    const monthString =
      months > 0 ? `${months} month${months > 1 ? "s" : ""}` : "";
    const dayString = days > 0 ? `${days} day${days > 1 ? "s" : ""}` : "";

    const result = [yearString, monthString, dayString]
      .filter((str) => str)
      .join(" ");

    return result;
  };

  const NewDurationValue = (
    startDate: Dayjs | null,
    endDate: Dayjs | null = dayjs(),
    value: string,
    index: number
  ) => {
    const start =
      startDate && dayjs(startDate).isValid() ? dayjs(startDate) : dayjs();
    const end = endDate && dayjs(endDate).isValid() ? dayjs(endDate) : dayjs();
    const check = experienceData[index]?.START_DATE === start;
    if (check) {
      newDuration(value);
    } else if (!check) {
      if (!start.isValid() || !end.isValid()) {
        console.error("Invalid start or end date:", startDate, endDate);
        return;
      }

      let years = end.diff(start, "year");
      const adjustedStartForMonths = start.add(years, "year");
      let months = end.diff(adjustedStartForMonths, "month");
      const adjustedStartForDays = adjustedStartForMonths.add(months, "month");
      let days = end.diff(adjustedStartForDays, "day");

      const yearString =
        years > 0 ? `${years} year${years > 1 ? "s" : ""}` : "";
      const monthString =
        months > 0 ? `${months} month${months > 1 ? "s" : ""}` : "";
      const dayString = days > 0 ? `${days} day${days > 1 ? "s" : ""}` : "";

      const result = [yearString, monthString, dayString]
        .filter((str) => str)
        .join(" ");
      return result;
    }
  };

  return (
    <>
      <CustomModal
        open={show1}
        handleClose={() => setShow1(false)}
        // sx={{ height: "auto", mt: 5 }}
        child={<FillModal setOpen1={setShow1} />}
      />
      <CustomModal
        open={show}
        handleClose={() => setShow(false)}
        sx={{ minWidth: "35%", padding: 5 }}
        child={<SuccessfulProfileModal progress={progress} show1={show} />}
      />
      <CustomModal
        open={show2}
        handleClose={() => setShow2(false)}
        child={<AlertCompleteModal setShow={setShow2} />}
      />

      <StyledContainer maxWidth="xl">
        <Box>
          <AddWorkExperience
            getWorkExperience={getWorkExperience}
            save={save}
            setSave={setSave}
            onOpen={handleFalse}
            setShowExperience1={setShowExperience}
            active={active}
            setDisAbleExpand={setDisAbleExpand}
            trigger={trigger}
            setTrigger={setTrigger}
          />
        </Box>
      </StyledContainer>
      <StyledContainer maxWidth="xl">
        <br />
        {Array.isArray(experienceData) &&
          experienceData.map((e: any, i: number) => (
            <>
              <SummaryBox key={e.EID}>
                <Typography
                  sx={{
                    fontWeight: 600,
                    fontSize: "14px",
                    color: "#3F3F40",
                    marginLeft: "10px",
                  }}
                >
                  {new Date(e.START_DATE).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                  })}{" "}
                  {e.END_DATE ? "to" : ""}{" "}
                  {e.END_DATE &&
                    new Date(e.END_DATE).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                </Typography>
                <Typography
                  sx={{
                    fontWeight: 400,
                    fontSize: "14px",
                    color: "#3F3F40",
                  }}
                >
                  {e.COMPANY_NAME} - {e.JOB_TITLE}
                </Typography>
                <ButtonBox>
                  <CustomIconButton
                    variant="primary"
                    icon={EditNoteIcon}
                    disable={
                      editExperience[e.EID] === true ||
                      disAbleExpand ||
                      disableOtherActions[e.EID]
                    }
                    onClick={() => {
                      handleEdit(e.EID);
                      setNewEID(e.EID);
                      setShowExperience(false);
                      setIsDisabled(true);
                    }}
                  />
                  &nbsp; &nbsp;
                  <CustomIconButton
                    variant="primary"
                    icon={DeleteIcon}
                    disable={disableOtherActions[e.EID]}
                    onClick={() => handlePopup(e.EID)}
                  />
                  &nbsp; &nbsp;
                  <CustomIconButton
                    variant="primary"
                    icon={SaveIcon}
                    disable={
                      !submitEnabled[e.EID] || disableOtherActions[e.EID]
                    }
                    onClick={() => {
                      handleSubmit(e.EID);
                    }}
                  />
                  &nbsp; &nbsp;
                  <CustomIconButton
                    variant="secondary"
                    icon={
                      expandedExperience[e.EID]
                        ? ExpandLessRoundedIcon
                        : ExpandCircleDownIcon
                    }
                    disable={disAbleExpand || disableOtherActions[e.EID]}
                    onClick={() =>
                      handleClickExpand(
                        e.EID,
                        expandedExperience[e.EID] ? "UP" : "DOWN"
                      )
                    }
                  />
                </ButtonBox>
              </SummaryBox>
              <br />
              <br />
              {expandedExperience[e.EID] && (
                <>
                  <WhiteGrid container>
                    <Grid item xs={12} sm={6} md={4}>
                      <CustomTextInput
                        label="Company"
                        name="COMPANY_NAME"
                        value={e.COMPANY_NAME}
                        onChange={(event) => handleChange(event, e.EID)}
                        helper
                        required
                        allowSpaces
                        readonly={enable}
                        isEditable={isEditable}
                        showRequiredError={showRequiredError}
                        textOnly
                      />
                    </Grid>
                    <Grid item xs={12} sm={6} md={4}>
                      <CustomAutoComplete
                        label="Employment Type"
                        options={EType}
                        value={
                          EType.find(
                            (option) => option.label === e.EMPLOYMENT_TYPE
                          ) || null
                        }
                        onChange={(event, newValue) =>
                          handleEmployee(event, newValue, e.EID)
                        }
                        helper
                        required
                        readOnly={enable}
                        showRequiredError={showRequiredError}
                        isEditable={isEditable}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6} md={4}>
                      <CustomTextInput
                        label="Job Title"
                        name="JOB_TITLE"
                        value={e.JOB_TITLE}
                        onChange={(event) => handleChange(event, e.EID)}
                        helper
                        allowSpaces
                        required
                        readonly={enable}
                        isEditable={isEditable}
                        showRequiredError={showRequiredError}
                        textOnly
                      />
                    </Grid>
                    <Grid item xs={12} sm={6} md={4}>
                      <CustomDatePicker
                        label="Start Date"
                        name="START_DATE"
                        value={e.START_DATE ? dayjs(e.START_DATE) : null}
                        maxDate={dayjs().subtract(1, "day")}
                        onChange={(date) =>
                          handleManualDateChange(date, "START_DATE", e.EID)
                        }
                        required
                        helper
                        readOnly={enable}
                        showRequiredError={showRequiredError}
                        isEditable={isEditable}
                        helperText={error1}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6} md={4}>
                      <CustomDatePicker
                        label="End Date"
                        name="END_DATE"
                        value={dayjs(e.END_DATE)}
                        maxDate={dayjs().subtract(1, "day")}
                        minDate={
                          e.START_DATE
                            ? dayjs(e.START_DATE).add(1, "day")
                            : undefined
                        }
                        onChange={
                          (date) =>
                            handleManualDateChange(date, "END_DATE", e.EID)
                          // handleDateChange(date, "END_DATE", e.EID)
                        }
                        // required
                        helper
                        readOnly={!e.START_DATE || enable}
                        isEditable={isEditable}
                        helperText={error3}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6} md={4}>
                      <CustomTextInput
                        label="Duration"
                        name="DURATION"
                        // value={
                        //   e.DURATION ? `${e.DURATION} months ` : "0 months"
                        // }
                        // value={
                        //   experienceData[i]?.START_DATE !== e?.START_DATE
                        //     ? calculateDateDifference(
                        //         e?.START_DATE,
                        //         e?.END_DATE
                        //       )
                        //     : newDuration(e?.DURATION)
                        // }
                        value={NewDurationValue(
                          e?.START_DATE,
                          e?.END_DATE,
                          e?.DURATION,
                          i
                        )}
                        onChange={(event) => handleChange(event, e.EID)}
                        helper
                        required
                        allowSpaces
                        // readonly
                        readonly={enable}
                        isEditable={isEditable}
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <CustomTextArea
                        id={"textArea"}
                        label="Tell us about the Role"
                        name="ROLE_DESCRIPTION"
                        value={e.ROLE_DESCRIPTION}
                        onChange={(event) => handleChange(event, e.EID)}
                        required
                        helper
                        disabled={enable}
                        showRequiredError={showRequiredError}
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <SkillsInput
                        id={`skillsInput-${e.EID}`}
                        label="Preferred Skills"
                        name="SKILLS"
                        skills={e.SKILLS}
                        onDeleteSkill={(skillIndex: any) =>
                          handleDeleteSkill(skillIndex, e.EID)
                        }
                        onAddSkill={(skill) => handleAddSkill(skill, e.EID)}
                        required
                        helper
                        disabled={enable}
                        showRequiredError={showRequiredError}
                      />
                    </Grid>
                  </WhiteGrid>
                  <br />
                </>
              )}
            </>
          ))}

        <CustomModal
          open={showExperience}
          handleClose={() => setShowExperience(false)}
          sx={{ minWidth: "35%", padding: 5 }}
          child={
            <DeleteExperinceModal
              setShowExperience={setShowExperience}
              handleDelete={handleDelete}
            />
          }
        />
      </StyledContainer>
    </>
  );
};

export default WorkExperience;

const StyledContainer = styled(Container)`
  padding: 25px;
`;
const NoDataBox = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  /* background-color: #f0f0f0; */
  border-radius: 10px;
  margin-top: 10rem;
  padding: 20px;
`;
const WhiteGrid = styled(Grid)`
  border: 2px solid white;
  border-radius: 7px;
  display: flex;
  justify-content: flex-end;
  padding: 30px;
`;

const SummaryBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  padding: 5px;
  background-color: #ffffff;
  border-radius: 5px;
  align-items: center;
`;

const ButtonBox = styled(Box)`
  display: flex;
  flex-direction: row;
  padding: 5px;
  border-radius: 5px;
  background-color: #ffffff;
`;
