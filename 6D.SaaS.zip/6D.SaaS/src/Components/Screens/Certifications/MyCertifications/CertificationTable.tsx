import {
  FormControlLabel,
  IconButton,
  LinearProgress,
  Table,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  useMediaQuery,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import TableBody from "@mui/material/TableBody";
import CancelIcon from "@mui/icons-material/Cancel";
import TimelapseIcon from "@mui/icons-material/Timelapse";
import VerifiedIcon from "@mui/icons-material/Verified";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import PlayCircleOutlineRoundedIcon from "@mui/icons-material/PlayCircleOutlineRounded";
import NotStartedIcon from "@mui/icons-material/NotStarted";
import Paper from "@mui/material/Paper";
import Checkbox from "@mui/material/Checkbox";
import { Box } from "@mui/material";
import React, { useState } from "react";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import CustomButton from "../../../Button/CustomButton";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../../../Store/UserSlice";
import { useNavigate } from "react-router-dom";
import {
  changeClassRoomValue,
  getAssessmentIndex,
  getModuleIndex,
  getTopicIndex,
} from "../../../../Store/ClassroomSlice";
import useResponsiveCoursePerPage from "../CourseCatlog/useResponsiveCoursePerPage";

const label = { inputProps: { "aria-label": "Checkbox demo" } };

interface CourseDetails {
  CID: number;
  TITLE: string;
  DESCRIPTION: string;
  DURATION: number;
  THUMBNAIL: string;
  AVAILABILITY: string;
}

interface Certification {
  UC_ID: number;
  CID: number;
  UID: number;
  STATUS: string;
  PROGRESS: any;
  ATTEMPT: number;
  ENROLLED_ON: string;
  TIME_SPENT: any;
  courseDetails: CourseDetails;
}

interface CertificationProps {
  data: Certification[];
  handleModal: (cetifications: Certification) => void;
  getUserCertification: () => Promise<void>;
}

const CertificationTable: React.FC<CertificationProps> = ({
  data,
  handleModal,
  getUserCertification,
}) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [showScore, setShowScore] = useState(false);
  const [titleSort, setTitleSort] = useState(false);
  const [isStatusDesc, setIsStatusDesc] = React.useState(false);
  const [isTitleDesc, setIsTitleDesc] = React.useState(false);
  const [isprogressDesc, setIsprogressDesc] = React.useState(false);
  const [currentPage, setCurrentPage] = React.useState(1);
  const coursePerPage = useResponsiveCoursePerPage();
  const [isReversed, setIsReversed] = useState(false);
  const [isSortAttempt, setIsSortAttempt] = useState(false);
  const [isSortTime, setIsSortTime] = useState(false);
  const [isSortDate, setIsSortDate] = useState(false);
  const [isSortProgress, setIsSortProgress] = useState(false);
  const [isStatusFiltered, setIsStatusFiltered] = React.useState(false);
  const userId = useSelector((state: RootState) => state.user.userID);

  const handleExpandTitle = () => {
    if (!titleSort) {
      setTitleSort(true);
      setIsTitleDesc(false);
    } else {
      setIsTitleDesc((prev) => !prev);
    }
    // setIsReversed((prev) => !prev);
    setIsSortAttempt(false);
    setIsSortTime(false);
    setIsSortProgress(false);
    setIsStatusFiltered(false);
    setIsSortDate(false);
  };

  const handleExpandTime = () => {
    setIsSortTime(!isSortTime);
    setIsReversed(false);
    setIsSortProgress(false);
    setIsSortAttempt(false);
    setIsStatusFiltered(false);
    setIsSortDate(false);
  };

  const handleExpandStatus = () => {
    if (!isStatusFiltered) {
      setIsStatusFiltered(true);
      setIsStatusDesc(false);
    } else {
      setIsStatusDesc((prev) => !prev);
    }
    // setIsStatusFiltered(!isStatusFiltered);
    // setIsReversed(false);
    setTitleSort(false);
    setIsSortTime(false);
    setIsSortAttempt(false);
    setIsSortProgress(false);
    setIsSortDate(false);
  };

  const handleExpandProgress = () => {
    if (!isSortProgress) {
      setIsSortProgress(true);
      setIsprogressDesc(false);
    } else {
      setIsprogressDesc((prev) => !prev);
    }
    // setIsSortProgress(!isSortProgress);
    // setIsReversed(!isSortProgress);
    setTitleSort(false);
    setIsSortTime(false);
    setIsSortAttempt(false);
    setIsStatusFiltered(false);
    setIsSortDate(false);
  };

  const handleExpandDate = () => {
    setIsSortDate(!isSortDate);
    setIsReversed(false);
    setIsSortTime(false);
    setIsSortAttempt(false);
    setIsSortProgress(false);
    setIsStatusFiltered(false);
  };

  const formatDuration = (duration: number) => {
    const hours = Math.floor(duration);
    const minutes = (duration % 1) * 60;

    return minutes > 0 ? `${hours} hr ${minutes} min` : `${hours} hr`;
  };

  const parseDate = (dateString: string): string => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const monthNames = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    const month = monthNames[date.getMonth()];
    const year = date.getFullYear();
    return `${day} ${month} ${year}`;
  };

  const sortCertificationList = React.useMemo(() => {
    let certificationList = [...data];
    certificationList.reverse();

    if (isReversed) {
      certificationList.reverse();
    }
    if (titleSort) {
      certificationList.sort((a, b) =>
        isTitleDesc
          ? b.courseDetails.TITLE.localeCompare(a.courseDetails.TITLE)
          : a.courseDetails.TITLE.localeCompare(b.courseDetails.TITLE)
      );
    }
    if (isSortProgress) {
      certificationList.sort((a, b) =>
        isprogressDesc
          ? Number(b.PROGRESS) - Number(a.PROGRESS)
          : Number(a.PROGRESS) - Number(b.PROGRESS)
      );
    }
    if (isSortTime) {
      certificationList.sort((a, b) => a.TIME_SPENT - b.TIME_SPENT);
    }
    if (isSortDate) {
      certificationList.sort(
        (a, b) =>
          new Date(a.ENROLLED_ON).getTime() - new Date(b.ENROLLED_ON).getTime()
      );
    }
    if (isStatusFiltered) {
      certificationList.sort((a, b) =>
        isStatusDesc
          ? b.STATUS.localeCompare(a.STATUS)
          : a.STATUS.localeCompare(b.STATUS)
      );
    }
    return certificationList;
  }, [
    data,
    isReversed,
    isStatusFiltered,
    isSortAttempt,
    isSortTime,
    isSortProgress,
    isSortDate,
    isTitleDesc,
    titleSort,
    isprogressDesc,
    isStatusDesc,
  ]);

  const indexOfLastJob = currentPage * coursePerPage;
  const indexOfFirstJob = indexOfLastJob - coursePerPage;
  const currentCertificationList = sortCertificationList.slice(
    indexOfFirstJob,
    indexOfLastJob
  );

  const totalPages = Math.ceil(data.length / coursePerPage);

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  const handleContinue = (certifications: any) => {
    dispatch(changeClassRoomValue(certifications.courseDetails.CID));
    dispatch(getTopicIndex(0));
    dispatch(getModuleIndex(0));
    dispatch(getAssessmentIndex(0));
    navigate(
      `/landing/classroom?continueToLast=${certifications.courseDetails.CID}`,
      {
        state: { courseTitle: certifications.courseDetails.TITLE },
      }
    );
  };

  const renderPageNumbers = (totalPages: number): JSX.Element[] => {
    const pageNumbers: JSX.Element[] = [];

    const firstRange = 3;
    const lastRange = 3;

    for (let i = 1; i <= Math.min(firstRange, totalPages); i++) {
      pageNumbers.push(
        <Typography
          sx={{
            marginLeft: "20px",
            padding: "4px 12px 4px 12px",
            borderRadius: "6px",
            borderWidth: currentPage === i ? "1px" : "0px",
            borderStyle: currentPage === i ? "solid" : "none",
            borderColor: currentPage === i ? "#2A62AA" : "transparent",
            backgroundColor: currentPage === i ? "#EDF1F4" : "transparent",
            color: currentPage === i ? "#2A62AA" : "black",
            cursor: "pointer",
          }}
          key={i}
          onClick={() => setCurrentPage(i)}
        >
          {i}
        </Typography>
      );
    }

    if (totalPages > firstRange + lastRange) {
      pageNumbers.push(
        <Typography sx={{ marginLeft: "40px" }} key="ellipsis-start">
          ...
        </Typography>
      );
    }

    const startLastRange = Math.max(totalPages - lastRange + 1, firstRange + 1);
    for (let i = startLastRange; i <= totalPages; i++) {
      pageNumbers.push(
        <Typography
          sx={{
            marginLeft: "20px",
            padding: "4px 12px 4px 12px",
            borderRadius: "6px",
            borderWidth: currentPage === i ? "1px" : "0px",
            borderStyle: currentPage === i ? "solid" : "none",
            borderColor: currentPage === i ? "#2A62AA" : "transparent",
            backgroundColor: currentPage === i ? "#EDF1F4" : "transparent",
            color: currentPage === i ? "#2A62AA" : "black",
            cursor: "pointer",
          }}
          key={i}
          onClick={() => setCurrentPage(i)}
        >
          {i}
        </Typography>
      );
    }
    return pageNumbers;
  };

  const CustomLinear = styled(LinearProgress, {
    shouldForwardProp: (prop) => prop !== "progress",
  })<{ progress: any }>(({ theme, progress }) => ({
    padding: "2px",
    width: "100%",
    margin: "5px",
    borderRadius: "7px",
    "& .MuiLinearProgress-bar": {
      backgroundColor: progress === "100" ? "#48A055" : "#ef5c00",
    },
  }));

  React.useEffect(() => {
    getUserCertification();
  }, [userId]);

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: "100%",
          justifyContent: "space-between",
        }}
      >
        <TableContainer component={Paper}>
          <Table sx={{ width: "100%" }} size="small" aria-label="a dense table">
            <TableHead>
              <TableRow>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                    width: "20px",
                  }}
                >
                  <Checkbox {...label} disabled />
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                    // width: "100%",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    Title
                    <IconButton onClick={handleExpandTitle}>
                      <KeyboardArrowDownIcon
                        sx={{
                          cursor: "pointer",
                          color: titleSort ? "#919599" : "#929396",
                          transform:
                            titleSort && isTitleDesc
                              ? "rotate(180deg)"
                              : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </Box>
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    Progress Bar
                    <IconButton onClick={handleExpandProgress}>
                      <KeyboardArrowDownIcon
                        sx={{
                          cursor: "pointer",
                          color: isSortProgress ? "#919599" : "#929396",
                          transform:
                            isSortProgress && isprogressDesc
                              ? "rotate(180deg)"
                              : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </Box>
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    Status
                    <IconButton onClick={handleExpandStatus}>
                      <KeyboardArrowDownIcon
                        sx={{
                          cursor: "pointer",
                          color: isStatusFiltered ? "#919599" : "#929396",
                          transform:
                            isStatusFiltered && isStatusDesc
                              ? "rotate(180deg)"
                              : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </Box>
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    Time Spent
                    <IconButton onClick={handleExpandTime}>
                      <KeyboardArrowDownIcon
                        sx={{
                          cursor: "pointer",
                          color: isSortTime ? "#919599" : "#929396",
                          transform: isSortTime ? "rotate(180deg)" : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </Box>
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    Enrolled On
                    <IconButton onClick={handleExpandDate}>
                      <KeyboardArrowDownIcon
                        sx={{
                          cursor: "pointer",
                          color: isSortDate ? "#919599" : "#929396",
                          transform: isSortDate ? "rotate(180deg)" : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </Box>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <>
                {currentCertificationList.map(
                  (certifications, index: number) => (
                    <TableRow key={index}>
                      <TableCell
                        sx={{
                          border: "1px solid #f0f0f0",
                          height: "48px",
                          width: "20px",
                        }}
                      >
                        <Checkbox {...label} disabled />
                      </TableCell>
                      <TableCell
                        align="left"
                        sx={{
                          border: "1px solid #f0f0f0",
                          color: "#656566",
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          height: "48px",
                        }}
                      >
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "start",
                            // cursor: "pointer",
                            whiteSpace: "nowrap",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            // maxWidth: "100%",
                          }}
                          // onClick={() => handleModal(certifications)}
                        >
                          {certifications.courseDetails.TITLE.slice(
                            0,
                            1
                          ).toUpperCase() +
                            certifications.courseDetails.TITLE.slice(1)}
                          &nbsp;&nbsp;
                          {/* <PlayCircleOutlineRoundedIcon
                        style={{
                          color: "info.main",
                          fontSize: "18px",
                          cursor: "pointer",
                        }}
                      /> */}
                        </Box>
                        <CustomButton
                          name={
                            certifications.STATUS === "COMPLETED"
                              ? "View Score"
                              : certifications.STATUS === "InProgress"
                              ? "Resume Topic"
                              : certifications.STATUS === "Not Started"
                              ? "Continue"
                              : // : certifications.STATUS === "DISQUALIFIED"
                                // ? "Re-Enroll"
                                "Continue"
                          }
                          variant={
                            certifications.STATUS !== "COMPLETED"
                              ? "primary"
                              : "secondary"
                          }
                          padding={"10px 20px"}
                          disabled={
                            certifications.STATUS === "Certified" ||
                            certifications.STATUS === "DISQUALIFIED"
                          }
                          onClick={() => {
                            if (certifications.STATUS === "InProgress") {
                              handleContinue(certifications);
                            } else if (
                              certifications.STATUS === "Not Started"
                            ) {
                              navigate(`/landing/classroom`, {
                                state: {
                                  courseTitle:
                                    certifications.courseDetails.TITLE,
                                  courseID: certifications.courseDetails.CID,
                                },
                              });
                              dispatch(
                                changeClassRoomValue(
                                  certifications.courseDetails.CID
                                )
                              );
                            } else if (certifications.STATUS === "COMPLETED") {
                              handleModal(certifications);
                            }
                          }}
                        />
                      </TableCell>
                      <TableCell
                        sx={{
                          border: "1px solid #f0f0f0",
                          textAlign: "center",
                          color: "#5F5E5B",
                          height: "48px",
                          // minWidth: "232px",
                        }}
                      >
                        <ProgressBox>
                          <CustomLinear
                            variant="determinate"
                            color="secondary"
                            value={certifications.PROGRESS}
                            progress={certifications.PROGRESS}
                          />
                          &nbsp;
                          <Typography className="progress">
                            {Math.round(certifications.PROGRESS)}%
                          </Typography>
                        </ProgressBox>
                      </TableCell>
                      <TableCell
                        sx={{
                          border: "1px solid #f0f0f0",
                          textAlign: "center",
                          color: "#5F5E5B",
                          height: "48px",
                          // minWidth: "140px",
                        }}
                      >
                        {(certifications.STATUS === "COMPLETED" && (
                          <Typography
                            className="Certify"
                            sx={{
                              color: "#48A055",
                              display: "flex",
                              justifyContent: "center",
                              alignItems: "center",
                              fontSize: "12px",
                              fontWeight: 400,
                            }}
                          >
                            <VerifiedIcon sx={{ width: 16 }} /> &nbsp;Certified
                          </Typography>
                        )) ||
                          (certifications.STATUS === "Not Started" && (
                            <Typography
                              className="Certify"
                              sx={{
                                color: "#ef5c00",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                fontSize: "12px",
                                fontWeight: 400,
                              }}
                            >
                              <TimelapseIcon sx={{ width: 16 }} /> &nbsp;
                              InProgress
                            </Typography>
                          )) ||
                          (certifications.STATUS === "DISQUALIFIED" && (
                            <Typography
                              className="Certify"
                              sx={{
                                color: "#BF1932",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                fontSize: "12px",
                                fontWeight: 400,
                              }}
                            >
                              <CancelIcon
                                sx={{ width: 16, color: "#BF1932" }}
                              />{" "}
                              &nbsp;DisQualified
                            </Typography>
                          )) ||
                          (certifications.STATUS === "InProgress" && (
                            <Typography
                              className="Certify"
                              sx={{
                                color: "#ef5c00",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                fontSize: "12px",
                                fontWeight: 400,
                              }}
                            >
                              <TimelapseIcon sx={{ width: 16 }} /> &nbsp;
                              InProgress
                            </Typography>
                          ))}
                      </TableCell>
                      <TableCell
                        sx={{
                          border: "1px solid #f0f0f0",
                          textAlign: "center",
                          color: "#5F5E5B",
                          height: "48px",
                          // minWidth: "140px",
                        }}
                      >
                        {certifications.TIME_SPENT
                          ? certifications.TIME_SPENT
                          : ""}
                      </TableCell>
                      <TableCell
                        sx={{
                          border: "1px solid #f0f0f0",
                          textAlign: "center",
                          color: "#5F5E5B",
                          height: "48px",
                          minWidth: "140px",
                        }}
                      >
                        {certifications.ENROLLED_ON
                          ? parseDate(certifications.ENROLLED_ON)
                          : " "}
                      </TableCell>
                    </TableRow>
                  )
                )}
              </>
            </TableBody>
          </Table>
        </TableContainer>
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            position: "absolute",
            width: "90%",
            bottom: 10,
            left: "53%",
            transform: "translateX(-50%)",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <CustomButton
            variant="secondary"
            name="Previous"
            padding="8px 14px"
            startIcon={<ArrowBackIcon />}
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
          />
          <Box sx={{ display: "flex", alignItems: "center" }}>
            {renderPageNumbers(totalPages)}
          </Box>
          <CustomButton
            variant="secondary"
            name={"Next"}
            padding="8px 14px"
            endIcon={<ArrowForwardIcon />}
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
          />
        </Box>
      </Box>
    </>
  );
};

export default CertificationTable;

const ProgressBox = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
`;
