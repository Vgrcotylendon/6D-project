import React from "react";
import styled from "styled-components";
import { Typography, Box } from "@mui/material";
import CertificationCard from "./CertificationCard";
import CertificationTable from "./CertificationTable";
import CustomModal from "../../../Modal/CustomModal";
import CourseData from "./CourseData";

interface CourseDetails {
  CID: number;
  TITLE: string;
  DESCRIPTION: string;
  DURATION: number;
  THUMBNAIL: string;
  AVAILABILITY: string;
}

interface Certification {
  UC_ID: number;
  CID: number;
  UID: number;
  STATUS: string;
  PROGRESS: number;
  ATTEMPT: number;
  ENROLLED_ON: string;
  TIME_SPENT: any;
  courseDetails: CourseDetails;
}
interface toogle {
  certificationValue: boolean;
  certifications: Certification[];
  getUserCertification: () => Promise<void>;
}
const MyCertifications: React.FC<toogle> = ({
  certificationValue,
  certifications,
  getUserCertification,
}) => {
  const [open, setOpen] = React.useState(false);
  const [selectedCertification, setSelectedCertification] =
    React.useState<Certification | null>(null);

  const handleOpen = (certifications: Certification) => {
    setSelectedCertification(certifications);
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
    setSelectedCertification(null);
  };

  return (
    <>
      <CustomModal
        open={open}
        handleClose={() => handleClose()}
        sx={{ width: "75%", height: "auto", mt: 5 }}
        child={
          <CourseData
            getUserCertification={getUserCertification}
            selectedCertification={selectedCertification}
            handleClose={handleClose}
          />
        }
      />
      {certifications.length === 0 ? (
        <NoDataBox>
          <Typography
            sx={{ fontWeight: 600, fontSize: "16px", color: "#4C2D2D" }}
          >
            Enroll a course from course catalog tab
          </Typography>
        </NoDataBox>
      ) : (
        <>
          {certificationValue ? (
            <CertificationTable
             getUserCertification={getUserCertification}
              data={certifications}
              handleModal={handleOpen}
            />
          ) : (
            <CertificationCard data={certifications} handleModal={handleOpen} />
          )}
        </>
      )}
    </>
  );
};

export default MyCertifications;

const NoDataBox = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f0f0f0;
  border-radius: 10px;
  padding: 20px;
`;
