import React, { useEffect } from "react";
import {
  Typography,
  Table,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableBody,
  LinearProgress,
  Box,
  IconButton,
} from "@mui/material";
import styled from "styled-components";
import CloseIcon from "@mui/icons-material/Close";
import { useSelector } from "react-redux";
import { RootState } from "../../../../Store/UserSlice";
import { instance } from "../../../../Controller/Common";

interface CourseDetails {
  CID: number;
  TITLE: string;
  DESCRIPTION: string;
  DURATION: number;
  THUMBNAIL: string;
  AVAILABILITY: string;
}

interface Certification {
  UC_ID: number;
  CID: number;
  UID: number;
  STATUS: string;
  PROGRESS: number;
  ATTEMPT: number;
  ENROLLED_ON: string;
  TIME_SPENT: any;
  courseDetails: CourseDetails;
}
interface CertifiactionProps {
  selectedCertification: Certification | null;
  getUserCertification: () => Promise<void>;
  handleClose: () => void;
}

const CourseData: React.FC<CertifiactionProps> = ({
  selectedCertification,
  getUserCertification,
  handleClose,
}) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [scoreDetails, setScoreDetails] = React.useState<any[]>([]);
  const open = Boolean(anchorEl);
  const userId = useSelector((state: RootState) => state.user.userID);

  const GetQuestionAttempts = async () => {
    try {
      const response = await instance.get(
        `/6D/assessment/getResultForFinalAssessment?CID=${selectedCertification?.CID}&UID=${userId}`
      );
      if (response.status === 200) {
        setScoreDetails(response.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (selectedCertification) {
      GetQuestionAttempts();
    }
  }, [selectedCertification, userId]);

  return (
    <>
      <Box sx={{ padding: "40px", borderRadius: "5px" }}>
        <IconButton
          size="small"
          onClick={() => {
            handleClose();
          }}
          sx={{ position: "absolute", top: 10, right: 10 }}
        >
          <CloseIcon />
        </IconButton>
        <Typography align="center" margin={"30px"}>
          {selectedCertification?.courseDetails.TITLE}
        </Typography>
        {scoreDetails && scoreDetails.length > 0 ? (
          <Box sx={{ padding: "10px 80px 10px 80px" }}>
            <TableContainer sx={{ overflowY: "auto", maxHeight: 250}}>
              <Table stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell
                      align={"center"}
                      sx={{
                        bgcolor: "#F5F5F5",
                        minWidth: 200,
                        border: "none",
                      }}
                    >
                      {"Attempts Taken"}
                    </TableCell>
                    <TableCell
                      align={"center"}
                      sx={{
                        bgcolor: "#F5F5F5",
                        minWidth: 200,
                        border: "none",
                      }}
                    >
                      {"Final Score"}
                    </TableCell>
                    <TableCell
                      align={"center"}
                      sx={{
                        bgcolor: "#F5F5F5",
                        minWidth: 200,
                        border: "none",
                      }}
                    >
                      {"Cut-off Score"}
                    </TableCell>
                    <TableCell
                      align={"center"}
                      sx={{
                        bgcolor: "#F5F5F5",
                        minWidth: 200,
                        border: "none",
                      }}
                    >
                      {"Result"}
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {scoreDetails &&
                    scoreDetails.map((e: any, i: number) => (
                      <TableRow key={i}>
                        <TableCell align="center" sx={{ border: "none" }}>
                          {e.STATUS === "COMPLETED" ? `${i + 1}` : null}
                        </TableCell>
                        <TableCell align="center" sx={{ border: "none" }}>
                          {e.STATUS === "COMPLETED"
                            ? `${e.FINAL_SCORE}%`
                            : null}
                        </TableCell>
                        <TableCell align="center" sx={{ border: "none" }}>
                          {e.STATUS === "COMPLETED" ? `${e.CUT_OFF}%` : null}
                        </TableCell>
                        <TableCell align="center" sx={{ border: "none" }}>
                          {e.STATUS === "COMPLETED"
                            ? e.FINAL_SCORE >= e.CUT_OFF
                              ? "Pass"
                              : "Fail"
                            : null}
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        ) : (
          <Typography align="center" margin={"30px"}>
            No final score available
          </Typography>
        )}
      </Box>
    </>
  );
};

export default CourseData;

