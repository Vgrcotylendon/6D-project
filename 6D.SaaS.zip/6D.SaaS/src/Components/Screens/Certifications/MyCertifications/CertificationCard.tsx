import React, { useState } from "react";
import {
  Box,
  Container,
  Divider,
  Grid,
  IconButton,
  LinearProgress,
  Typography,
} from "@mui/material";
import VerifiedIcon from "@mui/icons-material/Verified";
import CancelIcon from "@mui/icons-material/Cancel";
import TimelapseIcon from "@mui/icons-material/Timelapse";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import { styled } from "@mui/system";
import CustomButton from "../../../Button/CustomButton";
import {
  changeClassRoomValue,
  getAssessmentIndex,
  getModuleIndex,
  getTopicIndex,
} from "../../../../Store/ClassroomSlice";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

interface Detail {
  head: string;
  child: React.ReactNode;
}
interface CourseDetails {
  CID: number;
  TITLE: string;
  DESCRIPTION: string;
  DURATION: number;
  THUMBNAIL: string;
  AVAILABILITY: string;
}

interface Certification {
  UC_ID: number;
  CID: number;
  UID: number;
  STATUS: string;
  PROGRESS: number;
  ATTEMPT: number;
  ENROLLED_ON: string;
  TIME_SPENT: any;
  courseDetails: CourseDetails;
}

interface CertificationProps {
  data: Certification[];
  handleModal: (cetifications: Certification) => void;
}
const CertificationCard: React.FC<CertificationProps> = ({
  data,
  handleModal,
}) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [currentPage, setCurrentPage] = useState(1);
  const certificationPerPage = 4;
  const indexOfLastJob = currentPage * certificationPerPage;
  const indexOfFirstJob = indexOfLastJob - certificationPerPage;
  const currentCertification = data.slice(indexOfFirstJob, indexOfLastJob);

  const totalPages = Math.ceil(data.length / certificationPerPage);

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  const parseDate = (dateString: string): string => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const monthNames = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    const month = monthNames[date.getMonth()];
    const year = date.getFullYear();
    return `${day} ${month} ${year}`;
  };

  const renderPageNumbers = (totalPages: number): JSX.Element[] => {
    const pageNumbers: JSX.Element[] = [];

    const firstRange = 3;
    const lastRange = 3;

    for (let i = 1; i <= Math.min(firstRange, totalPages); i++) {
      pageNumbers.push(
        <Typography
          sx={{
            marginLeft: "20px",
            padding: "4px 12px 4px 12px",
            borderRadius: "6px",
            borderWidth: currentPage === i ? "1px" : "0px",
            borderStyle: currentPage === i ? "solid" : "none",
            borderColor: currentPage === i ? "#2A62AA" : "transparent",
            backgroundColor: currentPage === i ? "#EDF1F4" : "transparent",
            color: currentPage === i ? "#2A62AA" : "black",
            cursor: "pointer",
          }}
          key={i}
          onClick={() => setCurrentPage(i)}
        >
          {i}
        </Typography>
      );
    }

    if (totalPages > firstRange + lastRange) {
      pageNumbers.push(
        <Typography sx={{ marginLeft: "40px" }} key="ellipsis-start">
          ...
        </Typography>
      );
    }

    const startLastRange = Math.max(totalPages - lastRange + 1, firstRange + 1);
    for (let i = startLastRange; i <= totalPages; i++) {
      pageNumbers.push(
        <Typography
          sx={{
            marginLeft: "20px",
            padding: "4px 12px 4px 12px",
            borderRadius: "6px",
            borderWidth: currentPage === i ? "1px" : "0px",
            borderStyle: currentPage === i ? "solid" : "none",
            borderColor: currentPage === i ? "#2A62AA" : "transparent",
            backgroundColor: currentPage === i ? "#EDF1F4" : "transparent",
            color: currentPage === i ? "#2A62AA" : "black",
            cursor: "pointer",
          }}
          key={i}
          onClick={() => setCurrentPage(i)}
        >
          {i}
        </Typography>
      );
    }
    return pageNumbers;
  };

  const Details: React.FC<Detail> = ({ head, child }) => {
    return (
      <DetailBox>
        <Typography className="myCertifyHead">{head}</Typography>
        {head === "Hiring Position" ? (
          child
        ) : (
          <Typography
            sx={{ fontSize: "14px", fontWeight: 400, color: "#656566" }}
          >
            {child}
          </Typography>
        )}
      </DetailBox>
    );
  };
  const CustomLinear = styled(LinearProgress, {
    shouldForwardProp: (prop) => prop !== "progress",
  })<{ progress: any }>(({ theme, progress }) => ({
    padding: "2px",
    width: "100px",
    margin: "5px",
    borderRadius: "7px",
    "& .MuiLinearProgress-bar": {
      backgroundColor: progress === "100" ? "#48A055" : "#ef5c00",
    },
  }));

  const handleContinue = (certifications: any) => {
    dispatch(changeClassRoomValue(certifications.courseDetails.CID));
    dispatch(getTopicIndex(0));
    dispatch(getModuleIndex(0));
    dispatch(getAssessmentIndex(0));
    navigate(
      `/landing/classroom?continueToLast=${certifications.courseDetails.CID}`,
      {
        state: { courseTitle: certifications.courseDetails.TITLE },
      }
    );
  };

  return (
    <>
      <Container maxWidth="xl" sx={{ position: "relative" }}>
        <CustomContainer container spacing={1} sx={{ marginTop: 6 }}>
          {currentCertification.reverse().map((certifications, index) => (
            <Grid item xs={6} key={index} padding={1}>
              <CourseBox>
                <CourseNameBox>
                  <Typography
                    className="courseName"
                    color="#656566"
                    sx={{
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {certifications.courseDetails.TITLE}
                  </Typography>
                  {/* <IconButton className="getCertified">
                    <ChevronRightIcon />
                  </IconButton> */}
                </CourseNameBox>
                <DBox>
                  <Details
                    head="Progress Bar"
                    child={
                      <Box
                        sx={{
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        <ProgressBox>
                          <CustomLinear
                            variant="determinate"
                            color="secondary"
                            value={certifications.PROGRESS}
                            progress={certifications.PROGRESS}
                          />
                          &nbsp;
                          <Typography className="progress">
                            {Math.round(certifications.PROGRESS)}%
                          </Typography>
                        </ProgressBox>
                      </Box>
                    }
                  />
                  <Divider
                    sx={{
                      background: "#ffffff",
                      marginTop: "2px",
                      marginBottom: "2px",
                      height: "0.5px",
                    }}
                  />
                  <Details
                    head="Certification Status"
                    child={
                      certifications.STATUS === "COMPLETED" ? (
                        <Typography
                          className="Certify"
                          sx={{
                            color: "#48A055",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            fontSize: "12px",
                            fontWeight: 400,
                          }}
                        >
                          <VerifiedIcon sx={{ width: 16 }} /> &nbsp;Certified
                        </Typography>
                      ) : certifications.STATUS === "Not Started" ? (
                        <Typography
                          className="Certify"
                          sx={{
                            color: "#ef5c00",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            fontSize: "12px",
                            fontWeight: 400,
                          }}
                        >
                          <TimelapseIcon sx={{ width: 16 }} /> &nbsp; InProgress
                        </Typography>
                      ) : certifications.STATUS === "DISQUALIFIED" ? (
                        <Typography
                          className="Certify"
                          sx={{
                            color: "#BF1932",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            fontSize: "12px",
                            fontWeight: 400,
                          }}
                        >
                          <CancelIcon sx={{ width: 16, color: "#BF1932" }} />{" "}
                          &nbsp;DisQualified
                        </Typography>
                      ) : (
                        certifications.STATUS === "InProgress" && (
                          <Typography
                            className="Certify"
                            sx={{
                              color: "#ef5c00",
                              display: "flex",
                              justifyContent: "center",
                              alignItems: "center",
                              fontSize: "12px",
                              fontWeight: 400,
                            }}
                          >
                            <TimelapseIcon sx={{ width: 16 }} /> &nbsp;
                            InProgress
                          </Typography>
                        )
                      )
                    }
                  />
                  <Divider
                    sx={{
                      background: "#ffffff",
                      marginTop: "2px",
                      marginBottom: "2px",
                      height: "0.5px",
                    }}
                  />
                  <Details
                    head="Time Spent"
                    child={
                      certifications.TIME_SPENT ? certifications.TIME_SPENT : ""
                    }
                  />
                  <Divider
                    sx={{
                      background: "#ffffff",
                      marginTop: "2px",
                      marginBottom: "2px",
                      height: "0.5px",
                    }}
                  />
                  <Details
                    head="Enrolled On"
                    child={parseDate(certifications.ENROLLED_ON) || ""}
                  />
                </DBox>
                <Box sx={{ display: "flex", justifyContent: "end" }}>
                  <CustomButton
                    name={
                      certifications.STATUS === "COMPLETED"
                        ? "View Score"
                        : certifications.STATUS === "InProgress"
                        ? "Resume Topic"
                        : // : certifications.STATUS === "DISQUALIFIED"
                          // ? "Re-Enroll"
                          "Continue"
                    }
                    variant={
                      certifications.STATUS !== "COMPLETED"
                        ? "primary"
                        : "secondary"
                    }
                    padding={"10px 20px"}
                    disabled={
                      certifications.STATUS === "Certified" ||
                      certifications.STATUS === "DISQUALIFIED"
                    }
                    onClick={() => {
                      if (certifications.STATUS === "InProgress") {
                        handleContinue(certifications);
                      } else if (certifications.STATUS === "Not Started") {
                        navigate(`/landing/classroom`, {
                          state: {
                            courseTitle: certifications.courseDetails.TITLE,
                          },
                        });
                      } else if (certifications.STATUS === "COMPLETED") {
                        handleModal(certifications);
                      }
                    }}
                  />
                </Box>
              </CourseBox>
            </Grid>
          ))}
        </CustomContainer>

        {/* Pagination Box */}
      </Container>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          position: "absolute",
          width: "90%",
          bottom: 10,
          left: "53%",
          transform: "translateX(-50%)",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <CustomButton
          variant="secondary"
          name="Previous"
          padding="8px 14px"
          startIcon={<ArrowBackIcon />}
          onClick={handlePreviousPage}
          disabled={currentPage === 1}
        />
        <Box sx={{ display: "flex", alignItems: "center" }}>
          {renderPageNumbers(totalPages)}
        </Box>
        <CustomButton
          variant="secondary"
          name={"Next"}
          padding="8px 14px"
          endIcon={<ArrowForwardIcon />}
          onClick={handleNextPage}
          disabled={currentPage === totalPages}
        />
      </Box>
    </>
  );
};
export default CertificationCard;
const CustomContainer = styled(Grid)`
  border: 2px solid white;
  border-radius: 3px;
  display: flex;
  height: calc(73vh - 70px);
  padding: 20px;
  overflow-y: auto;
`;

const CourseBox = styled(Box)`
  display: flex;
  flex-direction: column;
  background-color: white;
  padding: 15px;
  border-radius: 7px;
`;

const CourseNameBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  color: #0f96f0;
  height: 50px;
  /* cursor: pointer; */
  background-color: #f0f0f0;
  border-radius: 5px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 100%;
`;
const DetailBox = styled(Box)`
  width: 100%;
  display: flex;
  padding: 3px;
`;
const DBox = styled(Box)`
  padding: 15px;
`;
const ProgressBox = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
`;
