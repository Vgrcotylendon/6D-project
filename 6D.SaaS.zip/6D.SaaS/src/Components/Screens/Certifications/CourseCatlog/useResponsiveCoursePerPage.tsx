import * as React from "react";

const useResponsiveCoursePerPage = () => {
  const [coursePerPage, setCoursePerPage] = React.useState(5);

  React.useEffect(() => {
    const Total = window.innerHeight - 385.03;
    const per = Total / 62.19;

    const calculateCoursesPerPage = () => {
      const screenHeight = window.screen.height;
      const screenWidth = window.screen.width;

      if (screenHeight >= 1080 && screenWidth >= 1920) {
        setCoursePerPage(per);
      } else if (screenHeight >= 768 && screenWidth >= 1024) {
        setCoursePerPage(per);
      } else {
        setCoursePerPage(per);
      }
    };

    calculateCoursesPerPage();

    window.addEventListener("resize", calculateCoursesPerPage);

    return () => {
      window.removeEventListener("resize", calculateCoursesPerPage);
    };
  }, []);

  return coursePerPage;
};

export default useResponsiveCoursePerPage;