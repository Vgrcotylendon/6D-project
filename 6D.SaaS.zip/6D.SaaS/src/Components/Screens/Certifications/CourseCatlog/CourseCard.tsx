import { Container, Grid, Box, Card, Typography, Divider } from "@mui/material";
import React, { useState } from "react";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import PlayCircleOutlineRoundedIcon from "@mui/icons-material/PlayCircleOutlineRounded";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import { styled } from "@mui/system";
import CustomButton from "../../../Button/CustomButton";
import { useSelector } from "react-redux";
import { RootState } from "../../../../Store/UserSlice";
import { instance } from "../../../../Controller/Common";
import CustomModal from "../../../Modal/CustomModal";
import EnrollModal from "./EnRollModal";

interface Topic {
  TID: number;
  NAME: string;
  CONTENT: string;
  CONTENT_TYPE: string;
  METADATA: string;
}

interface Module {
  MID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
  Topic: Topic[];
}
interface FinalAssessment {
  AID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
}
interface Course {
  CID: number;
  TITLE: string;
  DESCRIPTION: string;
  DURATION: number;
  THUMBNAIL: any;
  AVAILABILITY: string;
  userEnrolled: boolean;
  Module: Module[];
  AUTHOR:string;
  FinalAssessment: FinalAssessment[];
  userStatus:string;
  timespent:any;
}
interface courseprops {
  courseList: Course[];
  GetCourse: () => Promise<void>;
  handleModal: (course: Course) => void;
  getUserCertification: () => Promise<void>;
  setValue: React.Dispatch<React.SetStateAction<number>>;
}

const CourseCard: React.FC<courseprops> = ({
  courseList,
  handleModal,
  GetCourse,
  getUserCertification,
  setValue,
}) => {
  const [enroll, setEnroll]=React.useState({});
  const [currentPage, setCurrentPage] = useState(1);
  const coursePerPage = 6;
  const userId = useSelector((state: RootState) => state.user.userID);
  const indexOfLastJob = currentPage * coursePerPage;
  const indexOfFirstJob = indexOfLastJob - coursePerPage;
  const currentCourse = courseList.slice(indexOfFirstJob, indexOfLastJob);
  const [show, setShow] = React.useState(false);
  const [loadingCourseId, setLoadingCourseId] = React.useState<number | null>(
    null
  );
  const totalPages = Math.ceil(courseList.length / coursePerPage);

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };
  const handleClose = () => {
    setShow(false);
  };

  const formatDuration = (duration: number) => {
    const hours = Math.floor(duration);
    const minutes = (duration % 1) * 60;

    return minutes > 0 ? `${hours} hrs ${minutes} min` : `${hours} hrs`;
  };

  const renderPageNumbers = (totalPages: number): JSX.Element[] => {
    const pageNumbers: JSX.Element[] = [];

    const firstRange = 3;
    const lastRange = 3;

    for (let i = 1; i <= Math.min(firstRange, totalPages); i++) {
      pageNumbers.push(
        <Typography
          sx={{
            marginLeft: "20px",
            padding: "4px 12px 4px 12px",
            borderRadius: "6px",
            borderWidth: currentPage === i ? "1px" : "0px",
            borderStyle: currentPage === i ? "solid" : "none",
            borderColor: currentPage === i ? "#2A62AA" : "transparent",
            backgroundColor: currentPage === i ? "#EDF1F4" : "transparent",
            color: currentPage === i ? "#2A62AA" : "black",
            cursor: "pointer",
          }}
          key={i}
          onClick={() => setCurrentPage(i)}
        >
          {i}
        </Typography>
      );
    }

    if (totalPages > firstRange + lastRange) {
      pageNumbers.push(
        <Typography sx={{ marginLeft: "40px" }} key="ellipsis-start">
          ...
        </Typography>
      );
    }

    const startLastRange = Math.max(totalPages - lastRange + 1, firstRange + 1);
    for (let i = startLastRange; i <= totalPages; i++) {
      pageNumbers.push(
        <Typography
          sx={{
            marginLeft: "20px",
            padding: "4px 12px 4px 12px",
            borderRadius: "6px",
            borderWidth: currentPage === i ? "1px" : "0px",
            borderStyle: currentPage === i ? "solid" : "none",
            borderColor: currentPage === i ? "#2A62AA" : "transparent",
            backgroundColor: currentPage === i ? "#EDF1F4" : "transparent",
            color: currentPage === i ? "#2A62AA" : "black",
            cursor: "pointer",
          }}
          key={i}
          onClick={() => setCurrentPage(i)}
        >
          {i}
        </Typography>
      );
    }
    return pageNumbers;
  };

  const EnrollCourse = async (course: Course) => {
    try {
      setLoadingCourseId(course.CID);
      const response = await instance.post(`/6D/enRoll/Course`, {
        CID: course.CID,
        UID: userId,
        STATUS: "Not Started",
        PROGRESS: 0,
      });
      if (response.status === 200) {
        setValue(1);
        GetCourse();
        getUserCertification();
      }
    } catch (error:any) {
      setEnroll(error?.response?.data?.data);
      setShow(true);
      console.error(error);
    } finally {
      setLoadingCourseId(null);
    }
  };

  const capitalizeTitle = (title: string) => {
    return title.replace(/\b\w/g, (char: string) => char.toUpperCase());
  };

  return (
    <>
      <Container maxWidth="xl" sx={{ position: "relative" }}>
        <CustomContainer container spacing={2} sx={{ marginTop: 6 }}>
          {currentCourse
            .sort((a, b) => a.TITLE.localeCompare(b.TITLE))
            .map((course) => (
              <Grid item xs={4} key={course.CID} padding={1}>
                <MainCard>
                  <MainBox>
                    <SubBox onClick={() => handleModal(course)}>
                      <Typography
                        color={"info.main"}
                        sx={{
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {capitalizeTitle(course.TITLE)}
                      </Typography>
                      <PlayCircleOutlineRoundedIcon
                        sx={{ color: "info.main", fontSize: "18px" }}
                      />
                    </SubBox>
                    <SubBox2>
                      <TextBox>
                        <Typography
                          sx={{
                            color: "#3F3F40",
                            fontSize: "14px",
                            fontWeight: 400,
                          }}
                        >
                          Duration
                        </Typography>
                        <Typography
                          sx={{
                            color: "#656566",
                            fontSize: "14px",
                            fontWeight: 400,
                          }}
                        >
                          {formatDuration(course.DURATION)}
                        </Typography>
                      </TextBox>
                      <Divider
                        sx={{
                          background: "#f0f0f0",
                          marginTop: "2px",
                          marginBottom: "2px",
                          height: "0.5px",
                        }}
                      />
                      <TextBox>
                        <Typography
                          sx={{
                            color: "#3F3F40",
                            fontSize: "14px",
                            fontWeight: 400,
                            padding: "8px 0px 0px 0px",
                          }}
                        >
                          Availability
                        </Typography>

                        <Typography
                          sx={{
                            color:
                              course.AVAILABILITY === "Y" ? "green" : "red",
                            display: "flex",
                            fontSize: "14px",
                            fontWeight: 400,
                            padding: "8px 0px 0px 0px",
                          }}
                        >
                          <IconBox>
                            {course.AVAILABILITY === "Y" ? (
                              <CheckCircleIcon
                                style={{ color: "green", fontSize: "18px" }}
                              />
                            ) : (
                              <CancelIcon
                                style={{ color: "red", fontSize: "18px" }}
                              />
                            )}
                            &nbsp;&nbsp;&nbsp;
                          </IconBox>
                          {course.AVAILABILITY === "Y" ? "Yes" : "No"}
                        </Typography>
                      </TextBox>
                      <Divider
                        sx={{
                          background: "#f0f0f0",
                          marginTop: "2px",
                          marginBottom: "2px",
                          height: "0.5px",
                        }}
                      />
                    </SubBox2>
                    <Box style={{ display: "flex", justifyContent: "end" }}>
                      <CustomButton
                        name={
                          loadingCourseId === course.CID
                            ? "Loading..."
                            : course.userEnrolled
                            ? "Enrolled"
                            // :course.userStatus === "DISQUALIFIED"?"Re-Enroll"
                            : "Enroll"
                        }
                        variant={"primary"}
                        padding={
                          course.userEnrolled || loadingCourseId === course.CID
                            ? "8px 10px"
                            : "8px 20px"
                        }
                        disabled={
                          loadingCourseId === course.CID ||
                          course.userEnrolled ||
                          course.AVAILABILITY === "N"
                        }
                        onClick={() => EnrollCourse(course)}
                      />
                    </Box>
                  </MainBox>
                </MainCard>
              </Grid>
            ))}
        </CustomContainer>
        <CustomModal
          open={show}
          handleClose={handleClose}
          sx={{ height: "auto", mt: 5 }}
          child={<EnrollModal setShow={setShow} enroll={enroll}/>}
        />
      </Container>
      <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            position: "absolute",
            width: "90%",
            bottom: 10,
            left: "53%",
            transform: "translateX(-50%)",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <CustomButton
            variant="secondary"
            name={"Previous"}
            padding={"8px 14px"}
            startIcon={<ArrowBackIcon />}
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
          />
          {/* <Typography>
            Page {currentPage} of {totalPages}
          </Typography> */}
          <Box sx={{ display: "flex", alignItems: "center" }}>
            {renderPageNumbers(totalPages)}
          </Box>
          <CustomButton
            variant="secondary"
            name={"Next"}
            padding={"8px 14px"}
            endIcon={<ArrowForwardIcon />}
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
          />
        </Box>
    </>
  );
};

export default CourseCard;

const CustomContainer = styled(Grid)`
  border: 2px solid white;
  border-radius: 3px;
  display: flex;
  height: calc(73vh - 70px);
  padding: 20px;
  overflow-y: auto;
`;
const MainCard = styled(Card)`
  padding: 8px;
  box-shadow: none !important;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
`;
const MainBox = styled(Box)`
  padding: 6px;
`;
const SubBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  color: #0f96f0;
  height: 50px;
  cursor: pointer;
  background-color: #f0f0f0;
  border-radius: 5px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 100%;
`;
const SubBox2 = styled(Box)`
  background-color: #fff;
  padding: 20px;
`;
const TextBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding: 0 0px 10px 0;
`;
const IconBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: center;
`;