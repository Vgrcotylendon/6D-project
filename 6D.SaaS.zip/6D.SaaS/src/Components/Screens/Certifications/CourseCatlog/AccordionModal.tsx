import {
  Typography,
  Card,
  Box
} from "@mui/material";
import React from "react";
import styled from "styled-components";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import AccordionImage from "../../../../Assets/interviewImage.png";
import pace from "../../../../Assets/pace.png";

interface Topic {
  TID: number;
  NAME: string;
  CONTENT: string;
  CONTENT_TYPE: string;
  METADATA: string;
}

interface Module {
  MID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
  Topic: Topic[];
}
interface FinalAssessment {
  AID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
}
interface Course {
  CID: number;
  TITLE: string;
  DESCRIPTION: string;
  DURATION: number;
  THUMBNAIL: any;
  AVAILABILITY: string;
  userEnrolled: boolean;
  AUTHOR: string;
  FinalAssessment: FinalAssessment[];
  Module: Module[];
}

interface CourseProps {
  selectedCourse?: Course | null;
  courseDetails: any[];
  checked: boolean[];
  nextPage: number;
  selectedTopic: any;
  hide: boolean;
  setHide: (value: boolean) => void;
  setNextPage: React.Dispatch<React.SetStateAction<number>>;
  topicLength: any;
  completedTopic: any;
}

const AccordionModal: React.FC<CourseProps> = ({
  selectedCourse,
  courseDetails,
}) => {
  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60); 
    const remainingMinutes = minutes % 60; 
  
    const hoursPart = `${hours} hrs`; 
    const minutesPart = remainingMinutes > 0 ? `${remainingMinutes} min` : "0 min";
  
    return `${hoursPart} ${minutesPart}`.trim(); 
  };

  const calculateTotalDuration = (modules: any[]) => {
    let totalMinutes = 0;
  
    modules?.forEach((module: any) => {
      module.topics.forEach((topic: any) => {
        const duration = parseInt(topic.TOPIC_DURATION, 10);
        if (!isNaN(duration)) {
          totalMinutes += duration;
        }
      });
    });
  
    return totalMinutes;
  };
  
  const modules = courseDetails[0]?.Module || [];
  const totalMinutes = calculateTotalDuration(modules);

return (
  <div>
    <MainCard>
      <MainBox>
        <SubBox1>
          <Typography
            sx={{ fontWeight: 600, color: "#FFFFFF", fontSize: "14px" }}
          >
            {courseDetails[0]?.TITLE || "No Data Found"}
          </Typography>
        </SubBox1>
        <SubBox2>
          <Box sx={{ display: "flex", flexDirection: "row" }}>
            <ImageBox>
              <img
                src={AccordionImage}
                alt="AccordionImage"
                style={{
                  width: "100%",
                  height: "auto",
                  maxWidth: "300px",
                  marginRight: "10px",
                }}
              />
            </ImageBox>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                marginLeft: "18px",
                justifyContent: "space-between",
                padding: "6px 6px 6px 0px"
              }}
            >
              <Typography
                sx={{ fontWeight: 400, color: "#3F3F40", fontSize: "12px" }}
              >
                {courseDetails[0]?.DESCRIPTION || "Not Found"}
              </Typography>
              <Typography
                sx={{
                  fontWeight: 400,
                  color: "#3F3F40",
                  fontSize: "12px",
                  marginTop: "30px",
                }}
              >
                Author-{courseDetails[0]?.AUTHOR || "Not Found"}
              </Typography>
            </Box>
          </Box>
          <TimeBox>
            <AccessTimeIcon style={{ color: "#656566", fontSize: "30px" }} />
            &nbsp;&nbsp;
            <TextBox>
              <Typography
                sx={{
                  fontSize: "12px",
                  fontWeight: 500,
                  color: "#656566",
                }}
              >
                Estimated Time
              </Typography>
              <Typography
                sx={{
                  fontSize: "10px",
                  fontWeight: 400,
                  color: "#656566",
                }}
              >
                {formatDuration(totalMinutes) || "0 min"}
              </Typography>
            </TextBox>
          </TimeBox>
        </SubBox2>
      </MainBox>
    </MainCard>
    {courseDetails[0]?.Module?.map((module: any, index: number) => {
       const totalTopicDuration = module.topics.reduce((total: number, topic: any) => {
        const duration = parseFloat(topic.TOPIC_DURATION) || 0; 
        return total + duration;
      }, 0);
      return (
      <Main1Card key={module.MID}>
        <Box
          sx={{
            padding: "10px 10px 10px 10px",
            borderRadius: "2px",
            backgroundColor: "#F5F5F5",
            width: "100%",
          }}
        >
          <TitleBox>
            <Typography
              sx={{
                fontWeight: 600,
                color: "black",
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
                overflow: "hidden",
              }}
            >
              Module {index + 1}:&nbsp;
              {module.moduleName ? module.moduleName : "Assessment Module"}
            </Typography>
            <ViewBox>
              <Time1Box>
                <AccessTimeIcon
                  style={{ fontSize: "30px", color: "#656566" }}
                />
                &nbsp;&nbsp;
                <Box>
                  <Typography
                    sx={{
                      fontSize: "12px",
                      fontWeight: 500,
                      color: "#656566",
                    }}
                  >
                    Estimated Time
                  </Typography>
                  <Typography
                    sx={{
                      fontSize: "10px",
                      fontWeight: 400,
                      color: "#656566",
                    }}
                  >
                    {formatDuration(totalTopicDuration) || "null"}
                  </Typography>
                </Box>
              </Time1Box>
            </ViewBox>
          </TitleBox>
        </Box>
        {module.topics.map((topic: any, idx: number) => (
          <Main2Box key={topic.TID}>
            <VideoBox>
              <Box1>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <Typography sx={{ color: "#2a62aa" }}>
                  {topic.topicName || (topic.IdType === "Assessment" ? topic.assessmentName : null)}
                </Typography>
              </Box1>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
              {topic.IdType !== "Assessment" &&(
                <Box2>
                  <img src={pace} alt="pace" style={{ marginRight: "5px" }} />
                  <Typography
                    sx={{
                      fontSize: "12px",
                      fontWeight: 400,
                      color: "#656566",
                    }}
                  >
                   {topic.TOPIC_DURATION} minutes
                  </Typography>
                </Box2>
              )}
              </Box>
            </VideoBox>
          </Main2Box>
        ))}
      </Main1Card>
      );
})}
    {courseDetails[0]?.FinalAssessment && (
      <>
        {courseDetails[0]?.FinalAssessment?.[0] && (
          <Main1Card>
            <Box
              sx={{
                padding: "10px 10px 10px 10px",
                borderRadius: "2px",
                backgroundColor: "#F5F5F5",
                width: "100%",
              }}
            >
              <TitleBox>
                <Typography
                  sx={{
                    fontWeight: 600,
                    color: "black",
                    whiteSpace: "nowrap",
                    textOverflow: "ellipsis",
                    overflow: "hidden",
                  }}
                >
                  Final Assessment
                </Typography>
                <ViewBox></ViewBox>
              </TitleBox>
            </Box>
            <Main2Box>
              <VideoBox>
                <Box1>
                  &nbsp;&nbsp;&nbsp;&nbsp;
                  <Typography sx={{ color: "#2a62aa" }}>
                    {courseDetails[0].FinalAssessment[0]?.NAME || null}
                  </Typography>
                </Box1>
              </VideoBox>
            </Main2Box>
          </Main1Card>
        )}
      </>
    )}
  </div>
);
};

export default AccordionModal;

const MainCard = styled(Card)`
  display: flex;
  padding: 35px;
  align-items: center;
  justify-content: center;
  box-shadow: none !important;
`;

const TextBox = styled(Box)`
  display: flex;
  flex-direction: column;
  margin-left: 1px;
`;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  width: 100%;
`;
const SubBox1 = styled(Box)`
  padding: 10px;
  border-radius: 5px;
  background-color: #2a62aa;
  width: 100%;
`;
const SubBox2 = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 10px;
  width: 100%;
`;
const ImageBox = styled(Box)`
  background-color: #e7f3f0;
  max-width: 300px;
  flex-shrink: 0;
`;
const Time1Box = styled(Box)`
  display: flex;
  align-items: center;
`;
const Main1Card = styled(Card)`
  box-shadow: none !important;
  display: flex;
  padding: 0px 20px 0px 0px;
  margin-top: 20px;
  flex-direction: column;
`;
const TitleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
`;

const TimeBox = styled(Box)`
  display: flex;
  /* align-items: center; */
`;
const Main2Box = styled(Box)`
  padding: 10px;
  border-radius: 2px;
  width: 100%;
  background-color: #f5f5f5;
  border-bottom: 1px solid #eeecec;
`;
const VideoBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Box1 = styled(Box)`
  display: flex;
  flex-direction: row;
`;
const Box2 = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
  margin-right: 20px;
`;
const ViewBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
`;
