import React, { useEffect, useRef, useState } from "react";
import { Box, IconButton } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import AccordionModal from "./AccordionModal";
import { useDispatch, useSelector } from "react-redux";
import { instance } from "../../../../Controller/Common";
import { getModule } from "../../../../Store/ClassroomSlice";

interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
  };
}

interface Topic {
  TID: number;
  NAME: string;
  CONTENT: string;
  CONTENT_TYPE: string;
  METADATA: string;
}

interface FinalAssessment {
  AID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
}

interface Module {
  MID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
  Topic: Topic[];
}

interface Course {
  CID: number;
  TITLE: string;
  DESCRIPTION: string;
  DURATION: number;
  THUMBNAIL: any;
  AVAILABILITY: string;
  userEnrolled: boolean;
  FinalAssessment: FinalAssessment[];
  AUTHOR:string;
  Module: Module[];
}

interface CourseProps {
  selectedCourse: Course | null;
  handleClose: () => void;
}

const CourseModal1: React.FC<CourseProps> = ({ selectedCourse, handleClose }) => {
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const [courseDetails, setCourseDetails] = useState<any[]>([]);
  const [checked, setChecked] = useState<boolean[]>([]);
  const value = useSelector((state: StateType) => state.classRoom.value);
  const [nextPage, setNextPage] = useState(0);
  const [selectedTopic, setSelectedTopic] = useState<any>(null);
  const [moduleLength, setModuleLength] = useState<number | undefined>(undefined);
  const [topicLength, setTopicLength] = useState<number | undefined>(undefined);
  const [completedTopic, setCompletedTopic] = useState<number | undefined>(undefined);
  const [hide, setHide] = useState(true);
  const dispatch = useDispatch();

  const GetCourseDetails = async () => {
    try {
      const response = await instance.get(
        //  `/6D/Course/getAllCourseByUserId?userId=${userId}`
        `6D/Course/getCourseDetailsBy-CID?CID=${selectedCourse?.CID}`
      );
      if (response.status === 200) {
        const data = response.data;
        setCourseDetails(data);
        const moduleLength1 = data[0]?.Module?.length;
        const totalTopics = data[0]?.Module.reduce(
          (acc: number, module: any) => acc + module.Topic.length,
          0
        );
        const completedTopics = data[0].Module.reduce(
          (acc: number, module: any) => {
            const completedCount = module.Topic.filter(
              (topic: any) => topic.STATUS === "COMPLETED"
            ).length;
            return acc + completedCount;
          },
          0
        );
        setChecked(new Array(moduleLength1).fill(false));
        dispatch(getModule(data[0]?.Module));
        setModuleLength(moduleLength1);
        setTopicLength(totalTopics);
        setCompletedTopic(completedTopics);
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (selectedCourse) {
      GetCourseDetails();
    }
  }, [selectedCourse, value]);

  useEffect(() => {
    window.scroll(0, 0);
  }, []);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (scrollContainerRef.current) {
        const { key } = event;
        const scrollAmount = 20;

        if (key === "ArrowDown") {
          scrollContainerRef.current.scrollBy(0, scrollAmount);
        } else if (key === "ArrowUp") {
          scrollContainerRef.current.scrollBy(0, -scrollAmount);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  return (
    <Box sx={{ padding: "40px" ,backgroundColor:"#F5F5F5",borderRadius:"5px"}}>
      <IconButton
        size="small"
        onClick={() => {
          handleClose();
        }}
        sx={{ position: "absolute", top:10, right: 10 }}
      >
        <CloseIcon />
      </IconButton>
        <Box
          ref={scrollContainerRef}
          tabIndex={0}
          sx={{
            display: "flex",
            flexDirection: "column",
            backgroundColor: "#F5F5F5",
            borderRadius: "3px",
            padding: "20px",
            overflowY: "scroll",
            maxHeight: 450,
            "&::-webkit-scrollbar": {
              width: 0, 
            },
            "&": {
              msOverflowStyle: "none",
              scrollbarWidth: "none", 
            },
          }}
        >
      <AccordionModal
        selectedCourse={selectedCourse}
        nextPage={nextPage}
        selectedTopic={selectedTopic}
        courseDetails={courseDetails}
        checked={checked}
        hide={hide}
        setHide={setHide}
        topicLength={topicLength}
        completedTopic={completedTopic}
        setNextPage={setNextPage}
      />
      </Box>
    </Box>
  );
};

export default CourseModal1;
