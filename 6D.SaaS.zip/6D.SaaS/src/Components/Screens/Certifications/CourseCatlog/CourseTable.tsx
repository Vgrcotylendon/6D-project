import * as React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import PlayCircleOutlineRoundedIcon from "@mui/icons-material/PlayCircleOutlineRounded";
import CancelIcon from "@mui/icons-material/Cancel";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Checkbox from "@mui/material/Checkbox";
import { Box, IconButton, Typography } from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import CustomButton from "../../../Button/CustomButton";
import { instance } from "../../../../Controller/Common";
import { useSelector } from "react-redux";
import { RootState } from "../../../../Store/UserSlice";
import CustomModal from "../../../Modal/CustomModal";
import EnrollModal from "./EnRollModal";
import useResponsiveCoursePerPage from "./useResponsiveCoursePerPage";

const label = { inputProps: { "aria-label": "Checkbox demo" } };

interface Topic {
  TID: number;
  NAME: string;
  CONTENT: string;
  CONTENT_TYPE: string;
  METADATA: string;
}
interface FinalAssessment {
  AID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
}
interface Module {
  MID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
  Topic: Topic[];
}

interface Course {
  CID: number;
  TITLE: string;
  DESCRIPTION: string;
  DURATION: number;
  THUMBNAIL: any;
  AVAILABILITY: string;
  userEnrolled: boolean;
  FinalAssessment: FinalAssessment[];
  AUTHOR: string;
  Module: Module[];
  userStatus: string;
  timespent:any;
}
interface CourseProps {
  GetCourse: () => Promise<void>;
  getUserCertification: () => Promise<void>;
  courseList: Course[];
  handleModal: (course: Course) => void;
  setValue: React.Dispatch<React.SetStateAction<number>>;
}

const CourseTable: React.FC<CourseProps> = ({
  courseList = [],
  handleModal,
  GetCourse,
  getUserCertification,
  setValue,
}) => {
  const [enroll, setEnroll] = React.useState({});
  const [currentPage, setCurrentPage] = React.useState(1);
  const coursePerPage = useResponsiveCoursePerPage();
  const [isReversed, setIsReversed] = React.useState(false);
  const [isTitleDesc, setIsTitleDesc] = React.useState(false);
  const [isReversedStatus, setIsReversedStatus] = React.useState(false);
  const [isTitleSort, setIsTitleSort] = React.useState(true);
  const [isSort, setIsSort] = React.useState(false);
  const [isFiltered, setIsFiltered] = React.useState(false);
  const [isDurationDesc, setIsDurationDesc] = React.useState(false);
  const [isStatusSort, setIsStatusSort] = React.useState(false);
  const [isAvailabilityDesc, setIsAvailabilityDesc] = React.useState(false);
  const [statusFilter, setStatusFilter] = React.useState<null | "Y" | "N">(
    null
  );
  const [loadingCourseId, setLoadingCourseId] = React.useState<number | null>(
    null
  );
  const [isStatusDesc, setIsStatusDesc] = React.useState(false);
  const [show, setShow] = React.useState(false);
  const [isAvailabilitySort, setIsAvailabilitySort] = React.useState(false);
  const userId = useSelector((state: RootState) => state.user.userID);

  const handleExpandTitle = () => {
    if (!isTitleSort) {
      setIsTitleSort(true);
      setIsTitleDesc(false);
    } else {
      setIsTitleDesc((prev) => !prev);
    }
    setIsSort(false);
    setIsStatusSort(false);
    setIsAvailabilitySort(false);
    setIsFiltered(false);
    setStatusFilter(null);
  };

  const handleExpandLength = () => {
    if (!isSort) {
      setIsSort(true);
      setIsDurationDesc(false);
    } else {
      setIsDurationDesc((prev) => !prev);
      setIsReversed(false);
      setIsAvailabilitySort(false);
      setIsReversedStatus(false);
      setIsFiltered(false);
      setStatusFilter(null);
      setIsTitleSort(false);
    }
  };
  const handleExpandAvailability = () => {
    if (!isAvailabilitySort) {
      setIsAvailabilitySort(true);
      setIsAvailabilityDesc(false);
    } else {
      setIsAvailabilityDesc((prev) => !prev);
    }
    setIsReversed(false);
    setIsSort(false);
    setIsReversedStatus(false);
    setIsFiltered(false);
    setStatusFilter(null);
    setIsTitleSort(false);
  };

  const handleExpandStatus = () => {
    if (!isStatusSort) {
      setIsStatusSort(true);
      setIsStatusDesc(false);
    } else {
      setIsStatusDesc((prev) => !prev);
    }
    setIsTitleSort(false);
    setIsReversed(false);
    setIsSort(false);
    setIsAvailabilitySort(false);
    setIsFiltered(false);
    setStatusFilter(null);
  };

  const formattedDuration = (duration: string | number) => {
    const totalMinutes = Number(duration);
    
    const hours = Math.floor(totalMinutes / 60);
    const minutes = Math.floor(totalMinutes % 60);
    
    if (hours > 0) {
      return `${hours} hrs ${minutes} min`;
    } else {
      return `0 hrs ${minutes} min`;
    }
  };

  const sortedCourseList = React.useMemo(() => {
    let sortedList = [...courseList];

    if (isSort) {
      sortedList.sort((a, b) =>
        isDurationDesc ? b.DURATION - a.DURATION : a.DURATION - b.DURATION
      );
    } else if (isAvailabilitySort) {
      sortedList.sort((a, b) =>
        isAvailabilityDesc
          ? b.AVAILABILITY.localeCompare(a.AVAILABILITY)
          : a.AVAILABILITY.localeCompare(b.AVAILABILITY)
      );
    } else if (isStatusSort) {
      sortedList.sort((a, b) => {
        const aValue = a.userEnrolled ? "Enrolled" : "Enroll";
        const bValue = b.userEnrolled ? "Enrolled" : "Enroll";
        return isStatusDesc
          ? bValue.localeCompare(aValue)
          : aValue.localeCompare(bValue);
      });
    } else if (isTitleSort) {
      sortedList.sort((a, b) =>
        isTitleDesc
          ? b.TITLE.localeCompare(a.TITLE)
          : a.TITLE.localeCompare(b.TITLE)
      );
    }

    if (isFiltered && statusFilter) {
      sortedList = sortedList.filter(
        (course) => course.AVAILABILITY === statusFilter
      );
    }

    return sortedList;
  }, [
    courseList,
    isReversed,
    isSort,
    isAvailabilitySort,
    isTitleSort,
    isTitleDesc,
    isSort,
    isDurationDesc,
    isAvailabilitySort,
    isAvailabilityDesc,
    isStatusSort,
    isStatusDesc,
    isFiltered,
    statusFilter,
  ]);

  const indexOfLastJob = currentPage * coursePerPage;
  const indexOfFirstJob = indexOfLastJob - coursePerPage;
  const currentCourseList = sortedCourseList.slice(
    indexOfFirstJob,
    indexOfLastJob
  );

  const totalPages = Math.ceil(courseList.length / coursePerPage);

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };
  const handleClose = () => {
    setShow(false);
  };
  const renderPageNumbers = (totalPages: number): JSX.Element[] => {
    const pageNumbers: JSX.Element[] = [];

    const firstRange = 3;
    const lastRange = 3;

    for (let i = 1; i <= Math.min(firstRange, totalPages); i++) {
      pageNumbers.push(
        <Typography
          sx={{
            marginLeft: "20px",
            padding: "4px 12px 4px 12px",
            borderRadius: "6px",
            borderWidth: currentPage === i ? "1px" : "0px",
            borderStyle: currentPage === i ? "solid" : "none",
            borderColor: currentPage === i ? "#2A62AA" : "transparent",
            backgroundColor: currentPage === i ? "#EDF1F4" : "transparent",
            color: currentPage === i ? "#2A62AA" : "black",
            cursor: "pointer",
          }}
          key={i}
          onClick={() => setCurrentPage(i)}
        >
          {i}
        </Typography>
      );
    }

    if (totalPages > firstRange + lastRange) {
      pageNumbers.push(
        <Typography sx={{ marginLeft: "40px" }} key="ellipsis-start">
          ...
        </Typography>
      );
    }

    const startLastRange = Math.max(totalPages - lastRange + 1, firstRange + 1);
    for (let i = startLastRange; i <= totalPages; i++) {
      pageNumbers.push(
        <Typography
          sx={{
            marginLeft: "20px",
            padding: "4px 12px 4px 12px",
            borderRadius: "6px",
            borderWidth: currentPage === i ? "1px" : "0px",
            borderStyle: currentPage === i ? "solid" : "none",
            borderColor: currentPage === i ? "#2A62AA" : "transparent",
            backgroundColor: currentPage === i ? "#EDF1F4" : "transparent",
            color: currentPage === i ? "#2A62AA" : "black",
            cursor: "pointer",
          }}
          key={i}
          onClick={() => setCurrentPage(i)}
        >
          {i}
        </Typography>
      );
    }
    return pageNumbers;
  };

  const EnrollCourse = async (course: Course) => {
    try {
      setLoadingCourseId(course.CID);
      const response = await instance.post(`/6D/enRoll/Course`, {
        CID: course.CID,
        UID: userId,
        STATUS: "Not Started",
        PROGRESS: 0,
      });
      if (response.status === 200 && response.data.success) {
        setValue(1);
        GetCourse();
        getUserCertification();
      }
    } catch (error:any) {
      setEnroll(error?.response?.data?.data);
      setShow(true);
      console.error(error);
    } finally {
      setLoadingCourseId(null);
    }
  };
  const capitalizeTitle = (title: string) => {
    return title.slice(0, 1).toUpperCase() + title.slice(1);
  };

  return (
    <div>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: "100%",
          justifyContent: "space-between",
        }}
      >
        <TableContainer component={Paper}>
          <Table sx={{ width: "100%" }} size="small" aria-label="a dense table">
            <TableHead>
              <TableRow>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                    width: "20px",
                  }}
                >
                  <Checkbox {...label} disabled />
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    Title
                    <IconButton onClick={handleExpandTitle}>
                      <KeyboardArrowDownIcon
                        sx={{
                          cursor: "pointer",
                          color: isTitleSort ? "#919599" : "#929396",
                          transform:
                            isTitleSort && isTitleDesc
                              ? "rotate(180deg)"
                              : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </Box>
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    Status
                    <IconButton onClick={handleExpandStatus}>
                      <KeyboardArrowDownIcon
                        sx={{
                          cursor: "pointer",
                          color: isStatusSort ? "#919599" : "#929396",
                          transform:
                            isStatusSort && isStatusDesc
                              ? "rotate(180deg)"
                              : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </Box>
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                    width: "120px",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      width: "120px",
                    }}
                  >
                    {" "}
                    Duration
                    <IconButton onClick={handleExpandLength}>
                      <KeyboardArrowDownIcon
                        sx={{
                          cursor: "pointer",
                          color: isSort ? "#919599" : "#929396",
                          transform:
                            isSort && isDurationDesc
                              ? "rotate(180deg)"
                              : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </Box>
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#f0f0f0",
                    color: "#5F5E5B",
                    height: "72px",
                    borderLeft: "1px solid #d6d6d3",
                    width: "160px",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      width: "160px",
                    }}
                  >
                    Availability
                    <IconButton onClick={handleExpandAvailability}>
                      <KeyboardArrowDownIcon
                        sx={{
                          cursor: "pointer",
                          color: isAvailabilitySort ? "#919599" : "#929396",
                          transform:
                            isAvailabilitySort && isAvailabilityDesc
                              ? "rotate(180deg)"
                              : "none",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </IconButton>
                  </Box>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {currentCourseList.map((course) => (
                <TableRow key={course.CID}>
                  <TableCell
                    sx={{
                      border: "1px solid #f0f0f0",
                      height: "48px",
                    }}
                  >
                    <Checkbox {...label} disabled />
                  </TableCell>
                  <TableCell
                    align="left"
                    sx={{
                      border: "1px solid #f0f0f0",
                      color: "info.main",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      height: "48px",
                      overflow: "hidden",
                    }}
                  >
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "start",
                        cursor: "pointer",
                        whiteSpace: "nowrap",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        maxWidth: "100%",
                      }}
                      onClick={() => handleModal(course)}
                    >
                      {capitalizeTitle(course.TITLE)}
                      &nbsp;&nbsp;
                      <PlayCircleOutlineRoundedIcon
                        style={{
                          color: "info.main",
                          fontSize: "18px",
                          cursor: "pointer",
                        }}
                      />
                    </Box>
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid #f0f0f0",
                      textAlign: "center",
                      color: "#5F5E5B",
                      height: "48px",
                      width: "120px",
                    }}
                  >
                    <CustomButton
                      name={
                        loadingCourseId === course.CID
                          ? "Loading..."
                          // : course.userStatus === "DISQUALIFIED"
                          // ? "Re-Enroll"
                          : course.userEnrolled
                          ? "Enrolled"
                          : "Enroll"
                      }
                      variant={"primary"}
                      padding={
                        course.userEnrolled || loadingCourseId === course.CID
                          ? "8px 10px"
                          : "8px 20px"
                      }
                      disabled={
                        loadingCourseId === course.CID ||
                          // (course.userStatus !== "DISQUALIFIED" && course.userEnrolled) ||
                        course.userEnrolled ||
                        course.AVAILABILITY === "N"
                      }
                      onClick={() => EnrollCourse(course)}
                    />
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid #f0f0f0",
                      textAlign: "center",
                      color: "#5F5E5B",
                      height: "48px",
                      width: "120px",
                    }}
                  >
                    {formattedDuration(course.timespent)}
                    {/* {formatDuration(course.DURATION)} */}
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid #f0f0f0",
                      textAlign: "center",
                      color: course.AVAILABILITY === "Y" ? "green" : "red",
                      height: "48px",
                      width: "160px",
                    }}
                  >
                    <Typography
                      sx={{
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "center",
                        color: course.AVAILABILITY === "Y" ? "green" : "red",
                      }}
                    >
                      <>
                        {course.AVAILABILITY === "Y" ? (
                          <CheckCircleIcon
                            style={{ color: "green", fontSize: "18px" }}
                          />
                        ) : (
                          <CancelIcon
                            style={{ color: "red", fontSize: "18px" }}
                          />
                        )}
                        &nbsp;&nbsp;&nbsp;
                      </>
                      {course.AVAILABILITY === "Y" ? "Yes" : "No"}
                    </Typography>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            position: "absolute",
            width: "90%",
            bottom: 10,
            left: "53%",
            transform: "translateX(-50%)",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <CustomButton
            variant="secondary"
            name={"Previous"}
            padding={"8px 14px"}
            startIcon={<ArrowBackIcon />}
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
          />
          {/* <Typography>
            Page {currentPage} of {totalPages}
          </Typography> */}
          <Box sx={{ display: "flex", alignItems: "center" }}>
            {renderPageNumbers(totalPages)}
          </Box>
          <CustomButton
            variant="secondary"
            name={"Next"}
            padding={"8px 14px"}
            endIcon={<ArrowForwardIcon />}
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
          />
        </Box>
      </Box>
      <CustomModal
        open={show}
        handleClose={handleClose}
        child={<EnrollModal setShow={setShow} enroll={enroll} />}
      />
    </div>
  );
};

export default CourseTable;
