import {
  Box,
  Divider,
  FormControl,
  IconButton,
  InputAdornment,
  OutlinedInput,
  Typography,
} from "@mui/material";
import React from "react";
import CloseIcon from "@mui/icons-material/Close";
import MailIcon from "@mui/icons-material/Mail";
import styled from "styled-components";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import { useNavigate } from "react-router-dom";
import CustomButton from "../../../Button/CustomButton";

interface mailid {
  setShow: React.Dispatch<React.SetStateAction<boolean>>;
  enroll: any;
}

const EnrollModal: React.FC<mailid> = ({ setShow, enroll }) => {
  const Navigate = useNavigate();

  const handleNavigate = () => {
    setShow(false);
    if (
      enroll?.profile_status === false &&
      enroll?.education_status === false
    ) {
      Navigate(`/landing/profile?profile`);
    } else if (enroll?.education_status === false) {
      Navigate(`/landing/profile?tab=1`);
    }
  };

  return (
    <MainBox>
      <IconButton
        size="small"
        onClick={() => setShow(false)}
        sx={{ position: "absolute", top: 10, right: 10 }}
      >
        <CloseIcon />
      </IconButton>
      <SubBox>
        <Sub1Box>
          <Box>
            <Typography
              sx={{
                fontSize: "16px",
                fontWeight: 600,
                color: "#3a65dd",
                lineHeight: "21.68px",
                padding: "20px",
                textAlign: "center",
              }}
            >
              {enroll?.profile_status === false
                ? "Complete Your Profile and Education Details to Enroll"
                : "Complete Your Education Details to Enroll"}
            </Typography>
            <Box
              sx={{
                backgroundColor: "#0c0c0c",
                height: "0.5px",
                width: "448px",
              }}
            />
            <Typography
              sx={{
                fontSize: "12px",
                fontWeight: 400,
                color: "#4C2D2D",
                lineHeight: "21.68px",
                padding: "20px 0",
                width: "448px",
              }}
            >
              To proceed with course enrollment, please complete your{" "}
              {enroll?.profile_status === false
                ? "profile and Education Details."
                : "Education Details."}{" "}
              We require up-to-date information to ensure a smooth enrollment
              process.
              <br />
              Once Your Profile is complete, you'll be able to enroll in the
              course.
            </Typography>
            <Box
              sx={{
                backgroundColor: "#0c0c0c",
                height: "0.5px",
                width: "448px",
              }}
            />
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                padding: "20px 0px 20px 0px",
              }}
            >
              <CustomButton
                name={
                  enroll?.profile_status === false
                    ? "Complete profile"
                    : "Complete Education Details"
                }
                variant="primary"
                padding="5px 15px"
                onClick={handleNavigate}
              />
            </Box>
          </Box>
        </Sub1Box>
      </SubBox>
    </MainBox>
  );
};

export default EnrollModal;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  background-color: #ffffff;
  border-radius: 10px;
  padding: 30px;
  justify-content: center;
  align-items: center;
`;
const SubBox = styled(Box)`
  display: flex;
  flex-direction: column;
  background-color: #f6f5f5;
  border-radius: 10px;
  padding: 20px;
  justify-content: center;
  align-items: center;
`;
const Sub1Box = styled(Box)`
  display: flex;
  flex-direction: column;
  background-color: #ffffff;
  border-radius: 10px;
  padding: 16px;
  justify-content: center;
`;
