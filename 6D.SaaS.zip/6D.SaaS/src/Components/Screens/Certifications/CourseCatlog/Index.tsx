import * as React from "react";
import CourseTable from "./CourseTable";
import CourseCard from "./CourseCard";
import CustomModal from "../../../Modal/CustomModal";
import CourseModal1 from "./CourseModal1";

interface Topic {
  TID: number;
  NAME: string;
  CONTENT: string;
  CONTENT_TYPE: string;
  METADATA: string;
 }

interface Module {
  MID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR:number;
  Topic:Topic[];
}
interface FinalAssessment {
  AID: number;
  NAME: string;
  DURATION: string;
  STATUS: string;
  AUTHOR: number;
}
interface Course {
  CID: number;
  TITLE: string;
  DESCRIPTION:string;
  DURATION: number;
  THUMBNAIL: any;
  AVAILABILITY:string;
  userEnrolled: boolean;
  FinalAssessment:FinalAssessment[];
  AUTHOR:string;
  Module: Module[]; 
  userStatus:string;
  timespent:any;
}
interface CourseListProps {
  certificationValue: boolean;
  course: Course[];
  GetCourse:() => Promise<void>;
  setValue:React.Dispatch<React.SetStateAction<number>>;
  getUserCertification: () => Promise<void>;
}

const CourseList: React.FC<CourseListProps> = ({
  certificationValue,
  getUserCertification,
  course,
  GetCourse,
  setValue
}) => {
  const [selectedCourse, setSelectedCourse] = React.useState<Course | null>(
    null
  );
  const [open, setOpen] = React.useState(false);

  const handleOpen = (course: Course) => {
    setSelectedCourse(course);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedCourse(null);
  };

  return (
    <>
      <CustomModal
        open={open}
        handleClose={handleClose}
        sx={{ width: "70%", height: "auto", mt: 5 }}
        child={
          <CourseModal1
            selectedCourse={selectedCourse}
            handleClose={handleClose}
          />
        }
      />
      {certificationValue ? (
        <CourseTable courseList={course} setValue={setValue} GetCourse={GetCourse} handleModal={handleOpen} getUserCertification={getUserCertification}/>
      ) : (
        <CourseCard courseList={course} handleModal={handleOpen} setValue={setValue} GetCourse={GetCourse} getUserCertification={getUserCertification}/>
      )}
    </>
  );
};

export default CourseList;


