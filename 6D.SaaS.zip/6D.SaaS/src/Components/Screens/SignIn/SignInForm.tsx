import {
  Box,
  Card,
  Divider,
  Grid,
  Typography,
  IconButton,
} from "@mui/material";
import React, { useState } from "react";
import MailIcon from "@mui/icons-material/Mail";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import { Link, useNavigate } from "react-router-dom";
import InputField from "../../Input/InputField";
import Google from "../../../Assets/Google.svg";
import { cookies, ImageUrl, instance } from "../../../Controller/Common";
import { useGoogleLogin } from "@react-oauth/google";
import CustomButton1 from "../../Button/CustomButton1";
import {
  SignInFailed,
  SignInSuccess,
  StartSignIn,
  UpdateProfile,
} from "../../../Store/UserSlice";
import { useDispatch } from "react-redux";
import CustomModal from "../../Modal/CustomModal";
import GoogleSigninModal from "./GoogleSigninModal";
import AlertModal from "../SignUp/AlertModal";
import GoogleAlertModal from "./GoogleAlertModal";

interface signUpProps {
  setVal: React.Dispatch<React.SetStateAction<number>>;
  mobileNumber: string;
  setMobileNumber: React.Dispatch<React.SetStateAction<string>>;
  email: string;
  setEmail: React.Dispatch<React.SetStateAction<string>>;
  setOpenPolicy: React.Dispatch<React.SetStateAction<boolean>>;
  setOpenTerms: React.Dispatch<React.SetStateAction<boolean>>;
}

const SignInForm: React.FC<signUpProps> = ({
  mobileNumber,
  setMobileNumber,
  email,
  setEmail,
  setVal,
  setOpenPolicy,
  setOpenTerms,
}) => {
  const [password, setPassword] = useState<string>("");
  const [errorMsg, setErrorMsg] = useState(false);
  const [errorMsgMobile, setErrorMsgMobile] = useState(false);
  function validateEmail(Email: string | number) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(String(Email).toLowerCase());
  }

  function validateIndianMobileNumber(mobileNumber: string) {
    const regex = /^[6-9]\d{9}$/;
    return regex.test(mobileNumber);
  }
  const [open, setOpen] = useState(false);
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [mobileerror, setMobileError] = useState(false);
  const [emailError, setEmailError] = useState(false);
  const [googlerror, setGoogleError] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleOpenTerms = () => setOpenTerms(true);
  const handleOpenPolicy = () => setOpenPolicy(true);

  const handlePhoneNumber = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;

    value = value.replace(/\D/g, "");
    if (value.startsWith("91") && value.length > 10) {
      value = value.slice(2);
    }
    if (value.length > 10) {
      value = value.slice(0, 10);
    }
    if (validateIndianMobileNumber(value)) {
      value = `+91${value}`;
      setMobileError(false);
    } else {
      setMobileError(true);
    }
    setMobileNumber(value);
    setEmail("");
    setEmailError(false);
    setErrorMsgMobile(false);
  };
  const SignInForMobile = async () => {
    try {
      const response = await instance.post("/6D/auth/sendCodeforMobile", {
        mobileNumber,
      });
      if (response.status === 200) {
        setVal(1);
        setErrorMsgMobile(false);
      }
    } catch (error) {
      setErrorMsgMobile(true);
      console.error(error);
    }
  };
  const SignInCheck = async () => {
    try {
      const response = await instance.post("/6D/auth/CheckEmailSignIn", {
        email,
      });

      if (response.status === 200) {
        setVal(1);
        setErrorMsg(false);
      }
    } catch (error: any) {
      if (error.response) {
        const status = error.response.status;

        if (status === 400) {
          console.log("Email required");
        } else if (status === 401) {
          setErrorMsg(true);
          console.log("User not found");
        } else if (status === 404) {
          setErrorMsg(true);
          console.log("User not found");
        } else if (status === 406) {
          setOpen(true);
          console.log("User not enabled");
        } else {
          console.error("An unexpected error occurred:", error);
        }
      } else {
        console.error("Network error or no response:", error);
      }
    }
  };

  const handleClick = () => {
    if (!email && !mobileNumber) {
      setShow1(true);
    }
    if (email) {
      SignInCheck();
    } else if (mobileNumber) {
      SignInForMobile();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleClick();
    }
  };

  const login = useGoogleLogin({
    onSuccess: async (tokenResponse: any) => {
      try {
        const accessToken = tokenResponse?.access_token;
        if (accessToken) {
          const tokenInfoResponse = await fetch(
            `https://www.googleapis.com/oauth2/v3/tokeninfo?access_token=${accessToken}`
          );
          const data = await tokenInfoResponse.json();

          if (data.email) {
            try {
              const response = await instance.post(
                "/6D/auth/socialMediaSignIn",
                {
                  email: data.email,
                  accountOrigin: "GOOGLE",
                }
              );
              if (response.status === 200) {
                dispatch(SignInSuccess(response.data));
                dispatch(UpdateProfile(`${ImageUrl}${response.data.profile}`));
                cookies.set("userId", response.data.userId);
                cookies.set("token", response.data.token);
                cookies.set("refreshToken", response.data.refreshToken);
                const status = cookies.get("modal");
                status === undefined && cookies.set("modal", false);
                navigate("/landing");
              } else if (response.status === 400) {
                console.error(
                  "This email is already registered. Please use a different email or log in"
                );
              } else {
                console.error("Unexpected response status:", response.status);
              }
            } catch (error) {
              setShow(true);
              console.error("Error during sign up:", error);
            }
          } else {
            console.error("No email found in token info");
          }
        } else {
          console.error("No access_token found in tokenResponse");
        }
      } catch (error) {
        console.error(
          "Error fetching token info or during login process:",
          error
        );
      }
    },
    onError: (error) => {
      console.error("Login Failed", error);
    },
  });

  return (
    <>
      {/* <CustomModal
        open={openTerms}
        handleClose={() => handleOpenTerms()}
        sx={{ width: "100%", height: "100%", mt: 8 }}
        child={<TermsModal handleCloseTerms={handleCloseTerms} />}
      />
      <CustomModal
        open={openPolicy}
        sx={{ width: "100%", height: "100%", mt: 8 }}
        handleClose={() => handleOpenPolicy()}
        child={<PolicyModal handleClosePolicy={handleClosePolicy} />}
      /> */}
      <CustomModal
        open={show}
        handleClose={() => setShow(false)}
        child={<GoogleSigninModal setShow={setShow} />}
      />
      <CustomModal
        open={show1}
        handleClose={() => setShow1(false)}
        child={<AlertModal setShow1={setShow1} />}
      />
      <CustomModal
        open={open}
        handleClose={() => setOpen(false)}
        child={<GoogleAlertModal setOpen={setOpen} />}
      />
      <Grid
        item
        padding={2}
        sx={{
          // minWidth: { xs: "90%", sm: 500, md: 500 },
          minHeight: { md: 400 },
        }}
      >
        <Typography
          align="center"
          variant="h4"
          sx={{ fontWeight: "700", fontSize: "32px", lineHeight: "43.36px" }}
        >
          Sign into your Account
        </Typography>
        <Typography
          align="center"
          sx={{
            fontSize: "12px",
            mt: 0.5,
            lineHeight: "16.26px",
            fontWeight: "400",
            color: "#3F3F40",
          }}
        >
          Don't have an account?&nbsp;
          <Link
            to={"/signup"}
            style={{
              fontSize: "12px",
              color: "#0000EE",
              fontWeight: 700,
              textDecoration: "none",
            }}
          >
            signup
          </Link>
        </Typography>
        <Card
          elevation={0}
          sx={{
            bgcolor: "#F2F2F2",
            p: "15px 50px",
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
            borderRadius: 2,
            mt: 1.5,
          }}
        >
          <Typography
            align="center"
            sx={{
              fontSize: "14px",
              fontWeight: "600",
              lineHeight: "18.97px",
              mb: 1,
            }}
          >
            Phone Number
          </Typography>
          <InputField
            id={"phone number"}
            label="Phone number"
            placeholder={"Enter here"}
            value={mobileNumber}
            helper={
              (mobileerror && "Please enter a valid phone number.") ||
              errorMsgMobile === true
                ? "Entered phone Number is not registered"
                : null
            }
            onChange={handlePhoneNumber}
            icon={LocalPhoneIcon}
            onKeyDown={handleKeyDown}
          />
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              mb: 1,
            }}
          >
            <Divider sx={{ width: 70, bgcolor: "#8C8C8C" }} />
            &nbsp;&nbsp;&nbsp;{" "}
            <Typography sx={{ color: "#939393", fontSize: "11px" }}>
              or
            </Typography>
            &nbsp;&nbsp;&nbsp;
            <Divider sx={{ width: 70, bgcolor: "#8C8C8C" }} />
          </Box>
          <Typography
            align="center"
            sx={{
              fontSize: "14px",
              fontWeight: "600",
              lineHeight: "18.97px",
              mb: 1,
            }}
          >
            Email Address
          </Typography>
          <InputField
            id={"mail"}
            label="Email"
            placeholder={"Enter here"}
            icon={MailIcon}
            value={email}
            helper={
              (emailError && "Please enter a valid email address") ||
              errorMsg === true
                ? "Entered email ID is not registered"
                : null
            }
            onChange={(e) => {
              setEmailError(validateEmail(e.target.value) ? false : true);
              setEmail(e.target.value);
              setMobileNumber("");
              setMobileError(false);
              setErrorMsg(false);
            }}
            onKeyDown={handleKeyDown}
          />
        </Card>
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            mt: 1,
            // mb: 1,
          }}
        >
          <Divider sx={{ width: 80, bgcolor: "#939393" }} />
          &nbsp;&nbsp;&nbsp;{" "}
          <Typography sx={{ color: "#939393", fontSize: "11px" }}>
            or
          </Typography>
          &nbsp;&nbsp;&nbsp;
          <Divider sx={{ width: 80, bgcolor: "#939393" }} />
        </Box>
        <Card
          elevation={0}
          sx={{
            bgcolor: "#F2F2F2",
            p: "20px 50px",
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
            mt: 1.5,
            borderRadius: 2,
          }}
        >
          <Typography
            align="center"
            sx={{
              fontSize: "14px",
              fontWeight: "600",
              lineHeight: "18.97px",
              mb: 1,
            }}
          >
            Sign in Using
          </Typography>
          <Box sx={{ display: "flex", justifyContent: "center" }}>
            <IconButton
              sx={{
                m: 1,
                // width: 50,
                // height: 50,
                borderRadius: 2,
                display: "flex",
                textTransform: "none",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                p: 1,
                bgcolor: "#fff",
              }}
              onClick={() => login()}
            >
              <img src={Google} alt="Google" width={20} height={20} />
            </IconButton>
            {/* <IconButton
              sx={{
                m: 1,
                // width: 50,
                // height: 50,
                borderRadius: 2,
                display: "flex",
                textTransform: "none",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                p: 1,
                bgcolor: "#fff",
              }}
              // onClick={() => login()}
            >
              <img src={Facebook} alt="fb" width={20} height={20} />
            </IconButton>
            <IconButton
              sx={{
                m: 1,
                // width: 50,
                // height: 50,
                borderRadius: 2,
                display: "flex",
                textTransform: "none",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                p: 1,
                bgcolor: "#fff",
              }}
              // onClick={() => login()}
            >
              <img src={Linkedin} alt="Linked in" width={20} height={20} />
            </IconButton> */}
          </Box>
        </Card>
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
          }}
        >
          <Box sx={{ display: "flex", justifyContent: "center" }}>
            <CustomButton1
              name="Sign In"
              variant="primary"
              onClick={() => {
                handleClick();
              }}
              style={{ marginTop: "30px" }}
              disabled={mobileerror || emailError}
            />
          </Box>
          <Grid
            sx={{
              mt: 2,

              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Typography
              sx={{
                fontSize: "12px",
                color: "#939393",
                fontWeight: 400,
                lineHeight: "18.97px",
              }}
            >
              Protected and subject to the
            </Typography>
            &nbsp;
            <Link
              to={"#"}
              onClick={handleOpenPolicy}
              style={{
                color: "#0000EE",
                fontSize: "12px",
                fontWeight: 400,
                lineHeight: "18.97px",
                textDecoration: "none",
              }}
            >
              privacy policy
            </Link>
            &nbsp;{" "}
            <Typography
              sx={{
                fontSize: "12px",
                color: "#939393",
                fontWeight: 400,
                lineHeight: "18.97px",
              }}
            >
              and
            </Typography>{" "}
            &nbsp;
            <Link
              to={"#"}
              onClick={handleOpenTerms}
              style={{
                color: "#0000EE",
                fontSize: "12px",
                fontWeight: 400,
                lineHeight: "18.97px",
                textDecoration: "none",
              }}
            >
              Terms of Services
            </Link>
          </Grid>
        </Box>
      </Grid>
    </>
  );
};
export default SignInForm;
