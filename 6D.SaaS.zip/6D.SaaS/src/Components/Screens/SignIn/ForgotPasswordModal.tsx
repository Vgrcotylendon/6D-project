import {
  Box,
  FormControl,
  IconButton,
  InputAdornment,
  OutlinedInput,
  Typography,
} from "@mui/material";
import React from "react";
import CloseIcon from "@mui/icons-material/Close";
import MailIcon from "@mui/icons-material/Mail";
import styled from "styled-components";
import CustomButton1 from "../../Button/CustomButton1";
import { cookies, instance } from "../../../Controller/Common";
import { useNavigate } from "react-router-dom";

interface mailid {
  email: string;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  handleClose: () => void;
}

const ForgotPasswordModal: React.FC<mailid> = ({
  email,
  setOpen,
  handleClose,
}) => {
  const [successMsg, setSuccessMsg] = React.useState(false);
  const [errorMsg, setErrorMsg] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [emailAddress, setEmailAddress] = React.useState(email);
  const Navigate = useNavigate();

  const ResetPassword = async () => {
    setLoading(true);
    try {
      const response = await instance.post("/6D/auth/forgotPassword", {
        email:emailAddress,
      });

      if (response.status === 200) {
        setSuccessMsg(true);
        cookies.set("tempPasswordUsed", true);
      }
    } catch (error: unknown | any) {
      setErrorMsg(true);
      if (error.response) {
        console.error(`Error: ${error.response.data.message}`);
      } else if (error.request) {
        console.error("No response received from the server.");
      } else {
        console.error("An unknown error occurred:", error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      ResetPassword();
    }
  };
  const handleNavigate = () => {
    setOpen(false);
    Navigate("/Signin");
  };

  return (
    <MainBox>
      <IconButton
        size="small"
        onClick={() => {
          handleClose();
        }}
        sx={{ position: "absolute", top: 10, right: 10 }}
      >
        <CloseIcon />
      </IconButton>
      <SubBox>
        <Sub1Box>
          {successMsg ? (
            <Box>
              <Typography
                sx={{
                  fontSize: "16px",
                  fontWeight: 600,
                  color: "#4C2D2D",
                  lineHeight: "21.68px",
                  padding: "20px",
                  textAlign: "center"
                }}
              >
                Password Reset Email Sent
              </Typography>
              <Box
                sx={{
                  backgroundColor: "#0c0c0c",
                  height: "0.5px",
                  width: "448px",
                }}
              />
              <Typography
                sx={{
                  fontSize: "12px",
                  fontWeight: 400,
                  color: "#4C2D2D",
                  lineHeight: "21.68px",
                  padding: "20px 0",
                  width: "448px",
                }}
              >
                We've sent a temporary password to your registered email address
                with the subject line:{" "}
                <span style={{ fontWeight: "bold" }}>
                  Forgot Password Reset for Your 6D LMS Account.
                </span>
                <br /> <br />
                Please check your inbox and follow the instructions to log in.
                If you don't see the email, check your spam or junk folder.
                <br />
                <br /> Once you log in with the temporary password, you will be
                prompted to create a new password.
              </Typography>
              <Box
                sx={{
                  backgroundColor: "#0c0c0c",
                  height: "0.5px",
                  width: "448px",
                }}
              />
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  padding: "20px 0px 20px 0px",
                }}
              >
                <CustomButton1
                  name="Back to Login"
                  variant="primary"
                  padding="5px 15px"
                  onClick={handleNavigate}
                />
              </Box>
            </Box>
          ) : (
            <>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Typography
                  sx={{
                    fontSize: "16px",
                    fontWeight: 600,
                    color: "#4C2D2D",
                    lineHeight: "21.68px",
                    padding: "20px",
                  }}
                >
                  Forgot Password &nbsp;?
                </Typography>
              </Box>
              <Box
                sx={{
                  backgroundColor: "#d9d9dd",
                  height: "1px",
                  width: "448px",
                }}
              />
              <Typography
                sx={{
                  fontSize: "12px",
                  fontWeight: 400,
                  color: "#4C2D2D",
                  lineHeight: "21.68px",
                  padding: "20px 0",
                  width: "448px",
                }}
              >
                No worries! Enter your registered email address below, and we'll
                send you a temporary password for one-time use. You'll need to
                update your password after logging in.
              </Typography>
              <Typography
                sx={{
                  fontSize: "12px",
                  fontWeight: 500,
                  lineHeight: "16.26px",
                  mb: 1,
                  color: "#3F3F40",
                }}
              >
                Email address*
              </Typography>
              <FormControl sx={{ width: "448px", height: "40px" }}>
                <OutlinedInput
                  placeholder="sample@gmail.com"
                  value={emailAddress}
                  onChange={(e) => {
                    setEmailAddress(e.target.value);
                    setErrorMsg(false);
                }}
                  onKeyDown={handleKeyDown}
                  endAdornment={
                    <InputAdornment position="end">
                      <MailIcon />
                    </InputAdornment>
                  }
                />
                {errorMsg === true && (
                <Typography sx={{fontSize:"10px", color:"red"}}>Entered E-mail Id is not registered !</Typography>
              )}
              </FormControl>
              <Box sx={{ width: "448px", padding: "20px 0px 20px 0px",marginTop:"20px" }}>
                <Typography
                  sx={{
                    fontWeight: 400,
                    fontSize: "12px",
                    color: "#3F3F40",
                  }}
                >
                  Check your inbox for an email with your temporary password. If
                  you don't see it, please check your spam or junk folder or
                  contact our support team for assistance at
                  support@6dworks.com.
                </Typography>
              </Box>
              <Box
                sx={{
                  backgroundColor: "#0c0c0c",
                  height: "0.5px",
                  width: "448px",
                }}
              />
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  marginTop: "20px",
                }}
              >
                <CustomButton1
                  name="Cancel"
                  variant="secondary"
                  padding="5px 15px"
                  onClick={handleClose}
                />
                <CustomButton1
                  name={loading ? "Loading..." : "Reset My Password"}
                  variant="primary"
                  padding="5px 15px"
                  onClick={ResetPassword}
                  disabled={loading}
                />
              </Box>
            </>
          )}
        </Sub1Box>
      </SubBox>
    </MainBox>
  );
};

export default ForgotPasswordModal;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  background-color: #ffffff;
  border-radius: 10px;
  padding: 30px;
  justify-content: center;
  align-items: center;
`;
const SubBox = styled(Box)`
  display: flex;
  flex-direction: column;
  background-color: #f6f5f5;
  border-radius: 10px;
  padding: 20px;
  justify-content: center;
  align-items: center;
`;
const Sub1Box = styled(Box)`
  display: flex;
  flex-direction: column;
  background-color: #ffffff;
  border-radius: 10px;
  padding: 16px;
  justify-content: center;
`;
