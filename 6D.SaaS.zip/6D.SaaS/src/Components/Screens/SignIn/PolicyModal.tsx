import React, { useEffect, useRef } from "react";
import { Box, Typography, IconButton } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
 
interface policyProps {
  maxheight?: any;
  marginBottom?: any;
  marginTop?: any;
  height: any;
  handleClosePolicy: () => void;
}
 
const PolicyModal: React.FC<policyProps> = ({
  handleClosePolicy,
  maxheight,
  marginTop,
  height,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
 
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (scrollContainerRef.current) {
        const { key } = event;
        const scrollAmount = 20;
 
        if (key === "ArrowDown") {
          scrollContainerRef.current.scrollBy(0, scrollAmount);
        } else if (key === "ArrowUp") {
          scrollContainerRef.current.scrollBy(0, -scrollAmount);
        }
      }
    };
 
    window.addEventListener("keydown", handleKeyDown);
 
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);
  return (
    <div
      style={{
        maxHeight: `${height}px`,
        minHeight: `${height}px`,
        padding: "0px",
      }}
    >
      <Box
        sx={{
          maxHeight: `${marginTop}px`,
          minHeight: `${marginTop}px`,
        }}
      ></Box>
      <Box sx={{ padding: "0px 70px" }}>
        <IconButton
          size="small"
          onClick={() => {
            handleClosePolicy();
          }}
          sx={{ position: "absolute", top: 90, right: 20 }}
        >
          <CloseIcon />
        </IconButton>
        <Box
          ref={scrollContainerRef}
          tabIndex={0}
          sx={{
            maxHeight: `${maxheight}px`,
            minHeight: `${maxheight}px`,
            display: "flex",
            flexDirection: "column",
            backgroundColor: "#F5F5F5",
            borderRadius: "3px",
            padding: "0px 30px",
            overflowY: "scroll",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            "&::-webkit-scrollbar": {
              width: 10,
            },
            "&::-webkit-scrollbar-thumb": {
              backgroundColor: "#B0B0B0",
              borderRadius: "10px",
            },
            "&::-webkit-scrollbar-thumb:hover": {
              backgroundColor: "#8E8E8E",
            },
            "&::-webkit-scrollbar-track": {
              backgroundColor: "#F0F0F0",
              borderRadius: "10px",
            },
            "&": {
              msOverflowStyle: "none",
              scrollbarWidth: "thin",
            },
          }}
        >
          <Typography
            sx={{
              fontSize: "24px",
              fontWeight: 400,
              color: "#3F3F40",
              padding: "10px",
              pt: "30px",
            }}
          >
            Privacy Policy
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            1.Introduction
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            Welcome to 6D LMS. Your privacy is important to us, and we are
            committed to protecting your personal information. This Privacy
            Policy explains how we collect, use, disclose, and safeguard your
            data when you use our platform, including the website, mobile
            application, and services provided by 6D LMS ("Service"). By
            accessing or using our Service, you agree to the collection and use
            of information in accordance with this policy.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            2.Information We Collect
          </Typography>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start",
            }}
          >
            <Typography
              sx={{
                fontSize: "14px",
                fontWeight: 400,
                color: "#69696d",
                padding: "10px",
              }}
            >
              We collect the following types of information:
            </Typography>
            <ul style={{ marginLeft: "20px", color: "#69696d" }}>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Personal Data: When you register for an account or use our
                  Service, we may collect personal information such as your
                  name, email address, phone number, and institution details.
                </Typography>
              </li>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Usage Data: We automatically collect data regarding your
                  interaction with the platform, including IP address, browser
                  type, access times, and pages viewed.
                </Typography>
              </li>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Cookies and Tracking Data: We use cookies to track activity
                  and store information about your preferences.
                </Typography>
              </li>
            </ul>
          </Box>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            How We Use Your Information
          </Typography>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start",
            }}
          >
            <Typography
              sx={{
                fontSize: "14px",
                fontWeight: 400,
                color: "#69696d",
                padding: "10px",
              }}
            >
              We use the information we collect to:
            </Typography>
 
            <ul style={{ marginLeft: "20px", color: "#69696d" }}>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Provide and maintain our Service;
                </Typography>
              </li>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Improve user experience and customize the platform;
                </Typography>
              </li>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Communicate with you, including responding to inquiries or
                  sending notifications about updates;
                </Typography>
              </li>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Ensure the security and integrity of our platform.
                </Typography>
              </li>
            </ul>
          </Box>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Data Sharing and Disclosure
          </Typography>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start",
            }}
          >
            <Typography
              sx={{
                fontSize: "14px",
                fontWeight: 400,
                color: "#69696d",
                padding: "10px",
              }}
            >
              We do not sell or rent your personal information to third parties.
              We may share your information with:
            </Typography>
 
            <ul style={{ marginLeft: "20px", color: "#69696d" }}>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Service Providers: Third-party companies or individuals that
                  assist us in operating the platform.
                </Typography>
              </li>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Legal Requirements: When required by law, regulation, or court
                  order, we may disclose personal data.
                </Typography>
              </li>
            </ul>
          </Box>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Data Security
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            We implement industry-standard security measures to protect your
            personal information from unauthorized access, disclosure,
            alteration, or destruction. However, no method of transmission over
            the internet or electronic storage is completely secure, and we
            cannot guarantee absolute security.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Your Data Rights
          </Typography>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start",
            }}
          >
            <Typography
              sx={{
                fontSize: "14px",
                fontWeight: 400,
                color: "#69696d",
                padding: "10px",
              }}
            >
              Depending on your location, you may have the following rights
              regarding your personal information:
            </Typography>
 
            <ul style={{ marginLeft: "20px", color: "#69696d" }}>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Access, correction, or deletion of your personal data;
                </Typography>
              </li>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Restriction or objection to processing;
                </Typography>
              </li>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  Data portability.
                </Typography>
              </li>
              <li>
                <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                  To exercise these rights, please contact us at [support
                  email].
                </Typography>
              </li>
            </ul>
          </Box>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Changes to This Policy
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            We may update this Privacy Policy from time to time. Any changes
            will be notified by posting the updated policy on our platform. You
            are encouraged to review this policy periodically.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Contact Us
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            If you have any questions about this Privacy Policy, please contact
            us at:
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
            }}
          >
            Email:
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              pb: "30px",
            }}
          >
            Phone:
          </Typography>
        </Box>
      </Box>
    </div>
  );
};
 
export default PolicyModal;