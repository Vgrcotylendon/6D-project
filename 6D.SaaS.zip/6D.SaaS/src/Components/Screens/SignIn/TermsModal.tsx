import React, { useEffect, useRef } from "react";
import { Box, Typography, IconButton } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
 
interface CourseProps {
  handleCloseTerms: () => void;
  maxheight?: any;
  marginBottom?: any;
  marginTop?: any;
  height: any;
}
 
const TermsModal: React.FC<CourseProps> = ({
  handleCloseTerms,
  maxheight,
  marginTop,
  marginBottom,
  height,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
 
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (scrollContainerRef.current) {
        const { key } = event;
        const scrollAmount = 20;
 
        if (key === "ArrowDown") {
          scrollContainerRef.current.scrollBy(0, scrollAmount);
        } else if (key === "ArrowUp") {
          scrollContainerRef.current.scrollBy(0, -scrollAmount);
        }
      }
    };
 
    window.addEventListener("keydown", handleKeyDown);
 
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);
  return (
    <div
      style={{
        maxHeight: `${height}px`,
        minHeight: `${height}px`,
        padding: "0px",
      }}
    >
      <Box
        sx={{
          maxHeight: `${marginTop}px`,
          minHeight: `${marginTop}px`,
        }}
      ></Box>
      <Box sx={{ padding: "0px 70px" }}>
        <IconButton
          size="small"
          onClick={() => {
            handleCloseTerms();
          }}
          sx={{ position: "absolute", top: 90, right: 20 }}
        >
          <CloseIcon />
        </IconButton>
        <Box
          ref={scrollContainerRef}
          tabIndex={0}
          sx={{
            maxHeight: `${maxheight}px`,
            minHeight: `${maxheight}px`,
            display: "flex",
            flexDirection: "column",
            backgroundColor: "#F5F5F5",
            borderRadius: "3px",
            padding: "0px 30px",
            overflowY: "scroll",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            "&::-webkit-scrollbar": {
              width: 10,
            },
            "&::-webkit-scrollbar-thumb": {
              backgroundColor: "#B0B0B0",
              borderRadius: "10px",
            },
            "&::-webkit-scrollbar-thumb:hover": {
              backgroundColor: "#8E8E8E",
            },
            "&::-webkit-scrollbar-track": {
              backgroundColor: "#F0F0F0",
              borderRadius: "10px",
            },
            "&": {
              msOverflowStyle: "none",
              scrollbarWidth: "thin",
            },
          }}
        >
          <Typography
            sx={{
              fontSize: "24px",
              fontWeight: 400,
              color: "#3F3F40",
              padding: "10px",
              pt: "30px",
            }}
          >
            Terms of service
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Introduction
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            Welcome to 6D LMS! These Terms of Service ("Terms") govern your
            access to and use of the 6D LMS platform, including any related
            content, features, and services ("Service"). By accessing or using
            our Service, you agree to be bound by these Terms. Please read these
            Terms carefully before using the Service. If you do not agree to
            these Terms, you must not use our Service.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Eligibility
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            To use the Service, you must be at least 18 years old or have
            permission from a parent or legal guardian. By using the Service,
            you represent that you meet these eligibility requirements.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            User Accounts
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            Registration: You must create an account to access certain features
            of our Service. When you create an account, you must provide
            accurate, complete, and up-to-date information. Security: You are
            responsible for maintaining the confidentiality of your account
            credentials. Notify us immediately if you believe your account has
            been compromised. Termination: We reserve the right to suspend or
            terminate your account for any reason, including but not limited to
            violation of these Terms.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Acceptable Use
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            When using our Service, you agree to: Comply with all applicable
            laws and regulations; Not engage in any activity that is unlawful,
            harmful, or disruptive to the Service or other users; Not use the
            Service for any commercial purpose without prior authorization.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Content and Intellectual Property
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            Your Content: By uploading or submitting content to the Service, you
            grant us a non-exclusive, worldwide, royalty-free license to use,
            distribute, and display the content in connection with operating the
            Service. Our Content: All content provided by 6D LMS, including
            text, graphics, logos, and software, is our intellectual property
            and may not be reproduced or used without our express permission.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Fees and Payments
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            If you are using a paid subscription or purchasing services through
            6D LMS, you agree to the terms of the subscription and are
            responsible for all applicable fees. Failure to pay fees on time may
            result in suspension of your account.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Disclaimer of Warranties
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            The Service is provided on an "as is" and "as available" basis. We
            do not warrant that the Service will be uninterrupted, error-free,
            or free of viruses. You use the Service at your own risk.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Limitation of Liability
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            To the maximum extent permitted by law, 6D LMS will not be liable
            for any indirect, incidental, or consequential damages arising from
            your use of the Service. Our total liability for any claim related
            to the Service shall not exceed the amount paid by you to use the
            Service in the preceding 12 months.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Indemnification
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            You agree to indemnify and hold 6D LMS, its affiliates, and
            employees harmless from any claims, damages, or expenses arising
            from your use of the Service, your violation of these Terms, or your
            violation of any law or rights of a third party.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            Changes to the Terms We may modify these Terms at anytime. Changes
            will be posted on the platform, and continued use of the Service
            after changes have been made constitutes your acceptance of the new
            Terms.
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              padding: "10px",
            }}
          >
            Governing Law
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              color: "#69696d",
              padding: "10px",
            }}
          >
            These Terms shall be governed by and construed in accordance with
            the laws of, without regard to its conflict of law provisions.
            Contact Us For questions or concerns regarding these Terms, please
            contact us at:
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
            }}
          >
            Email:
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 700,
              color: "#3F3F40",
              pb: "30px",
            }}
          >
            Phone:
          </Typography>
        </Box>
      </Box>
    </div>
  );
};
 
export default TermsModal;