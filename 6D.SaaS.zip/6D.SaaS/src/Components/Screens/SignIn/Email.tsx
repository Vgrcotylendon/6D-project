import { Card, Grid, Typography } from "@mui/material";
import React, { useState } from "react";
import MailIcon from "@mui/icons-material/Mail";
import { Link, useNavigate } from "react-router-dom";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { cookies, ImageUrl, instance } from "../../../Controller/Common";
import {
  RootState,
  SignInFailed,
  SignInSuccess,
  StartSignIn,
  UpdateProfile,
} from "../../../Store/UserSlice";
import { useDispatch, useSelector } from "react-redux";
import InputField from "../../Input/InputField";
import CustomButton1 from "../../Button/CustomButton1";
import CustomModal from "../../Modal/CustomModal";
import ForgotPasswordModal from "./ForgotPasswordModal";

export interface valueProps {
  setVal: React.Dispatch<React.SetStateAction<number>>;
  emailValue: string;
}

const Email: React.FC<valueProps> = ({ emailValue }) => {
  const [email, setEmail] = useState<string>(emailValue);
  const [password, setPassword] = useState<string>("");
  const [content, setContent] = useState("Enter your Password");
  const [errorMsg, setErrorMsg] = useState(false);
  const dispatch = useDispatch();
  const [showPassword, setShowPassword] = useState(false);
  const [open, setOpen] = useState(false);
  const [openPolicy, setOpenPolicy] = useState(false);
  const [openTerms, setOpenTerms] = useState(false);
  const handleOpenTerms = () => setOpenTerms(true);
  const handleCloseTerms = () => setOpenTerms(false);
  const handleOpenPolicy = () => setOpenPolicy(true);
  const handleClosePolicy = () => setOpenPolicy(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const toggleModal = () => {
    setOpen(!open);
    setPassword("");
  };
  const handleClose = () => setOpen(false);
  const Navigate = useNavigate();
  const Loading = useSelector((state: RootState) => state.user.loading);

  const SignIn = async () => {
    dispatch(StartSignIn());
    try {
      const response = await instance.post("/6D/auth/EmailSignIn", {
        email,
        password,
      });
      if (response.status === 200) {
        dispatch(SignInSuccess(response.data.user));
        dispatch(UpdateProfile(`${ImageUrl}${response.data.user.profile}`));
        cookies.set("userId", response.data.user.userId);
        cookies.set("token", response.data.user.token);
        cookies.set("refreshToken", response.data.user.refreshToken);
        const status = cookies.get("modal");
        status === undefined && cookies.set("modal", false);
        const tempPasswordUsed = cookies.get("tempPasswordUsed");
        if (tempPasswordUsed) {
          cookies.remove("tempPasswordUsed");
          Navigate("/landing/settings?tab=password");
        } else {
          Navigate("/landing");
        }
      }
    } catch (error: unknown | any) {
      dispatch(SignInFailed(error));
      if (error.response && error.response.status === 404) {
        setErrorMsg(true);
        setPassword("");
        console.log("Email not found. Please sign up.");
      } else if (error.response.status === 400) {
        setContent("Wrong password. Try Again");
      } else if (error.response.status === 500) {
        setErrorMsg(true);
      }
    }
  };
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      SignIn();
    }
  };

  return (
    <>
      <CustomModal
        open={open}
        handleClose={() => handleClose()}
        child={
          <ForgotPasswordModal
            handleClose={handleClose}
            email={email}
            setOpen={setOpen}
          />
        }
      />
      <Grid item sx={{ minWidth: { xs: "90%", sm: 500 } }}>
        <Typography
          align="center"
          variant="h4"
          sx={{ fontWeight: "700", fontSize: "32px", lineHeight: "43.36px" }}
        >
          {content}
        </Typography>
        <Typography
          align="center"
          sx={{
            fontSize: "12px",
            mt: 1,
            lineHeight: "16.26px",
            fontWeight: "400",
          }}
        >
          Don't have an account?&nbsp;
          <Link
            to={"/signup"}
            style={{
              color: "#0000EE",
              fontWeight: 700,
              fontSize: "12px",
              textDecoration: "none",
            }}
          >
            signup
          </Link>
        </Typography>
        <Card
          elevation={0}
          sx={{
            bgcolor: "#F2F2F2",
            padding: "20px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
            borderRadius: 2,
            mt: 3,
            mb: 7,
          }}
        >
          <Grid
            container
            spacing={2}
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              marginTop: "0px",
            }}
          >
            <Grid item xs={11}>
              <Typography
                align="left"
                sx={{
                  color: "#3F3F40",
                  fontSize: "14px",
                  fontWeight: "600",
                  lineHeight: "18.97px",
                  mb: 1,
                }}
              >
                Email Address*
              </Typography>
              <InputField
                id={"email"}
                label="Email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setErrorMsg(false);
                }}
                icon={MailIcon}
                onKeyDown={handleKeyDown}
                helper={
                  errorMsg === true
                    ? "Entered E-mail Id is not registered !"
                    : null
                }
              />
            </Grid>
            <Grid item xs={11}>
              <Typography
                align="left"
                sx={{
                  color: "#3F3F40",
                  fontSize: "14px",
                  fontWeight: "600",
                  lineHeight: "18.97px",
                  mb: 1,
                }}
              >
                Password*
              </Typography>
              <InputField
                id={"password"}
                label="Password"
                value={password}
                type={showPassword ? "text" : "password"}
                helper={
                  content === "Wrong password. Try Again"
                    ? "The passwords entered do not match. Please try again."
                    : null
                }
                onChange={(e) => {
                  setPassword(e.target.value);
                  password && setContent("Enter Your Password");
                  setErrorMsg(false);
                }}
                icon={showPassword ? VisibilityOff : Visibility}
                iconClick={handleClickShowPassword}
                onKeyDown={handleKeyDown}
              />
            </Grid>
          </Grid>
        </Card>

        <Grid
          sx={{
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
          }}
        >
          <Grid sx={{ display: "flex", justifyContent: "center" }}>
            <CustomButton1
              disabled={!password}
              name="Sign In"
              variant="primary"
              onClick={SignIn}
              loading={Loading}
            />
          </Grid>
          <Link
            to="#"
            onClick={toggleModal}
            style={{
              lineHeight: "18.97px",
              marginTop: "15px",
              color: "#0000EE",
              fontSize: "14px",
              fontWeight: 400,
              textDecoration: "none",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            Forgot Password &nbsp;?
          </Link>
          <Typography
            align="center"
            sx={{
              fontSize: "12px",
              fontWeight: 400,
              lineHeight: "18.97px",
              mt: 2,
              color: "#939393",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            Protected and subject to the &nbsp;
            <Link
              to={"#"}
              onClick={handleOpenPolicy}
              style={{
                color: "#0000EE",
                fontSize: "12px",
                fontWeight: 400,
                lineHeight: "18.97px",
                textDecoration: "none",
              }}
            >
              privacy policy
            </Link>
            &nbsp; and &nbsp;
            <Link
              to={"#"}
              onClick={handleOpenTerms}
              style={{
                color: "#0000EE",
                fontSize: "12px",
                fontWeight: 400,
                lineHeight: "18.97px",
                textDecoration: "none",
              }}
            >
              Terms of Services
            </Link>
          </Typography>
        </Grid>
      </Grid>
    </>
  );
};
export default Email;
