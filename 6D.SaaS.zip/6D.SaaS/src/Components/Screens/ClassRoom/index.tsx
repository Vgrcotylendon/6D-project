import SideBar from "./SideBar";
import React, { useEffect } from "react";
import { Container, Grid, Box, Typography } from "@mui/material";
import styled from "styled-components";
import AccordionBox from "./AccordionBox";

interface topicProps {
  courseDetails: any[];
  setModuleIndex: (value: any) => void;
  GetAssessmentQuestiomDetails: (AID: number) => void;
  GetCourseDetails: () => void;
  setTopicContentDetails: React.Dispatch<React.SetStateAction<any>>;
  GetTopicContentDetails: (cid: number, mid: number, tid: number) => void;
  checked: boolean[];
  setOpen: (value: boolean) => void;
  open: boolean;
  setExpand1: (value: any) => void;
  expand1:any;
  moduleIndex: number;
  topicLength: number;
  topicDetails: any[];
  completedTopic: number;
  nextPage: number;
  selectedCourseTitle: any;
  expanded: any;
  // GetAllcourseDetails: () => void;
  ContinueToLast: () => void;
  selectedTopicIndex: number;
  GetTopicDetails: (moduleId: string) => void;
  GetAssessmentDetails: (moduleId: string) => void;
  setNextPage: React.Dispatch<React.SetStateAction<number>>;
  setNext: React.Dispatch<React.SetStateAction<number>>;
  next: number;
  setChecked: React.Dispatch<React.SetStateAction<boolean[]>>;
  setHide: (value: boolean) => void;
  hide: boolean;
  expandedIndex: any;
  handleChange: (index: number) => void;
  handleAssementDetails: (
    assessment: any,
    idx: number | undefined,
    module: any,
    AID: number,
  ) => void;
  setSelectedTopicDetails: (topic: any) => void;
  setSelectedAssessmentDetails: (assessment: any) => void;
  setQuestionDetails: React.Dispatch<React.SetStateAction<any>>;
  setAssessmentDetails: React.Dispatch<React.SetStateAction<any>>;
  handleTopicDetatils: (
    content: any,
    topic: any,
    idx: number,
    module: any,
    index: number,
    cid: number,
    tid: number,
    mid: number,
  ) => void;
  handleExpansion: (index: number, moduleId: string) => void;
  handleExpansion1: (index: number, moduleId: string) => void;
  selectedTopic: any;
  topicContentDetails: {
    TID: number;
    NAME: string;
    CONTENT: string;
    CONTENT_TYPE: string;
    METADATA: string;
    UT_ID: number;
    PROGRESS: string;
    STATUS: string;
    CID: number;
    MID: number;
  };
  selectedModuleName: any;
  selectedAssessmentDetails: any;
  assessmentDetails: any[];
  selectedTopicContent: any;
  selectedTopicDetails: any;
  selectedAssesment: any;
  selectedFinalAssesment: any;
  QuestionDetails: any[];
  setExpand: (value: boolean) => void;
  setExpanded:(value:any)=> void;
  expand: boolean;
}
const MyClassRoom: React.FC<topicProps> = ({
  setExpand,
  GetCourseDetails,
  setExpanded,
  setExpand1,
  expand1,
  expand,
  topicContentDetails,
  selectedCourseTitle,
  courseDetails,
  // GetAllcourseDetails,
  setSelectedAssessmentDetails,
  nextPage,
  selectedTopicContent,
  setNextPage,
  setQuestionDetails,
  setHide,
  open,
  setModuleIndex,
  GetAssessmentQuestiomDetails,
  setOpen,
  checked,
  topicLength,
  expanded,
  completedTopic,
  selectedTopicIndex,
  GetTopicContentDetails,
  topicDetails,
  ContinueToLast,
  GetTopicDetails,
  GetAssessmentDetails,
  hide,
  selectedTopicDetails,
  selectedAssessmentDetails,
  assessmentDetails,
  setTopicContentDetails,
  setAssessmentDetails,
  selectedModuleName,
  selectedFinalAssesment,
  expandedIndex,
  moduleIndex,
  QuestionDetails,
  handleExpansion,
  handleExpansion1,
  handleChange,
  setSelectedTopicDetails,
  handleAssementDetails,
  handleTopicDetatils,
  selectedTopic,
  setNext,
  next,
  selectedAssesment,
}) => {

  useEffect(() => {
    window.scroll(0, 0);
  }, []);

  return (
    <>
      {" "}
      <CustomBox>
        {courseDetails?.length > 0 ? (
          <>
            <SideBarContainer>
              <SideBar
               nextPage={nextPage}
               GetCourseDetails={GetCourseDetails}
                setExpand={setExpand1}
                expand={expand1}
                expanded={expanded}
                setExpandAll={setExpand}
                expandAll={expand}
                setExpanded={setExpanded}
                open={open}
                QuestionDetails={QuestionDetails}
                setOpen={setOpen}
                selectedCourseTitle={selectedCourseTitle}
                setQuestionDetails={setQuestionDetails}
                handleExpansion1={handleExpansion1}
                topicContentDetails={topicContentDetails}
                handleTopicDetatils={handleTopicDetatils}
                handleAssementDetails={handleAssementDetails}
                GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
                courseDetails={courseDetails}
                checked={checked}
                topicDetails={topicDetails}
                GetTopicDetails={GetTopicDetails}
                GetAssessmentDetails={GetAssessmentDetails}
                assessmentDetails={assessmentDetails}
                handleChange={handleChange}
                setNextPage={setNextPage}
                setHide={setHide}
              />
            </SideBarContainer>
            <MainContent>
              <Container maxWidth="xl">
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    marginTop: "2rem",
                  }}
                >
                  <Grid container spacing={6}>
                    <Grid item xs={12} md={12}>
                      <AccordionBox
                      GetCourseDetails={GetCourseDetails}
                      // GetAllcourseDetails={GetAllcourseDetails}
                        setModuleIndex={setModuleIndex}
                        GetAssessmentQuestiomDetails={
                          GetAssessmentQuestiomDetails
                        }
                        setOpen={setOpen}
                        setExpand={setExpand}
                        expand={expand}
                        setNext={setNext}
                        next={next}
                        setQuestionDetails={setQuestionDetails}
                        GetTopicContentDetails={GetTopicContentDetails}
                        setAssessmentDetails={setAssessmentDetails}
                        setSelectedTopicDetails={setSelectedTopicDetails}
                        GetTopicDetails={GetTopicDetails}
                        setTopicContentDetails={setTopicContentDetails}
                        topicContentDetails={topicContentDetails}
                        moduleIndex={moduleIndex}
                        selectedTopicContent={selectedTopicContent}
                        selectedTopicIndex={selectedTopicIndex}
                        handleTopicDetatils={handleTopicDetatils}
                        QuestionDetails={QuestionDetails}
                        ContinueToLast={ContinueToLast}
                        selectedTopicDetails={selectedTopicDetails}
                        selectedModuleName={selectedModuleName}
                        selectedAssessmentDetails={selectedAssessmentDetails}
                        setSelectedAssessmentDetails={
                          setSelectedAssessmentDetails
                        }
                        handleAssementDetails={handleAssementDetails}
                        handleExpansion={handleExpansion}
                        expandedIndex={expandedIndex}
                        topicDetails={topicDetails}
                        assessmentDetails={assessmentDetails}
                        selectedCourseTitle={selectedCourseTitle}
                        nextPage={nextPage}
                        selectedTopic={selectedTopic}
                        selectedAssesment={selectedAssesment}
                        selectedFinalAssesment={selectedFinalAssesment}
                        courseDetails={courseDetails}
                        checked={checked}
                        hide={hide}
                        setHide={setHide}
                        topicLength={topicLength}
                        completedTopic={completedTopic}
                        setNextPage={setNextPage}
                      />
                    </Grid>
                  </Grid>
                </Box>
              </Container>
            </MainContent>
          </>
        ) : (
          <Typography
            sx={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
           {''}
          </Typography>
        )}
      </CustomBox>
    </>
  );
};

export default MyClassRoom;

const CustomBox = styled(Box)`
  display: flex;
`;

const SideBarContainer = styled.div`
  position: sticky;
  /* top: 100; */
  /* height: 87vh; */
  /* background-color: #F5F5F5; */
  /* flex-shrink: 0; */
`;

const MainContent = styled.div`
  flex-grow: 1;
  background-color: #f5f5f5;
  /* margin-left: 250px; */
  margin-top: 55px;
  padding: 10px;
`;
