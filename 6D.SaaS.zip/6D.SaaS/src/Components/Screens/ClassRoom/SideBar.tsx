import { Box, Card, Collapse, IconButton, Typography } from "@mui/material";
import React from "react";
import clsx from "clsx";
import styled from "styled-components";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import NotStartedIcon from "@mui/icons-material/NotStarted";
import PendingIcon from "@mui/icons-material/Pending";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import MenuIcon from "@mui/icons-material/Menu";
import { useDispatch, useSelector } from "react-redux";
import { getFinalAssessmentAID } from "../../../Store/ClassroomSlice";

interface StateType {
  classRoom: {
    MID: number;
    AID: number;
    value: number;
    enrolledCourse: any;
    topic: any;
    topicIndex: number;
    module: any;
    moduleIndex: number;
    finalAssessment: any;
    finalAssessmentIndex: number;
    finalAssessmentStatus: any;
    topicAssessmentDetails: any;
    finalAssessmentDetailsStatus: any;
  };
}

interface SideBarProps {
  nextPage: number;
  courseDetails: any[];
  checked: boolean[];
  topicDetails: any[];
  assessmentDetails: any[];
  setOpen: (value: boolean) => void;
  setExpanded: (value: any) => void;
  open: boolean;
  selectedCourseTitle: any;
  expanded: any;
  topicContentDetails: {
    TID: number;
    NAME: string;
    CONTENT: string;
    CONTENT_TYPE: string;
    METADATA: string;
    UT_ID: number;
    PROGRESS: string;
    STATUS: string;
    CID: number;
    MID: number;
  };
  setExpandAll: (value: boolean) => void;
  expandAll: boolean;
  setHide: (value: boolean) => void;
  handleTopicDetatils: (
    content: any,
    topic: any,
    idx: number,
    module: any,
    index: number,
    cid: number,
    tid: number,
    mid: number
  ) => void;
  handleAssementDetails: (
    assessment: any,
    idx: number | undefined,
    module: any,
    AID: number
  ) => void;
  QuestionDetails: any[];
  setExpand: (value: any) => void;
  expand: any;
  GetCourseDetails: () => void;
  setQuestionDetails: React.Dispatch<React.SetStateAction<any>>;
  setNextPage: React.Dispatch<React.SetStateAction<number>>;
  GetTopicDetails: (moduleId: string) => void;
  GetAssessmentDetails: (moduleId: string) => void;
  GetAssessmentQuestiomDetails: (AID: number) => void;
  handleExpansion1: (index: number, moduleId: string) => void;
  handleChange: (index: number) => void;
}

const SideBar: React.FC<SideBarProps> = ({
  courseDetails,
  checked,
  nextPage,
  setExpand,
  setExpandAll,
  expand,
  GetCourseDetails,
  setNextPage,
  setExpanded,
  setOpen,
  open,
  selectedCourseTitle,
  setQuestionDetails,
  setHide,
  handleExpansion1,
  expanded,
  topicContentDetails,
  handleTopicDetatils,
  handleAssementDetails,
}) => {
  const dispatch = useDispatch();
  const value = useSelector((state: StateType) => state.classRoom.value);
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse
  );
  const finalStatus = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentDetailsStatus
  );

  const FA_Details = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentStatus
  );
  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);

  const handleChange1 = (index: number) => {
    const newExpanded = [...expand];
    newExpanded[index] = !newExpanded[index];
    setExpand(newExpanded);
    setExpanded(null);
  };

  const handleFinalAssessmentSelection = (AID: number, finalIndex: number) => {
    dispatch(getFinalAssessmentAID(AID));
    setNextPage(3);
    setHide(false);
    const newExpanded = [...expand];
    newExpanded[finalIndex] = false;
    setExpand(newExpanded);
  };

  const sortedModules =
    courseDetails && courseDetails[0]?.Module
      ? [...courseDetails[0].Module].sort(
          (a: any, b: any) => a.ModuleOrder - b.ModuleOrder
        )
      : [];

  const AllAssessmentTopicDetails = useSelector(
    (state: StateType) => state.classRoom.topicAssessmentDetails
  );

  return (
    <>
      <IconButton
        onClick={() => {
          GetCourseDetails();
          setOpen(!open);
          setExpand(
            Array(courseDetails[0]?.FinalAssessment?.length).fill(false)
          );
          setExpanded(null);
          setExpandAll(false);
        }}
        sx={{
          top: 56,
          transform: open ? "translateX(248px)" : "translateX(0)",
          transition: "transform 0.3s ease",
          width: 17,
          height: 17,
          zIndex: 99999999,
          backgroundColor: "#2A62AA",
          color: "#fff",
          position: "absolute",
          borderRadius: 1,
          "&:hover": {
            backgroundColor: "#2A62AA",
            color: "#fff",
          },
        }}
      >
        <MenuIcon sx={{ fontSize: "15px", cursor: "pointer" }} />
      </IconButton>
      <SidebarContainer
        sx={{
          "&::-webkit-scrollbar": {
            width: "15px",
            height: "5px",
          },
          "&::-webkit-scrollbar-track": {
            background: "#2a62aa",
            marginTop: 3.5,
            borderRadius: "5px",
          },
          "&::-webkit-scrollbar-thumb": {
            background: "#2a62aa",
            borderRadius: "5px",
          },
          "&::-webkit-scrollbar-thumb:hover": {
            background: "#466996",
          },
        }}
      >
        <Collapse orientation="horizontal" in={open} collapsedSize={0}>
          <Box sx={{ width: "250px", bgcolor: "white", borderRadius: "5px" }}>
            <Card
              elevation={0}
              className={clsx({
                "sidebar-classroom": true,
              })}
              style={{ backgroundColor: "#2A62AA" }}
            >
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "left",
                  }}
                >
                  <Typography
                    style={{
                      fontWeight: 400,
                      color: "white",
                      fontSize: "12px",
                      cursor:
                        nextPage === 3 ||
                        nextPage === 4 ||
                        nextPage === 5 ||
                        nextPage === 6
                          ? "default"
                          : "pointer",
                    }}
                    onClick={() => {
                      if (
                        nextPage === 3 ||
                        nextPage === 4 ||
                        nextPage === 5 ||
                        nextPage === 6
                      ) {
                        return;
                      }
                      setNextPage(0);
                      setHide(true);
                      GetCourseDetails();
                    }}
                  >
                    {selectedCourseTitle ||
                      rootCourse[0]?.courseDetails?.TITLE ||
                      "No Data Found"}
                  </Typography>
                </Box>
              </Box>
            </Card>
          </Box>
          {sortedModules.map((module: any, moduleIndex: number) => {
            return (
              <Box
                sx={{ width: "250px", bgcolor: "#ffffff" }}
                key={moduleIndex}
              >
                <Card
                  elevation={0}
                  className={clsx({
                    "sidebar-classroom": true,
                    "background-blue":
                      expanded !== moduleIndex && !checked[moduleIndex],
                    "background-white": checked[moduleIndex],
                  })}
                  sx={{
                    backgroundColor:
                      expanded === moduleIndex ? "#E5EDF3" : "none",
                  }}
                  key={moduleIndex}
                >
                  <Box
                    sx={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "left",
                      }}
                    >
                      <Typography
                        className={clsx({
                          "sidebar-module": true,
                          "sidebar-module-black": checked[moduleIndex],
                          "sidebar-module-white":
                            expanded !== moduleIndex && !checked[moduleIndex],
                        })}
                        style={{
                          fontWeight:
                            expanded === moduleIndex ? 600 : "initial",
                        }}
                      >
                        Module {moduleIndex + 1}: {module.NAME || "null"}
                      </Typography>
                      <Typography
                        sx={{
                          display: "flex",
                          justifyContent: "left",
                          alignItems: "center",
                          mt: 1,
                        }}
                        className={clsx({
                          "sidebar-module": true,
                          "sidebar-module-black": checked[moduleIndex],
                          "sidebar-module-white":
                            expanded !== moduleIndex && !checked[moduleIndex],
                        })}
                      >
                        <AccessTimeIcon
                          sx={{
                            fontSize: "15px",
                            color: checked[moduleIndex] ? "#999ea5" : "#CAD8EA",
                          }}
                        />
                        &nbsp;
                        {module.DURATION &&
                                module.DURATION.includes("NaN")
                                  ? "0 hrs 0 min"
                                  : module.DURATION || "null"}
                      </Typography>
                    </Box>
                    <Box>
                      <IconButton
                        className="sidebar-downArrrow"
                        onClick={() => {
                          // GetCourseDetails();
                          handleExpansion1(moduleIndex, module.MID);
                        }}
                      >
                        <KeyboardArrowDownIcon
                          sx={{
                            fontSize: "25px",
                            color:
                              expanded === moduleIndex ? "#919599" : "#CAD8EA",
                            transform:
                              expanded === moduleIndex
                                ? "rotate(180deg)"
                                : "none",
                            transition: "transform 0.3s ease",
                          }}
                        />
                      </IconButton>
                    </Box>
                  </Box>
                  <Collapse
                    in={expanded === moduleIndex}
                    collapsedSize={0}
                    sx={{
                      backgroundColor: checked[moduleIndex] ? "#E5EDF3" : "fff",
                    }}
                  >
                    <Box
                      sx={{
                        backgroundColor: checked[moduleIndex]
                          ? "#E5EDF3"
                          : "fff",
                      }}
                    >
                      {AllAssessmentTopicDetails?.map(
                        (topic: any, topicIndex: number) => (
                          <>
                            {topic.TID && (
                              <React.Fragment key={topicIndex}>
                                <Box
                                  sx={{
                                    backgroundColor: "#d1d1d1",
                                    height: "0.3px",
                                    marginBottom: "8px",
                                    marginTop: "10px",
                                  }}
                                />
                                <Typography
                                  className={clsx({
                                    "sidebar-module": true,
                                    "sidebar-module-black":
                                      checked[moduleIndex],
                                    "sidebar-module-white":
                                      expanded !== moduleIndex &&
                                      !checked[moduleIndex],
                                  })}
                                  sx={{
                                    cursor:
                                      moduleIndex === 0
                                        ? "pointer"
                                        : moduleIndex !== 0 &&
                                          courseDetails[0]?.Module[
                                            moduleIndex - 1
                                          ]?.STATUS === "COMPLETED"
                                        ? "pointer"
                                        : "default",
                                  }}
                                  onClick={() => {
                                    if (
                                      moduleIndex !== 0 &&
                                      courseDetails[0]?.Module[moduleIndex - 1]
                                        ?.STATUS === "COMPLETED"
                                    ) {
                                    
                                      setQuestionDetails([]);
                                      handleTopicDetatils(
                                        topicContentDetails,
                                        topic,
                                        topicIndex,
                                        module,
                                        moduleIndex,
                                        courseDetails[0]?.CID,
                                        module.MID,
                                        topic.TID
                                      );
                                      setOpen(false);
                                    } else if (moduleIndex === 0) {
                                      setQuestionDetails([]);
                                      handleTopicDetatils(
                                        topicContentDetails,
                                        topic,
                                        topicIndex,
                                        module,
                                        moduleIndex,
                                        courseDetails[0]?.CID,
                                        module.MID,
                                        topic.TID
                                      );
                                      setOpen(false);
                                    }
                                  }}
                                >
                                  {moduleIndex + 1}.{topicIndex + 1}&nbsp;
                                  {topic.NAME || "null"}
                                </Typography>
                                <Typography
                                  sx={{
                                    display: "flex",
                                    justifyContent: "left",
                                    alignItems: "center",
                                    mt: 1,
                                  }}
                                  className={clsx({
                                    "sidebar-module": true,
                                    "sidebar-module-black":
                                      checked[moduleIndex],
                                    "sidebar-module-white":
                                      expanded !== moduleIndex &&
                                      !checked[moduleIndex],
                                  })}
                                >
                                  {topic.STATUS === "COMPLETED" ? (
                                    <CheckCircleIcon
                                      style={{
                                        color: "green",
                                        marginRight: "5px",
                                      }}
                                    />
                                  ) : topic.STATUS === "Not Started" ? (
                                    <NotStartedIcon
                                      style={{
                                        fontSize: "15px",
                                        color: "#656566",
                                        marginRight: "5px",
                                        marginBottom: "2px",
                                      }}
                                    />
                                  ) : (
                                    <PendingIcon
                                      style={{
                                        color: "#EF5C00",
                                        fontSize: "15px",
                                      }}
                                    />
                                  )}
                                  &nbsp;{" "}
                                  {topic.STATUS === "COMPLETED"
                                    ? "Complete"
                                    : topic.STATUS || "Pending"}
                                </Typography>
                              </React.Fragment>
                            )}
                            {topic.AID && (
                              <React.Fragment key={topicIndex}>
                                <Box
                                  sx={{
                                    backgroundColor: "#d1d1d1",
                                    height: "0.3px",
                                    marginBottom: "8px",
                                    marginTop: "10px",
                                  }}
                                />
                                <Typography
                                  className={clsx({
                                    "sidebar-module": true,
                                    "sidebar-module-black":
                                      checked[moduleIndex],
                                    "sidebar-module-white":
                                      expanded !== moduleIndex &&
                                      !checked[moduleIndex],
                                  })}
                                  sx={{
                                    cursor:
                                      moduleIndex === 0
                                        ? "pointer"
                                        : moduleIndex !== 0 &&
                                          courseDetails[0]?.Module[
                                            moduleIndex - 1
                                          ]?.STATUS === "COMPLETED"
                                        ? "pointer"
                                        : "default",
                                  }}
                                  onClick={() => {
                                    if (
                                      moduleIndex !== 0 &&
                                      courseDetails[0]?.Module[moduleIndex - 1]
                                        ?.STATUS === "COMPLETED"
                                    ) {
                                      handleAssementDetails(
                                        topic,
                                        topicIndex,
                                        module,
                                        topic.AID
                                      );
                                      setOpen(false);
                                    } else if (moduleIndex === 0) {
                                      handleAssementDetails(
                                        topic,
                                        topicIndex,
                                        module,
                                        topic.AID
                                      );
                                      setOpen(false);
                                    }
                                  }}
                                >
                                  {topic?.NAME ? topic?.NAME : null}
                                </Typography>
                              </React.Fragment>
                            )}
                          </>
                        )
                      )}
                    </Box>
                  </Collapse>
                </Card>
              </Box>
            );
          })}
        </Collapse>
        {courseDetails[0].FinalAssessment?.length > 0 && (
          <>
            <Collapse orientation="horizontal" in={open} collapsedSize={0}>
              {courseDetails[0]?.FinalAssessment?.map(
                (finalAsses: any, finalIndex: number) => (
                  <Box
                    sx={{ width: "250px", bgcolor: "#ffffff" }}
                    key={finalIndex}
                  >
                    <Card
                      elevation={0}
                      className={clsx({
                        "sidebar-classroom": true,
                        "background-blue": !expand[finalIndex],
                        "background-white": expand[finalIndex],
                      })}
                    >
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: "row",
                            justifyContent: "space-between",
                            alignItems: "center",
                          }}
                        >
                          <Typography
                            className={clsx({
                              "sidebar-module": true,
                              "sidebar-module-black": expand[finalIndex],
                              "sidebar-module-white": !expand[finalIndex],
                            })}
                          >
                            Final Assessment
                          </Typography>
                        </Box>
                        <Box>
                          <IconButton
                            className="sidebar-downArrrow"
                            onClick={() => handleChange1(finalIndex)}
                          >
                            <KeyboardArrowDownIcon
                              sx={{
                                fontSize: "25px",
                                color: expand[finalIndex]
                                  ? "#919599"
                                  : "#CAD8EA",
                                transform: expand[finalIndex]
                                  ? "rotate(180deg)"
                                  : "none",
                                transition: "transform 0.3s ease",
                              }}
                            />
                          </IconButton>
                        </Box>
                      </Box>
                      <Collapse in={expand[finalIndex]} collapsedSize={0}>
                        <Box>
                          <React.Fragment key={finalIndex}>
                            <Box
                              sx={{
                                backgroundColor: "#d1d1d1",
                                height: "0.3px",
                                marginBottom: "8px",
                                marginTop: "10px",
                              }}
                            />
                            <Typography
                              sx={{
                                display: "flex",
                                justifyContent: "left",
                                alignItems: "center",
                                mt: 0.5,
                                cursor:
                                  FA_Details?.every(
                                    (module: any) =>
                                      module.STATUS === "COMPLETED"
                                  ) && finalStatus.Status !== "COMPLETED"
                                    ? "pointer"
                                    : "default",
                              }}
                              className={clsx({
                                "sidebar-module": true,
                                "sidebar-module-black": expand[finalIndex],
                                "sidebar-module-white": !expand[finalIndex],
                              })}
                              onClick={() =>
                                FA_Details?.every(
                                  (module: any) => module.STATUS === "COMPLETED"
                                ) &&
                                finalStatus.Status !== "COMPLETED" &&
                                handleFinalAssessmentSelection(
                                  finalAsses?.AID,
                                  finalIndex
                                )
                              }
                            >
                              {finalAsses?.NAME ? finalAsses?.NAME : null}
                            </Typography>
                          </React.Fragment>
                        </Box>
                      </Collapse>
                    </Card>
                  </Box>
                )
              )}
            </Collapse>
          </>
        )}
      </SidebarContainer>
    </>
  );
};

export default SideBar;

const SidebarContainer = styled(Box)`
  height: 100vh;
  margin-top: 50px;
  overflow-y: scroll;
  position: sticky;
  top: 0;
`;
