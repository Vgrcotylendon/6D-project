import React, { FC } from "react";
import { Box, Typography, IconButton, Collapse } from "@mui/material";
import styled from "styled-components";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import PendingIcon from "@mui/icons-material/Pending";
import NotStartedIcon from "@mui/icons-material/NotStarted";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import CricleIcon from "../../../Assets/pendingIcon.png";
import Welcome from "./Screens/Welcome";
import FinalAssessment from "./FinalAssessment";
import Assessment from "./Screens/Assessment";
import FinalAssessmentQuestion from "./Screens/FinalAssessment/FinalAssessmentQuestion";
import FinalQuestions from "./Screens/FinalAssessment/FinalQuestions";
import SubmitAssessment from "./Screens/FinalAssessment/SubmitAssessment";
import AttemptAssessment from "./Screens/FinalAssessment/AttemptAssessment";
import { useDispatch, useSelector } from "react-redux";
import ClockIcon from "../../../Assets/pace@2x.png"
import {
  getFinalAssessmentAID,
  getFinalAssessmentDetails
} from "../../../Store/ClassroomSlice";
import { cookies, instance } from "../../../Controller/Common";
import { RootState } from "../../../Store/UserSlice";
import CustomModal from "../../Modal/CustomModal";
import TopicAlertModal from "./TopicAlertModal";

interface StateType {
  classRoom: {
    MID: number;
    AID: number;
    value: number;
    AccordionTask: any;
    allCourseDetails: any;
    topicId: any;
    moduleId: any;
    assessmentId: any;
    topicAssessmentDetails: any;
    TopicOrder: any;
    ModuleOrder: any;
    finalAssessmentDetailsStatus: any;
  };
}

interface ModuleAccordionProps {
  courseDetails: any[];
  topicDetails: any[];
  assessmentDetails: any[];
  selectedTopicIndex: number;
  hide: boolean;
  GetTopicDetails: (moduleId: string) => void;
  setSelectedTopicDetails: (topic: any) => void;
  setTopicContentDetails: React.Dispatch<React.SetStateAction<any>>;
  setQuestionDetails: React.Dispatch<React.SetStateAction<any>>;
  setAssessmentDetails: React.Dispatch<React.SetStateAction<any>>;
  GetTopicContentDetails: (cid: number, mid: number, tid: number) => void;
  setModuleIndex: (value: any) => void;
  GetAssessmentQuestiomDetails: (AID: number) => void;
  expandedIndex: any;
  selectedModuleName: any;
  moduleIndex: number;
  selectedTopicContent: any;
  QuestionDetails: any[];
  topicContentDetails: {
    TID: number;
    NAME: string;
    CONTENT: string;
    CONTENT_TYPE: string;
    METADATA: string;
    UT_ID: number;
    PROGRESS: string;
    STATUS: string;
    CID: number;
    MID: number;
  };
  selectedTopicDetails: any;
  selectedAssessmentDetails: any;
  setHide: (value: boolean) => void;
  setOpen: (value: boolean) => void;
  // GetAllcourseDetails: () => void;
  GetCourseDetails: () => void;
  setSelectedAssessmentDetails: (assessment: any) => void;
  handleTopicDetatils: (
    content: any,
    topic: any,
    idx: number,
    module: any,
    index: number,
    cid: number,
    tid: number,
    mid: number
  ) => void;
  handleAssementDetails: (
    assessment: any,
    idx: number | undefined,
    module: any,
    AID: number
  ) => void;
  handleExpansion: (index: number, moduleId: string) => void;
  nextPage: number;
  selectedTopic: any;
  selectedAssesment: any;
  selectedFinalAssesment: any;
  setNext: React.Dispatch<React.SetStateAction<number>>;
  setNextPage: React.Dispatch<React.SetStateAction<number>>;
  setExpand: (value: boolean) => void;
  expand: boolean;
}

const ModuleAccordion: FC<ModuleAccordionProps> = ({
  assessmentDetails,
  topicContentDetails,
  setQuestionDetails,
  courseDetails,
  // GetAllcourseDetails,
  setSelectedTopicDetails,
  setModuleIndex,
  GetAssessmentQuestiomDetails,
  moduleIndex,
  hide,
  GetCourseDetails,
  setOpen,
  expandedIndex,
  setAssessmentDetails,
  handleExpansion,
  handleTopicDetatils,
  handleAssementDetails,
  GetTopicDetails,
  selectedModuleName,
  selectedTopicIndex,
  selectedTopicContent,
  setTopicContentDetails,
  QuestionDetails,
  selectedTopicDetails,
  selectedAssessmentDetails,
  setSelectedAssessmentDetails,
  GetTopicContentDetails,
  nextPage,
  setHide,
  setNext,
  setNextPage,
  expand,
}) => {
  const dispatch = useDispatch();
  const [show, setShow] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [questionLength, setQuestionLength] = React.useState<number>(0);
  const [finalQuestionDetails, setFinalQuestionDetails] = React.useState<any[]>(
    []
  );
  const [isDisabledCheckAndRadio, setIsDisabledCheckAndRadio] =
    React.useState(false);
  const AllAssessmentTopicDetails = useSelector(
    (state: StateType) => state.classRoom.topicAssessmentDetails
  );
  const handleClose = () => {
    setShow(false);
  };

  const userId =
    useSelector((state: RootState) => state.user.userID) ??
    cookies.get("userId");
  const courseDetailsModuleOrder = useSelector(
    (state: StateType) => state.classRoom.ModuleOrder
  );
  const courseDetailsTopicOrder = useSelector(
    (state: StateType) => state.classRoom.TopicOrder
  );
  const courseDetailsMID = useSelector(
    (state: StateType) => state.classRoom.moduleId
  );
  const [displayTime, setDisplayTime] = React.useState("00:00:00");
  const sortedModules =
    courseDetails && courseDetails[0]?.Module
      ? [...courseDetails[0].Module].sort(
          (a: any, b: any) => a.ModuleOrder - b.ModuleOrder
        )
      : [];
  const getTaskCompletion = (moduleId: number) => {
    const taskDetail = courseDetails[0]?.TaskDetails?.find(
      (task: any) => task.mid === moduleId
    );
    return taskDetail
      ? {
          completed: taskDetail.noOfCompletedTasks,
          total: taskDetail.noOfTasks,
        }
      : { completed: 0, total: 0 };
  };

  const handleNextButton = async () => {
    setLoading(true);
    try {
      // const response = await instance.get(
      //   `/6D/map/new-nextTask?CID=${
      //     courseDetails[0]?.CID
      //   }&UID=${userId}&MID=${courseDetailsMID}&TopicOrder=${
      //     order.topic || courseDetailsTopicOrder
      //   }&ModuleOrder=${order.module || courseDetailsModuleOrder}`
      // );
      const response = await instance.get(
        `/6D/map/new-nextTask?CID=${courseDetails[0]?.CID}&UID=${userId}&MID=${courseDetailsMID}&TopicOrder=${courseDetailsTopicOrder}&ModuleOrder=${courseDetailsModuleOrder}`
      );
      if (response.status === 200) {
        let data = response.data[0];
        // setOrder({ topic: data.TopicOrder, module: data.ModuleOrder });
        if (data.type === "Topic") {
          await GetTopicContentDetails(data.CID, data.MID, data.TID);
          setQuestionLength(0);
          setNextPage(1);
        } else if (data.type === "Assessment") {
          setIsDisabledCheckAndRadio(false);
          await GetAssessmentQuestiomDetails(data.AID);
          setQuestionLength(0);
          setNextPage(2);
          // if (finalStatus.status === "COMPLETED") {
          //   setHide(true);
          //   setNextPage(0);
          // } else {
          //   setNextPage(2);
          // }
        } else if (data.type === "Final Assessment") {
          dispatch(getFinalAssessmentDetails(data));
          dispatch(getFinalAssessmentAID(data.AID));
          setQuestionLength(0);
          setNextPage(3);
        }
      }
      // GetAllcourseDetails();
    } catch (error: any) {
      if (
        error?.response?.status === 500 &&
        error?.response?.data?.message ===
          "Complete all the tasks in the current module to move to the next module."
      ) {
        setShow(true);
      }
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <CustomModal
        open={show}
        handleClose={handleClose}
        sx={{ height: "auto", mt: 5 }}
        child={<TopicAlertModal setShow={setShow} />}
      />
      {nextPage === 0 && (
        <>
          <Box sx={{ marginBottom: "20px" }}>
            <>
              {sortedModules.map((module: any, index: number) => {
                const taskCompletion = getTaskCompletion(module.MID);

                return (
                  <MainBox
                    key={index}
                    sx={{
                      backgroundColor:
                        module.STATUS === "InProgress" ? "#E5EDF3" : "#F5F5F5",
                    }}
                  >
                    <TitleBox>
                      <Box sx={{ width: "70%" }}>
                        <Typography
                          sx={{
                            fontSize: "14px",
                            fontWeight: 600,
                            color: "#3F3F40",
                            whiteSpace: "nowrap",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                          }}
                        >
                          Module {module.moduleNo || index + 1}:&nbsp;
                          {module.NAME || "null"}
                        </Typography>
                      </Box>
                      <ViewBox>
                        <TextBox>
                          <TimeBox>
                            <AccessTimeIcon
                              style={{ fontSize: "30px", color: "#656566" }}
                            />
                            &nbsp;&nbsp;
                            <Box>
                              <Typography
                                sx={{
                                  fontSize: "12px",
                                  fontWeight: 500,
                                  color: "#656566",
                                  width: "100px"
                                }}
                              >
                                Estimated Time
                              </Typography>
                              <Typography
                                sx={{
                                  fontSize: "10px",
                                  fontWeight: 400,
                                  color: "#656566",
                                }}
                              >
                                {module.DURATION &&
                                module.DURATION.includes("NaN")
                                  ? "0 hrs 0 min"
                                  : module.DURATION || "null"}
                              </Typography>
                            </Box>
                          </TimeBox>
                          <StatusBox>
                            {module.STATUS === "InProgress" ? (
                              <PendingIcon
                                style={{ color: "#EF5C00", fontSize: "30px" }}
                              />
                            ) : module.STATUS === "Not Started" ? (
                              <NotStartedIcon
                                style={{ fontSize: "30px", color: "#656566" }}
                              />
                            ) : (
                              <CheckCircleIcon
                                style={{ color: "green", fontSize: "30px" }}
                              />
                            )}
                            &nbsp;&nbsp;
                            <Box>
                              <Typography
                                sx={{
                                  fontSize: "12px",
                                  fontWeight: 500,
                                  color: "#656566",
                                }}
                              >
                                {module.STATUS === "COMPLETED"
                                  ? "Complete"
                                  : module.STATUS || "null"}
                              </Typography>
                              <Typography
                                key={index}
                                sx={{
                                  fontSize: "10px",
                                  fontWeight: 400,
                                  color: "#656566",
                                   width: "130px"
                                }}
                              >
                                {taskCompletion.completed} of{" "}
                                {taskCompletion.total} tasks completed
                              </Typography>
                            </Box>
                          </StatusBox>
                        </TextBox>
                        <Box sx={{ marginLeft: "20px" }}>
                          <IconButton
                            sx={{ cursor: "pointer" }}
                            onClick={() => handleExpansion(index, module.MID)}
                          >
                            <KeyboardArrowDownIcon
                              sx={{
                                fontSize: "30px",
                                color:
                                  expand || expandedIndex === index
                                    ? "#919599"
                                    : "#929396",
                                transform:
                                  expand || expandedIndex === index
                                    ? "rotate(180deg)"
                                    : "none",
                                transition: "transform 0.2s ease",
                                cursor: "pointer",
                              }}
                            />
                          </IconButton>
                        </Box>
                      </ViewBox>
                    </TitleBox>
                    <>
                      <Collapse
                        in={expand || expandedIndex === index}
                        collapsedSize={0}
                      >
                        {(expand === true
                          ? AllAssessmentTopicDetails.filter(
                              (i: any) => i.MID === module.MID
                            )
                          : AllAssessmentTopicDetails
                        )?.map((topic: any, idx: number) => (
                          <>
                            {topic.TID && (
                              <Main2Box
                                key={idx}
                                sx={{
                                  backgroundColor:
                                    module.STATUS === "InProgress"
                                      ? "#E5EDF3"
                                      : "#F5F5F5",
                                }}
                              >
                                <Box sx={{ width: "70%" }}>
                                  <Typography
                                    sx={{
                                      color: "#2a62aa",
                                      fontSize:"14px",
                                      cursor:
                                        index === 0
                                          ? "pointer"
                                          : index !== 0 &&
                                            courseDetails[0]?.Module[index - 1]
                                              ?.STATUS === "COMPLETED"
                                          ? "pointer"
                                          : "default",
                                    }}
                                    onClick={() => {
                                      if (
                                        index !== 0 &&
                                        courseDetails[0]?.Module[index - 1]
                                          ?.STATUS === "COMPLETED"
                                      ) {
                                        handleTopicDetatils(
                                          topicContentDetails,
                                          topic,
                                          idx,
                                          module,
                                          index,
                                          courseDetails[0]?.CID,
                                          module.MID,
                                          topic.TID
                                        );
                                      } else if (index === 0) {
                                        handleTopicDetatils(
                                          topicContentDetails,
                                          topic,
                                          idx,
                                          module,
                                          index,
                                          courseDetails[0]?.CID,
                                          module.MID,
                                          topic.TID
                                        );
                                      }
                                    }}
                                  >
                                    {topic.NAME || null}
                                  </Typography>
                                </Box>
                                <Box2>
                                  <Box
                                    sx={{
                                      display: "flex",
                                      flexDirection: "row",
                                      alignItems: "center",
                                      justifyContent: "center",
                                      marginRight: "35px",
                                    }}
                                  >
                                    <img src={ClockIcon}
                                      style={{ marginRight: "5px" , width: "16px",  height: "16px"}}
                                    />
                                    <Typography
                                      sx={{
                                        fontSize: "10px",
                                        fontWeight: 400,
                                        color: "#656566",
                                      }}
                                    >
                                      {topic.DURATION}&nbsp;minutes
                                    </Typography>
                                  </Box>
                                  <Box3>
                                    {topic.STATUS === "COMPLETED" ? (
                                      <CheckCircleIcon
                                        style={{
                                          color: "green",
                                          marginRight: "5px",
                                        }}
                                      />
                                    ) : topic.STATUS === "Not Started" ? (
                                      <img
                                        src={CricleIcon}
                                        alt="icon"
                                        style={{
                                          color: "#5a5b5c",
                                          marginRight: "5px",
                                        }}
                                      />
                                    ) : (
                                      <PendingIcon
                                        style={{
                                          color: "#EF5C00",
                                          marginRight: "5px",
                                          fontSize: "18px",
                                        }}
                                      />
                                    )}
                                    &nbsp;&nbsp;
                                    <Typography
                                      sx={{
                                        fontSize: "10px",
                                        fontWeight: 400,
                                        color:
                                          topic.STATUS === "COMPLETED"
                                            ? "green"
                                            : topic.STATUS === "InProgress"
                                            ? "#EF5C00"
                                            : "#656566",
                                      }}
                                    >
                                      {topic.STATUS === "COMPLETED"
                                        ? "Complete"
                                        : topic.STATUS || "Pending"}
                                    </Typography>
                                  </Box3>
                                </Box2>
                              </Main2Box>
                            )}

                            {topic.AID && (
                              <Main2Box
                                sx={{
                                  backgroundColor:
                                    module.STATUS === "InProgress"
                                      ? "#E5EDF3"
                                      : "#F5F5F5",
                                }}
                                key={idx}
                              >
                                <Box1>
                                  <Typography
                                    sx={{
                                      color: "#2a62aa",
                                      fontSize:"14px",
                                      cursor:
                                        index === 0
                                          ? "pointer"
                                          : index !== 0 &&
                                            courseDetails[0]?.Module[index - 1]
                                              ?.STATUS === "COMPLETED"
                                          ? "pointer"
                                          : "default",
                                    }}
                                    onClick={() => {
                                      if (
                                        index !== 0 &&
                                        courseDetails[0]?.Module[index - 1]
                                          ?.STATUS === "COMPLETED"
                                      ) {
                                        handleAssementDetails(
                                          topic,
                                          idx,
                                          module,
                                          topic.AID
                                        );
                                      } else if (index === 0) {
                                        handleAssementDetails(
                                          topic,
                                          idx,
                                          module,
                                          topic.AID
                                        );
                                      }
                                    }}
                                  >
                                    {topic?.NAME ? topic?.NAME : null}
                                  </Typography>
                                </Box1>
                              </Main2Box>
                            )}
                          </>
                        ))}
                      </Collapse>
                    </>
                  </MainBox>
                );
              })}
              <>
                {courseDetails[0]?.FinalAssessment?.map(
                  (assessment: any, index: number) => (
                    <FinalAssessment
                      GetAssessmentQuestiomDetails={
                        GetAssessmentQuestiomDetails
                      }
                      key={index}
                      QuestionDetails={
                        finalQuestionDetails ||
                        (QuestionDetails[0]?.assessmentType ===
                          "Final Assessment" &&
                          QuestionDetails)
                      }
                      expand={expand}
                      assessment={assessment}
                      index={index}
                      courseDetails={courseDetails}
                      hide={hide}
                      handleExpansion={handleExpansion}
                      nextPage={nextPage}
                      selectedTopic={"selectedTopic"}
                      setHide={setHide}
                      setNext={setNext}
                      setNextPage={setNextPage}
                    />
                  )
                )}
              </>
            </>
          </Box>
        </>
      )}

      {nextPage === 1 && (
        <Welcome
          setOpen={setOpen}
          loading={loading}
          GetCourseDetails={GetCourseDetails}
          courseDetails={courseDetails}
          // GetAllcourseDetails={GetAllcourseDetails}
          setIsDisabledCheckAndRadio={setIsDisabledCheckAndRadio}
          isDisabledCheckAndRadio={isDisabledCheckAndRadio}
          setModuleIndex={setModuleIndex}
          show={show}
          setShow={setShow}
          handleNextButton={handleNextButton}
          GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
          nextPage={nextPage}
          setQuestionDetails={setQuestionDetails}
          setNext={setNext}
          setHide={setHide}
          setQuestionLength={setQuestionLength}
          questionLength={questionLength}
          selectedAssessmentDetails={selectedAssessmentDetails}
          setSelectedAssessmentDetails={setSelectedAssessmentDetails}
          QuestionDetails={QuestionDetails}
          setNextPage={setNextPage}
          GetTopicContentDetails={GetTopicContentDetails}
          GetTopicDetails={GetTopicDetails}
          setAssessmentDetails={setAssessmentDetails}
          assessmentDetails={assessmentDetails}
          setSelectedTopicDetails={setSelectedTopicDetails}
          setTopicContentDetails={setTopicContentDetails}
          topicContentDetails={topicContentDetails}
          selectedModuleIndex={moduleIndex}
          selectedTopicIndex={selectedTopicIndex}
          selectedTopicDetails={selectedTopicDetails}
          selectedModuleName={selectedModuleName}
          selectedTopicContent={selectedTopicContent}
        />
      )}
      {nextPage === 2 &&
        QuestionDetails &&
        QuestionDetails[0]?.assessmentType !== "Final Assessment" && (
          <Assessment
            setOpen={setOpen}
            GetCourseDetails={GetCourseDetails}
            setIsDisabledCheckAndRadio={setIsDisabledCheckAndRadio}
            isDisabledCheckAndRadio={isDisabledCheckAndRadio}
            setShow={setShow}
            handleNextButton={handleNextButton}
            GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
            fromWelcomepage={false}
            nextPage={nextPage}
            topicContentDetails={topicContentDetails}
            setTopicContentDetails={setTopicContentDetails}
            setNext={setNext}
            setHide={setHide}
            setQuestionLength={setQuestionLength}
            questionLength={questionLength}
            selectedModuleName={selectedModuleName}
            setQuestionDetails={setQuestionDetails}
            selectedAssessmentDetails={selectedAssessmentDetails}
            assessmentQuestionDetails={QuestionDetails}
            setNextPage={setNextPage}
            // GetAllcourseDetails={GetAllcourseDetails}
          />
        )}
      {nextPage === 3 && (
        <FinalAssessmentQuestion
          GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
          setNext={setNext}
          nextPage={nextPage}
          QuestionDetails={
            finalQuestionDetails ||
            (QuestionDetails[0]?.assessmentType === "Final Assessment" &&
              QuestionDetails)
          }
          courseDetails={courseDetails}
          setHide={setHide}
          setNextPage={setNextPage}
        />
      )}
      {nextPage === 4 && (
        <FinalQuestions
          setNext={setNext}
          GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
          setHide={setHide}
          questionLength={questionLength}
          courseDetails={courseDetails}
          setQuestionLength={setQuestionLength}
          selectedAssessmentDetails={selectedAssessmentDetails}
          selectedModuleName={selectedModuleName}
          setNextPage={setNextPage}
          displayTime={displayTime}
          setDisplayTime={setDisplayTime}
          nextPage={nextPage}
        />
      )}
      {nextPage === 5 && (
        <SubmitAssessment
          questionLength={questionLength}
          GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
          setQuestionLength={setQuestionLength}
          setNext={setNext}
          setHide={setHide}
          displayTime={displayTime}
          setDisplayTime={setDisplayTime}
          setNextPage={setNextPage}
          nextPage={nextPage}
        />
      )}
      {nextPage === 6 && (
        <AttemptAssessment
          setNext={setNext}
          setQuestionLength={setQuestionLength}
          setHide={setHide}
          setNextPage={setNextPage}
          nextPage={nextPage}
        />
      )}
    </div>
  );
};

export default ModuleAccordion;

const MainBox = styled(Box)`
  box-shadow: none !important;
  display: flex;
  background-color: #f5f5f5;
  padding: 15px 10px 15px 10px;
  border-bottom: 1px solid #f1eeee;
  flex-direction: column;
`;
const TitleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: 0px 0px 0px 10px;
`;
const TextBox = styled(Box)`
  display: flex;
  flex-direction: row;
`;
const StatusBox = styled(Box)`
  display: flex;
  flex-direction: row;
  margin-left: 20px;
  align-items: center;
`;
const TimeBox = styled(Box)`
  display: flex;
  align-items: center;
`;
const Main2Box = styled(Box)`
  padding: 10px 20px 10px 20px;
  margin-top: 10px;
  display: flex;
  border-radius: 2px;
  background-color: #f5f5f5;
  flex-direction: row;
  border-bottom: 1px solid #f1eeee;
  justify-content: space-between;
  align-items: center;
`;
const Box1 = styled(Box)`
  display: flex;
  flex-direction: row;
`;
const Box2 = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
  /* width: 33%; */
  padding: 0px 125px 0px 0px;
`;
const Box3 = styled(Box)`
  display: flex;
  flex-direction: row;
  margin-left: 2rem;
  align-items: center;
  justify-content: center;
`;
const ViewBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;
