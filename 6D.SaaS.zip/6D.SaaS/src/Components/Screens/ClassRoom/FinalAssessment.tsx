import React, { FC, useState } from "react";
import { Box, Typography, IconButton, Collapse } from "@mui/material";
import styled from "styled-components";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import FinalAssessmentQuestion from "./Screens/FinalAssessment/FinalAssessmentQuestion";
import { useDispatch, useSelector } from "react-redux";
import { getFinalAssessmentAID } from "../../../Store/ClassroomSlice";

interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
    finalAssessment: any;
    finalAssessmentIndex: number;
    finalAssessmentStatus: any;
    finalAssessmentQuestionDetails: any;
    finalAssessmentAttempt: any;
    finalAssessmentDetailsStatus:any;
  };
}

interface ModuleAccordionProps {
  courseDetails?: any[];
  QuestionDetails: any[];
  hide?: boolean;
  GetAssessmentQuestiomDetails: (AID: number) => void;
  setHide: (value: boolean) => void;
  nextPage?: number;
  selectedTopic?: any;
  handleExpansion?: (index: number, moduleId: string) => void;
  setNext?: React.Dispatch<React.SetStateAction<number>>;
  setNextPage: React.Dispatch<React.SetStateAction<number>>;
  assessment?: any;
  index: number;
  expand?: boolean;
}

const FinalAssessment: FC<ModuleAccordionProps> = ({
  assessment,
  QuestionDetails,
  courseDetails,
  GetAssessmentQuestiomDetails,
  nextPage,
  expand,
  index,
  setHide,
  setNext,
  setNextPage,
}) => {
  const [expanded, setExpanded] = useState<boolean[]>(
    new Array(courseDetails?.length).fill(false)
  );

  const [finalAID, setFinalAID] = useState<number>();

  const FA_Details = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentStatus
  );
  const finalStatus = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentDetailsStatus
  );

  const handleAssementQuestionDetails = (AID: number) => {
    setNextPage(3);
    setHide(false);
    setFinalAID(AID);
  };
  const dispatch = useDispatch();

  const handleExpansion1 = (index: number) => {
    const newExpanded = [...expanded];
    newExpanded[index] = !newExpanded[index];
    setExpanded(newExpanded);
  };

  return (
    <div>
      <>
        <MainCard key={index}>
          <TitleBox>
            <Box sx={{ display: "flex", width: "70%" }}>
              <Typography
                sx={{
                  fontSize: "14px",
                  fontWeight: 600,
                  color: "#3F3F40",
                }}
              >
                Final Assesment
              </Typography>
            </Box>
            <Box>
              <IconButton onClick={() => handleExpansion1(index)}>
                <KeyboardArrowDownIcon
                  sx={{
                    fontSize: "30px",
                    color: expand || expanded[index] ? "#919599" : "#929396",
                    transform:
                      expand || expanded[index] ? "rotate(180deg)" : "none",
                    transition: "transform 0.2s ease",
                    cursor:"pointer"
                  }}
                />
              </IconButton>
            </Box>
          </TitleBox>
          <>
            <Collapse in={expand || expanded[index]} collapsedSize={0}>
              <Main2Box key={index}>
                <Box1>
                  <Typography
                    sx={{
                      color: "#2a62aa",
                      fontSize:"14px",
                      cursor:
                        FA_Details?.every(
                          (module: any) => module.STATUS === "COMPLETED"
                        ) && finalStatus.Status !== "COMPLETED"? "pointer"
                          : "default",
                    }}
                    onClick={() => {
                      // FA_Details?.every(
                      //   (module: any) => module.STATUS === "COMPLETED"
                      // ) ||
                      //   finalAttempts?.some(
                      //     (attempt: any) =>
                      //       attempt.STATUS !== "COMPLETED" &&
                      //       attempt.FINAL_SCORE < attempt.CUT_OFF
                      //   )&& finalStatus.Status !== "COMPLETED" ||
                      //   (finalAssessmentAttempt !== 3 &&
                      FA_Details?.every(
                        (module: any) => module.STATUS === "COMPLETED"
                      ) && finalStatus.Status !== "COMPLETED" &&
                          handleAssementQuestionDetails(assessment?.AID)
                      dispatch(getFinalAssessmentAID(assessment?.AID));
                    }}
                  >
                    {assessment?.NAME ? assessment?.NAME : "null"}
                  </Typography>
                </Box1>
              </Main2Box>
            </Collapse>
          </>
        </MainCard>
      </>
      {nextPage === 3 && (
        <FinalAssessmentQuestion
         GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
          setNext={setNext}
          finalAID={finalAID}
          QuestionDetails={QuestionDetails}
          courseDetails={courseDetails}
          setHide={setHide}
          setNextPage={setNextPage}
          assessment={assessment}
        />
      )}
    </div>
  );
};

export default FinalAssessment;

const MainCard = styled(Box)`
  box-shadow: none !important;
  display: flex;
  background-color: #f5f5f5;
  padding: 15px 10px 15px 18px;
  border-bottom: 1px solid #f1eeee;
  flex-direction: column;
`;
const TitleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
`;
const Main2Box = styled(Box)`
  padding: 10px;
  margin-top: 10px;
  display: flex;
  border-radius: 2px;
  background-color: #f5f5f5;
  flex-direction: row;
  border-bottom: 1px solid #f1eeee;
  margin-right: 70px;
  justify-content: space-between;
  align-items: center;
`;
const Box1 = styled(Box)`
  display: flex;
  flex-direction: row;
`;
