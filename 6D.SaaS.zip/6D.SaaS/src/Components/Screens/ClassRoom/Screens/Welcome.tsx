import React, { FC, useEffect } from "react";
import {
  Box,
  Button,
  Typography,
} from "@mui/material";
import styled from "styled-components";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import ReactHtmlParser from "react-html-parser";
import { useDispatch, useSelector } from "react-redux";
import CustomButton from "../../../Button/CustomButton";
import CustomIconButton from "../../../Button/CustomIconButton";
import { instance } from "../../../../Controller/Common";
import { RootState } from "../../../../Store/UserSlice";
import { useNavigate } from "react-router-dom";
import Assessment from "./Assessment";
import {
  getModuleName,
  getModuleOrder,
  getTopicOrder,
} from "../../../../Store/ClassroomSlice";

interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
    continueButtonDetails: any;
    allCourseDetails: any;
    topicId: any;
    moduleId: any;
    assessmentId: any;
    finalAssessmentDetails: any;
    moduleName: any;
    finalAssessmentStatus: any;
    finalAssessmentDetailsStatus: any;
    ModuleOrder: any;
    TopicOrder: any;
  };
}
interface CourseProps {
  setIsDisabledCheckAndRadio: React.Dispatch<React.SetStateAction<boolean>>;
  isDisabledCheckAndRadio: boolean;
  QuestionDetails: any[];
  GetCourseDetails: () => void;
  nextPage: number;
  show: boolean;
  loading: boolean;
  courseDetails: any[];
  setQuestionLength: React.Dispatch<React.SetStateAction<number>>;
  questionLength: number;
  setShow: React.Dispatch<React.SetStateAction<boolean>>;
  handleNextButton: () => void;
  setNext: React.Dispatch<React.SetStateAction<number>>;
  setHide: (value: boolean) => void;
  setOpen: (value: boolean) => void;
  selectedAssessmentDetails: any;
  setSelectedAssessmentDetails: (assessment: any) => void;
  setNextPage: React.Dispatch<React.SetStateAction<number>>;
  assessmentDetails: any[];
  selectedTopicDetails: any;
  selectedModuleName: any;
  selectedTopicIndex: number;
  setSelectedTopicDetails: (topic: any) => void;
  GetTopicContentDetails: (cid: number, mid: number, tid: number) => void;
  selectedModuleIndex: number;
  topicContentDetails: {
    TID: number;
    NAME: string;
    CONTENT: string;
    CONTENT_TYPE: string;
    METADATA: string;
    UT_ID: number;
    PROGRESS: string;
    STATUS: string;
    CID: number;
    MID: number;
    ModuleName?: string;
    moduleStatus?: string;
    ModuleOrder?: any;
    TopicOrder?: any;
    moduleName?: any;
  };
  GetTopicDetails: (moduleId: string) => void;
  selectedTopicContent: any;
  setTopicContentDetails: React.Dispatch<React.SetStateAction<any>>;
  setQuestionDetails: React.Dispatch<React.SetStateAction<any>>;
  setAssessmentDetails: React.Dispatch<React.SetStateAction<any>>;
  setModuleIndex: (value: any) => void;
  GetAssessmentQuestiomDetails: (AID: number) => void;
  // GetAllcourseDetails: () => void;
}
const Welcome: FC<CourseProps> = ({
  selectedTopicDetails,
  selectedModuleName,
  nextPage,
  GetCourseDetails,
  setIsDisabledCheckAndRadio,
  isDisabledCheckAndRadio,
  GetAssessmentQuestiomDetails,
  handleNextButton,
  setOpen,
  loading,
  setQuestionLength,
  setShow,
  GetTopicContentDetails,
  setQuestionDetails,
  questionLength,
  selectedTopicIndex,
  setTopicContentDetails,
  topicContentDetails,
  QuestionDetails,
  setNext,
  courseDetails,
  setHide,
  selectedAssessmentDetails,
  setNextPage,
}) => {
  const dispatch = useDispatch();
  const [order, setOrder] = React.useState({ topic: "", module: "" });
  const userId = useSelector((state: RootState) => state.user.userID);
  const [prevDisabled, setPrevDisabled] = React.useState(false);
  const [completedTopics, setCompletedTopics] = React.useState<boolean[]>(
    Array(selectedTopicDetails?.length).fill(false)
  );
  const FA_Details = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentStatus
  );
  const ContinueModuleName = useSelector(
    (state: StateType) => state.classRoom.moduleName
  );
  const value = useSelector((state: StateType) => state.classRoom.value);
  const continueDetails = useSelector(
    (state: StateType) => state.classRoom.continueButtonDetails
  );
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse
  );
  const courseDetailsMID = useSelector(
    (state: StateType) => state.classRoom.moduleId
  );
  const courseDetailsTID = useSelector(
    (state: StateType) => state.classRoom.topicId
  );
  const AllCourseDetails = useSelector(
    (state: StateType) => state.classRoom.allCourseDetails
  );

  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);
  const TopicId = topicContentDetails?.TID;
  const TopicU_Id = topicContentDetails?.UT_ID;
  const ModuleId = selectedModuleName?.MID;

  const moduleIndex = AllCourseDetails[0]?.Modules.findIndex(
    (module: any) => module.MID === courseDetailsMID
  );
  const courseDetailsModuleOrder = useSelector(
    (state: StateType) => state.classRoom.ModuleOrder
  );
  const courseDetailsTopicOrder = useSelector(
    (state: StateType) => state.classRoom.TopicOrder
  );
  const moduleNo = AllCourseDetails[0]?.Modules[moduleIndex]?.moduleNo;

  const topicIndex = AllCourseDetails[0]?.Modules[
    moduleIndex
  ]?.Topics.findIndex((module: any) => module.TID === courseDetailsTID);
  const topicNo =
    AllCourseDetails[0]?.Modules[moduleIndex]?.Topics[topicIndex]?.topicNo;

  const allModules = AllCourseDetails[0]?.Modules || [];
  const matchedModules = allModules.map((module: any) => {
    const matchingFaModule = FA_Details?.find(
      (faModule: any) => faModule.MID === module.MID
    );

    return {
      MID: module.MID,
      moduleName: matchingFaModule ? matchingFaModule.NAME : "No Match",
    };
  });

  const currentModule = matchedModules?.find(
    (mod: any) => mod.MID === courseDetailsMID
  );
  const moduleName = currentModule?.moduleName || "Module Name Not Found";

  const handleClickToPrev = async () => {
    try {
      const response = await instance.get(
        `/6D/map/new-previousTask?CID=${
          courseDetails[0]?.CID
        }&UID=${userId}&MID=${courseDetailsMID}&TopicOrder=${
          order.topic || courseDetailsTopicOrder
        }&ModuleOrder=${order.module || courseDetailsModuleOrder}`
      );
      if (response.status === 200) {
        GetCourseDetails();
        let data = response.data[0];
        setOrder({ topic: data.TopicOrder, module: data.ModuleOrder });
        if (data.type === "Topic") {
          await GetTopicContentDetails(data.CID, data.MID, data.TID);
          setNextPage(1);
        } else if (data.type === "Assessment") {
          await GetAssessmentQuestiomDetails(data.AID);
          setNextPage(2);
        }
        // GetAllcourseDetails();
      }
    } catch (error: any) {
      // if (
      //   error.response.status === 500 &&
      //   error.response.data.message ===
      //     "Complete all the tasks in the current module to move to the next module."
      // ) {
      //   setShow(true);
      // }
      console.log(error);
    }
  };
  const courseDetailsModeuleID = useSelector(
    (state: StateType) => state.classRoom.moduleId
  );
  const switchToComplete = async () => {
    setOpen(false);
    try {
      const response = await instance.put(
        `/6D/Topic/UpdateUserTopicStatus?userTopicId=${TopicU_Id}&topicId=${TopicId}&userId=${userId}&status=COMPLETED&progress=100&MID=${topicContentDetails.MID}&CID=${topicContentDetails.CID}`
      );
      if (response.status === 200) {
        setCompletedTopics((prev) =>
          prev.map((completed, index) =>
            index === selectedTopicIndex ? true : completed
          )
        );
        // GetTopicDetails(ModuleId || topicContentDetails.MID);
        GetTopicContentDetails(
          topicContentDetails.CID,
          topicContentDetails.MID || courseDetailsModeuleID || ModuleId,
          topicContentDetails.TID || TopicId 
        );
        // GetAllcourseDetails();
        GetCourseDetails();
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    window.scroll(0, 0);
  }, []);

  useEffect(() => {
    dispatch(getModuleOrder(topicContentDetails?.ModuleOrder));
    dispatch(getTopicOrder(topicContentDetails?.TopicOrder));
  }, [topicContentDetails, dispatch]);

  useEffect(() => {
    dispatch(getModuleName(topicContentDetails?.moduleName));
  }, [topicContentDetails]);

  return (
    <>
      <div style={{ marginTop: "20px" }}>
        {topicContentDetails && (
          <>
            <HeadBox>
              {topicContentDetails ? (
                <>
                  <Typography
                    sx={{
                      fontWeight: 400,
                      fontSize: "11px",
                      color: "#3F3F40",
                      paddingLeft: "20px",
                      cursor: "pointer",
                    }}
                    onClick={() => {
                      setNextPage(0);
                      setHide(true);
                      GetCourseDetails();
                    }}
                  >
                    {rootCourse[0]?.courseDetails?.TITLE ||
                      "Course Title Not Found"}
                  </Typography>
                  <ModuleBox>
                    <Typography
                      sx={{
                        fontWeight: 400,
                        fontSize: "14px",
                        color: "#2A62AA",
                        paddingLeft: "20px",
                        cursor: "pointer",
                      }}
                      onClick={() => {
                        setNextPage(0);
                        setHide(true);
                      }}
                    >
                      Module {moduleNo || courseDetailsModuleOrder}:{" "}
                      {topicContentDetails?.ModuleName ||
                      topicContentDetails?.moduleName ||
                        ContinueModuleName ||
                        moduleName ||
                        selectedModuleName?.NAME ||
                        continueDetails?.moduleName ||
                        "Module Name Not Found"}
                    </Typography>
                  </ModuleBox>
                  <SubTitleBox>
                    <Typography sx={{fontSize:"14px",fontWeight:600,color:"#FFFFFF",marginLeft:"5px"}}>
                  {moduleNo || courseDetailsModuleOrder}.
                    {topicNo || courseDetailsTopicOrder}{" "}
                    {topicContentDetails?.NAME || "Exercise Name Not Found"}
                    </Typography>
                    <ButtonBox>
                      {topicContentDetails.STATUS !== "COMPLETED" ? (
                        <CustomButton
                          name={"Mark as completed"}
                          startIcon={<CheckCircleIcon />}
                          variant="secondary"
                          padding={"0px 5px 0px 8px"}
                          onClick={switchToComplete}
                        />
                      ) : (
                        <Button
                          sx={{
                            backgroundColor: "green",
                            color: "white",
                            textTransform: "none",
                          }}
                          startIcon={
                            <CheckCircleIcon sx={{ color: "white" }} />
                          }
                        >
                          Completed
                        </Button>
                      )}
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <Box>
                        <CustomIconButton
                          icon={ArrowBackIosIcon}
                          variant="secondary"
                          iconSize={15}
                          onClick={handleClickToPrev}
                          disable={prevDisabled}
                          padding={"15px"}
                        />
                        &nbsp;&nbsp;&nbsp;
                        <CustomIconButton
                          icon={ArrowForwardIosIcon}
                          iconSize={15}
                          variant="secondary"
                          disable={prevDisabled || loading}
                          onClick={() => {
                            handleNextButton();
                            setOpen(false);
                          }}
                          padding={"15px"}
                        />
                      </Box>
                    </ButtonBox>
                  </SubTitleBox>
                  <ContentBox>
                    <Typography>
                      {topicContentDetails?.CONTENT
                        ? ReactHtmlParser(topicContentDetails?.CONTENT)
                        : "Content not available"}
                    </Typography>
                  </ContentBox>
                </>
              ) : (
                <Typography className="welcome-title">
                  Course or Topic not found
                </Typography>
              )}
            </HeadBox>
          </>
        )}
        {QuestionDetails &&
        QuestionDetails &&
        QuestionDetails[0]?.assessmentType !== "Final Assessment" &&
        QuestionDetails.length > 0 ? (
          <Assessment
            setOpen={setOpen}
            GetCourseDetails={GetCourseDetails}
            setIsDisabledCheckAndRadio={setIsDisabledCheckAndRadio}
            isDisabledCheckAndRadio={isDisabledCheckAndRadio}
            // GetAllcourseDetails={GetAllcourseDetails}
            fromWelcomepage={true}
            nextPage={nextPage}
            topicContentDetails={topicContentDetails}
            setTopicContentDetails={setTopicContentDetails}
            setNext={setNext}
            setQuestionLength={setQuestionLength}
            questionLength={questionLength}
            setHide={setHide}
            selectedModuleName={selectedModuleName}
            setQuestionDetails={setQuestionDetails}
            selectedAssessmentDetails={selectedAssessmentDetails}
            assessmentQuestionDetails={QuestionDetails}
            setNextPage={setNextPage}
            handleNextButton={handleNextButton}
            GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
            GetTopicContentDetails={GetTopicContentDetails}
            setShow={setShow}
          />
        ) : null}
      </div>
    </>
  );
};

export default Welcome;

const HeadBox = styled(Box)`
  background-color: #f5f5f5;
  padding: 15px;
  border-radius: 7px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const SubTitleBox = styled(Typography)`
  background-color: #2a62aa;
  padding: 15px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px;
  font-weight: 600;
  font-size: 14px;
  color: #ffffff;
`;
const ButtonBox = styled(Box)`
  display: flex;
  flex-direction: row;
  // margin-top: 10px;
  justify-content: space-between;
`;
const ModuleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  margin-top: 10px;
  justify-content: space-between;
  margin-bottom: 10px;
`;
const ContentBox = styled(Box)`
  display: flex;
  flex-direction: column;
  padding: 10px 20px 20px 20px;
  background-color: #ffffff;
  overflow-y: auto;
`;
