import React, { FC, useEffect, useRef, useState } from "react";
import {
  Box,
  Button,
  Checkbox,
  Radio,
  Typography,
} from "@mui/material";
import styled from "styled-components";
import CloseIcon from "@mui/icons-material/Close";
import DoneIcon from "@mui/icons-material/Done";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import ReactHtmlParser from "react-html-parser";
import { useSelector } from "react-redux";
import CustomButton from "../../../Button/CustomButton";
import { instance } from "../../../../Controller/Common";
import { RootState } from "../../../../Store/UserSlice";
import { AnyARecord } from "dns";

interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
    topic: any;
    assessmentQuestion: any;
    topicIndex: number;
    module: any;
    moduleIndex: number;
    assessmentIndex: number;
    continueButtonDetails: any;
    allCourseDetails: any;
    topicId: any;
    moduleId: any;
    assessmentId: any;
    finalAssessmentDetails: any;
    finalAssessmentStatus: any;
    finalAssessmentDetailsStatus: any;
    ModuleOrder: any;
    TopicOrder: any;
    moduleName: any;
  };
}
interface CourseProps {
  setIsDisabledCheckAndRadio: React.Dispatch<React.SetStateAction<boolean>>;
  isDisabledCheckAndRadio: boolean;
  setOpen: (value: boolean) => void;
  GetAssessmentQuestiomDetails: (AID: number) => void;
  GetTopicContentDetails?: (cid: number, mid: number, tid: number) => void;
  nextPage: number;
  GetCourseDetails: () => void;
  setQuestionLength: React.Dispatch<React.SetStateAction<number>>;
  questionLength: number;
  // GetAllcourseDetails: () => void;
  fromWelcomepage: boolean;
  selectedAssessmentDetails: any;
  selectedModuleName: any;
  assessmentQuestionDetails: any;
  setNext: React.Dispatch<React.SetStateAction<number>>;
  setHide: (value: boolean) => void;
  setNextPage: React.Dispatch<React.SetStateAction<number>>;
  setQuestionDetails: React.Dispatch<React.SetStateAction<any>>;
  setShow: React.Dispatch<React.SetStateAction<boolean>>;
  handleNextButton: () => void;
  topicContentDetails: {
    TID: number;
    NAME: string;
    CONTENT: string;
    CONTENT_TYPE: string;
    METADATA: string;
    UT_ID: number;
    PROGRESS: string;
    STATUS: string;
    CID: number;
    MID: number;
  };
  setTopicContentDetails: React.Dispatch<React.SetStateAction<any>>;
}
const Assessment: FC<CourseProps> = ({
  setIsDisabledCheckAndRadio,
  isDisabledCheckAndRadio,
  setOpen,
  setQuestionLength,
  selectedModuleName,
  questionLength,
  assessmentQuestionDetails,
  GetAssessmentQuestiomDetails,
  handleNextButton,
}) => {
  const userId = useSelector((state: RootState) => state.user.userID);
  const value = useSelector((state: StateType) => state.classRoom.value);
  const [selectedAnswers, setSelectedAnswers] = React.useState<string[]>([]);
  const [isSubmitDisabled, setIsSubmitDisabled] = React.useState(true);
  const [isNextDisabled, setIsNextDisabled] = React.useState(true);
  const [isLastQuestion, setIsLastQuestion] = React.useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [totalScore, setTotalScore] = React.useState(0);
  const [userScore, setUserScore] = React.useState(0);
  const [displayTime, setDisplayTime] = useState("00:00:00");
  const timerRef = useRef<number | null>(null);
  // const IntialTimer =
  //   assessmentQuestionDetails[questionLength - 1] &&
  //   assessmentQuestionDetails[questionLength - 1]?.timeTaken;
  const timeToSeconds = (time: string) => {
    const [hours, minutes, seconds] = time?.split(":").map(Number);
    return hours * 3600 + minutes * 60 + seconds;
  };
  // const InitialTime = IntialTimer && timeToSeconds(IntialTimer);
  const timeTakenRef = useRef(0);
  const continueDetails = useSelector(
    (state: StateType) => state.classRoom.continueButtonDetails
  );
  const ContinueModuleName = useSelector(
    (state: StateType) => state.classRoom.moduleName
  );
  const courseDetailsMID = useSelector(
    (state: StateType) => state.classRoom.moduleId
  );
  const AllCourseDetails = useSelector(
    (state: StateType) => state.classRoom.allCourseDetails
  );
  const FA_Details = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentStatus
  );
  const courseDetailsModuleOrder = useSelector(
    (state: StateType) => state.classRoom.ModuleOrder
  );
  const moduleIndex = AllCourseDetails[0]?.Modules.findIndex(
    (module: any) => module.MID === courseDetailsMID
  );
  const moduleNo = AllCourseDetails[0]?.Modules[moduleIndex]?.moduleNo;

  const allModules = AllCourseDetails[0]?.Modules || [];

  const matchedModules = allModules.map((module: any) => {
    const matchingFaModule = FA_Details?.find(
      (faModule: any) => faModule.MID === module.MID
    );

    return {
      MID: module.MID,
      moduleName: matchingFaModule ? matchingFaModule.NAME : "No Match",
    };
  });

  const currentModule = matchedModules?.find(
    (mod: any) => mod.MID === courseDetailsMID
  );
  const moduleName = currentModule?.moduleName || "Module Name Not Found";

  useEffect(() => {
    setTotalScore(assessmentQuestionDetails?.length * 10);
    setUserScore(
      assessmentQuestionDetails
        ?.map((e: any) => (e.USER_ANSWER?.IsCorrect ? 1 : 0))
        ?.reduce((a: any, b: AnyARecord) => a + b, 0) * 10
    );
  }, [assessmentQuestionDetails]);

  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse
  );
  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);

  const handleChange = (choiceValue: string) => {
    setOpen(false);
    const isMultipleAnswer =
      assessmentQuestionDetails[questionLength]?.TYPE === "Multiple Answer";

    if (isMultipleAnswer) {
      if (selectedAnswers.includes(choiceValue)) {
        setSelectedAnswers(
          selectedAnswers.filter((answer) => answer !== choiceValue)
        );
      } else {
        setSelectedAnswers([...selectedAnswers, choiceValue]);
      }
    } else {
      setSelectedAnswers([choiceValue]);
    }

    setIsSubmitDisabled(false);
  };

  const handleClickToPrev = () => {
    setOpen(false);
    const totalQuestions = assessmentQuestionDetails?.length;
    if (totalQuestions && questionLength < totalQuestions - 1) {
      setQuestionLength((prevLength) => prevLength + 1);
      setIsSubmitDisabled(true);
      setIsNextDisabled(true);
      setIsDisabledCheckAndRadio(false);
      startTimer();
      // GetCourseDetails();
      if (
        assessmentQuestionDetails[questionLength - 1] &&
        assessmentQuestionDetails[questionLength - 1].timeTaken !== undefined &&
        assessmentQuestionDetails[questionLength - 1].timeTaken === "0"
      ) {
        timeTakenRef.current = timeToSeconds(
          assessmentQuestionDetails[questionLength - 1].timeTaken
        );
      }
    }
    if (questionLength === totalQuestions - 1) {
      setIsLastQuestion(true);
    } else {
      setIsLastQuestion(false);
    }
  };

  const postUserAnswer = async (data: any): Promise<void> => {
    try {
      setIsLoading(true);
      const response = await instance.post(`/6D/assessment/userAnswers`, data);
      if (response.status === 200) {
        console.log("SUCCESS");
        GetAssessmentQuestiomDetails(data?.AID);
        setIsSubmitDisabled(true);
        setIsNextDisabled(false);
        setIsDisabledCheckAndRadio(true);
        // GetAllcourseDetails();
        // GetCourseDetails();
        stopTimer();
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitAnswer = () => {
    const currentQuestion = assessmentQuestionDetails[questionLength];
    const correctAnswers =
      currentQuestion?.ANSWER?.trim().split(/,\s*(?=<)/) || [];
    const userQuestionId = assessmentQuestionDetails[questionLength]?.userQId;
    const isAnswerCorrect = selectedAnswers.every((answer) =>
      correctAnswers.includes(answer.trim())
    );

    const choiceIDs = currentQuestion.CHOICE.filter((choice: any) =>
      selectedAnswers.includes(choice.Choice)
    ).map((choice: any) => choice.ChoiceID);

    postUserAnswer({
      ChoiceID: choiceIDs.join(", "),
      QID: currentQuestion.QID,
      UID: userId,
      AID:
        // selectedAssessmentDetails?.AID ??
        assessmentQuestionDetails[0]?.USER_ANSWER?.AID ??
        assessmentQuestionDetails[0]?.AID,
      IsCorrect: isAnswerCorrect,
      userQID: userQuestionId,
      time: displayTime,
      MID: assessmentQuestionDetails[0]?.MID ?? selectedModuleName?.MID,
      CID: rootCourse[0]?.courseDetails?.CID,
    });
  };

  const [userSelectedWrongAnswer, setUserSelectedWrongAnswer] = useState(true);
  const [userSelectedCorrectAnswer, setUserSelectedCorrectAnswer] =
    useState(true);

  useEffect(() => {
    if (
      assessmentQuestionDetails &&
      assessmentQuestionDetails[questionLength]
    ) {
      const userAnswer = assessmentQuestionDetails[questionLength]?.USER_ANSWER;

      if (userAnswer === null) {
        setUserSelectedWrongAnswer(true);
        setUserSelectedCorrectAnswer(true);
      } else if (userAnswer?.IsCorrect === true) {
        setIsNextDisabled(false);
        setUserSelectedCorrectAnswer(false);
        setUserSelectedWrongAnswer(true);
      } else if (userAnswer?.IsCorrect === false) {
        setIsNextDisabled(false);
        setUserSelectedWrongAnswer(false);
        setUserSelectedCorrectAnswer(true);
      }
    }
  }, [assessmentQuestionDetails, questionLength]);

  // --------------------------
  useEffect(() => {
    timerRef.current = window.setInterval(() => {
      timeTakenRef.current += 1;
      setDisplayTime(formatTime(timeTakenRef.current));
    }, 1000);

    return () => stopTimer();
  }, []);

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };
  const startTimer = () => {
    if (!timerRef.current) {
      // Only start if the timer is not already running
      timerRef.current = window.setInterval(() => {
        timeTakenRef.current += 1;
        setDisplayTime(formatTime(timeTakenRef.current));
      }, 1000);
    }
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600)
      .toString()
      .padStart(2, "0");
    const m = Math.floor((seconds % 3600) / 60)
      .toString()
      .padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${h}:${m}:${s}`;
  };

  useEffect(() => {
    setQuestionLength(0);
  }, [assessmentQuestionDetails[0]?.AID]);

  return (
    <div>
      {assessmentQuestionDetails && assessmentQuestionDetails ? (
        <>
          <TitleBox>
            <Typography
               sx={{
                fontWeight: 400,
                fontSize: "11px",
                color: "#3F3F40",
                paddingLeft: "20px",
              }}
            >
              {rootCourse[0]?.courseDetails?.TITLE || "Course Title Not Found"}
            </Typography>
            <ModuleBox>
              <Typography
                 sx={{
                  fontWeight: 400,
                  fontSize: "14px",
                  color: "#2A62AA",
                  paddingLeft: "20px",
                }}
              >
                Module{" "}
                {moduleNo ||
                  courseDetailsModuleOrder ||
                  continueDetails?.ModuleOrder}
                :{" "}
                {ContinueModuleName ||
                  assessmentQuestionDetails[0]?.moduleName ||
                  continueDetails?.moduleName ||
                  moduleName ||
                  selectedModuleName?.NAME ||
                  "Module Name Not Found"}
              </Typography>
            </ModuleBox>
            <QuestionBox>
              <SubQuestionBox>
                <Typography
                  sx={{
                    fontWeight: 600,
                    fontSize: "14px",
                    color: "#E5E5E5",
                    marginRight: "20px",
                  }}
                >
                  Question {questionLength + 1} of{" "}
                  {assessmentQuestionDetails?.length}
                </Typography>
                <Typography
                  sx={{
                    fontWeight: 400,
                    fontSize: "14px",
                    color: "#E5E5E5",
                    marginRight: "20px",
                  }}
                >
                  {
                    assessmentQuestionDetails[questionLength]?.Question
                      ?.QuestionType
                  }
                </Typography>
                <Typography
                  sx={{
                    fontWeight: 400,
                    fontSize: "10px",
                    color: "#E5E5E5",
                    marginRight: "20px",
                  }}
                >
                  Marked for 10 points
                </Typography>
              </SubQuestionBox>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-evenly",
                }}
              >
                <Typography
                  sx={{
                    fontWeight: 600,
                    fontSize: "14px",
                    color: "#E5E5E5",
                    marginRight: "20px",
                  }}
                >
                  Time Taken &nbsp;&nbsp;
                  {assessmentQuestionDetails[questionLength]?.timeTaken !== "0"
                    ? assessmentQuestionDetails[questionLength]?.timeTaken
                    : formatTime(timeTakenRef.current)}
                </Typography>
                <Typography
                  sx={{
                    fontWeight: 600,
                    fontSize: "14px",
                    color: "#E5E5E5",
                    marginRight: "20px",
                  }}
                >
                  Score: {userScore}/{totalScore}
                </Typography>
              </Box>
            </QuestionBox>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                padding: "20px",
                backgroundColor: "#FFFFFF",
              }}
            >
              <Typography>
                {assessmentQuestionDetails[questionLength]
                  ? ReactHtmlParser(
                      assessmentQuestionDetails[questionLength]?.QUESTION
                    )
                  : "Question Not found"}
              </Typography>
              <Sub1Box>
                {assessmentQuestionDetails[questionLength]?.CHOICE?.map(
                  (choice: any, index: number) => {
                    const choiceValue = choice.Choice;
                    if (!choiceValue) return null;

                    const userAnswer = assessmentQuestionDetails[questionLength]
                      ?.USER_ANSWER
                      ? assessmentQuestionDetails[questionLength]?.USER_ANSWER
                          ?.IsCorrect
                      : null;

                    const selectedChoiceIds = assessmentQuestionDetails[
                      questionLength
                    ]?.USER_ANSWER?.ChoiceID?.split(", ").map((id: string) =>
                      parseInt(id)
                    );

                    const isChoiceSelected = selectedChoiceIds?.includes(
                      choice.ChoiceID
                    );

                    const QuestionType =
                      assessmentQuestionDetails[questionLength]?.QUESTION_TYPE;

                    const isChoiceNotSelected = !selectedChoiceIds?.includes(
                      choice.ChoiceID
                    );

                    const backgroundColor =
                      userAnswer === null
                        ? "transparent"
                        : userAnswer === true && isChoiceSelected
                        ? "#48A055"
                        : userAnswer === false &&
                          QuestionType !== "Multiple Choice" &&
                          isChoiceSelected
                        ? "#BF1932"
                        : userAnswer === false &&
                          QuestionType === "Multiple Choice" &&
                          choice.IsCorrect === true &&
                          isChoiceNotSelected
                        ? "#48A055"
                        : userAnswer === false &&
                          QuestionType === "Multiple Choice" &&
                          choice.IsCorrect === true &&
                          isChoiceSelected
                        ? "#48A055"
                        : userAnswer === false &&
                          QuestionType === "Multiple Choice" &&
                          choice.IsCorrect === false &&
                          isChoiceSelected
                        ? "#BF1932"
                        : "transparent";
                    const textColor =
                      userAnswer === null
                        ? "#3F3F40"
                        : userAnswer === true && isChoiceSelected
                        ? "#fff"
                        : userAnswer === false &&
                          QuestionType !== "Multiple Choice" &&
                          isChoiceSelected
                        ? "#fff"
                        : userAnswer === false &&
                          QuestionType === "Multiple Choice" &&
                          choice.IsCorrect === true &&
                          isChoiceNotSelected
                        ? "#fff"
                        : userAnswer === false &&
                          QuestionType === "Multiple Choice" &&
                          choice.IsCorrect === true &&
                          isChoiceSelected
                        ? "#fff"
                        : userAnswer === false &&
                          QuestionType === "Multiple Choice" &&
                          choice.IsCorrect === false &&
                          isChoiceSelected
                        ? "#fff"
                        : "#3F3F40";

                    const isMultipleAnswer =
                      assessmentQuestionDetails[questionLength]?.TYPE ===
                      "Multiple Answer";

                    return (
                      <TextBox
                        key={choiceValue}
                        sx={{
                          backgroundColor: backgroundColor,
                          transition: "background-color 0.3s",
                        }}
                      >
                        {isMultipleAnswer ? (
                          <Checkbox
                            name={choiceValue}
                            checked={isChoiceSelected}
                            onChange={() => handleChange(choiceValue)}
                            disabled={
                              userAnswer !== null || isDisabledCheckAndRadio
                            }
                            sx={{
                              "&.MuiCheckbox-root": {
                                color: "gray",
                                // color: userAnswer === null ? "gray" : "white",
                                transition: "background-color 0.3s",
                              },
                            }}
                          />
                        ) : (
                          <Radio
                            name="radio-buttons"
                            inputProps={{ "aria-label": choiceValue }}
                            // checked={selectedAnswers.includes(choiceValue)}
                            checked={
                              assessmentQuestionDetails[questionLength]
                                ?.USER_ANSWER
                                ? isChoiceSelected
                                : selectedAnswers.includes(choiceValue)
                            }
                            onChange={() => handleChange(choiceValue)}
                            // disabled={isDisabledCheckAndRadio}
                            disabled={
                              userAnswer !== null || isDisabledCheckAndRadio
                            }
                            sx={{
                              "&.MuiCheckbox-root": {
                                color: "white",
                                transition: "background-color 0.3s",
                              },
                            }}
                          />
                        )}
                        <Typography
                          sx={{
                            fontSize: "14px",
                            fontWeight: 400,
                            color: textColor,
                            transition: "color 0.3s",
                          }}
                        >
                          {ReactHtmlParser(choiceValue) || null}
                        </Typography>
                      </TextBox>
                    );
                  }
                )}
              </Sub1Box>

              {/* *********************************************************** */}
            </Box>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                padding: "30px",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <CustomButton
                name={isLoading ? "Loading..." : "Submit"}
                variant="primary"
                padding="6px"
                onClick={handleSubmitAnswer}
                disabled={isSubmitDisabled || isLoading}
              />
              <Box>
                <Button
                  variant="contained"
                  endIcon={<CloseIcon />}
                  sx={{
                    backgroundColor: "#BF1932",
                    textTransform: "none",
                    "&.Mui-disabled": {
                      backgroundColor: "#EDF1F4",
                      color: "#939597",
                    },
                  }}
                  // disabled={true}
                  disabled={userSelectedWrongAnswer}
                >
                  Wrong
                </Button>
                &nbsp; &nbsp; &nbsp;
                <Button
                  variant="contained"
                  endIcon={<DoneIcon />}
                  sx={{
                    backgroundColor: "#48A055",
                    textTransform: "none",
                    "&.Mui-disabled": {
                      backgroundColor: "#EDF1F4",
                      color: "#939597",
                    },
                  }}
                  disabled={userSelectedCorrectAnswer}
                >
                  Correct
                </Button>
              </Box>
              <CustomButton
                name={
                  questionLength + 1 === assessmentQuestionDetails?.length
                    ? "Finish"
                    : "Next Question"
                }
                variant="primary"
                endIcon={<ArrowForwardIosIcon />}
                padding="6px"
                onClick={() => {
                  if (
                    questionLength + 1 ===
                    assessmentQuestionDetails?.length
                  ) {
                    stopTimer();
                    handleNextButton();
                    // setQuestionLength(0);
                  } else {
                    window.scroll(0, 0);
                    handleClickToPrev();
                    setSelectedAnswers([]);
                  }
                }}
                disabled={isNextDisabled}
              />
            </Box>
          </TitleBox>
        </>
      ) : (
        <Typography className="welcome-title">Assessment not found</Typography>
      )}
    </div>
  );
};

export default Assessment;

const TitleBox = styled(Box)`
  background-color: #f5f5f5;
  padding: 15px;
  border-radius: 7px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;

const ModuleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  margin-top: 10px;
  justify-content: space-between;
`;
const Sub1Box = styled(Box)`
  display: flex;
  flex-direction: column;
  padding: 10px;
`;
const TextBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
`;
const QuestionBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 10px;
  background-color: #2a62aa;
  align-items: center;
  padding: 16px;
`;
const SubQuestionBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-evenly;
  align-items: center;
`;
