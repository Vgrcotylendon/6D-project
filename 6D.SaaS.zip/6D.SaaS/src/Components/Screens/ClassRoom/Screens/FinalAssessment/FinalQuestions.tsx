import React, { FC, useEffect, useRef } from "react";
import {
  Box,
  Checkbox,
  Divider,
  Radio,
  Typography,
} from "@mui/material";
import styled from "styled-components";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import CustomButton from "../../../../Button/CustomButton";
import { useDispatch, useSelector } from "react-redux";
import CustomIconButton from "../../../../Button/CustomIconButton";
import ReactHtmlParser from "react-html-parser";
import { cookies, instance } from "../../../../../Controller/Common";
import { RootState } from "../../../../../Store/UserSlice";
import {
  FinalAssessmentTimer,
  GetAnswers,
  GetSumitted,
} from "../../../../../Store/ClassroomSlice";

interface StateType {
  classRoom: {
    value: number;
    MID: number;
    enrolledCourse: any;
    topic: any;
    assessmentQuestion: any;
    topicIndex: number;
    module: any;
    moduleIndex: number;
    assessmentIndex: number;
    finalAssessment: any[];
    finalAssessmentAID: number;
    finalAssessmentAttempt: any;
    finalAssessmentDetails: any;
    finalAssessmentDetailsStatus: any;
    Answers: any;
    SubmittedAnswers: any;
    timer: any;
    NewSelectedAnswers: any;
  };
}
interface dataType {
  ChoiceID: number;
  QID: number;
  UID: number;
  AID: number;
  IsCorrect: boolean;
  userQID: number;
  time: string;
  MID: number;
  CID: number;
}
interface ModuleAccordionProps {
  finalAID?: number;
  GetAssessmentQuestiomDetails: (AID: number) => void;
  courseDetails?: any[];
  GetFinalAssessmentQuestiomDetails?: (id: any) => void;
  questionLength?: any;
  setDisplayTime?: (value: any) => void;
  setQuestionLength?: (value: any) => void;
  assessment?: any;
  displayTime?: any;
  setHide?: (value: boolean) => void;
  setNext?: React.Dispatch<React.SetStateAction<number>>;
  setNextPage?: React.Dispatch<React.SetStateAction<number>>;
  selectedAssessmentDetails?: any;
  selectedModuleName?: any;
  nextPage?: number;
  QuestionDetails?: any[];
}

const FinalQuestions: FC<ModuleAccordionProps> = ({
  setHide,
  displayTime,
  GetFinalAssessmentQuestiomDetails,
  questionLength,
  setQuestionLength,
  QuestionDetails,
  setNextPage,
}) => {
  const dispatch = useDispatch();
  const [selectedChoices, setSelectedChoice] = React.useState({});
  const [choices, setChoices] = React.useState<any[]>([]);
  const [submitData, setSubmitData] = React.useState<any>({});
  const [isSubmitted, setIsSubmitted] = React.useState<{
    [key: number]: boolean;
  }>({});
  const [selectedAnswers, setSelectedAnswers] = React.useState<{
    [key: number]: any;
  }>({});
  const FA_Details = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentDetails
  );
  const finalStatus = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentDetailsStatus
  );
  const finalAssessmentName = FA_Details.NAME;
  const finalAssessmentAttempt = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentAttempt
  );
  const userId =
    useSelector((state: RootState) => state.user.userID) ??
    cookies.get("userId");
  const value = useSelector((state: StateType) => state.classRoom.value);
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse
  );
  const newQuestions = useSelector(
    (state: StateType) => state.classRoom.finalAssessment
  );
  const finalAssessmentAid = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentAID
  );
  const timerRef = useRef<number | null>(null);
  const timeTakenRef = useRef(0);
  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);
  const Answers = useSelector((state: StateType) => state.classRoom.Answers);
  const SubmittedAnswers = useSelector(
    (state: StateType) => state.classRoom.SubmittedAnswers
  );
  
  const postUserAnswer = async (
    ChoiceID: number,
    QID: number,
    IsCorrect: boolean,
    userQId: number
  ): Promise<void> => {
    try {
      const response = await instance.post(
        `/6D/assessment/submitAnswerFor-FA`,
        {
          ChoiceID: ChoiceID,
          QID: QID,
          UID: userId,
          AID: finalAssessmentAid,
          IsCorrect: IsCorrect,
          userQID: userQId,
          time: displayTime,
          CID: rootCourse[0]?.courseDetails?.CID,
        }
      );
      if (response.status === 200) {
        console.log("SUCCESS");
        setChoices((prev: any) => [
          ...prev,
          {
            questionLength: questionLength,
            ChoiceID: ChoiceID,
            QID: QID,
            IsCorrect: IsCorrect,
          },
        ]);
        setIsSubmitted((prev) => ({
          ...prev,
          [questionLength]: true,
        }));
        GetFinalAssessmentQuestiomDetails &&
          GetFinalAssessmentQuestiomDetails(finalAssessmentAid);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleAnswerSelection = (
    choice: any,
    questionIndex: number,
    isMultiple: boolean
  ) => {
    if (isSubmitted[questionIndex]) return;
    setSelectedChoice(choice);
    dispatch(
      GetAnswers({
        choice: choice,
        questionIndex: questionIndex,
        isMultiple: isMultiple,
      })
    );

    setSelectedAnswers((prev) => {
      const currentSelections = prev[questionIndex] || [];
      const updatedSelections = isMultiple
        ? currentSelections.includes(choice)
          ? currentSelections.filter((c: any) => c !== choice)
          : [...currentSelections, choice]
        : choice;

      return {
        ...prev,
        [questionIndex]: updatedSelections,
      };
    });
  };

  const handleSubmitAnswer = (questionIndex: any, isMultipl: any) => {
    const currentQuestion =
      (QuestionDetails && QuestionDetails[questionLength]) ||
      newQuestions[questionLength];

    const isMultiple = currentQuestion.TYPE === "Multiple Answer";
    const selectedChoice =
      Answers[questionLength] || selectedAnswers[questionLength];

    if (!selectedChoice) {
      alert("Please select an answer before submitting.");
      return;
    }

    const submissionData = {
      CHOICE: isMultiple
        ? selectedChoice.map((choice: any) => choice.ChoiceID)
        : selectedChoice.ChoiceID,
      QID: currentQuestion.QID,
      IsCorrect: isMultiple
        ? selectedChoice.some((choice: any) => choice.IsCorrect)
        : selectedChoice.IsCorrect,
      userQId: currentQuestion.userQId,
    };

    setSubmitData(submissionData);
    postUserAnswer(
      isMultiple ? submissionData.CHOICE.join(",") : submissionData.CHOICE,
      submissionData.QID,
      submissionData.IsCorrect,
      submissionData.userQId
    );

    dispatch(
      GetSumitted({
        choice: selectedChoices,
        questionIndex: questionIndex,
        isMultiple: isMultiple,
      })
    );
    setIsSubmitted((prev) => ({
      ...prev,
      [questionLength]: true,
    }));
  };

  const handleClickToNext = () => {
    const totalQuestions = QuestionDetails?.length || newQuestions.length;
    if (totalQuestions && questionLength < totalQuestions - 1) {
      setQuestionLength &&
        setQuestionLength((prevLength: number) => prevLength + 1);
      setIsSubmitted((prev) => ({
        ...prev,
        [questionLength]: !!isSubmitted[questionLength],
      }));
    } else {
      setNextPage && setNextPage(5);
      setHide && setHide(false);
    }
  };

  const handleClickToPrev = () => {
    if (questionLength > 0) {
      setQuestionLength &&
        setQuestionLength((prevLength: number) => prevLength - 1);
    }
  };

  const handleNavigate = () => {
    setNextPage && setNextPage(3);
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600)
      .toString()
      .padStart(2, "0");
    const m = Math.floor((seconds % 3600) / 60)
      .toString()
      .padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${h}:${m}:${s}`;
  };

  const Timer = useSelector((state: StateType) => state.classRoom.timer);
  useEffect(() => {
    timeTakenRef.current = Timer;
  }, [Timer]);

  useEffect(() => {
    timerRef.current = window.setInterval(() => {
      timeTakenRef.current += 1;
      dispatch(FinalAssessmentTimer(timeTakenRef.current));
    }, 1000);

    return () => stopTimer();
  }, []);

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  return (
    <div>
      {QuestionDetails || newQuestions ? (
        <TitleBox>
          <Typography
           sx={{
            fontWeight: 400,
            fontSize: "11px",
            color: "#3F3F40",
            paddingLeft: "20px",
          }}
          >
            {rootCourse[0]?.courseDetails?.TITLE || "Course Title Not Found"}
          </Typography>
          <ModuleBox>
            <Typography
               sx={{
                fontWeight: 400,
                fontSize: "14px",
                color: "#2A62AA",
                paddingLeft: "20px",
              }}
            >
              {finalAssessmentName}
            </Typography>
          </ModuleBox>
          <QuestionBox>
            <SubQuestionBox>
              <Typography
                sx={{
                  fontWeight: 600,
                  fontSize: "14px",
                  color: "#E5E5E5",
                  marginRight: "20px",
                }}
              >
                Final Assessment
              </Typography>
            </SubQuestionBox>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-evenly",
              }}
            >
              <Typography
                sx={{
                  fontWeight: 600,
                  fontSize: "14px",
                  color: "#E5E5E5",
                  marginRight: "20px",
                }}
              >
                Time Taken &nbsp;&nbsp;
                {QuestionDetails &&
                QuestionDetails[questionLength]?.timeTaken !== "0" &&
                QuestionDetails[questionLength]?.timeTaken !== null
                  ? QuestionDetails[questionLength]?.timeTaken
                  : newQuestions[questionLength]?.timeTaken !== "0" &&
                    newQuestions[questionLength]?.timeTaken !== null
                  ? newQuestions[questionLength]?.timeTaken
                  : formatTime(Timer)}
              </Typography>
              <Typography
                sx={{
                  fontWeight: 600,
                  fontSize: "14px",
                  color: "#E5E5E5",
                  marginRight: "20px",
                }}
              >
                Attempt: {finalAssessmentAttempt}/{finalStatus.attemptLength}
              </Typography>
            </Box>
          </QuestionBox>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              padding: "20px",
              height: "50vh",
              backgroundColor: "#FFFFFF",
            }}
          >
            <Typography
              sx={{
                fontSize: "14px",
                fontWeight: 400,
                padding: "5px 0px 5px 0px",
              }}
            >
              {(QuestionDetails && QuestionDetails[questionLength]) ||
              newQuestions[questionLength]
                ? ReactHtmlParser(
                    (QuestionDetails &&
                      QuestionDetails[questionLength]?.QUESTION) ||
                      newQuestions[questionLength]?.QUESTION
                  )
                : "Question Not found"}
            </Typography>
            <Typography
              sx={{
                marginBottom: "10px",
                marginTop: "10px",
                fontWeight: 400,
                color: "#3F3F40",
                fontSize: "12px",
              }}
            >
              {(QuestionDetails && QuestionDetails[questionLength]) ||
              newQuestions[questionLength]
                ? (QuestionDetails && QuestionDetails[questionLength]?.HINT) ||
                  newQuestions[questionLength]?.HINT
                : "Question Not found"}
            </Typography>
            {(
              (QuestionDetails && QuestionDetails[questionLength]?.CHOICE) ||
              newQuestions[questionLength]?.CHOICE ||
              []
            ).map((choice: any, index: number) => {
              const currentQuestion =
                (QuestionDetails && QuestionDetails[questionLength]) ||
                newQuestions[questionLength];
              const isMultipleAnswer =
                currentQuestion.TYPE === "Multiple Answer";

              const isSelected = isMultipleAnswer
                ? (Answers[questionLength]?.length &&
                    Answers[questionLength][index]?.ChoiceID ===
                      choice?.ChoiceID) ||
                  (selectedAnswers[questionLength]?.length &&
                    selectedAnswers[questionLength][index]?.ChoiceID ===
                      choice?.ChoiceID)
                : (Answers[questionLength] || selectedAnswers[questionLength])
                    ?.ChoiceID === choice?.ChoiceID;

              return (
                <React.Fragment key={choice.ChoiceID}>
                  <TextBox>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      {isMultipleAnswer ? (
                        <Checkbox
                          checked={isSelected}
                          onChange={() =>
                            handleAnswerSelection(choice, questionLength, true)
                          }
                          inputProps={{ "aria-label": `choice-${index}` }}
                          disabled={
                            isSubmitted[questionLength] ||
                            SubmittedAnswers[questionLength]

                            // ||
                            // Answers[questionLength]
                          }
                        />
                      ) : (
                        <Radio
                          checked={isSelected}
                          onChange={() =>
                            handleAnswerSelection(choice, questionLength, false)
                          }
                          name="radio-buttons"
                          inputProps={{ "aria-label": `choice-${index}` }}
                          disabled={
                            isSubmitted[questionLength] ||
                            SubmittedAnswers[questionLength]

                            // ||
                            // Answers[questionLength]
                          }
                        />
                      )}
                      <Typography
                        sx={{
                          fontSize: "14px",
                          fontWeight: 400,
                          color: "#3F3F40",
                        }}
                      >
                        {ReactHtmlParser(choice.Choice)}
                      </Typography>
                    </Box>
                  </TextBox>
                  <Divider />
                </React.Fragment>
              );
            })}
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              padding: "30px",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <CustomButton
              name={"View Instructions"}
              variant="secondary"
              padding="3px 5px 3px 5px"
              onClick={handleNavigate}
            />
            <CustomButton
              name={"Submit Answer"}
              variant="primary"
              padding="3px 5px 3px 5px"
              onClick={() =>
                handleSubmitAnswer(
                  questionLength,
                  (QuestionDetails &&
                    QuestionDetails[questionLength].TYPE ===
                      "Multiple Answer") ||
                    (newQuestions &&
                      newQuestions[questionLength].TYPE === "Multiple Answer")
                    ? true
                    : false
                )
              }
              disabled={
                isSubmitted[questionLength] || SubmittedAnswers[questionLength]
              }
            />
            <Box>
              <CustomIconButton
                icon={ArrowBackIosIcon}
                variant="primary"
                iconSize={15}
                padding={"15px"}
                onClick={handleClickToPrev}
                disable={questionLength === 0}
              />
              &nbsp;&nbsp;&nbsp;
              <CustomIconButton
                icon={ArrowForwardIosIcon}
                iconSize={15}
                variant="primary"
                padding={"15px"}
                onClick={handleClickToNext}
              />
            </Box>
          </Box>
        </TitleBox>
      ) : (
        <Typography className="welcome-title">Assessment not found</Typography>
      )}
    </div>
  );
};

export default FinalQuestions;

const TitleBox = styled(Box)`
  background-color: #f5f5f5;
  padding: 15px;
  border-radius: 7px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;

const ModuleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  margin-top: 10px;
  justify-content: space-between;
`;

const QuestionBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 10px;
  background-color: #2a62aa;
  align-items: center;
  padding: 16px;
`;
const SubQuestionBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-evenly;
  align-items: center;
`;

const TextBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
`;
