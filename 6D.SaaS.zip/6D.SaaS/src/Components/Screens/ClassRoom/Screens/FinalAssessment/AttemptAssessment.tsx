import React, { FC, useEffect } from "react";
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import styled from "styled-components";
import CustomButton from "../../../../Button/CustomButton";
import { useDispatch, useSelector } from "react-redux";
import { cookies, instance } from "../../../../../Controller/Common";
import { RootState } from "../../../../../Store/UserSlice";
import {
  CleaRassessmentTimer,
  ClearFinalAssessmentAttempt,
  FinalAssessmentTimer,
  getFinalAssessment,
  getFinalAssessmentAID,
  getFinalAssessmentAttempt,
  getFinalAssessmentDetails,
} from "../../../../../Store/ClassroomSlice";
import { useNavigate } from "react-router-dom";
import ReactHtmlParser from "react-html-parser";

interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
    topic: any;
    assessmentQuestion: any;
    topicIndex: number;
    module: any;
    moduleIndex: number;
    assessmentIndex: number;
    finalAssessmentAID: number;
    finalAssessmentAttempt: any;
    finalAssessmentQuestionDetails: any;
    finalAssessmentDetails: any;
    finalAssessmentDetailsStatus: any;
  };
}
interface ModuleAccordionProps {
  setHide: (value: boolean) => void;
  setNext: React.Dispatch<React.SetStateAction<number>>;
  setQuestionLength: (value: any) => void;
  setNextPage: React.Dispatch<React.SetStateAction<number>>;
  nextPage: number;
}

const AttemptAssessment: FC<ModuleAccordionProps> = ({
  setHide,
  setNext,
  setQuestionLength,
  setNextPage,
  nextPage,
}) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const value = useSelector((state: StateType) => state.classRoom.value);
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse
  );
  const FA_Details = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentDetails
  );
  const finalStatus = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentDetailsStatus
  );
  const finalAssessmentName = FA_Details.NAME;
  const finalAssessmentAid = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentAID
  );
  const finalAttempts = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentQuestionDetails
  );
  const finalAssessmentAttempt = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentAttempt
  );
  const userId =
    useSelector((state: RootState) => state.user.userID) ??
    cookies.get("userId");

  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);

  const GetQuestionAttempts = async () => {
    try {
      const response = await instance.get(
        `/6D/assessment/getResultForFinalAssessment?CID=${rootCourse[0]?.courseDetails?.CID}&UID=${userId}`
      );
      if (response.status === 200) {
        // const count = response.data.reduce((acc: any, i: any) => {
        //   return i.STATUS === "COMPLETED" ? acc + 1 : acc;
        // }, 1);
        // dispatch(getFinalAssessmentAttempt(count));
      }
    } catch (error) {
      console.log(error);
    }
  };

  const GetReAttemptsQuestion = async () => {
    try {
      const response = await instance.get(
        `/6D/assessment/reAttemptFinalAssessment?CID=${rootCourse[0]?.courseDetails?.CID}&UID=${userId}&AID=${finalAssessmentAid}`
      );
      if (response.status === 200) {
        dispatch(getFinalAssessmentDetails(response.data[0]));
        dispatch(getFinalAssessmentAID(response.data[0]?.AID));
        dispatch(getFinalAssessment(null));
        setQuestionLength(0);
        dispatch(getFinalAssessmentAttempt(finalAssessmentAttempt + 1));
        dispatch(FinalAssessmentTimer(0));
        setNextPage(3);
        dispatch(CleaRassessmentTimer());
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleReAttempt = () => {
    GetReAttemptsQuestion();
    setNextPage(3);
  };
  const handleNavigate = () => {
    navigate("/landing/certification?tab=1");
    dispatch(ClearFinalAssessmentAttempt())
  };

  useEffect(() => {
    GetQuestionAttempts();
  }, []);

  return (
    <div>
      <TitleBox>
        <Typography
           sx={{
            fontWeight: 400,
            fontSize: "11px",
            color: "#3F3F40",
            paddingLeft: "20px",
          }}
        >
          {rootCourse[0]?.courseDetails?.TITLE || "Course Title Not Found"}
        </Typography>
        <ModuleBox>
          <Typography
            sx={{
              fontWeight: 400,
              fontSize: "14px",
              color: "#2A62AA",
              paddingLeft: "20px",
            }}
          >
            {finalAssessmentName}
          </Typography>
        </ModuleBox>
        <QuestionBox>
          <SubQuestionBox>
            <Typography
              sx={{
                fontWeight: 600,
                fontSize: "14px",
                color: "#E5E5E5",
                marginRight: "20px",
              }}
            >
              Final Assessment
            </Typography>
          </SubQuestionBox>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-evenly",
            }}
          >
            <Typography
              sx={{
                fontWeight: 600,
                fontSize: "14px",
                color: "#E5E5E5",
                marginRight: "20px",
              }}
            >
              Time Taken &nbsp;&nbsp;{" "}
              {finalAttempts[finalAssessmentAttempt - 1]?.timeTaken}
            </Typography>
            <Typography
              sx={{
                fontWeight: 600,
                fontSize: "14px",
                color: "#E5E5E5",
                marginRight: "20px",
              }}
            >
              Attempt: {finalAssessmentAttempt}/{finalStatus.attemptLength}
            </Typography>
          </Box>
        </QuestionBox>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            padding: "20px 20px 100px 20px",
            backgroundColor: "#FFFFFF",
          }}
        >
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 600,
              padding: "5px 0px 5px 0px",
            }}
          >
            Attempt & Re-attempt
          </Typography>
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              padding: "5px 0px 5px 0px",
            }}
          >
            {ReactHtmlParser(FA_Details.attempt_instructions)}
          </Typography>
          <br />
          <br />
          <Box sx={{ padding: "10px 100px 10px 100px" }}>
            <TableContainer sx={{ overflowY: "auto", maxHeight: 250 }}>
              <Table stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell
                      align={"center"}
                      sx={{
                        bgcolor: "#F5F5F5",
                        minWidth: 200,
                        border: "none",
                      }}
                    >
                      {"Attempts Taken"}
                    </TableCell>
                    <TableCell
                      align={"center"}
                      sx={{
                        bgcolor: "#F5F5F5",
                        minWidth: 200,
                        border: "none",
                      }}
                    >
                      {"Final Score"}
                    </TableCell>
                    <TableCell
                      align={"center"}
                      sx={{
                        bgcolor: "#F5F5F5",
                        minWidth: 200,
                        border: "none",
                      }}
                    >
                      {"Cut-off Score"}
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {finalAttempts &&
                    finalAttempts.map((e: any, i: number) => (
                      <TableRow key={i}>
                        <TableCell align="center" sx={{ border: "none" }}>
                          {e.STATUS === "COMPLETED" ? `${i + 1}` : null}
                        </TableCell>
                        <TableCell align="center" sx={{ border: "none" }}>
                        {e.STATUS === "COMPLETED" ? (e.FINAL_SCORE === 0 ? e.FINAL_SCORE : `${e.FINAL_SCORE}%`) : null}
                        </TableCell>
                        <TableCell align="center" sx={{ border: "none" }}>
                          {e.STATUS === "COMPLETED" ?`${ e.CUT_OFF}%` : null}
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              marginTop: "20px",
            }}
          >
            {finalAttempts?.some(
              (attempt: any) =>
                attempt.STATUS === "COMPLETED" &&
                attempt.FINAL_SCORE >= attempt.CUT_OFF
            ) ? (
              <Typography
                sx={{
                  color: "#48A055",
                  fontWeight: 600,
                  fontSize: "14px",
                  width: "50%",
                  textAlign: "center",
                }}
              >
                “Congratulations! You passed the final assessment on your {finalAssessmentAttempt}
                &nbsp; attempt. Keep up the great work!”
              </Typography>
            ) : finalAssessmentAttempt >= finalStatus.attemptLength ? (
              <Typography
                sx={{
                  color: "#D32F2F",
                  fontWeight: 600,
                  fontSize: "14px",
                  textAlign: "center",
                  width: "50%",
                }}
              >
                Unfortunately, you did not meet the pass cut-off after{" "}
                {finalStatus.attemptLength} attempts. You have failed!
              </Typography>
            ) : (
              <Typography
                sx={{
                  color: "#D32F2F",
                  fontWeight: 600,
                  fontSize: "14px",
                  textAlign: "center",
                  width: "50%",
                }}
              >
                You did not meet the pass cut-off in your{" "}
                {finalAssessmentAttempt} attempt. Don't worry, you have{" "}
                {finalStatus.attemptLength - finalAssessmentAttempt} more
                attempts to improve your score!
              </Typography>
            )}
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              marginTop: "20px",
            }}
          >
            {finalAttempts?.some(
              (attempt: any) =>
                attempt.STATUS === "COMPLETED" &&
                attempt.FINAL_SCORE >= attempt.CUT_OFF
            ) || finalAssessmentAttempt >= finalStatus.attemptLength ? (
              <CustomButton
                name={"Exit Final Assessment"}
                variant="primary"
                padding={"5px 10px 5px 10px"}
                onClick={handleNavigate}
              />
            ) : (
              <CustomButton
                name={"Re-Attempt"}
                variant="primary"
                padding={"5px 10px 5px 10px"}
                onClick={handleReAttempt}
              />
            )}
          </Box>
        </Box>
      </TitleBox>
    </div>
  );
};

export default AttemptAssessment;

const TitleBox = styled(Box)`
  background-color: #f5f5f5;
  padding: 15px;
  border-radius: 7px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;

const ModuleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  margin-top: 10px;
  justify-content: space-between;
`;

const QuestionBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 10px;
  background-color: #2a62aa;
  align-items: center;
  padding: 16px;
`;
const SubQuestionBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-evenly;
  align-items: center;
`;
