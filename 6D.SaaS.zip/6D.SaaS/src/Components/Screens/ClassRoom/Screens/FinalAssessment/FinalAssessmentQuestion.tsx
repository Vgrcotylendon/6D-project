import React, { FC, useEffect, useRef } from "react";
import { Box, Typography } from "@mui/material";
import styled from "styled-components";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import CustomButton from "../../../../Button/CustomButton";
import { useDispatch, useSelector } from "react-redux";
import FinalQuestions from "./FinalQuestions";
import { RootState } from "../../../../../Store/UserSlice";
import { instance } from "../../../../../Controller/Common";
import {
  FinalAssessmentTimer,
  getFinalAssessment,
} from "../../../../../Store/ClassroomSlice";
import ReactHtmlParser from "react-html-parser";

interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
    topic: any;
    assessmentQuestion: any;
    topicIndex: number;
    module: any;
    moduleIndex: number;
    assessmentIndex: number;
    finalAssessmentAID: number;
    finalAssessmentDetails: any;
    finalAssessmentAttempt: any;
    finalAssessmentDetailsStatus: any;
    timer: any;
  };
}

interface ModuleAccordionProps {
  questionLength?: number;
  setQuestionLength?: (value: number) => void;
  GetAssessmentQuestiomDetails: (AID: number) => void;
  QuestionDetails: any[];
  finalAID?: number;
  nextPage?: number;
  assessment?: any;
  setHide?: (value: boolean) => void;
  setNext?: React.Dispatch<React.SetStateAction<number>>;
  setNextPage?: React.Dispatch<React.SetStateAction<number>>;
  courseDetails?: any[];
  index?: number | undefined;
  expand?: boolean;
}

const FinalAssessmentQuestion: FC<ModuleAccordionProps> = ({
  setHide,
  nextPage,
  GetAssessmentQuestiomDetails,
  questionLength,
  setQuestionLength,
  assessment,
  finalAID,
  QuestionDetails,
  index,
  setNext,
  courseDetails,
  setNextPage,
}) => {
  const [finalAssessmentQuestion, setFinalAssessmentQuestion] =
    React.useState();
  const value = useSelector((state: StateType) => state.classRoom.value);
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse
  );
  const finalStatus = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentDetailsStatus
  );
  const finalAssessmentAttempt = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentAttempt
  );
  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);
  const finalAssessmentAid = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentAID
  );
  const FA_Details = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentDetails
  );
  const finalAssessmentName = FA_Details.NAME;
  const userId = useSelector((state: RootState) => state.user.userID);

  const dispatch = useDispatch();

  const GetFinalAssessmentQuestiomDetails = async (id: any = null) => {
    try {
      const response = await instance.get(
        `/6D/map/getAssessment-Question-ByAID?AID=${
          finalAssessmentAid ?? QuestionDetails[0]?.AID
        }&userId=${userId}`
      );
      if (response.status === 200) {
        setQuestionLength && setQuestionLength(0);
        let data = response.data;
        dispatch(getFinalAssessment(data));
        setFinalAssessmentQuestion(data);
        setNextPage && setNextPage(4);
        return data;
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleAssementQuestionDetails = () => {
     GetFinalAssessmentQuestiomDetails();
    // setNextPage && setNextPage(4);
  };
  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600)
      .toString()
      .padStart(2, "0");
    const m = Math.floor((seconds % 3600) / 60)
      .toString()
      .padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${h}:${m}:${s}`;
  };

  const timerRef = useRef<number | null>(null);
  const timeTakenRef = useRef(0);

  const Timer = useSelector((state: StateType) => state.classRoom.timer);
  useEffect(() => {
    timeTakenRef.current = Timer;
  }, [Timer]);

  useEffect(() => {
    if (Timer !== 0) {
      timerRef.current = window.setInterval(() => {
        timeTakenRef.current += 1;
        dispatch(FinalAssessmentTimer(timeTakenRef.current));
      }, 1000);

      return () => stopTimer();
    }
  }, []);

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  return (
    <div>
      <>
        <TitleBox>
          <Typography
             sx={{
              fontWeight: 400,
              fontSize: "11px",
              color: "#3F3F40",
              paddingLeft: "20px",
            }}
          >
            {rootCourse[0]?.courseDetails?.TITLE || "Course Title Not Found"}
          </Typography>
          <ModuleBox>
            <Typography
             sx={{
              fontWeight: 400,
              fontSize: "14px",
              color: "#2A62AA",
              paddingLeft: "20px",
            }}
            >
              {finalAssessmentName}
            </Typography>
          </ModuleBox>
          <QuestionBox>
            <SubQuestionBox>
              <Typography
                sx={{
                  fontWeight: 600,
                  fontSize: "14px",
                  color: "#E5E5E5",
                  marginRight: "20px",
                }}
              >
                Final Assessment
              </Typography>
            </SubQuestionBox>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-evenly",
              }}
            >
              <Typography
                sx={{
                  fontWeight: 600,
                  fontSize: "14px",
                  color: "#E5E5E5",
                  marginRight: "20px",
                }}
              >
                Time Taken &nbsp;&nbsp;{" "}
                {formatTime(Timer) !== "00:00:00"
                  ? formatTime(Timer)
                  : "00:00:00"}
              </Typography>
              <Typography
                sx={{
                  fontWeight: 600,
                  fontSize: "14px",
                  color: "#E5E5E5",
                  marginRight: "20px",
                }}
              >
                Attempt: {finalAssessmentAttempt}/{finalStatus.attemptLength}
              </Typography>
            </Box>
          </QuestionBox>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              padding: "20px",
              backgroundColor: "#FFFFFF",
            }}
          >
            <Typography
              sx={{
                fontSize: "14px",
                fontWeight: 600,
                padding: "5px 0px 5px 0px",
              }}
            >
              Instruction
            </Typography>
            <Typography
              sx={{
                fontSize: "14px",
                fontWeight: 400,
                padding: "5px 0px 5px 0px",
              }}
            >
              {ReactHtmlParser(FA_Details.assessment_instructions)}
            </Typography>
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              padding: "30px",
              justifyContent: "flex-end",
              alignItems: "center",
            }}
          >
            <CustomButton
              name={"To Questions"}
              variant="primary"
              endIcon={<ArrowForwardIosIcon />}
              padding="10px"
              onClick={() => {
                handleAssementQuestionDetails();
                setQuestionLength && setQuestionLength(0);
              }}
            />
          </Box>
        </TitleBox>
        {nextPage === 4 && QuestionDetails && QuestionDetails.length > 0 ? (
          <FinalQuestions
            GetFinalAssessmentQuestiomDetails={
              GetFinalAssessmentQuestiomDetails
            }
            GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
            finalAID={finalAID}
            setNext={setNext}
            setHide={setHide}
            QuestionDetails={QuestionDetails}
            assessment={assessment}
            setNextPage={setNextPage}
            //  GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
          />
        ) : null}
      </>
    </div>
  );
};

export default FinalAssessmentQuestion;

const TitleBox = styled(Box)`
  background-color: #f5f5f5;
  padding: 15px;
  border-radius: 7px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;

const ModuleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  margin-top: 10px;
  justify-content: space-between;
`;

const QuestionBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 10px;
  background-color: #2a62aa;
  align-items: center;
  padding: 16px;
`;
const SubQuestionBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-evenly;
  align-items: center;
`;

