import React, { FC, useEffect, useRef } from "react";
import { Box,Typography } from "@mui/material";
import styled from "styled-components";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import CustomButton from "../../../../Button/CustomButton";
import { useDispatch, useSelector } from "react-redux";
import CustomIconButton from "../../../../Button/CustomIconButton";
import { cookies, instance } from "../../../../../Controller/Common";
import { RootState } from "../../../../../Store/UserSlice";
import {
  ClearAnswers,
  CleaRassessmentTimer,
  FinalAssessmentTimer,
  getFinalAssessmentAttempt,
  getFinalAssessmentQuestionDetails,
} from "../../../../../Store/ClassroomSlice";

interface StateType {
  classRoom: {
    value: number;
    enrolledCourse: any;
    topic: any;
    assessmentQuestion: any;
    topicIndex: number;
    module: any;
    moduleIndex: number;
    assessmentIndex: number;
    finalAssessment: any[];
    finalAssessmentAID: number;
    finalAssessmentAttempt: any;
    finalAssessmentDetails: any;
    finalAssessmentDetailsStatus: any;
    timer: any;
  };
}
interface ModuleAccordionProps {
  setQuestionLength: (value: any) => void;
  GetAssessmentQuestiomDetails?: (AID: number) => void;
  questionLength: any;
  displayTime?: any;
  setDisplayTime?: (value: any) => void;
  setHide: (value: boolean) => void;
  setNext: React.Dispatch<React.SetStateAction<number>>;
  setNextPage: React.Dispatch<React.SetStateAction<number>>;
  nextPage: number;
}

const SubmitAssessment: FC<ModuleAccordionProps> = ({
  setQuestionLength,
  setNextPage,
}) => {
  const dispatch = useDispatch();
  const [allQuestionsCompleted, setAllQuestionsCompleted] =
    React.useState(false);
  const [getStatus, setGetStatus] = React.useState<any>([]);
  const value = useSelector((state: StateType) => state.classRoom.value);
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse
  );
  const finalStatus = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentDetailsStatus
  );
  const FA_Details = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentDetails
  );
  const finalAssessmentName = FA_Details.NAME;
  const finalAssessmentAid = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentAID
  );
  const finalAssessmentAttempt = useSelector(
    (state: StateType) => state.classRoom.finalAssessmentAttempt
  );
  const newQuestions = useSelector(
    (state: StateType) => state.classRoom.finalAssessment
  );
  const userId =
    useSelector((state: RootState) => state.user.userID) ??
    cookies.get("userId");
  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600)
      .toString()
      .padStart(2, "0");
    const m = Math.floor((seconds % 3600) / 60)
      .toString()
      .padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${h}:${m}:${s}`;
  };
  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);

  const GetQuestionAttempts = async () => {
    try {
      const response = await instance.get(
        `/6D/assessment/getResultForFinalAssessment?CID=${rootCourse[0]?.courseDetails?.CID}&UID=${userId}`
      );
      if (response.status === 200) {
        dispatch(getFinalAssessmentQuestionDetails(response.data));
        const count = response.data.reduce((acc: any, i: any) => {
          return i.STATUS === "COMPLETED" ? acc + 1 : acc;
        }, 0);
        dispatch(getFinalAssessmentAttempt(count));
      }
    } catch (error) {
      console.log(error);
    }
  };

  const postFinalAssessmentAnswer = async () => {
    try {
      const response = await instance.post(
        `/6D/assessment/submitFinalAssessment?CID=${
          rootCourse[0]?.courseDetails?.CID
        }&UID=${userId}&AID=${finalAssessmentAid}&TimeTakenMins=${formatTime(Timer)}`
      );
      if (response.status === 200) {
        console.log("success");
        GetQuestionAttempts();
        dispatch(ClearAnswers());
        stopTimer();
        dispatch(CleaRassessmentTimer());     
      }
    } catch (error) {
      console.log(error);
    }
  };

  const GetQuestionStatus = async () => {
    try {
      const response = await instance.get(
        `/6D/assessment/getFinalAssessmentQuestionStatus?CID=${rootCourse[0]?.courseDetails?.CID}&UID=${userId}&AID=${finalAssessmentAid}`
      );
      if (response.status === 200) {
        setGetStatus(response.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleSumitAnswer = () => {
    setNextPage(6);
    postFinalAssessmentAnswer();
  };

  const handleClickToPrev = () => {
    setNextPage(4);
  };

  const mergedQuestions = newQuestions.map((question) => {
    const statusMatch = getStatus.find(
      (status: any) => status.QID === question.QID
    );
    return {
      ...question,
      status: statusMatch?.Status || "Not yet started",
    };
  });

  useEffect(() => {
    const allCompleted = mergedQuestions.every(
      (question) => question.status === "COMPLETED"
    );
    setAllQuestionsCompleted(allCompleted);
  }, [mergedQuestions]);

  const timerRef = useRef<number | null>(null);
  const timeTakenRef = useRef(0);

  const Timer = useSelector((state: StateType) => state.classRoom.timer);
  useEffect(() => {
    timeTakenRef.current = Timer;
  }, [Timer]);

  useEffect(() => {
    timerRef.current = window.setInterval(() => {
      timeTakenRef.current += 1;
      dispatch(FinalAssessmentTimer(timeTakenRef.current));
    }, 1000);

    return () => stopTimer();
  }, []);

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  useEffect(() => {
    GetQuestionStatus();
  }, []);

  return (
    <div>
      <TitleBox>
        <Typography
          sx={{
            fontWeight: 400,
            fontSize: "11px",
            color: "#3F3F40",
            paddingLeft: "20px",
          }}
        >
          {rootCourse[0]?.courseDetails?.TITLE || "Course Title Not Found"}
        </Typography>
        <ModuleBox>
          <Typography
            sx={{
              fontWeight: 400,
              fontSize: "14px",
              color: "#2A62AA",
              paddingLeft: "20px",
            }}
          >
            {finalAssessmentName}
          </Typography>
        </ModuleBox>
        <QuestionBox>
          <SubQuestionBox>
            <Typography
              sx={{
                fontWeight: 600,
                fontSize: "14px",
                color: "#E5E5E5",
                marginRight: "20px",
              }}
            >
              Final Assessment
            </Typography>
          </SubQuestionBox>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-evenly",
            }}
          >
            <Typography
              sx={{
                fontWeight: 600,
                fontSize: "14px",
                color: "#E5E5E5",
                marginRight: "20px",
              }}
            >
              Time Taken &nbsp;&nbsp; {formatTime(Timer)}
            </Typography>
            <Typography
              sx={{
                fontWeight: 600,
                fontSize: "14px",
                color: "#E5E5E5",
                marginRight: "20px",
              }}
            >
              Attempt: {finalAssessmentAttempt}/{finalStatus.attemptLength}
            </Typography>
          </Box>
        </QuestionBox>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            padding: "20px 20px 40px 20px",
            backgroundColor: "#FFFFFF",
          }}
        >
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 600,
              padding: "5px 0px 5px 0px",
            }}
          >
            Final Check
          </Typography>
          <Typography
            sx={{
              // marginTop: "10px",
              marginBottom: "10px",
              marginTop: "10px",
              fontWeight: 400,
              color: "#3F3F40",
              fontSize: "12px",
            }}
          >
            Note:&nbsp; Analyze the case study provided and respond with a
            well-structured analysis. Address the key issues, propose solutions,
            and back up your recommendations with appropriate office etiquette
            practices.
          </Typography>
          {mergedQuestions.map((question, index) => (
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
                borderBottom: "1px solid #f1eeee",
                padding: "10px",
              }}
            >
              <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                Question {index + 1}
              </Typography>
              <Box>
                {question.status === "COMPLETED" ? (
                  <CustomButton
                    name={"Answer Submitted"}
                    variant="secondary"
                    padding={"3px 5px 3px 5px"}
                    disabled
                  />
                ) : (
                  <CustomButton
                    name={"Submit Your Answer"}
                    variant="primary"
                    padding={"3px 5px 3px 5px"}
                    onClick={() => {
                      setQuestionLength(index);
                      setNextPage && setNextPage(4);
                    }}
                  />
                )}
              </Box>
            </Box>
          ))}
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            padding: "30px",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <CustomButton
            name={"View Instructions"}
            variant="secondary"
            padding="3px 5px 3px 5px"
            onClick={() => setNextPage(3)}
          />
          <CustomButton
            name={"Submit Final Assessment"}
            variant="primary"
            padding="3px 5px 3px 5px"
            onClick={handleSumitAnswer}
            disabled={!allQuestionsCompleted}
          />
          <Box>
            <CustomIconButton
              icon={ArrowBackIosIcon}
              variant="primary"
              iconSize={15}
              padding={"15px"}
              onClick={handleClickToPrev}
            />
            &nbsp;&nbsp;&nbsp;
            <CustomIconButton
              icon={ArrowForwardIosIcon}
              iconSize={15}
              variant="primary"
              padding={"15px"}
              disable
              // onClick={() => setNextPage(6)}
            />
          </Box>
        </Box>
      </TitleBox>
    </div>
  );
};

export default SubmitAssessment;

const TitleBox = styled(Box)`
  background-color: #f5f5f5;
  padding: 15px;
  border-radius: 7px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;

const ModuleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  margin-top: 10px;
  justify-content: space-between;
`;

const QuestionBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 10px;
  background-color: #2a62aa;
  align-items: center;
  padding: 16px;
`;
const SubQuestionBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-evenly;
  align-items: center;
`;

