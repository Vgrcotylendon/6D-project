import React from "react";
import { Box, Typography, IconButton } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import CustomButton from "../../Button/CustomButton";
interface TopicProps {
  setShow: React.Dispatch<React.SetStateAction<boolean>>;
}
const TopicAlertModal: React.FC<TopicProps> = ({ setShow }) => {
  return (
    <div>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: "#eff4f7",
          borderRadius: "10px",
          padding: "40px",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <IconButton
          size="small"
          onClick={() => setShow(false)}
          sx={{ position: "absolute", top: 8, right: 10 }}
        >
          <CloseIcon />
        </IconButton>

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            backgroundColor: "#FFFFFf",
            borderRadius: "10px",
            padding: "20px",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Typography
            sx={{
              fontWeight: 600,
              color: "#2A62AA",
              fontSize: "16px",
              p: "10px 10px 20px 10px",
            }}
          >
            Complete Module Requirements to Proceed
          </Typography>

          <Box
            sx={{
              backgroundColor: "#ccc9c9",
              height: "0.2px",
              width: "500px",
            }}
          />
          <Box
            sx={{
              p: "40px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              width: "450px",
              textAlign: "center",
            }}
          >
            <Typography
              sx={{
                color: "#3F3F40",
                fontWeight: 400,
                fontSize: "12px",
                lineHeight: "16.26px",
              }}
            >
              Please mark all topics as complete and finish the assessments in
              this module to unlock access to the next module.
            </Typography>
          </Box>
          <Box
            sx={{
              backgroundColor: "#ccc9c9",
              height: "0.2px",
              width: "500px",
            }}
          />
          <Box sx={{ marginTop: "20px" }}>
            <CustomButton
              name="OK"
              padding={"10px"}
              variant="primary"
              onClick={() => setShow(false)}
            />
          </Box>
        </Box>
      </Box>
    </div>
  );
};

export default TopicAlertModal;
