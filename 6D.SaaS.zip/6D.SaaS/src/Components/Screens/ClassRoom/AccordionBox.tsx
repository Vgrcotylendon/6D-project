import { Card, Box, Typography, Button, LinearProgress } from "@mui/material";
import React from "react";
import styled from "styled-components";
import { useDispatch, useSelector } from "react-redux";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import PendingIcon from "@mui/icons-material/Pending";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AccordionImage from "../../../Assets/interviewImage.png";
import ModuleAccordion from "./ModuleAccordion";
import NotStartedIcon from "@mui/icons-material/NotStarted";
import CustomButton from "../../Button/CustomButton";
import {clearGetTopicAssessmentDetails} from "../../../Store/ClassroomSlice";
import { ImageUrl } from "../../../Controller/Common";

interface Course {
  id: number;
  CourseTitle: string;
  TimeSpent: string;
  status: string;
}
interface CourseProps {
  selectedTopicIndex: number;
  selectedTopicContent: any;
  moduleIndex: number;
  GetTopicContentDetails: (cid: number, mid: number, tid: number) => void;
  selectedCourse?: Course | null;
  courseDetails: any[];
  assessmentDetails: any[];
  topicDetails: any[];
  checked: boolean[];
  topicContentDetails: {
    TID: number;
    NAME: string;
    CONTENT: string;
    CONTENT_TYPE: string;
    METADATA: string;
    UT_ID: number;
    PROGRESS: string;
    STATUS: string;
    CID: number;
    MID: number;
  };
  expandedIndex: any;
  ContinueToLast: () => void;
  handleAssementDetails: (
    assessment: any,
    idx: number | undefined,
    module: any,
    AID: number,
  ) => void;
  handleTopicDetatils: (
    content: any,
    topic: any,
    idx: number,
    module: any,
    index: number,
    cid: number,
    tid: number,
    mid: number,
  ) => void;
  GetCourseDetails:()=>void;
  setModuleIndex: (value: any) => void;
  // GetAllcourseDetails: () => void;
  GetAssessmentQuestiomDetails: (AID: number) => void;
  handleExpansion: (index: number, moduleId: string) => void;
  nextPage: number;
  setOpen: (value: boolean) => void;
  GetTopicDetails: (moduleId: string) => void;
  setSelectedAssessmentDetails: (assessment: any) => void;
  selectedTopic: any;
  setTopicContentDetails: React.Dispatch<React.SetStateAction<any>>;
  setAssessmentDetails: React.Dispatch<React.SetStateAction<any>>;
  setQuestionDetails: React.Dispatch<React.SetStateAction<any>>;
  selectedModuleName: any;
  selectedAssessmentDetails: any;
  selectedTopicDetails: any;
  selectedAssesment: any;
  selectedFinalAssesment: any;
  QuestionDetails: any[];
  hide: boolean;
  setHide: (value: boolean) => void;
  setNextPage: React.Dispatch<React.SetStateAction<number>>;
  setNext: React.Dispatch<React.SetStateAction<number>>;
  setSelectedTopicDetails: (topic: any) => void;
  next: number;
  topicLength: any;
  completedTopic: any;
  selectedCourseTitle: any;
  setExpand: (value: boolean) => void;
  expand: boolean;
}
interface StateType {
  classRoom: {
    MID: number;
    AID: number;
    value: number;
    enrolledCourse: any;
    topic: any;
    topicIndex: number;
    module: any;
    moduleIndex: number;
    finalAssessment: any;
    finalAssessmentIndex: number;
  };
}
const AccordionBox: React.FC<CourseProps> = ({
  setExpand,
  setModuleIndex,
  GetCourseDetails,
  GetAssessmentQuestiomDetails,
  expand,
  selectedCourseTitle,
  topicContentDetails,
  topicDetails,
  selectedTopicContent,
  setQuestionDetails,
  setTopicContentDetails,
  setSelectedTopicDetails,
  GetTopicDetails,
  // GetAllcourseDetails,
  setAssessmentDetails,
  setNext,
  ContinueToLast,
  next,
  setOpen,
  assessmentDetails,
  selectedTopicDetails,
  selectedAssessmentDetails,
  setSelectedAssessmentDetails,
  selectedModuleName,
  selectedFinalAssesment,
  expandedIndex,
  moduleIndex,
  QuestionDetails,
  selectedTopicIndex,
  courseDetails,
  handleExpansion,
  handleAssementDetails,
  GetTopicContentDetails,
  handleTopicDetatils,
  nextPage,
  selectedTopic,
  selectedAssesment,
  setHide,
  hide,
  setNextPage,
}) => {
  const value = useSelector((state: StateType) => state.classRoom.value);
  const enrolledCourse = useSelector(
    (state: StateType) => state.classRoom.enrolledCourse
  );
  const dispatch = useDispatch();
  const rootCourse = enrolledCourse.filter((i: any) => i.CID === value);

  const totalTasks = courseDetails[0]?.TaskDetails.reduce(
    (acc: { noOfTasks: number; noOfCompletedTasks: number }, task: any) => {
      acc.noOfTasks += task.noOfTasks;
      acc.noOfCompletedTasks += task.noOfCompletedTasks;
      return acc;
    },
    { noOfTasks: 0, noOfCompletedTasks: 0 }
  );
  if (courseDetails[0]?.FinalAssessment?.length > 0) {
    totalTasks.noOfTasks += courseDetails[0].FinalAssessment.length;
    totalTasks.noOfCompletedTasks += courseDetails[0].FinalAssessment.filter(
      (assessment: any) => assessment.Status === "COMPLETED"
    ).length;
  }


const modules = courseDetails[0]?.Module || [];
let totalMinutes = 0;

modules.forEach((module: any) => {
  const duration = module.DURATION;

  if (duration && duration.includes("hrs") && duration.includes("min")) {
    const timeParts = duration.split(" ");
    const hours = parseInt(timeParts[0]) || 0; 
    const minutes = parseInt(timeParts[2]) || 0; 

    totalMinutes += (hours * 60) + minutes;
  }
});

const totalHours = Math.floor(totalMinutes / 60);
const remainingMinutes = totalMinutes % 60;

  return (
    <>
      {hide && next === 0 && (
        <>
          <MainCard>
            <MainBox>
              <SubBox1>
                <Typography
                  sx={{ fontWeight: 600, color: "#FFFFFF", fontSize: "14px" }}
                >
                  {selectedCourseTitle ||
                    rootCourse[0]?.courseDetails?.TITLE ||
                    "No Data Found"}
                </Typography>
              </SubBox1>
              <SubBox2>
                <HeaderBox>
                  <ImageBox>
                    <img
                      src={`${ImageUrl}${courseDetails[0].THUMBNAIL}` || AccordionImage}
                      alt="AccordionImage"
                      style={{
                        width: "200px",
                        height: "150px",
                        // maxWidth: "200px",
                        // marginRight: "10px",
                      }}
                    />
                  </ImageBox>
                  <ColumnBox>
                    <Box>
                      <Typography
                        sx={{
                          color: "#656566",
                          fontSize: "14px",
                          fontWeight: 400,
                          width: "90%",
                        }}
                      >
                        {" "}
                        {courseDetails[0]?.DESCRIPTION
                          ? courseDetails[0]?.DESCRIPTION
                          : "not found"}
                      </Typography>
                    </Box>
                    <RowBox1>
                      <Typography
                        sx={{
                          color: "#3F3F40",
                          fontSize: "14px",
                          fontWeight: 600,
                        }}
                      >
                        Author{" "}
                      </Typography>
                      &nbsp;&nbsp;
                      <Typography
                        sx={{
                          color: "#656566",
                          fontSize: "14px",
                          fontWeight: 400,
                        }}
                      >
                        {courseDetails[0]?.AUTHOR
                          ? courseDetails[0]?.AUTHOR
                          : "not found"}
                      </Typography>
                    </RowBox1>
                  </ColumnBox>
                </HeaderBox>
                <FlexBox>
                  <RowBox>
                    <TimeBox>
                      <AccessTimeIcon
                        style={{ color: "#656566", fontSize: "30px" }}
                      />
                      &nbsp;&nbsp;
                      <TextBox>
                        <Typography
                          sx={{
                            fontSize: "12px",
                            fontWeight: 500,
                            color: "#656566",
                            width:"100px"
                          }}
                        >
                          Estimated Time
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: "10px",
                            fontWeight: 400,
                            color: "#656566",
                            width:"100px"
                          }}
                        >
                          {/* {courseDetails[0]?.DURATION
                            ? formatDuration(courseDetails[0]?.DURATION)
                            : "not found"} */} {`${totalHours} hrs ${remainingMinutes} min`}
                        </Typography>
                      </TextBox>
                    </TimeBox>
                    <PendingBox>
                      {courseDetails[0]?.STATUS === "COMPLETED" ? (
                        <CheckCircleIcon
                          style={{ color: "green", fontSize: "30px" }}
                        />
                      ) : courseDetails[0]?.STATUS === "Not Started" ? (
                        <NotStartedIcon
                          style={{ fontSize: "30px", color: "#656566" }}
                        />
                      ) : (
                        <PendingIcon
                          style={{ color: "#EF5C00", fontSize: "30px" }}
                        />
                      )}
                      &nbsp;&nbsp;
                      <TextBox>
                        <Typography
                          sx={{
                            fontSize: "12px",
                            fontWeight: 500,
                            color: "#656566",
                            width:"80px"
                          }}
                        >
                          {courseDetails[0]?.STATUS === "COMPLETED"
                            ? "Complete"
                            : courseDetails[0]?.STATUS || "Status not found"}
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: "10px",
                            fontWeight: 400,
                            color: "#656566",
                            width:"130px"
                          }}
                        >
                          {" "}
                          {totalTasks?.noOfCompletedTasks || 0} of{" "}
                          {totalTasks?.noOfTasks || 0} tasks completed
                        </Typography>
                      </TextBox>
                    </PendingBox>
                  </RowBox>
                  <ProgressBox>
                    <Typography sx={{fontSize:"12px",fontWeight:500,color:"#656566"}}>Progress</Typography>
                    <CustomLinear
                      variant="determinate"
                      color="secondary"
                      value={courseDetails[0]?.PROGRESS || 0}
                    />
                    &nbsp;
                    <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>
                      {Math.round(courseDetails[0]?.PROGRESS)}%
                    </Typography>
                  </ProgressBox>
                  <ButtonBox>
                    <CustomButton
                      name={
                        courseDetails[0]?.STATUS === "COMPLETED"
                          ? "Completed"
                          : "Continue"
                      }
                      variant={"primary"}
                      disabled={courseDetails[0]?.STATUS === "COMPLETED"}
                      padding="8px 20px"
                      onClick={() => ContinueToLast()}
                    />
                  </ButtonBox>
                </FlexBox>
              </SubBox2>
            </MainBox>
          </MainCard>
          <ButtonBox2>
            <Button
              variant="text"
              sx={{ textTransform: "none", color: "#2A62AA",cursor:"pointer" ,fontSize:"12px"}}
              onClick={() => {
                dispatch(clearGetTopicAssessmentDetails());
                setExpand(!expand);
                setOpen(false);
              }}
            >
              {expand ? "Collapse All" : "Expand All"}
            </Button>
          </ButtonBox2>
        </>
      )}
      <ModuleAccordion
        GetCourseDetails={GetCourseDetails}
        // GetAllcourseDetails={GetAllcourseDetails}
        setModuleIndex={setModuleIndex}
        GetAssessmentQuestiomDetails={GetAssessmentQuestiomDetails}
        setExpand={setExpand}
        expand={expand}
        setOpen={setOpen}
        setQuestionDetails={setQuestionDetails}
        GetTopicContentDetails={GetTopicContentDetails}
        setAssessmentDetails={setAssessmentDetails}
        GetTopicDetails={GetTopicDetails}
        setSelectedTopicDetails={setSelectedTopicDetails}
        setTopicContentDetails={setTopicContentDetails}
        selectedTopicContent={selectedTopicContent}
        topicContentDetails={topicContentDetails}
        moduleIndex={moduleIndex}
        selectedTopicIndex={selectedTopicIndex}
        handleExpansion={handleExpansion}
        handleTopicDetatils={handleTopicDetatils}
        handleAssementDetails={handleAssementDetails}
        selectedAssessmentDetails={selectedAssessmentDetails}
        setSelectedAssessmentDetails={setSelectedAssessmentDetails}
        selectedModuleName={selectedModuleName}
        QuestionDetails={QuestionDetails}
        expandedIndex={expandedIndex}
        topicDetails={topicDetails}
        assessmentDetails={assessmentDetails}
        nextPage={nextPage}
        selectedTopicDetails={selectedTopicDetails}
        selectedTopic={selectedTopic}
        selectedAssesment={selectedAssesment}
        selectedFinalAssesment={selectedFinalAssesment}
        courseDetails={courseDetails}
        hide={hide}
        setHide={setHide}
        setNext={setNext}
        setNextPage={setNextPage}
      />
    </>
  );
};

export default AccordionBox;

const MainCard = styled(Card)`
  display: flex;
  padding: 30px 50px 30px 30px;
  box-shadow: none !important;
  margin-bottom: 0px;
`;
const FlexBox = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: inherit;
`;

const TextBox = styled(Box)`
  display: flex;
  flex-direction: column;
  margin-left: 1px;
`;

const ButtonBox = styled(Box)`
  display: flex;
  justify-content: flex-end;
`;

const ButtonBox2 = styled(Box)`
  display: flex;
  justify-content: flex-end;
  margin-bottom: 20px;
`;
const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  width: 100%;
`;
const SubBox1 = styled(Box)`
  padding: 10px;
  border-radius: 5px;
  background-color: #2a62aa;
  width: 100%;
`;
const SubBox2 = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 10px;
  width: 100%;
`;
const ImageBox = styled(Box)`
  background-color: #e7f3f0;
  width: 200px;
  height: 150px;
  flex-shrink: 0;
`;
const TimeBox = styled(Box)`
  display: flex;
  align-items: center;
`;
const PendingBox = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-left: 10px;
`;
const CustomLinear = styled(LinearProgress)`
  padding: 2px;
  width: 100%;
  height: 80px;
  margin: 5px;
  border-radius: 7px;
  & .MuiLinearProgress-bar {
    background-color: ${(props) => (props.value === 100 ? "green" : "#ef5c00")};
  }
`;
const RowBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;
const ProgressBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;

const ColumnBox = styled(Box)`
  display: flex;
  flex-direction: column;
  margin-left: 18px;
  justify-content: space-between;
  padding: 6px 6px 6px 0px;
`;
const HeaderBox = styled(Box)`
  display: flex;
  flex-direction: row;
`;
const RowBox1 = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
`;
