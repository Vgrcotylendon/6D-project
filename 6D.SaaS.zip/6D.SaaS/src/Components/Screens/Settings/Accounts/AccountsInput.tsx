import { Box, Grid, IconButton, Typography } from "@mui/material";
import React from "react";
import styled from "styled-components";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";

const listSetting = {
  Password: "12345576824648757978089",
  email: "tsvinith@gmail.com",
  phone: "+919486810773",
  Language: "English (US)",
  timezone: "(UTC-600) Central Time (US & Canada)",
};

const AccountsInput: React.FC = () => {
  const [showPassword, setShowPassword] = React.useState(false);
  const [showEmail, setShowEmail] = React.useState(false);
  const [showPhone, setShowPhone] = React.useState(false);
  const [showLanguage, setShowLanguage] = React.useState(false);
  const [showTimezone, setShowTimezone] = React.useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleClickShowEmail = () => setShowEmail((show) => !show);
  const handleClickShowPhone = () => setShowPhone((show) => !show);
  const handleClickShowLanguage = () => setShowLanguage((show) => !show);
  const handleClickShowTimezone = () => setShowTimezone((show) => !show);

  const handleMouseDown = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
  };

  return (
    <>
      <MainBox>
        <TitleBox>Account Settings</TitleBox>
        <Grid container spacing={1}>
          <Grid item xs={12} sm={12}>
            <TextBox>
              <InputBox>
                <Typography sx={{ fontWeight: 600 }}>Password</Typography>
                <StyledInput
                  value={listSetting.Password}
                  type={showPassword ? "text" : "password"}
                  readOnly
                />
              </InputBox>
              <IconBox>
                <IconButton
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDown}
                >
                  {showPassword ? <Visibility /> : <VisibilityOff />}
                </IconButton>
              </IconBox>
            </TextBox>
          </Grid>
          <Grid item xs={12} sm={12}>
            <TextBox>
              <InputBox>
                <Typography sx={{ fontWeight: 600 }}>Email Address</Typography>
                <StyledInput
                  value={listSetting.email}
                  type={showEmail ? "text" : "password"}
                  readOnly
                />
              </InputBox>
              <IconBox>
                <IconButton
                  onClick={handleClickShowEmail}
                  onMouseDown={handleMouseDown}
                >
                  {showEmail ? <Visibility /> : <VisibilityOff />}
                </IconButton>
              </IconBox>
            </TextBox>
          </Grid>
          <Grid item xs={12} sm={12}>
            <TextBox>
              <InputBox>
                <Typography sx={{ fontWeight: 600 }}>Phone Number</Typography>
                <StyledInput
                  value={listSetting.phone}
                  type={showPhone ? "text" : "password"}
                  readOnly
                />
              </InputBox>
              <IconBox>
                <IconButton
                  onClick={handleClickShowPhone}
                  onMouseDown={handleMouseDown}
                >
                  {showPhone ? <Visibility /> : <VisibilityOff />}
                </IconButton>
              </IconBox>
            </TextBox>
          </Grid>
          <Grid item xs={12} sm={12}>
            <TextBox>
              <InputBox>
                <Typography sx={{ fontWeight: 600 }}>Language</Typography>
                <StyledInput
                  value={listSetting.Language}
                  type={showLanguage ? "text" : "password"}
                  readOnly
                />
              </InputBox>
              <IconBox>
                <IconButton
                  onClick={handleClickShowLanguage}
                  onMouseDown={handleMouseDown}
                >
                  {showLanguage ? <Visibility /> : <VisibilityOff />}
                </IconButton>
              </IconBox>
            </TextBox>
          </Grid>
          <Grid item xs={12} sm={12}>
            <TextBox>
              <InputBox>
                <Typography sx={{ fontWeight: 600 }}>Time Zone</Typography>
                <StyledInput
                  value={listSetting.timezone}
                  type={showTimezone ? "text" : "password"}
                  readOnly
                />
              </InputBox>
              <IconBox>
                <IconButton
                  onClick={handleClickShowTimezone}
                  onMouseDown={handleMouseDown}
                >
                  {showTimezone ? <Visibility /> : <VisibilityOff />}
                </IconButton>
              </IconBox>
            </TextBox>
          </Grid>
        </Grid>
      </MainBox>
    </>
  );
};

export default AccountsInput;

const MainBox = styled(Box)`
  border: 2px solid white;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  padding: 30px;
  margin-top: 4rem;
`;
const TitleBox = styled(Box)`
  font-weight: 600;
  margin-bottom: 30px;
`;
const TextBox = styled(Box)`
  background-color: white;
  border-radius: 5px 5px 0 0;
  padding: 10px 20px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`;
const InputBox = styled(Box)`
  display: flex;
  flex-direction: column;
  width: 100%;
`;
const IconBox = styled(Box)`
  display: flex;
  flex-direction: column;
`;
const StyledInput = styled.input`
  border: none;
  outline: none;
  padding: 5px;
  font-size: 1rem;
  width: 100%;
`;
