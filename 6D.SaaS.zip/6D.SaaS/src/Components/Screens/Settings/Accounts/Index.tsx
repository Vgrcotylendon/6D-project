import { Container } from '@mui/material'
import React from 'react'
import AccountsInput from './AccountsInput'
import DeleteAccount from './DeleteAccount'

const Account:React.FC = () => {
  return (
    <Container maxWidth="xl">
     <AccountsInput/>
     <DeleteAccount/>
    </Container>
  )
}

export default Account