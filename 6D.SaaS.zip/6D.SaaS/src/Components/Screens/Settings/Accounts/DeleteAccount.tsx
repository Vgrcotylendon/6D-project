import React, { useState, ChangeEvent } from "react";
import { Box, Typography } from "@mui/material";
import styled from "styled-components";
import Checkbox from "@mui/material/Checkbox";
import CustomButton from "../../../Button/CustomButton";

const label = { inputProps: { "aria-label": "Checkbox demo" } };

const DeleteAccount: React.FC = () => {
  const [checked, setChecked] = useState<boolean>(false);

  const handleCheckboxChange = (event: ChangeEvent<HTMLInputElement>) => {
    setChecked(event.target.checked);
  };
  return (
    <MainBox>
      <Typography sx={{ fontWeight: 600, marginBottom: "10px" }}>
        DeleteAccount
      </Typography>
      <Typography sx={{ marginBottom: "20px" }}>
        When you delete your account,you lose access front account services and
        we permanently delete your personal data.You can cancel the deletion for
        14 days.
      </Typography>
      <CheckBox>
        <Checkbox
          {...label}
          checked={checked}
          onChange={handleCheckboxChange}
        />
        <Typography sx={{ fontSize: "14px" }}>
          Confirm that I want to delete my account.
        </Typography>
      </CheckBox>
      <Box>
      <CustomButton
          variant="secondary"
          name={"Learn More"}
          padding={"8px 14px"}
        />
        &nbsp;
        &nbsp;
         <CustomButton
          variant="secondary"
          name={"Delete Account"}
          padding={"8px 14px"}
        />
      </Box>
    </MainBox>
  );
};

export default DeleteAccount;

const MainBox = styled(Box)`
  border: 2px solid white;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  padding: 30px;
  margin-top: 2rem;
  margin-bottom: 3rem;
`;
const CheckBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
  margin-bottom: 20px;
`;
