import { Container } from "@mui/material";
import React from "react";
import PasswordInput from "./PasswordInput";

const MyPassword: React.FC = () => {
  return (
    <Container maxWidth="md">
      <PasswordInput />
    </Container>
  );
};

export default MyPassword;
