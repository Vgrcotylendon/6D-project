import React, { useEffect } from "react";
import { Box, Typography, Card, Grid } from "@mui/material";
import styled from "styled-components";
import ErrorIcon from "@mui/icons-material/Error";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useSelector } from "react-redux";
import CustomTextInput from "../../../Input/CustomTextInput";
import CustomButton from "../../../Button/CustomButton";
import { instance } from "../../../../Controller/Common";
import { RootState } from "../../../../Store/UserSlice";
import { useNavigate } from "react-router-dom";
import CustomModal from "../../../Modal/CustomModal";
import PasswordSuccessFullModal from "./PasswordSucessfullModal";

const PasswordInput: React.FC = () => {
  const navigate = useNavigate();
  const userId = useSelector((state: RootState) => state.user.userID);
  const [inputPassword, setInputPassword] = React.useState({
    newPassword: "",
    retypeNewPassword: "",
  });
  const [show, setShow] = React.useState(false);
  const mobileNumber = useSelector((state: RootState) => state.user.mobile);
  const googleLog = useSelector((state: RootState) => state.user.authType);
  const [userPassword, setUserPassword] = React.useState<string | undefined>();
  const [showNewPassword, setShowNewPassword] = React.useState(false);
  const [showReTypeNewPassword, setShowReTypeNewPassword] =
    React.useState(false);
  const [errorMessages, setErrorMessages] = React.useState<string[]>([]);
  const [error, setError] = React.useState(false);
  const [isPasswordValid, setIsPasswordValid] = React.useState(true);
  const handleClickshowNewPassword = () => setShowNewPassword((show) => !show);
  const handleClickshowReTypeNewPassword = () =>
    setShowReTypeNewPassword((show) => !show);

  const getUserPassword = async () => {
    try {
      const response = await instance.get(
        `/6D/auth/getPassword?userId=${userId}`
      );
      if (response.status === 200) {
        setUserPassword(
          response.data?.password ? response.data?.password : undefined
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getUserPassword();
  }, []);

  const validatePassword = (password: string) => {
    const errors: string[] = [];
    const regexes = {
      length: /.{8,}/,
      uppercase: /[A-Z]/,
      lowercase: /[a-z]/,
      number: /[0-9]/,
      special: /[!@#$%^&*]/,
    };

    if (!regexes.length.test(password)) {
      errors.push("Must be at least 8 characters long");
    }

    const matches = [
      regexes.uppercase.test(password),
      regexes.lowercase.test(password),
      regexes.number.test(password),
      regexes.special.test(password),
    ].filter(Boolean).length;

    if (matches < 3) {
      errors.push(
        "Must include at least three of the following: uppercase letter, lowercase letter, number, or special character"
      );
    }

    const commonPasswords = ["password123", "qwerty"];
    if (commonPasswords.includes(password.toLowerCase())) {
      errors.push(
        "Cannot be a commonly used password (e.g., 'password123', 'qwerty')"
      );
    }

    const personalInfo = ["username", "name", "email"];
    for (const info of personalInfo) {
      if (password.toLowerCase().includes(info.toLowerCase())) {
        errors.push("Cannot contain your username, name, or email address");
        break;
      }
    }

    const repeated = /(.)\1{3,}/;
    const sequential =
      /(?:012|123|234|345|456|567|678|789|890|abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz)/i;
    if (repeated.test(password) || sequential.test(password)) {
      errors.push(
        "Cannot contain repeated or sequential characters (e.g., 'aaaa', '1234')"
      );
    }

    setErrorMessages(errors);
    setIsPasswordValid(errors.length === 0);
    return errors.length === 0;
  };

  const getChangeUserPassword = async () => {
    if (
      inputPassword.newPassword !== inputPassword.retypeNewPassword ||
      inputPassword.newPassword.length < 8 ||
      inputPassword.retypeNewPassword.length < 8
    ) {
      setError(true);
      return false;
    }

    try {
      const response = await instance.post(
        `/6D/auth/changePassword?userId=${userId}&currentPassword=${userPassword}&newPassword=${inputPassword.newPassword}`
      );

      if (response.status === 200) {
        setInputPassword({
          newPassword: "",
          retypeNewPassword: "",
        });
        getUserPassword();
        setError(false);
        setShow(true);
        setTimeout(() => {
          navigate("/landing/activity");
          setShow(false);
        }, 2000);
      } else {
        alert("Failed to change the password. Please try again.");
      }
    } catch (error) {
      console.error("Error changing password:", error);
      alert(
        "An error occurred while changing the password. Please try again later."
      );
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(false);
    const { name, value } = e.target;
    setInputPassword((prevState) => ({
      ...prevState,
      [name]: value,
    }));
    if (name === "newPassword") {
      validatePassword(value);
    }
  };

  return (
    <div>
      <CustomModal
        open={show}
        handleClose={() => setShow(false)}
        child={<PasswordSuccessFullModal setShow={setShow} />}
      />
      <MainBox>
        <Typography sx={{ fontWeight: 600, marginBottom: "40px" }}>
          Change Password
        </Typography>
        <SubBox>
          <Grid container spacing={1}>
            <Grid item xs={12}>
              <CustomTextInput
                label="Current Password"
                name="currentPassword"
                value={userPassword}
                type={"password"}
                disabled={mobileNumber || googleLog}
              />
            </Grid>
            <Grid item xs={12}>
              {mobileNumber || googleLog ? <br />:null}
              <CustomTextInput
                label="New Password"
                name="newPassword"
                value={inputPassword.newPassword}
                onChange={handleChange}
                type={showNewPassword ? "text" : "password"}
                iconClick={handleClickshowNewPassword}
                helper
                helperText={!isPasswordValid ? errorMessages.join(", ") : null}
                icon={showNewPassword ? Visibility : VisibilityOff}
                disabled={mobileNumber || googleLog}
                isEditable={!mobileNumber || !googleLog}
              />
            </Grid>
            <Grid item xs={12}>
              {mobileNumber || googleLog ? <br />:null}
              <CustomTextInput
                label="Re-Type New Password"
                name="retypeNewPassword"
                value={inputPassword.retypeNewPassword}
                onChange={handleChange}
                type={showReTypeNewPassword ? "text" : "password"}
                iconClick={handleClickshowReTypeNewPassword}
                helper
                helperText={
                  error
                    ? "New Password and Re-Type New Password do not match. Please try again."
                    : null
                }
                icon={showReTypeNewPassword ? Visibility : VisibilityOff}
                disabled={mobileNumber || googleLog}
                isEditable={!mobileNumber || !googleLog}
              />
            </Grid>
          </Grid>
          {mobileNumber || googleLog ? <br />:null}
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <CustomButton
              name={"Change Current Password"}
              variant="primary"
              disabled={
                !inputPassword.newPassword || !inputPassword.retypeNewPassword
              }
              onClick={getChangeUserPassword}
            />
          </Box>
        </SubBox>
        <TitleBox>
          <ErrorIcon />
          &nbsp;&nbsp;
          <Typography>Password Creation Requirements</Typography>
        </TitleBox>
        <MainCard>
          <ol>
            <li>Must be at least 8 characters long.</li>
            <li>
              Must include at least three of the following: Uppercase letter
              (A-Z), Lowercase letter (a-z), Number (0-9), Special Character
              (e.g., !, @, #, $, %, ^, &, *).
            </li>
            <li>
              Common Passwords: Cannot be a commonly used password (e.g.,
              'password123', 'qwerty').
            </li>
            <li>
              Personal information: cannot contain your username, name, or email
              address.
            </li>
            <li>
              Repeated/Sequential Characters: Cannot contain repeated (e.g.,
              'aaaa') or sequential characters (e.g., '1234').
            </li>
          </ol>
        </MainCard>
      </MainBox>
    </div>
  );
};

export default PasswordInput;

const MainBox = styled(Box)`
  border: 2px solid white;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 30px;
  margin-top: 4rem;
  margin-bottom: 2rem;
`;
const SubBox = styled(Box)`
  border: 2px solid white;
  border-radius: 4px;
  padding: 30px;
`;
const TitleBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  margin-top: 40px;
`;
const MainCard = styled(Card)`
  display: flex;
  box-shadow: none !important;
  margin-top: 10px;
  padding: 20px;
`;
