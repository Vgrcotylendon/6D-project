import React from "react";
import { Box, Typography, Card } from "@mui/material";
import styled from "styled-components";
import Checkbox from "@mui/material/Checkbox";
import { Link } from "react-router-dom";

const label = { inputProps: { "aria-label": "Checkbox demo" } };

const Updates: React.FC = () => {
  return (
    <div>
      <MainBox>
        <Typography sx={{ fontWeight: 600, marginBottom: "20px" }}>
          Email News & Updates
        </Typography>
        <Typography sx={{ marginBottom: "40px" }}>
          From time to time,we'd like to send you emails with intreresting news
          about substance and your workspace.You can choose which of these
          updates you'd like to receive:updates
        </Typography>
        <MainCard>
          <TextBox>
            <Checkbox {...label} defaultChecked />
            <Typography>Tips and Tricks</Typography>
          </TextBox>
          <TextBox>
            <Checkbox {...label} defaultChecked />
            <Typography>Offers and Promotions</Typography>
          </TextBox>
          <TextBox>
            <Checkbox {...label} defaultChecked />
            <Typography>Research Opportunities</Typography>
          </TextBox>
          <TextBox>
            <Checkbox {...label} defaultChecked />
            <Typography>News Letters</Typography>
          </TextBox>
        </MainCard>
        <Typography sx={{ marginTop: "20px", marginBottom: "20px" }}>
          If you opt out of the above,note that we'll still send you important
          administrative emails,such as password resets.
        </Typography>
        <Typography >
          We will use this email address:
          <span style={{ fontWeight: "bold" }}>parvati_v@srm.com</span>
          <Link to='/' style={{textDecoration:"none"}}>(Change address)</Link>
        </Typography>
      </MainBox>
    </div>
  );
};

export default Updates;

const MainBox = styled(Box)`
  border: 2px solid white;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  padding: 30px;
  margin-top: 2rem;
  margin-bottom: 2rem;
`;
const MainCard = styled(Card)`
  display: flex;
  flex-direction: column;
  padding: 30px;
  box-shadow: none !important;
`;
const TextBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
`;
