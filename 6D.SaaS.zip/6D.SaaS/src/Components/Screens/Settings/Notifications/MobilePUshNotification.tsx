import { Box, Card, Typography } from "@mui/material";
import React from "react";
import styled from "styled-components";
import Radio from "@mui/material/Radio";

const MobilePUshNotification: React.FC = () => {
  const [selectedValue, setSelectedValue] = React.useState("a");
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedValue(event.target.value);
  };

  return (
    <div>
      <MainBox>
        <Typography sx={{ fontWeight: 600, marginBottom: "30px" }}>
          Mobile Push Notifications
        </Typography>
        <MainCard>
          <TextBox>
            <Radio
              checked={selectedValue === "a"}
              onChange={handleChange}
              value="a"
              name="radio-buttons"
              inputProps={{ "aria-label": "A" }}
            />
            <Typography>Send me mobile notification</Typography>
          </TextBox>
          <TextBox>
            <Radio
              checked={selectedValue === "b"}
              onChange={handleChange}
              value="b"
              name="radio-buttons"
              inputProps={{ "aria-label": "B" }}
            />
            <Typography>Once a day at most</Typography>
          </TextBox>
          <TextBox>
            <Radio
              checked={selectedValue === "c"}
              onChange={handleChange}
              value="c"
              name="radio-buttons"
              inputProps={{ "aria-label": "C" }}
            />
            <Typography>Never</Typography>
          </TextBox>
        </MainCard>
      </MainBox>
    </div>
  );
};

export default MobilePUshNotification;

const MainBox = styled(Box)`
  border: 2px solid white;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  padding: 30px;
  margin-top: 2rem;
`;
const MainCard = styled(Card)`
  display: flex;
  flex-direction: column;
  padding: 30px;
  box-shadow: none !important;
`;
const TextBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
`;
