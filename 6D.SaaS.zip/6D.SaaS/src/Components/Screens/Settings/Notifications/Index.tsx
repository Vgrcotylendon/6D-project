import { Container } from '@mui/material'
import React from 'react'
import NotificationCard from './NotificationCard'
import MobilePUshNotification from './MobilePUshNotification'
import Updates from './Updates'

const MyNotification:React.FC = () => {
  return (
    <Container  maxWidth="xl">
      <NotificationCard/>
      <MobilePUshNotification/>
      <Updates/>
    </Container>
  )
}

export default MyNotification