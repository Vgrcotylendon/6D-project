import React from 'react';
import {Box, Typography,Card} from "@mui/material";
import styled from 'styled-components';
import Checkbox from "@mui/material/Checkbox";

const label = { inputProps: { "aria-label": "Checkbox demo" } };

const NotificationCard:React.FC = () => {
  return (
    <div>
        <MainBox>
            <Typography sx={{fontWeight:600,marginBottom:"30px"}}>Notifications</Typography>
            <MainCard>
                <TextBox>
            <Checkbox  {...label} defaultChecked/><Typography>Certification updates</Typography>
            </TextBox>
            <TextBox>
            <Checkbox  {...label} defaultChecked/><Typography>Job updates</Typography>
            </TextBox>
            <TextBox>
            <Checkbox  {...label} defaultChecked/><Typography>System updates</Typography>
            </TextBox>
            </MainCard>
        </MainBox>
    </div>
  )
}

export default NotificationCard

const MainBox = styled(Box)`
  border: 2px solid white;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  padding: 30px;
  margin-top: 4rem;
`;
const MainCard = styled(Card)`
  display: flex;
  flex-direction: column;
  padding: 30px;
  box-shadow: none !important;
`;
const TextBox = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items:center;
`;