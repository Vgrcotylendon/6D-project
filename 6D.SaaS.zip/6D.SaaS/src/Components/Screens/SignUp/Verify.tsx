import { Box, Card, Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import OtpField from "../../Input/OtpField";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { cookies, instance } from "../../../Controller/Common";
import { useDispatch } from "react-redux";
import {
  SignInFailed,
  SignInSuccess,
  StartSignIn,
} from "../../../Store/UserSlice";
import CustomModal from "../../Modal/CustomModal";
import SuccessfulModal from "./SuccessfulModal";
import CustomButton1 from "../../Button/CustomButton1";
import SuccessfulModal1 from "./SucessfulModal1";
import AttemptModal from "./AttemptModal";

export interface valueProps {
  setVal: React.Dispatch<React.SetStateAction<number>>;
  value: string;
  mobileNumber?: string;
  setMobileNumber?: React.Dispatch<React.SetStateAction<string>>;
  email?: string;
  setEmail?: React.Dispatch<React.SetStateAction<string>>;
  fromSignUp?: boolean;
  setFromSignUp?: React.Dispatch<React.SetStateAction<any>>;
}
const Verify: React.FC<valueProps> = ({
  value,
  setVal,
  email,
  mobileNumber,
  setMobileNumber,
  setEmail,
  fromSignUp,
  setFromSignUp,
}) => {
  const [show, setShow] = useState(false);
  const [failAttempt, setFailAttempt] = useState(false);
  const [show1, setShow1] = useState(false);
  const [otp, setOtp] = useState("");
  const [head, setHead] = useState("");
  const [subhead, setSubHead] = useState("");
  const [time, setTime] = useState(300);
  const [attempts, setAttempts] = useState(1);
  const [success, setSuccess] = useState(false);
  const [verified, setVerified] = useState(false);
  const [error, setError] = useState(false);
  const [progress, setProgress] = useState(0);
  const [errormsg, setErrorMsg] = useState("");
  const [clear, setClear] = useState(false);
  const [load, setLoad] = useState({ verify: false, resend: false });
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const path = location.pathname;

  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (time > 0) {
      timer = setTimeout(() => {
        setTime((prevTime) => prevTime - 1);
      }, 1000);
    } else {
      setError(true);
      setErrorMsg("time expired");
      setHead("Times'up! Please request a new verification code.");
      setSubHead("Didn't Receive the code? Send Again");
    }
    return () => {
      if (timer) {
        clearTimeout(timer);
      }
    };
  }, [time]);

  useEffect(() => {
    if (attempts === 3 && time === 0) {
      setShow1(true);
      setFailAttempt(true);
    }
    if (errormsg !== "OTP does not match") {
      setErrorMsg(time !== 0 ? `${time} seconds` : "time expired");
    } else if (errormsg === "OTP does not match") {
      setTime(300);
    }
  }, [time, errormsg]);

  const VerifyCode = async () => {
    setError(false);
    setLoad((prev) => ({ ...prev, verify: true }));
    try {
      const response = await instance.post("/6D/auth/verifyCode", {
        code: otp,
        email,
      });
      if (response.status === 200) {
        setLoad((prev) => ({ ...prev, verify: false }));
        setSuccess(true);
        setVerified(true);
        setTimeout(() => {
          setVal(2);
        }, 3000);
        setFromSignUp?.(false);
      }
    } catch (error: any) {
      setLoad((prev) => ({ ...prev, verify: false }));
      console.error("Error verifying OTP:", error);
      if (error.response && error.response.status === 400) {
        setHead("The code you entered is incorrect. please try again");
        setSubHead("Re-enter Code");
        setErrorMsg("OTP does not match");
        setError(true);
        if (attempts === 3) {
          setFailAttempt(true);
          setShow1(true);
          setTimeout(() => {
            navigate(-1);
            setShow1(false);
          }, 4000);
        }
      } else {
        setErrorMsg("An unexpected error occurred while verifying OTP.");
        setError(true);
      }
    }
  };

  const VerifyCodeForMobile = async () => {
    dispatch(StartSignIn());
    setLoad((prev) => ({ ...prev, verify: true }));
    setError(false);
    let timer: NodeJS.Timeout | undefined;
    if (load.verify) {
      timer = setInterval(() => {
        setProgress((prev) => (prev >= 95 ? prev : prev + 5));
      }, 200);
    }
    try {
      const response = await instance.post("/6D/auth/verifyCodeforMobile", {
        code: otp,
        mobileNumber,
      });
      if (response.status === 200) {
        if (timer) clearInterval(timer);
        setProgress(100);
        setLoad((prev) => ({ ...prev, verify: false }));
        dispatch(SignInSuccess(response.data.isVerified));
        cookies.set("token", response.data.isVerified.token);
        cookies.set("refreshToken", response.data.isVerified.refreshToken);
        setSuccess(true);
        setVerified(true);
        setShow(true);
        navigate("/landing");
      }
    } catch (error: any) {
      if (timer) clearInterval(timer);
      setProgress(100);
      setLoad((prev) => ({ ...prev, verify: false }));
      console.error("Error verifying OTP:", error);
      dispatch(SignInFailed(error));
      if (error.response && error.response.status === 400) {
        setHead("The code you entered is incorrect. please try again");
        setSubHead("Re-enter Code");
        setErrorMsg("OTP does not match");
        setError(true);
        if (attempts === 3) {
          setFailAttempt(true);
          setShow1(true);
          setTimeout(() => {
            navigate(-1);
            setShow1(false);
          }, 4000);
        }
      } else {
        setErrorMsg("An unexpected error occurred while verifying OTP.");
        setError(true);
      }
    }
  };

  const ResendCode = async () => {
    if (attempts === 3) {
      setShow1(true);
      setFailAttempt(true);
      return;
    }
    setLoad((prev) => ({ ...prev, resend: true }));
    setError(false);
    setClear(!clear);
    try {
      const response = await instance.post("/6D/auth/sendCode", {
        email,
      });
      if (response.status === 200) {
        setLoad((prev) => ({ ...prev, resend: false }));
        setHead("A new code has been sent to your email address");
        setSubHead("Enter Verification Code");
        setTime(300);
        setErrorMsg(`${time} seconds`);
        setAttempts((prevAttempts) => prevAttempts + 1);
      }
    } catch (error) {
      console.error(error);
      setLoad((prev) => ({ ...prev, resend: false }));
    }
  };

  const ResendCodeForMobile = async () => {
    if (attempts === 3) {
      setShow1(true);
      setFailAttempt(true);
      return;
    }
    setLoad((prev) => ({ ...prev, resend: true }));
    setError(false);
    setClear(!clear);

    let url;
    if (fromSignUp) {
      url = `/6D/auth/reSendCodeforMobileInSignUp`;
    } else {
      url = `/6D/auth/sendCodeforMobile`;
    }
    try {
      const response = await instance.post(url, {
        mobileNumber,
      });
      if (response.status === 200) {
        setLoad((prev) => ({ ...prev, resend: false }));
        setHead("A new code has been sent to your phone number");
        setSubHead("Enter Verification Code");
        setTime(300);
        setErrorMsg(`${time} seconds`);
        setAttempts((prevAttempts) => prevAttempts + 1);
      }
    } catch (error) {
      setLoad((prev) => ({ ...prev, resend: false }));
      console.error(error);
    }
  };
  const VERIFY = () => {
    if (email) {
      VerifyCode();
    } else if (mobileNumber) {
      VerifyCodeForMobile();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      VERIFY();
    }
  };

  const handleNavigate = () => {
    if (email) {
      setEmail?.(" ");
    } else if (mobileNumber) {
      setMobileNumber?.(" ");
    }
    setVal(0);
  };

  const getErrorMessageColor = (
    errormsg: string,
    time: number,
    otp: string
  ) => {
    if (errormsg === "OTP does not match" || errormsg === "time expired") {
      return "red";
    }
    if (time === 0 || (otp.length === 4 && time > 0)) {
      return "black";
    }
    return "textPrimary";
  };

  useEffect(() => {
    if (mobileNumber && path === "/signup") {
      setHead(`Verify Your phone number`);
      setSubHead(`A verification code has been sent to your phone number.
         Please enter the code below. `);
    }
    if (mobileNumber && path === "/signin") {
      setHead(`Enter verification code`);
      setSubHead(` A verification code has been sent to your phone number.
         Please enter the code below.`);
    }
    if (mobileNumber && verified) {
      setHead("Phone Verified! Proceed");
      setSubHead("Successful Verification");
    }
    if (email) {
      setHead(`Verify Your email address`);
      setSubHead(`A verification code has been sent to your Email Address.
        Please enter the code below. `);
    }
    if (email && verified) {
      setHead("Email Verified! Proceed");
      setSubHead("Successful Verification");
    }
  }, [email, mobileNumber, verified, path]);

  useEffect(() => {
    if (failAttempt) {
      setShow1(true);
      const timer = setTimeout(() => {
        navigate(-1);
        setShow1(false);
      }, 4000);

      return () => clearTimeout(timer);
    }
  }, [attempts, navigate]);

  return (
    <>
      <CustomModal
        open={show1}
        handleClose={() => setShow1(false)}
        child={<AttemptModal setShow1={setShow1} />}
      />
      <Grid item sx={{ minWidth: 500 }}>
        <Typography
          align="center"
          variant="h4"
          sx={{ fontWeight: "700", fontSize: "32px", lineHeight: "43.36px" }}
        >
          {head}
        </Typography>
        <br />
        <Typography align="center" sx={{ fontWeight: 600, fontSize: "14px" }}>
          {subhead}
        </Typography>
        <br />
        <Card
          elevation={0}
          sx={{
            bgcolor: "#F2F2F2",
            p: "20px 50px",
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
            mt: 2,
            borderRadius: 2,
          }}
        >
          <OtpField
            setOtp={setOtp}
            time={time}
            otp={otp}
            error={error}
            success={success}
            clear={clear}
            onKeyDown={handleKeyDown}
          />
          {failAttempt ? (
            <>
              <Typography
                align="center"
                color="red"
                sx={{ fontSize: "12px", mt: 1.5, mb: 0 }}
              >
                OTP does not match
              </Typography>
              <Typography
                align="center"
                sx={{
                  fontSize: "14px",
                  fontWeight: 600,
                  color: "#3F3F40",
                  mt: 1,
                  mb: 1,
                }}
              >
                Please Try again After 15 minutes
              </Typography>
            </>
          ) : (
            <>
              <Typography
                align="center"
                color={getErrorMessageColor(errormsg, time, otp)}
                sx={{ fontSize: "12px", mt: 1.5, mb: 0 }}
              >
                {errormsg}
              </Typography>

              <Typography
                align="center"
                sx={{
                  fontSize: "14px",
                  fontWeight: 600,
                  color: "#3F3F40",
                  mt: 1,
                  mb: 1,
                }}
              >
                Attempts {attempts} of 3
              </Typography>
            </>
          )}
        </Card>
        <Box sx={{ display: "flex", justifyContent: "space-evenly" }}>
          <CustomButton1
            name="Resend Code"
            variant="primary"
            disabled={
              !(errormsg === "OTP does not match" || time === 0) || failAttempt
            }
            onClick={() => {
              if (email) {
                ResendCode();
              } else if (mobileNumber) {
                ResendCodeForMobile();
              }
            }}
            loading={load.resend}
            style={{ marginTop: 3 }}
          />
          <CustomButton1
            name="Verify Code"
            variant="primary"
            disabled={
              otp.length !== 4 ||
              errormsg === "OTP does not match" ||
              errormsg === "time expired" ||
              time === 0
            }
            onClick={() => {
              VERIFY();
            }}
            loading={load.verify}
            style={{ marginTop: 3 }}
          />
        </Box>
        {/* <Link
          to={"/signin"}
          style={{
            color: "#0000EE",
            fontWeight: 600,
            fontSize: "14px",
            textDecoration: "none",
          }}
        > */}
        <Typography
          align="center"
          sx={{
            color: "#0000EE",
            fontWeight: 600,
            fontSize: "14px",
            marginTop: "10px",
            lineHeight: "18.97px",
            cursor: "pointer",
          }}
          onClick={handleNavigate}
        >
          Sign into a different account
        </Typography>
        {/* </Link> */}
      </Grid>
      <CustomModal
        open={show}
        handleClose={() => setShow(false)}
        sx={{ minWidth: "35%", padding: 5 }}
        child={
          <SuccessfulModal1 load={load} progress={progress} setShow={setShow} />
        }
      />
    </>
  );
};
export default Verify;
