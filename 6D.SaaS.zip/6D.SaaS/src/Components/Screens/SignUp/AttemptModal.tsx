import { Box, IconButton, Typography } from "@mui/material";
import React from "react";
import CustomLinearProgress from "../Activity/MyDashBoard/LinearProgress";
import CircularProgress from "@mui/material/CircularProgress";
import CloseIcon from "@mui/icons-material/Close";
import CustomButton1 from "../../Button/CustomButton1";
import { useNavigate } from "react-router-dom";

interface SuccessProps {
  setShow1: (value: boolean) => void;
}

const AttemptModal: React.FC<SuccessProps> = ({ setShow1 }) => {
   const  navigate = useNavigate();

  const handleClose = () => {
     setShow1(false);
     navigate(-1);
  };

  return (
    <Box sx={{ padding: "30px", backgroundColor: "#f0f0f0" }}>
      <IconButton
        size="small"
        onClick={() => setShow1(false)}
        sx={{ position: "absolute", top: 10, right: 10 }}
      >
        <CloseIcon />
      </IconButton>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: "white",
          borderRadius: "10px",
          padding: "20px",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Typography
          sx={{
            fontSize: "16px",
            lineHeight: "21.68px",
            fontWeight: 600,
            color: "#4C2D2D",
            padding: "30px",
          }}
        >
          Verification failed
        </Typography>
        <Box
          sx={{
            backgroundColor: "#0c0c0c",
            height: "0.5px",
            width: "448px",
          }}
        />
        <Box
          sx={{
            display: "flex",
            width: "448px",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Typography
            sx={{
              fontSize: "14px",
              fontWeight: 400,
              padding: "20px 10px 20px 10px",
            }}
          >
            You have exceeded the maximum number of attempts. please try again
            after 15 minutes
          </Typography>
        </Box>
        <Box
          sx={{
            backgroundColor: "#8b8989",
            height: "0.5px",
            width: "448px",
          }}
        />
        <Box sx={{ padding: "10px 0px 10px 0px" }}>
          <CustomButton1
            name="OK"
            variant="primary"
            onClick={() => handleClose()}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default AttemptModal;
