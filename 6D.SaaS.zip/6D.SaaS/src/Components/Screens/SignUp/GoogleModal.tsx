import {
  Box,
  Divider,
  FormControl,
  IconButton,
  InputAdornment,
  OutlinedInput,
  Typography,
} from "@mui/material";
import React from "react";
import CloseIcon from "@mui/icons-material/Close";
import MailIcon from "@mui/icons-material/Mail";
import styled from "styled-components";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CustomButton1 from "../../Button/CustomButton1";
import { cookies, instance } from "../../../Controller/Common";
import { useNavigate } from "react-router-dom";

interface mailid {
  setShow: React.Dispatch<React.SetStateAction<boolean>>;
}

const GoogleModal: React.FC<mailid> = ({
  setShow,
}) => {
  const Navigate = useNavigate();

  const handleNavigate = () => {
    setShow(false);
    Navigate("/Signup");
  };

  return (
    <MainBox>
      <IconButton
        size="small"
        onClick={() => setShow(false)}
        sx={{ position: "absolute", top: 10, right: 10 }}
      >
        <CloseIcon />
      </IconButton>
      <SubBox>
        <Sub1Box>
            <Box>
              <Typography
                sx={{
                  fontSize: "16px",
                  fontWeight: 600,
                  color: "#4C2D2D",
                  lineHeight: "21.68px",
                  padding: "20px",
                  textAlign: "center"
                }}
              >
               Email Already Registered
              </Typography>
              <Box
                sx={{
                  backgroundColor: "#0c0c0c",
                  height: "0.5px",
                  width: "448px",
                }}
              />
              <Typography
                sx={{
                  fontSize: "12px",
                  fontWeight: 400,
                  color: "#4C2D2D",
                  lineHeight: "21.68px",
                  padding: "20px 0",
                  width: "448px",
                }}
              >
               This email address is already registered with an <span style={{fontWeight:"bold"}}>email</span> and  <span style={{fontWeight:"bold"}}>password</span>.
               <br/>
              Please signin using your email and password, or use adifferent Google account.
              </Typography>
              <Box
                sx={{
                  backgroundColor: "#0c0c0c",
                  height: "0.5px",
                  width: "448px",
                }}
              />
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  padding: "20px 0px 20px 0px",
                }}
              >
                <CustomButton1
                  name="Back to Home"
                  variant="primary"
                  padding="5px 15px"
                  onClick={handleNavigate}
                />
              </Box>
            </Box>
        </Sub1Box>
      </SubBox>
    </MainBox>
  );
};

export default GoogleModal;

const MainBox = styled(Box)`
  display: flex;
  flex-direction: column;
  background-color: #ffffff;
  border-radius: 10px;
  padding: 30px;
  justify-content: center;
  align-items: center;
`;
const SubBox = styled(Box)`
  display: flex;
  flex-direction: column;
  background-color: #f6f5f5;
  border-radius: 10px;
  padding: 20px;
  justify-content: center;
  align-items: center;
`;
const Sub1Box = styled(Box)`
  display: flex;
  flex-direction: column;
  background-color: #ffffff;
  border-radius: 10px;
  padding: 16px;
  justify-content: center;
`;
