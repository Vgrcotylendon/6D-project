import {
  Box,
  Card,
  Grid,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Modal,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import ErrorIcon from "@mui/icons-material/Error";
import styled from "styled-components";
import CloseIcon from "@mui/icons-material/Close";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { cookies, instance } from "../../../Controller/Common";
import { useNavigate } from "react-router-dom";
import CustomModal from "../../Modal/CustomModal";
import SuccessfulModal from "./SuccessfulModal";
import InputField from "../../Input/InputField";
import CustomButton1 from "../../Button/CustomButton1";
import { SignInSuccess } from "../../../Store/UserSlice";
import { useDispatch } from "react-redux";

interface valueProps {
  setVal: React.Dispatch<React.SetStateAction<number>>;
  email: string;
}
const CreatePassword: React.FC<valueProps> = ({ setVal, email }) => {
  const dispatch = useDispatch();
  const [showPassword, setShowPassword] = useState(false);
  // const [progress, setProgress] = React.useState(0);
  const [show, setShow] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [pass, setPass] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errorMessages, setErrorMessages] = useState<string[]>([]);
  const [isValidPassword, setIsValidPassword] = useState(false);
  const navigate = useNavigate();

  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleClickShowConfirmPassword = () =>
    setShowConfirmPassword((show) => !show);

  const validatePassword = (password: string) => {
    const errors: string[] = [];
    const regexes = {
      length: /.{8,}/,
      uppercase: /[A-Z]/,
      lowercase: /[a-z]/,
      number: /[0-9]/,
      special: /[!@#$%^&*]/,
    };

    if (!regexes.length.test(password)) {
      errors.push("Must be at least 8 characters long");
    }

    const matches = [
      regexes.uppercase.test(password),
      regexes.lowercase.test(password),
      regexes.number.test(password),
      regexes.special.test(password),
    ].filter(Boolean).length;

    if (matches < 3) {
      errors.push(
        "Must include: AZ, az, 1234..., !@#$%^&*"
        // "Must include at least three of the following: uppercase letter, lowercase letter, number, or special character"
      );
    }

    const commonPasswords = ["password123", "qwerty"];
    if (commonPasswords.includes(password.toLowerCase())) {
      errors.push(
        "Cannot be a commonly used password(e.g., 'password123','qwerty')"
      );
    }

    // Assuming 'username' is a variable holding user's personal information
    const personalInfo = ["username", "name", "email"];
    for (const info of personalInfo) {
      if (password.toLowerCase().includes(info.toLowerCase())) {
        errors.push("Cannot contain your username, name, or email address");
        break;
      }
    }

    const repeated = /(.)\1{3,}/;
    const sequential =
      /(?:012|123|234|345|456|567|678|789|890|abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz)/i;
    if (repeated.test(password) || sequential.test(password)) {
      errors.push(
        // "Cannot contain repeated (e.g., 'aaaa') or sequential characters (e.g., '1234')"
        "Cannot contain repeated (e.g., 'aaaa', '1234')"
      );
    }

    setErrorMessages(errors);
    setIsValidPassword(errors.length === 0);
    return errors.length === 0;
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setPass(value);
    validatePassword(value);
    if (validatePassword(value)) {
      return true;
    } else {
    }
  };

  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const require = [
    "Must be at least 8 characters long",
    "Must include at least three of the following: Uppercase letter (A-Z), Lowercase letter (a-z), Number (0-9), Special Character (e.g., !, @, #, $, %, ^, &, *)",
    "Common Passwords: Cannot be a commonly used password (e.g., 'password123', 'qwerty')",
    "Personal information: cannot contain your username, name, or email address.",
    "Repeated/Sequential Characters: Cannot contain repeated (e.g., 'aaaa') or sequential characters (e.g., '1234')",
  ];

  const Create = async () => {
    try {
      const response = await instance.post("/6D/auth/createPassword", {
        email,
        password: confirm,
      });
      if (response.status === 200) {
        // setVal(3);
        setShow(true);
        dispatch(SignInSuccess(response.data.create));
        cookies.set("token", response.data.create.token);
        cookies.set("refreshToken", response.data.create.refreshToken);
         navigate("/landing");
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <CustomModal
        open={open}
        handleClose={() => handleClose()}
        child={
          <MainBox>
            <IconButton
              size="small"
              onClick={() => {
                handleClose();
              }}
              sx={{ position: "absolute", top: 15, right: 15 }}
            >
              <CloseIcon />
            </IconButton>
            <SubBox1>
              <Typography
                sx={{
                  padding: "20px",
                  fontWeight: 600,
                  fontSize: "16px",
                  lineHeight: "21.68px",
                  color: "#4C2D2D",
                  textAlign: "Center",
                }}
              >
                Password Creation Rules
              </Typography>
              <Box
                sx={{
                  backgroundColor: "#a3a1a1",
                  height: "0.5px",
                  width: "410px",
                }}
              />
              <Card sx={{ bgcolor: "#ffff", mt: 2, p: "10px" }} elevation={0}>
                <List sx={{ listStyleType: "disc", pl: 2 }}>
                  {require.map((item, index) => (
                    <ListItem
                      key={index}
                      sx={{ display: "list-item", padding: 0 }}
                    >
                      <ListItemText
                        primary={
                          <Typography
                            sx={{ fontSize: "12px", fontWeight: 400 }}
                          >
                            {item}
                          </Typography>
                        }
                      />
                    </ListItem>
                  ))}
                </List>
                {/* <Typography align="left" sx={{ fontSize: "12px", mt: 1 }}>
                Please try again with stronger password
              </Typography> */}
              </Card>
              <Box
                sx={{
                  backgroundColor: "#2b2a2a",
                  height: "0.5px",
                  width: "410px",
                }}
              />
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  padding: "20px 0px 20px 0px",
                }}
              >
                <CustomButton1
                  name="Continue"
                  variant="primary"
                  padding="5px 15px"
                  onClick={handleClose}
                />
              </Box>
            </SubBox1>
          </MainBox>
        }
      />
      <Grid item>
        <Typography
          align="center"
          sx={{
            fontWeight: 700,
            fontSize: "32px",
            lineHeight: "43.36px",
            color: "#3F3F40",
          }}
        >
          {errorMessages.length === 0 ? "Create your password" : "Try Again"}
        </Typography>
        <Typography
          align="center"
          sx={{
            fontSize: "14px",
            fontWeight: 600,
            lineHeight: "18.97px",
            color: "#3F3F40",
            mt: "20px",
          }}
        >
          {errorMessages.length === 0
            ? "Set password"
            : "The password you enter does not meet the requirements.please try again."}
        </Typography>
        <Card
          elevation={0}
          sx={{
            bgcolor: "#F2F2F2",
            padding: "40px",
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
            height: "10rem",
            mt: 3,
            borderRadius: 2,
          }}
        >
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Typography
                align="left"
                sx={{
                  color: "#3F3F40",
                  fontSize: "14px",
                  fontWeight: 600,
                  lineHeight: "18.97px",
                  mb: 1,
                }}
              >
                Enter Password
              </Typography>
              <InputField
                id={"password"}
                label="Password"
                value={pass}
                onChange={handlePasswordChange}
                type={showPassword ? "text" : "password"}
                icon={showPassword ? VisibilityOff : Visibility}
                iconClick={handleClickShowPassword}
                helper={errorMessages.length > 0 ? errorMessages[0] : ""}
              />
            </Grid>

            <Grid item xs={12}>
              <Typography
                align="left"
                sx={{
                  color: "#3F3F40",
                  fontSize: "14px",
                  fontWeight: "600",
                  lineHeight: "18.97px",
                  mb: 1,
                }}
              >
                Re-Enter Password
              </Typography>
              <InputField
                id={"confirm password"}
                label="Confirm Password"
                value={confirm}
                type={showConfirmPassword ? "text" : "password"}
                onChange={(e) => setConfirm(e.target.value)}
                icon={showConfirmPassword ? VisibilityOff : Visibility}
                iconClick={handleClickShowConfirmPassword}
                helper={
                  confirm.length > 7 && confirm !== pass
                    ? "The passwords entered do not match. Please try again"
                    : // "Passwords does'nt match"
                      ""
                }
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    Create();
                  }
                }}
              />
            </Grid>
          </Grid>
        </Card>
        {/* {errorMessages.length > 0 && ( */}
        <Typography
          align="center"
          sx={{
            fontSize: "14px",
            mt: 2,
            color: "#0000EE",
            fontWeight: 400,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            cursor: "pointer",
          }}
          onClick={() => handleOpen()}
        >
          <ErrorIcon
            sx={{ fontSize: "18px", padding: 0.5, color: "#0000EE" }}
          />
          Password Creation Requirements
        </Typography>
        {/* )} */}
        <Box sx={{ display: "flex", justifyContent: "center", mt: 1 }}>
          <CustomButton1
            name="Signup"
            variant="primary"
            onClick={() => {
              Create();
            }}
            disabled={!confirm || !pass || confirm !== pass || !isValidPassword}
          />
        </Box>
        <Typography
          align="center"
          sx={{
            fontSize: "14px",
            mt: 1.5,
            color: "#0000EE",
            fontWeight: 600,
            cursor: "pointer",
          }}
          onClick={() => navigate("/Signin")}
        >
          Sign into different account
        </Typography>
      </Grid>
      <CustomModal
        open={show}
        handleClose={() => setShow(false)}
        sx={{ minWidth: "35%", padding: 5 }}
        child={<SuccessfulModal setShow={setShow}/>}
      />
    </>
  );
};

export default CreatePassword;

const MainBox = styled(Box)`
  position: absolute;
  top: 50%;
  left: 63%;
  transform: translate(-50%, -50%);
  width: 450px;
  background-color: #f5f5f5;
  padding: 50px;
  border-radius: 8px;
`;

const SubBox1 = styled(Box)`
  background-color: #ffff;
  padding: 10px;
  border-radius: 8px;
`;
