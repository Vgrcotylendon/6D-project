import {
  Box,
  Card,
  Divider,
  Grid,
  Typography,
  IconButton,
} from "@mui/material";
import React, { useState } from "react";
import MailIcon from "@mui/icons-material/Mail";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import { Link, useNavigate } from "react-router-dom";
import InputField from "../../Input/InputField";
import Google from "../../../Assets/Google.svg";
import Facebook from "../../../Assets/facebook.png";
import Linkedin from "../../../Assets/linkedin.png";
import { cookies, ImageUrl, instance } from "../../../Controller/Common";
import { useGoogleLogin } from "@react-oauth/google";
import { useLinkedIn } from "react-linkedin-login-oauth2";
import CustomButton1 from "../../Button/CustomButton1";
import { SignInSuccess, UpdateProfile } from "../../../Store/UserSlice";
import { useDispatch } from "react-redux";
import CustomModal from "../../Modal/CustomModal";
import TermsModal from "../SignIn/TermsModal";
import PolicyModal from "../SignIn/PolicyModal";
import GoogleModal from "./GoogleModal";
import AlertModal from "./AlertModal";
import GoogleAlertModal from "../SignIn/GoogleAlertModal";
import axios from "axios";

interface signUpProps {
  setVal: React.Dispatch<React.SetStateAction<number>>;
  mobileNumber: string;
  setMobileNumber: React.Dispatch<React.SetStateAction<string>>;
  email: string;
  setEmail: React.Dispatch<React.SetStateAction<string>>;
  setFromSignUp: React.Dispatch<React.SetStateAction<boolean>>;
  setOpenPolicy: React.Dispatch<React.SetStateAction<boolean>>;
  setOpenTerms: React.Dispatch<React.SetStateAction<boolean>>;
}

const SignUpForm: React.FC<signUpProps> = ({
  mobileNumber,
  setMobileNumber,
  email,
  setEmail,
  setVal,
  setFromSignUp,
  setOpenPolicy,
  setOpenTerms,
}) => {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  function validateEmail(Email: string | number) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(String(Email).toLowerCase());
  }

  function validateIndianMobileNumber(mobileNumber: string) {
    const regex = /^[6-9]\d{9}$/;
    return regex.test(mobileNumber);
  }
  const [open, setOpen] = useState(false);
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [mobileerror, setMobileError] = useState(false);
  const [emailError, setEmailError] = useState(false);
  const [errorMsg, setErrorMsg] = useState(false);
  const handleOpenTerms = () => setOpenTerms(true);
  const handleOpenPolicy = () => setOpenPolicy(true);

  const handlePhoneNumber = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;

    value = value.replace(/\D/g, "");
    if (value.startsWith("91") && value.length > 10) {
      value = value.slice(2);
    }
    if (value.length > 10) {
      value = value.slice(0, 10);
    }
    if (validateIndianMobileNumber(value)) {
      value = `+91${value}`;
      setMobileError(false);
    } else {
      setMobileError(true);
    }
    setMobileNumber(value);
    setEmail("");
    setEmailError(false);
    setErrorMsg(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      if (email) {
        GetCode();
      } else if (mobileNumber) {
        GetCodeForMobile();
      }
    }
  };

  const GetCode = async () => {
    setLoading(true);
    setErrorMsg(false);
    try {
      const response = await instance.post("/6D/auth/sendcode-new-email", {
        email,
      });

      if (response.status === 200) {
        setVal(1);
      }
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        if (error.response.status === 406) {
          setOpen(true);
          console.error("Error sending code:", error);
        } else if (error.response.status === 400) {
          setErrorMsg(true);
          console.error(
            "This email is already registered. Please use a different email or log in"
          );
        }
      } else {
        console.error("Unexpected error:", error);
      }
    } finally {
      setLoading(false);
    }
  };

  const GetCodeForMobile = async () => {
    try {
      const response = await instance.post("/6D/auth/sendcode-new-mobile", {
        mobileNumber,
      });
      if (response.status === 200) {
        setVal(1);
        setFromSignUp(true);
      } else if (response.status === 400) {
        setErrorMsg(true);
        console.error(
          "This email is already registered. Please use a different email or log in"
        );
      }
    } catch (error) {
      setErrorMsg(true);
      console.error("Error sending code:", error);
    } finally {
      setLoading(false);
    }
  };

  const login = useGoogleLogin({
    onSuccess: async (tokenResponse: any) => {
      const accessToken = tokenResponse?.access_token;

      if (accessToken) {
        try {
          const tokenInfoResponse = await fetch(
            `https://www.googleapis.com/oauth2/v3/tokeninfo?access_token=${accessToken}`
          );

          if (!tokenInfoResponse.ok) {
            throw new Error("Failed to fetch token info");
          }

          const data = await tokenInfoResponse.json();

          try {
            const response = await instance.post("/6D/auth/socialMediaSignUp", {
              email: data.email,
              accountOrigin: "GOOGLE",
            });

            if (response.status === 200) {
              dispatch(SignInSuccess(response.data));
              dispatch(UpdateProfile(`${ImageUrl}${response.data.profile}`));
              cookies.set("userId", response.data.userId);
              cookies.set("token", response.data.token);
              cookies.set("refreshToken", response.data.refreshToken);
              const status = cookies.get("modal");
              status === undefined && cookies.set("modal", false);
              navigate("/landing");
            } else if (response.status === 400) {
              setErrorMsg(true);
              console.error(
                "This email is already registered. Please use a different email or log in"
              );
            } else {
              console.error("Unexpected response status:", response.status);
            }
          } catch (error) {
            setErrorMsg(true);
            setShow(true);
            console.error("Error during sign up:", error);
          }
        } catch (error) {
          console.error("Error fetching token info:", error);
        } finally {
          setLoading(false);
        }
      } else {
        console.error("No access_token found in tokenResponse");
      }
    },
    onError: (error) => {
      console.error("Login Failed", error);
    },
  });

  const linkedInClientId = "86awasbwogybts";
  const linkedInRedirectUri = `${window.location.origin}/linkedin`;

  const { linkedInLogin } = useLinkedIn({
    clientId: linkedInClientId,
    redirectUri: linkedInRedirectUri,
    onSuccess: async (code) => {
      try {
        const tokenResponse = await fetch(
          "https://www.linkedin.com/oauth/v2/accessToken",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({
              grant_type: "authorization_code",
              code,
              redirect_uri: linkedInRedirectUri,
              client_id: linkedInClientId,
              client_secret: "e18xtWpgUHX4fL2j",
            }),
          }
        );

        const tokenData = await tokenResponse.json();
        const accessToken = tokenData.access_token;

        const emailResponse = await fetch(
          "https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))",
          {
            headers: {
              Authorization: `Bearer ${accessToken}`,
            },
          }
        );

        const emailData = await emailResponse.json();
        const userEmail = emailData.elements[0]["handle~"].emailAddress;
        setEmail(userEmail);
        GetCode();
      } catch (error) {
        console.error("Error in LinkedIn login process:", error);
      }
    },
    onError: (error) => {
      console.log("LinkedIn login error:", error);
    },
  });

  return (
    <>
      <CustomModal
        open={open}
        handleClose={() => setOpen(false)}
        child={<GoogleAlertModal setOpen={setOpen} />}
      />
      {/* <CustomModal
        open={openTerms}
        handleClose={() => handleOpenTerms()}
        sx={{ width: "100%", height: "100%", mt: 8 }}
        child={<TermsModal handleCloseTerms={handleCloseTerms} />}
      />
      <CustomModal
        open={openPolicy}
        handleClose={() => handleOpenPolicy()}
        sx={{ width: "100%", height: "100%", mt: 8 }}
        child={<PolicyModal handleClosePolicy={handleClosePolicy} />}
      /> */}
      <CustomModal
        open={show}
        handleClose={() => setShow(false)}
        child={<GoogleModal setShow={setShow} />}
      />
      <CustomModal
        open={show1}
        handleClose={() => setShow1(false)}
        child={<AlertModal setShow1={setShow1} />}
      />
      <Grid
        item
        padding={2}
        sx={{
          // minWidth: { xs: "90%", sm: 500, md: 500 },
          minHeight: { md: 400 },
        }}
      >
        <Typography
          align="center"
          variant="h4"
          sx={{ fontWeight: "700", fontSize: "32px", lineHeight: "43.36px" }}
        >
          Create an Account
        </Typography>
        <Typography
          align="center"
          sx={{
            fontSize: "12px",
            mt: 0.5,
            lineHeight: "16.26px",
            fontWeight: "400",
          }}
        >
          Already have an account?&nbsp;
          <Link
            to={"/signin"}
            style={{
              color: "#0000EE",
              fontWeight: 700,
              textDecoration: "none",
              fontSize: "12px",
            }}
          >
            Login
          </Link>
        </Typography>
        <Card
          elevation={0}
          sx={{
            bgcolor: "#F2F2F2",
            p: "15px 50px",
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
            borderRadius: 2,
            mt: 1.5,
            height: "auto",
          }}
        >
          <Typography
            align="center"
            sx={{
              fontSize: "14px",
              fontWeight: "600",
              lineHeight: "18.97px",
              mb: 1,
            }}
          >
            Phone Number
          </Typography>
          <InputField
            id={"phone number"}
            label="Phone number"
            placeholder={"Enter here"}
            value={mobileNumber}
            helper={
              (mobileerror && "Please enter a valid phone number.") ||
              (errorMsg === true
                ? "This phone number is already registered. Please use a different phone number or log in."
                : null)
            }
            onChange={handlePhoneNumber}
            icon={LocalPhoneIcon}
            onKeyDown={handleKeyDown}
          />
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              mb: 1,
            }}
          >
            <Divider sx={{ width: 70, bgcolor: "#8C8C8C" }} />
            &nbsp;&nbsp;&nbsp;{" "}
            <Typography sx={{ color: "#939393", fontSize: "11px" }}>
              or
            </Typography>
            &nbsp;&nbsp;&nbsp;
            <Divider sx={{ width: 70, bgcolor: "#8C8C8C" }} />
          </Box>
          <Typography
            align="center"
            sx={{
              fontSize: "14px",
              fontWeight: "600",
              lineHeight: "18.97px",
              mb: 1,
            }}
          >
            Email Address
          </Typography>
          <InputField
            id={"mail"}
            label="Email"
            placeholder={"Enter here"}
            icon={MailIcon}
            value={email}
            helper={
              (emailError && "Please enter a valid email address") ||
              (errorMsg === true
                ? "This email is already registered. Please use a different email or log in."
                : null)
            }
            onChange={(e) => {
              setEmailError(validateEmail(e.target.value) ? false : true);
              setEmail(e.target.value);
              setMobileNumber("");
              setMobileError(false);
              setErrorMsg(false);
            }}
            onKeyDown={handleKeyDown}
          />
        </Card>

        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            mt: 1,
            // mb: 1,
          }}
        >
          <Divider sx={{ width: 80, bgcolor: "#939393" }} />
          &nbsp;&nbsp;&nbsp;{" "}
          <Typography sx={{ color: "#939393", fontSize: "11px" }}>
            or
          </Typography>
          &nbsp;&nbsp;&nbsp;
          <Divider sx={{ width: 80, bgcolor: "#939393" }} />
        </Box>
        <Card
          elevation={0}
          sx={{
            bgcolor: "#F2F2F2",
            p: "20px 50px",
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
            mt: 1.5,
            borderRadius: 2,
          }}
        >
          <Typography
            align="center"
            sx={{
              fontSize: "14px",
              fontWeight: "600",
              lineHeight: "18.97px",
              mb: 1,
            }}
          >
            Sign in Using
          </Typography>
          <Box sx={{ display: "flex", justifyContent: "center" }}>
            <IconButton
              sx={{
                m: 1,
                // width: 50,
                // height: 50,
                textTransform: "none",
                borderRadius: 2,
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                p: 1,
                bgcolor: "#fff",
              }}
              onClick={() => login()}
            >
              <img src={Google} alt="Google" width={20} height={20} />
            </IconButton>
            {/* <IconButton
              sx={{
                m: 1,
                // width: 50,
                // height: 50,
                textTransform: "none",
                borderRadius: 2,
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                p: 1,
                bgcolor: "#fff",
              }}
            >
              <img src={Facebook} alt="Google" width={20} height={20} />
            </IconButton>
            <IconButton
              sx={{
                m: 1,
                // width: 50,
                // height: 50,
                textTransform: "none",
                borderRadius: 2,
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                p: 1,
                bgcolor: "#fff",
              }}
              onClick={() => linkedInLogin()}
            >
              <img src={Linkedin} alt="Google" width={20} height={20} />
            </IconButton> */}
          </Box>
        </Card>
        <Grid
          sx={{
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
          }}
        >
          <Grid sx={{ display: "flex", justifyContent: "center" }}>
            <CustomButton1
              name="Join us Today"
              variant="primary"
              onClick={() => {
                if (!email && !mobileNumber) {
                  setShow1(true);
                  return;
                }
                if (email) {
                  GetCode();
                } else if (mobileNumber) {
                  GetCodeForMobile();
                }
              }}
              style={{ marginTop: "30px" }}
              loading={loading}
              disabled={mobileerror || emailError}
            />
          </Grid>
          <Grid
            sx={{
              mt: 2,

              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Typography
              sx={{
                fontSize: "12px",
                color: "#939393",
                fontWeight: 400,
                lineHeight: "18.97px",
              }}
            >
              Protected and subject to the
            </Typography>
            &nbsp;
            <Link
              to={"#"}
              onClick={handleOpenPolicy}
              style={{
                color: "#0000EE",
                fontSize: "12px",
                fontWeight: 400,
                lineHeight: "18.97px",
                textDecoration: "none",
              }}
            >
              privacy policy
            </Link>
            &nbsp;{" "}
            <Typography
              sx={{
                fontSize: "12px",
                color: "#939393",
                fontWeight: 400,
                lineHeight: "18.97px",
              }}
            >
              and
            </Typography>{" "}
            &nbsp;
            <Link
              to={"#"}
              onClick={handleOpenTerms}
              style={{
                color: "#0000EE",
                fontSize: "12px",
                fontWeight: 400,
                lineHeight: "18.97px",
                textDecoration: "none",
              }}
            >
              Terms of Services
            </Link>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};
export default SignUpForm;
