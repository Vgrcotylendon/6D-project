import { Box, Card, Grid, Typography } from "@mui/material";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import CustomTextInput from "../../Input/CustomTextInput";
import CustomAutoComplete, { OptionType } from "../../Input/CustomAutoComplete";
import { instance } from "../../../Controller/Common";
import CustomButton1 from "../../Button/CustomButton1";

export default function Information() {
  const [gender, setGender] = React.useState<OptionType | null>(null);
  const [data, setData] = useState<{ [key: string]: string }>({
    firstName: "",
    middleName: "",
    lastName: "",
  });

  const handleGender = (
    event: React.ChangeEvent<{}>,
    newValue: OptionType | null
  ) => {
    setGender(newValue);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, name } = e.target;
    const textOnly = value.replace(/[^a-zA-Z]/g, ""); // Allow only text

    setData((prevData) => ({
      ...prevData,
      [name]: textOnly,
    }));
  };
  const genderOptions = [
    { value: 0, label: "Male" },
    { value: 1, label: "Female" },
    { value: 2, label: "Others" },
  ];

  const navigate = useNavigate();

  const Information = async () => {
    try {
      const response = await instance.post("/6D/user/createUserProfile", {
        // UID: ID,
        FIRST_NAME: data.firstName,
        LAST_NAME: data.lastName,
        MIDDLE_NAME: data.middleName,
        GENDER: gender?.label,
      });
      if (response.status === 200) {
        navigate("/signin");
      }
    } catch (error) {
      console.error(error);
    }
  };
  return (
    <Grid item xs={6} sx={{ minWidth: 500 }}>
      <Typography align="center" variant="h4" sx={{ fontWeight: "700" }}>
        Enter Your Information
      </Typography>
      <Card
        elevation={0}
        sx={{
          bgcolor: "#EDF1F4",
          p: "25px 90px",
          display: "flex",
          justifyContent: "center",
          flexDirection: "column",
          mt: 2,
          borderRadius: 2,
        }}
      >
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <CustomTextInput
              label="First Name"
              name="firstName"
              value={data.firstName}
              onChange={handleChange}
              required
              textOnly
            />
          </Grid>
          <Grid item xs={12}>
            <CustomTextInput
              label="Middle Name"
              name="middleName"
              value={data.middleName}
              onChange={handleChange}
              textOnly
            />
          </Grid>
          <Grid item xs={12}>
            <CustomTextInput
              label="Last Name"
              name="lastName"
              placeholder={"Enter here"}
              value={data.lastName}
              onChange={handleChange}
              required
              textOnly
            />
          </Grid>
          <Grid item xs={12}>
            <CustomAutoComplete
              label="Gender"
              options={genderOptions}
              value={gender}
              onChange={handleGender}
              required
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  Information();
                }
              }}
            />
          </Grid>
        </Grid>
      </Card>
      <Box sx={{ display: "flex", justifyContent: "center", mt: 1 }}>
        <CustomButton1
          name="Complete Signup"
          variant="primary"
          disabled={!data || !gender}
          onClick={() => Information()}
        />
      </Box>
    </Grid>
  );
}
