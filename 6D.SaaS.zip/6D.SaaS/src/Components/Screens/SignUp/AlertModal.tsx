import {
    Box,
    Divider,
    FormControl,
    IconButton,
    InputAdornment,
    OutlinedInput,
    Typography,
  } from "@mui/material";
  import React from "react";
  import CloseIcon from "@mui/icons-material/Close";
  import MailIcon from "@mui/icons-material/Mail";
  import styled from "styled-components";
  import CheckCircleIcon from "@mui/icons-material/CheckCircle";
  import CustomButton1 from "../../Button/CustomButton1";
  import { useNavigate } from "react-router-dom";
  
  interface mailid {
    setShow1: React.Dispatch<React.SetStateAction<boolean>>;
  }
  
  const AlertModal: React.FC<mailid> = ({
    setShow1,
  }) => {
  
    const handleNavigate = () => {
      setShow1(false);
    };
  
    return (
      <MainBox>
        <IconButton
          size="small"
          onClick={() => setShow1(false)}
          sx={{ position: "absolute", top: 10, right: 10 }}
        >
          <CloseIcon />
        </IconButton>
        <SubBox>
          <Sub1Box>
              <Box>
               
                <Typography
                  sx={{
                    fontSize: "14px",
                    fontWeight: 400,
                    color: "#4C2D2D",
                    lineHeight: "21.68px",
                    padding: "20px 0",
                  }}
                >
                Please enter either your email or mobile number.
                </Typography>
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    padding: "20px 0px 20px 0px",
                  }}
                >
                  <CustomButton1
                    name="OK"
                    variant="primary"
                    padding="5px 15px"
                    onClick={handleNavigate}
                  />
                </Box>
              </Box>
          </Sub1Box>
        </SubBox>
      </MainBox>
    );
  };
  
  export default AlertModal;
  
  const MainBox = styled(Box)`
    display: flex;
    flex-direction: column;
    background-color: #ffffff;
    border-radius: 10px;
    padding: 30px;
    justify-content: center;
    align-items: center;
  `;
  const SubBox = styled(Box)`
    display: flex;
    flex-direction: column;
    background-color: #f6f5f5;
    border-radius: 10px;
    padding: 20px;
    justify-content: center;
    align-items: center;
  `;
  const Sub1Box = styled(Box)`
    display: flex;
    flex-direction: column;
    background-color: #ffffff;
    border-radius: 10px;
    padding: 16px;
    justify-content: center;
  `;
  