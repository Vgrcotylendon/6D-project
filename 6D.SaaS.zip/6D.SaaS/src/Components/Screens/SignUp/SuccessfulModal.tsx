import { Box, IconButton, Typography } from "@mui/material";
import React from "react";
import CustomLinearProgress from "../Activity/MyDashBoard/LinearProgress";
import CloseIcon from "@mui/icons-material/Close";
import CustomButton1 from "../../Button/CustomButton1";

interface SuccessProps {
  setShow: (value: boolean) => void;
}

const SuccessfulModal: React.FC<SuccessProps> = ({ setShow }) => {
  return (
    <Box sx={{ padding: "30px", backgroundColor: "#f0f0f0" }}>
      <IconButton
        size="small"
        onClick={() => setShow(false)}
        sx={{ position: "absolute", top: 10, right: 10 }}
      >
        <CloseIcon />
      </IconButton>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: "white",
          borderRadius: "10px",
          padding: "20px",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Typography
          sx={{
            fontSize: "16px",
            lineHeight: "21.68px",
            fontWeight: 600,
            color: "#4C2D2D",
            padding: "30px",
          }}
        >
          Please Wait
        </Typography>
        <Box
          sx={{
            backgroundColor: "#0c0c0c",
            height: "0.5px",
            width: "448px",
          }}
        />
        <Typography
          sx={{
            fontSize: "14px",
            fontWeight: 400,
            padding: "20px 10px 20px 10px",
          }}
        >
          Your are being Signed Up
        </Typography>
        <Box sx={{ padding: "20px 10px 20px 10px" }}>
          <CustomLinearProgress progress={100} />
        </Box>
        <Box
          sx={{
            backgroundColor: "#8b8989",
            height: "0.5px",
            width: "448px",
          }}
        />
        <Box sx={{ padding: "10px 0px 10px 0px" }}>
          <CustomButton1
            name="OK"
            variant="primary"
            onClick={() => setShow(false)}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default SuccessfulModal;
