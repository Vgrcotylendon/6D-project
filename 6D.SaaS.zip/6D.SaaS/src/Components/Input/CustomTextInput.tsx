import {
  Box,
  FormHelperText,
  Grid,
  InputBase,
  Typography,
} from "@mui/material";
import React, { useRef, useState } from "react";
import ErrorIcon from "@mui/icons-material/Error";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import PendingIcon from "@mui/icons-material/Pending";

import styled from "styled-components";

interface TextInputProps {
  id?: string;
  placeholder?: string;
  value?: string | number;
  isURL?: any;
  name?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  icon?: React.ElementType;
  iconClick?: () => void;
  isEmail?: boolean;
  isMobileNo?: boolean;
  isPassword?: boolean;
  disabled?: boolean | any;
  required?: boolean;
  label: string;
  type?: string;
  textOnly?: boolean;
  number?: boolean;
  pincode?: boolean;
  helperText?: string | null;
  helper?: boolean;
  adhaar?: boolean;
  apaar?: boolean;
  password?: boolean;
  readonly?: boolean | string;
  isEditable?: boolean;
  nonEditable?: boolean;
  showRequiredError?: boolean;
  allowSpaces?: boolean;
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
}

const CustomTextInput: React.FC<TextInputProps> = ({
  label,
  id,
  placeholder,
  value,
  name,
  isURL,
  onChange,
  icon: IconComponent,
  iconClick,
  isPassword,
  isEmail,
  isMobileNo,
  required,
  disabled,
  helperText,
  textOnly,
  number,
  type,
  pincode,
  helper,
  adhaar,
  apaar,
  password,
  onKeyDown,
  readonly,
  isEditable = false,
  nonEditable,
  showRequiredError,
  allowSpaces,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<boolean>(false);
  const [helperMessage, setHelperMessage] = useState<string>("");

  const handleFocus = () => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  function validateURL(url: string) {
    const regex = /^(https?:\/\/)?(www\.)?linkedin\.com\/.*$/i;
    return regex.test(url);
  }

  function validateEmail(email: string | number) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/i;
    return regex.test(String(email));
  }
  function validateIndianMobileNumber(mobileNumber: string) {
    const regex = /^[6-9]\d{9}$/;
    return regex.test(mobileNumber);
  }
  function validatePassword(password: string) {
    const length = /.{12,}/;
    const uppercase = /[A-Z]/;
    const lowercase = /[a-z]/;
    const number = /[0-9]/;
    const special = /[!@#$%^&*]/;

    if (!length.test(password)) return false;
    if (!uppercase.test(password)) return false;
    if (!lowercase.test(password)) return false;
    if (!number.test(password)) return false;
    if (!special.test(password)) return false;

    return true;
  }

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    let { value, name } = event.target;

    if (isMobileNo) {
      value = value.replace(/\D/g, "");
      if (value.startsWith("91") && value.length > 10) {
        value = value.slice(2);
      }
      if (value.length > 10) {
        value = value.slice(0, 10);
      }
      if (validateIndianMobileNumber(value)) {
        value = value;
      }
    }

    if (textOnly) {
      value = value.replace(/[^a-zA-Z\s]/g, "");
    }
    if (adhaar || apaar) {
      value = value.replace(/\D/g, "");
      if (value.length > 12) {
        value = value.slice(0, 12);
      }
    }

    if (number) {
      value = value.replace(/\D/g, "");
    }
    if (pincode) {
      value = value.replace(/\D/g, "");
      if (value.length > 6) {
        value = value.slice(0, 6);
      }
    }

    if (onChange) {
      onChange({
        ...event,
        target: { ...event.target, value, name },
      });
    }
    setError(false);
    setHelperMessage("");

    if (isURL) {
      if (value && !validateURL(value)) {
        setError(true);
        setHelperMessage("Enter a valid URL.");
      } else {
        setError(false);
        setHelperMessage("");
      }
    }

    if (isEmail) {
      if (value === "") {
        setError(false);
      } else {
        if (!validateEmail(value)) {
          setError(true);
          setHelperMessage("Enter a valid email address.");
        } else {
          setError(false);
          setHelperMessage("");
        }
      }
    }
    if (isMobileNo) {
      if (value === "") {
        setError(false);
      } else {
        if (!validateIndianMobileNumber(value)) {
          setError(true);
          setHelperMessage("Enter a valid phone number.");
        } else {
          setError(false);
          setHelperMessage("");
        }
      }
    }

    if (isPassword) {
      if (value === "") {
        setError(false);
      } else {
        if (!validatePassword(value)) {
          setError(true);
          setHelperMessage(
            "Password must be at least 8 characters and include uppercase, lowercase, number, and special character."
          );
        }
      }
    }
  };
  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (!allowSpaces && event.key === " ") {
      event.preventDefault();
    }
    if (onKeyDown) {
      onKeyDown(event);
    }
  };
  return (
    <GridContainer>
      <GridTypo>
        {label}
        {required && "*"}
      </GridTypo>
      <InputBox
        onClick={handleFocus}
        disabled={disabled}
        isError={!!password}
        value={value}
        isEditable={isEditable}
        readonly={readonly}
      >
        <CustomInput
          id={id}
          placeholder={placeholder ?? `Enter ${label}`}
          value={value}
          readonly={readonly}
          name={name}
          type={type}
          onChange={handleChange}
          inputRef={inputRef}
          fullWidth
          autoFocus={!!value}
          disabled={disabled}
          isError={!!password}
          size="small"
          onKeyDown={handleKeyDown}
          inputProps={{ readOnly: readonly}}
          isEditable={isEditable}
        />
        {IconComponent && (
          <IconComponent
            sx={{
              color: value === "" ? "#939597" : "#000",
              cursor: iconClick && "pointer",
            }}
            onClick={iconClick}
          />
        )}

        {((adhaar || apaar) &&
          (String(value).length === 12 || String(value).length === 14) && (
            <CheckCircleIcon sx={{ color: "#48A055" }} />
          )) ||
          ((adhaar || apaar) && !value && (
            <PendingIcon sx={{ color: "warning.main" }} />
          ))}
      </InputBox>

      {/* Displaying error message for required fields */}
      {required && showRequiredError && !value && !disabled && (
        <Box sx={{ minHeight: 30 }}>
          <FormHelperText sx={{ mt: "8px", ml: "8px", color: "warning.main" }}>
            <Typography
              sx={{
                display: "flex",
                alignItems: "center",
                fontSize: "14px",
                color: "#BF1932",
              }}
            >
              <ErrorIcon sx={{ fontSize: "20px" }} />
              &nbsp; {label} is required
            </Typography>
          </FormHelperText>
        </Box>
      )}

      {!disabled && (
        <Box sx={{ minHeight: 30 }}>
          {error || helperMessage ? (
            <FormHelperText
              sx={{
                color: "#BF1932",
                ml: "8px",
                fontSize: "12px",
                display: "flex",
                flexDirection: "row",
                alignItems: "flex-start",
              }}
            >
              {helperMessage}
            </FormHelperText>
          ) : (
            helperText && (
              <FormHelperText
                sx={{ ml: "8px", fontSize: "14px", color: "#BF1932" }}
              >
                {helperText}
              </FormHelperText>
            )
          )}
        </Box>
      )}
    </GridContainer>
  );
};

export default CustomTextInput;
const GridContainer = styled(Grid)`
  margin: 0 15px;
  border-radius: 8px;
`;
const GridTypo = styled(Typography)`
  font-size: 10px;
  font-weight: 600;
  color: black;
  padding: 0 0 5px 0;
`;

const getBackgroundColor = ({
  disabled,
  isError,
  value,
  isEditable,
  readonly,
}: {
  disabled?: boolean;
  isError: boolean;
  value: any;
  isEditable: boolean;
  readonly?: any;
}) => {
  if ((value === undefined || value === "") && disabled) return "#babcbe";
  if ((value === undefined || value === "") && readonly) return "#f0f0f0";
  if (isError) return "#EFDFE1";
  if (isEditable) return "white";
  if (readonly) return "#f0f0f0";
  return value !== undefined ? "#f0f0f0" : "white";
};

const InputBox = styled(Box)<{
  disabled?: boolean;
  isError: boolean;
  value: any;
  isEditable: boolean;
  readonly?: any;
}>`
  display: flex;
  align-items: center;
  border-radius: 8px;
  border: 1px solid;
  border-color: ${({ isError, disabled }) =>
    disabled ? "#babcbe" : isError ? "#D77C89" : "#babcbe"};
  padding: 0 10px;
  /* "#f0f0f0" */
  background-color: ${({ disabled, isError, value, isEditable, readonly }) =>
    (value === undefined || value === "") && disabled
      ? "#babcbe"
      : isError
      ? "#EFDFE1"
      : isEditable
      ? "white"
      : readonly
      ? "#f0f0f0"
      : value !== undefined
      ? "#f0f0f0"
      : "#f0f0f0"};
  ${({ isEditable, disabled ,readonly}) =>
    !disabled &&
    isEditable &&
    `
      &:hover {
        background-color: ${(props: any) => getBackgroundColor(props)};
        border-color: #666668;
      }
    `}
  ${({ disabled, readonly}) => (disabled  || readonly) && `pointer-events: none;`}
`;

const CustomInput = styled(InputBase)<{
  disabled?: boolean;
  isError: boolean;
  value: any;
  isEditable: boolean;
  readonly?: any;
}>`
  width: 100%;
  border-radius: 5px;
  border: none;
  background-color: ${({ disabled, isError, isEditable, value, readonly }) =>
    (value === undefined || value === "") && disabled
      ? "#babcbe"
      : isError
      ? "#EFDFE1"
      : isEditable
      ? "white"
      : readonly
      ? "#f0f0f0"
      : value !== undefined
      ? "#f0f0f0"
      : "#f0f0f0"};
  height: 45px;
  & input {
    padding: 0 5px;
    height: 100%;
    cursor: ${({ disabled,readonly }) => (disabled || readonly ? "default" : "text")};
    pointer-events: ${({ disabled, readonly }) => (disabled || readonly ? "none" : "auto")};
  }
  & input::placeholder {
    color: ${({ disabled }) => (disabled ? "#000" : "#babcbe")};
    opacity: 1;
  }
  ${({ disabled, readonly }) =>
    (disabled || readonly) &&
    `
      pointer-events: none;
      cursor: not-allowed;
    `}
  &:hover {
    background-color: ${({ disabled, isError, isEditable, value, readonly }) =>
      (value === undefined || value === "") && disabled
        ? "#babcbe"
        : isError
        ? "#EFDFE1"
        : isEditable
        ? "white"
        : readonly
        ? "#f0f0f0"
        : value !== undefined
        ? "#f0f0f0"
        : "#f0f0f0"};
    border-color: #666668;
  }
  input:-webkit-autofill,
  input:-webkit-autofill:hover,
  input:-webkit-autofill:focus,
  input:-webkit-autofill:active {
    -webkit-box-shadow: ${({ isError, disabled }) =>
        disabled ? "#babcbe" : isError ? "EFDFE1" : "#fff"}
      0 0 0 30px white inset !important;
    -webkit-text-fill-color: black !important;
    transition: background-color 5000s ease-in-out 0s;
  }
`;
