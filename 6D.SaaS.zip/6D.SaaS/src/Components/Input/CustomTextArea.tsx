import {
  Box,
  FormHelperText,
  Grid,
  Typography,
} from "@mui/material";
import React, { useRef } from "react";
import styled from "styled-components";
import { Editor } from "@tinymce/tinymce-react";
import ErrorIcon from "@mui/icons-material/Error";

interface TextInputProps {
  id?: string;
  placeholder?: string;
  value?: string | number;
  name?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  disabled?: boolean;
  required?: boolean;
  label: string;
  type?: string;
  helperText?: string;
  helper?: boolean;
  showRequiredError?: boolean;
  isDisabled?: boolean;
}

const CustomTextArea: React.FC<TextInputProps> = ({
  label,
  id,
  placeholder,
  value,
  name,
  onChange,
  required,
  disabled,
  helperText,
  helper,
  showRequiredError,
  isDisabled = false,
}) => {
  const editorRef = useRef<any>(null);

  const ApiKey = process.env.REACT_APP_TINY_MCE_API_KEY;

  const handleEditorChange = (content: string) => {
    if (!disabled && onChange) {
      const strippedContent = content.replace(/<[^>]*>/g, " ");
      const words = strippedContent
        .trim()
        .split(/\s+/)
        .filter((word) => word.length > 0);

      let finalContent = content;

      if (words.length > 5000) {
        const limitedWords = words.slice(0, 5000).join(" ");
        finalContent = limitedWords;

        // Update the editor's content to reflect truncation
        if (editorRef.current) {
          editorRef.current.setContent(limitedWords);
        }
      }

      const syntheticEvent = {
        target: {
          name: name || "",
          value: finalContent,
        },
      } as React.ChangeEvent<HTMLInputElement>;

      onChange(syntheticEvent);
    }
  };

  React.useEffect(() => {
    if (editorRef.current) {
      editorRef.current.getElement().style.backgroundColor = disabled
        ? "#f0f0f0"
        : isDisabled
        ? "white"
        : "white";
    }
  }, [disabled, isDisabled, value]);

  return (
    <GridContainer>
      <Grid
        display="flex"
        justifyContent="space-between"
        marginBottom={1}
        paddingLeft={0.5}
        paddingRight={0.5}
      >
        <Typo>
          {label}
          {required && "*"}
        </Typo>
      </Grid>

      <EditorWrapper disabled={disabled} isDisabled={isDisabled}>
        <Editor
          apiKey={ApiKey}
          key={disabled ? "disabled" : "enabled"}
          id={id}
          onInit={(evt, editor) => (editorRef.current = editor)}
          value={String(value)}
          init={{
            height: 300,
            menubar: false,
            plugins: [
              // "advlist",
              // "autolink",
              // "lists",
              // "link",
              // "preview",
              // "wordcount",
              "anchor",
              "autolink",
              "charmap",
              "codesample",
              "emoticons",
              "image",
              "link",
              "lists",
              "media",
              "searchreplace",
              "table",
              "visualblocks",
              "wordcount",
              "checklist",
              "mediaembed",
              "casechange",
              "export",
              "formatpainter",
              "pageembed",
              "a11ychecker",
              "tinymcespellchecker",
              "permanentpen",
              "powerpaste",
              "advtable",
              "advcode",
              "editimage",
              "advtemplate",
              "ai",
              "mentions",
              "tinycomments",
              "tableofcontents",
              "footnotes",
              "mergetags",
              "autocorrect",
              "typography",
              "inlinecss",
              "markdown",
            ],
            font_family_formats: "Poppins=Poppins;",
            toolbar: "bold italic link bullist numlist | removeformat",
            content_style: `
             @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
              body {
                    font-family: Poppins;
                    font-size: 14px;
                    color: ${disabled ? "black" : "black"};
                    background-color: ${
                      disabled ? "#f0f0f0" : isDisabled ? "#fff" : "white"
                    };
                    margin: 0;
                    border-radius:7px;
                    padding-left:5px;
                    white-space: pre-wrap; /* Ensures text wraps correctly */
                    word-wrap: break-word; /* Breaks long words */
                    overflow-wrap: break-word; /* Prevents overflowing text */
                    overflow: auto; /* Adds scrollbar if content overflows */
                   }
                      p, h1, h2, h3, h4, h5, h6, span {
                      font-family: 'Poppins' !important;
                   }
                     `,
            statusbar: false,
            placeholder: placeholder || `Enter ${label}`,
            browser_spellcheck: true,
            toolbar_sticky: true,
            toolbar_location: "top",
            branding: false,
          }}
          onEditorChange={handleEditorChange}
          disabled={disabled}
        />
      </EditorWrapper>

      {helper && (
        <Box sx={{ minHeight: 30 }}>
          {!disabled && helper && showRequiredError && (
            <FormHelperText
              sx={{
                color: "#BF1932",
                ml: "8px",
                fontSize: "12px",
                display: "flex",
                flexDirection: "row",
                alignItems: "flex-start",
              }}
            >
              <>
                {helperText
                  ? helperText
                  : String(value).length === 0 && (
                      <>
                        <ErrorIcon sx={{ fontSize: "15px", mt: 0.1 }} />
                        &nbsp; {label} is required
                      </>
                    )}
              </>
            </FormHelperText>
          )}
        </Box>
      )}
    </GridContainer>
  );
};

export default CustomTextArea;

const GridContainer = styled(Grid)`
  margin: 0 15px;
  border-radius: 8px;
`;

const Typo = styled(Typography)`
  font-size: 10px;
  font-weight: 600;
  color: black;
  padding: 0 0 5px 0;
`;

const EditorWrapper = styled.div<{ disabled?: boolean; isDisabled?: boolean }>`
  .tox-tinymce {
    border: 1px solid #cfcdcd !important;
    border-radius: 8px !important;
    border: 1px solid #cfcdcd !important;
    pointer-events: ${({ disabled }) => (disabled ? "none" : "auto")};
  }

  .tox-editor-container {
    pointer-events: ${({ disabled }) => (disabled ? "none" : "auto")};
    background-color: ${({ disabled, isDisabled }) =>
      disabled ? "#f0f0f0" : isDisabled ? "#f0f0f0" : "white"};
  }

  .tox-toolbar {
    background-color: ${({ disabled }) =>
      disabled ? "#f0f0f0" : "white"} !important;
    /* border-bottom: 1px solid */
    /* ${({ disabled }) => (disabled ? "#f0f0f0" : "white")} !important; */
    pointer-events: ${({ disabled }) => (disabled ? "none" : "auto")};
  }

  .tox .tox-toolbar__primary {
    background-color: ${({ disabled }) =>
      disabled ? "#f0f0f0" : "white"} !important;
    margin-top: -4px;
    margin-bottom: -4px;
    min-height: 35px;
  }

  .tox .tox-toolbar__primary button {
    background-color: ${({ disabled }) =>
      disabled ? "#f0f0f0" : "white"} !important;
    color: ${({ disabled }) => (disabled ? "white" : "#f0f0f0")} !important;
  }
`;
