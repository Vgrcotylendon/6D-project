import React, { useRef } from "react";
import styled from "styled-components";
import ErrorIcon from "@mui/icons-material/Error";
import { Box, FormHelperText, InputBase, Typography } from "@mui/material";

interface InputFieldProps {
  id?: string;
  placeholder?: string;
  value?: string | number;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  iconClick?: () => void;
  icon?: React.ElementType;
  disabled?: boolean;
  readOnly?: boolean;
  helper?: any;
  type?: string;
  label?: string;
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
}

const InputField: React.FC<InputFieldProps> = ({
  id,
  placeholder,
  value,
  onChange,
  icon: IconComponent,
  onKeyDown,
  iconClick,
  disabled,
  type,
  label,
  helper,
  readOnly,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFocus = () => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    let { value } = event.target;
    onChange({
      ...event,
      target: { ...event.target, value },
    });
  };

  return (
    <>
      <Box
        onClick={handleFocus}
        sx={{
          display: "flex",
          alignItems: "center",
          borderRadius: "5px",
          border: helper && value ? "1px solid #BF1932" : "1px solid #babcbe",
          padding: "10px 10px",
          backgroundColor: helper && value ? "#EFDFE1" : "white",
          height: "40px",
          boxSizing: "border-box",
          "&:hover": {
            backgroundColor: value ? "white" : "#cedff0",
            border: value ? "1px solid #babcbe" : "1px solid #cedff0",
            "& .InputField": {
              backgroundColor: value ? "white" : "#cedff0",
            },
          },
          "&:active": {
            border: `2px solid #2A62AA`,
          },
        }}
      >
        <InputBase
          sx={{
            backgroundColor: helper && value ? "#EFDFE1" : "white",
            "& input": {
              fontSize: "15px !important",
              padding: 0,
            },
            "& input:-webkit-autofill, & input:-webkit-autofill:hover, & input:-webkit-autofill:focus, & input:-webkit-autofill:active":
              {
                WebkitBoxShadow: `${
                  helper && value ? "#EFDFE1" : "white"
                } 0 0 0 30px white inset !important`,
                WebkitTextFillColor: "black !important",
                transition: "background-color 5000s ease-in-out 0s",
              },
          }}
          className="InputField"
          id={id}
          placeholder={`Enter ${label}`}
          value={value}
          type={type}
          onChange={handleChange}
          inputRef={inputRef}
          fullWidth
          autoFocus={!!value}
          disabled={disabled}
          onKeyDown={onKeyDown}
          inputProps={{ readOnly: readOnly }}
        />
        {IconComponent && (
          <IconComponent
            sx={{
              color: value === "" ? "#939597" : "#000",
              cursor: iconClick && "pointer",
              fontSize: "20px",
            }}
            onClick={iconClick}
          />
        )}
      </Box>

      <Box sx={{ height: helper && value ? 30 : 15 }}>
        {" "}
        {helper && value && (
          <FormHelperText
            sx={{
              color: "#BF1932",
              ml: "8px",
              fontSize: "12px",
              display: "flex",
              flexDirection: "row",
              alignItems: "flex-start",
            }}
          >
            <ErrorIcon sx={{ color: "#BF1932", fontSize: "15px" }} />
            &nbsp; {helper}
          </FormHelperText>
        )}
      </Box>
    </>
  );
};

export default InputField;

export const GridTypo = styled(Typography)`
  font-size: 14px;
  font-weight: 550;
  color: black;
  padding: 0 0 10px 0;
`;

export const CustomInput = styled(InputBase)`
  width: 100%;
  border-radius: 5px;
  border: 1px solid #c0c2c4;
  background-color: white;
  height: 50px;
`;
