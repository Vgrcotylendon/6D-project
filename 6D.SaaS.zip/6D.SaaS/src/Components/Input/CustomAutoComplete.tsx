import * as React from "react";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import styled from "styled-components";
import { Box, FormHelperText, Grid, Typography } from "@mui/material";
import ErrorIcon from "@mui/icons-material/Error";

export interface OptionType {
  label: string;
  value: any;
}

interface CustomAutoCompleteProps {
  options: Array<OptionType>;
  label: string;
  name?: string;
  value?: OptionType | null;
  onChange?: (
    event: React.ChangeEvent<{}>,
    newValue: OptionType | null
  ) => void;
  required?: boolean;
  readOnly?: boolean;
  disabled?: boolean;
  helper?: boolean;
  helperText?: string;
  showRequiredError?: boolean;
  isEditable?: boolean;
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
}

const CustomAutoComplete: React.FC<CustomAutoCompleteProps> = ({
  options,
  label,
  value,
  onChange,
  required,
  disabled,
  helper,
  helperText,
  readOnly,
  onKeyDown,
  showRequiredError,
  name,
  isEditable,
}) => {
  return (
    <GridContainer>
      <GridTypo>
        {label}
        {required && "*"}
      </GridTypo>
      <InputBox
        disabled={disabled}
        value={value}
        readOnly={readOnly}
        isEditable={isEditable}
      >
        <Autocomplete
          disablePortal
          id="combo-box-demo"
          options={options}
          value={value}
          onChange={(event, newValue) => {
            if (!readOnly && onChange) {
              onChange(event, newValue);
            }
          }}
          getOptionLabel={(option) => option.label}
          size="small"
          popupIcon={readOnly ? null : undefined}
          forcePopupIcon={!readOnly}
          sx={{
            height: "45px",
            width: "100%",
            background:
              !value && disabled
                ? "#babcbe"
                : value && !isEditable
                ? "#f0f0f0"
                : isEditable
                ? "white"
                : readOnly
                ? "#f0f0f0"
                : !value && readOnly
                ? "#f0f0f0"
                : null,

            "& .MuiInputBase-root.Mui-readOnly": {
              cursor: "default",
              "& input": {
                cursor: "default",
              },
            },
            "& .MuiAutocomplete-popupIndicator": {
              display: readOnly ? "none" : "block",
            },
            "& .MuiAutocomplete-listbox": {
              fontFamily: "Poppins",
              fontSize: "14px",
            },
            "& .MuiInputBase-root": {
              fontFamily: "Poppins, sans-serif",
            },
          }}
          renderInput={(params) => (
            <StyledTextField
              {...params}
              label={label ? label : ""}
              autoComplete="on"
              name={name}
              focused
              inputProps={{
                ...params.inputProps,
                readOnly: readOnly,
                style: readOnly
                  ? { cursor: "default", fontFamily: "Poppins, sans-serif" }
                  : { fontFamily: "Poppins, sans-serif" },
              }}
              placeholder={`Enter ${label}`}
              value={value}
              disabled={disabled}
              isEditable={isEditable}
              onKeyDown={onKeyDown}
            />
          )}
          disabled={disabled}
          readOnly={readOnly}
        />
      </InputBox>
      {helper && (
        <Box sx={{ minHeight: 30 }}>
          {!disabled && helper && (
            <FormHelperText
              sx={{
                color: "#BF1932",
                ml: "8px",
                fontSize: "12px",
                display: "flex",
                flexDirection: "row",
                alignItems: "flex-start",
              }}
            >
              <>
                {!value && showRequiredError && (
                  <>
                    <ErrorIcon sx={{ fontSize: "15px", mt: 0.1 }} />
                    &nbsp; {label} is required
                  </>
                )}
              </>
            </FormHelperText>
          )}
        </Box>
      )}
    </GridContainer>
  );
};

export default CustomAutoComplete;

// Extend the props for the styled component
const StyledTextField = styled(TextField)<{
  disabled?: boolean;
  value?: any;
  readOnly?: boolean;
  isEditable?: boolean;
}>(({ disabled, value, readOnly, isEditable }) => ({
  "& .MuiInputBase-root": {
    backgroundColor:
      !value && disabled
        ? "#babcbe"
        : value && !isEditable
        ? "#f0f0f0"
        : isEditable
        ? "white"
        : readOnly
        ? "#f0f0f0"
        : !value && readOnly
        ? "#f0f0f0"
        : "#f0f0f0",
    color: disabled ? "#999" : "#000",
    cursor: readOnly ? "default" : "text",
    "&.Mui-focused": {
      cursor: readOnly ? "default" : "text",
    },
    "& input": {
      cursor: readOnly ? "default !important" : "text",
    },
    "& .MuiAutocomplete-endAdornment": {
      display: readOnly ? "none" : "flex",
    },
  },
  "& .MuiInputLabel-root": {
    display: "none",
  },
  "& .MuiOutlinedInput-notchedOutline": {
    border: "none",
  },
  "& input::placeholder": {
    color: disabled ? "#000" : "#999",
    opacity: 1,
  },
  padding: "5px 5px",
}));

const InputBox = styled(Box)<{
  disabled?: boolean;
  value?: any;
  readOnly?: any;
  isEditable?: boolean;
}>`
  display: flex;
  align-items: center;
  border-radius: 8px;
  border: 1px solid #babcbe;
  padding: 0 5px;
  background-color: ${({ disabled, value, readOnly, isEditable }) =>
    !value && disabled
      ? "#babcbe"
      : value && !isEditable
      ? "#f0f0f0"
      : readOnly
      ? "#f0f0f0"
      : !value && readOnly
      ? "#f0f0f0"
      : isEditable
      ? "white"
      : null};
  height: 45px;
  cursor: ${({ readOnly }) => (readOnly ? "default" : "text")};
`;

const GridContainer = styled(Grid)`
  margin: 0 15px;
  border-radius: 8px;
`;

const GridTypo = styled(Typography)`
  font-size: 10px;
  font-weight: 600;
  color: black;
  padding: 0 0 5px 0;
`;
