import React from "react";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { Box, FormHelperText, Grid, Typography } from "@mui/material";
import dayjs, { Dayjs } from "dayjs";
import weekOfYear from "dayjs/plugin/weekOfYear";
import customParseFormat from "dayjs/plugin/customParseFormat";
import localizedFormat from "dayjs/plugin/localizedFormat";
import isBetween from "dayjs/plugin/isBetween";
import advancedFormat from "dayjs/plugin/advancedFormat";
import updateLocale from "dayjs/plugin/updateLocale";
import styled from "styled-components";
import ErrorIcon from "@mui/icons-material/Error";

dayjs.extend(weekOfYear);
dayjs.extend(customParseFormat);
dayjs.extend(localizedFormat);
dayjs.extend(isBetween);
dayjs.extend(advancedFormat);
dayjs.extend(updateLocale);

dayjs.updateLocale("en", {
  week: {
    dow: 1,
  },
});

interface CustomDate {
  label: string;
  maxDate?: Dayjs;
  value?: Dayjs | null;
  name?: string;
  onChange?: (date: Dayjs | null) => void;
  required?: boolean;
  helper?: boolean;
  helperText?: string;
  disabled?: boolean;
  readOnly?: boolean;
  minDate?: Dayjs;
  weekday?: number;
  isEditable?: boolean;
  showRequiredError?: boolean;
}
const CustomDatePicker: React.FC<CustomDate> = ({
  label,
  value,
  onChange,
  required,
  name,
  maxDate = dayjs(),
  helper,
  minDate,
  helperText,
  weekday = dayjs(value).day(),
  disabled,
  isEditable = false,
  readOnly = false,
  showRequiredError,
}) => {
  const [open, setOpen] = React.useState(false);
  const handleFieldClick = () => {
    if (!readOnly && !disabled) {
      setOpen(true);
    }
  };
  return (
    <GridContainer>
      <GridTypo>
        {label}
        {required && "*"}
      </GridTypo>
      <InputBox
        disabled={disabled}
        value={value}
        isEditable={isEditable}
        readOnly={readOnly}
      >
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <StyledDatePicker
            label={label}
            name={name}
            value={value}
            // onChange={onChange}
            onChange={(date) => {
              onChange && onChange(date);
              // setOpen(false);
            }}
            disabled={disabled}
            maxDate={maxDate}
            minDate={minDate}
            readOnly={readOnly}
            isEditable={isEditable}
            open={open}
            onOpen={() => setOpen(true)}
            onClose={() => setOpen(false)}
            views={["year", "month", "day"]}
            openTo="day"
            slotProps={{
              textField: {
                size: "small",
                placeholder: value ? undefined : `Enter ${label}`, 
                focused: true,
                onClick: handleFieldClick,
                InputProps: {
                  readOnly: true,
                  style: {
                    cursor: readOnly ? "default" : "pointer",
                    // pointerEvents: readOnly ? "none" : "auto",
                  },
                },
                inputProps: {
                  readOnly: true, 
                },
              },
              popper: {
                sx: {
                  "& .MuiDateCalendar-root": {
                    backgroundColor: "#fff",
                    borderRadius: "8px",
                  },
                  "& .MuiPickersDay-root": {
                    color: "#333",
                    borderRadius: 1,
                    backgroundColor: "rgba(237, 241, 244, 1)",
                    "&:hover": {
                      backgroundColor: "#e0e0e0",
                    },
                    "&.Mui-selected": {
                      border: "3px solid #c9c9c9",
                      backgroundColor: "#b0cff8",
                      color: "#000",
                    },
                    "&:nth-of-type(6), &:nth-of-type(7),&:nth-of-type(1 + 1n)":
                      {
                        backgroundColor: "#2A62AA",
                        color: "#fff",
                      },
                  },
                  "& .MuiPickersDay-today": {
                    backgroundColor: "#fff",
                    color: "#000",
                    border: "1px solid gray",
                    "&:hover": {
                      backgroundColor: "#4c72a3",
                    },
                  },
                  "& .MuiDayCalendar-weekDayLabel": {
                    color: "#2A62AA",
                  },
                  "& .MuiPickersCalendarHeader-root": {
                    color: "#2A62AA",
                    margin: "0 auto",
                    zIndex: 2,
                  },
                  "& .MuiPickersArrowSwitcher-root": {
                    width: "100%",
                    justifyContent: "space-between",
                    margin: "0 auto",
                    position: "absolute",
                    left: 0,
                    zIndex: -1,
                  },
                  "& .MuiPickersCalendarHeader-label": {
                    fontWeight: "bold",
                  },
                  "& .MuiPickersArrowSwitcher-button": {
                    color: "#2A62AA",
                  },
                  "& .MuiPickersCalendarHeader-switchViewIcon": {
                    color: "#2A62AA",
                  },
                },
              },
            }}
            format="DD/MM/YYYY"
          />
        </LocalizationProvider>
      </InputBox>
      {helper && (
        <>
          {" "}
          <Box sx={{ minHeight: 30 }}>
            {!disabled && value === null && helper && (
              <FormHelperText
                sx={{
                  color: "#BF1932",
                  ml: "8px",
                  fontSize: "12px",
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "flex-start",
                }}
              >
                <>
                  {helperText
                    ? helperText
                    : !value &&
                      showRequiredError && (
                        <>
                          <ErrorIcon sx={{ fontSize: "15px", mt: 0.1 }} />
                          &nbsp; {label} is required
                        </>
                      )}
                </>
              </FormHelperText>
            )}
          </Box>
        </>
      )}
    </GridContainer>
  );
};

export default CustomDatePicker;

const StyledDatePicker = styled(DatePicker)<{
  disabled?: boolean;
  isEditable?: boolean;
  value?: any;
}>(({ disabled, value, readOnly, isEditable }) => ({
  "& .MuiInputBase-root": {
    backgroundColor:
      !value && disabled
        ? "#babcbe"
        : value && !isEditable
        ? "#f0f0f0"
        : isEditable
        ? "white"
        : readOnly
        ? "#f0f0f0"
        : "#f0f0f0",
    color: "#000",
    pointerEvents: readOnly ? "none" : "auto",
    cursor: readOnly ? "default" : "text",
    "& input": {
      cursor: readOnly ? "default" : "text",
    },
  },
  "& .MuiInputLabel-root": {
    display: "none",
  },
  "& .MuiOutlinedInput-notchedOutline": {
    border: "none",
  },
  "& input": {
    cursor: readOnly ? "default" : "text",
    "&::placeholder": {
      color: disabled ? "#000" : "#909092",
    },
  },
  width: "100%",
  " &:hover": {
    backgroundColor:
      !value && disabled
        ? "#babcbe"
        : value && !isEditable
        ? "#f0f0f0"
        : isEditable
        ? "white"
        : readOnly
        ? "#f0f0f0"
        : "#f0f0f0",
    borderColor: disabled || readOnly ? undefined : "#666668",
  },
}));

const InputBox = styled(Box)<{
  disabled?: boolean;
  value?: any;
  readOnly?: any;
  isEditable?: boolean;
}>`
  display: flex;
  align-items: center;
  border-radius: 8px;
  border: 1px solid #babcbe;
  padding: 0 2px;
  background-color: white;
  height: 45px;
  border-color: ${({ disabled, readOnly }) =>
    disabled || readOnly ? undefined : "#babcbe"};
  background-color: ${({ disabled, value, readOnly, isEditable }) =>
    !value && disabled
      ? "#babcbe"
      : value && !isEditable
      ? "#f0f0f0"
      : readOnly
      ? "#f0f0f0"
      : isEditable
      ? "white"
      : "#f0f0f0"};
  &:hover {
    background-color: ${({ disabled, value, readOnly, isEditable }) =>
      !value && disabled
        ? "#babcbe"
        : value && !isEditable
        ? "#f0f0f0"
        : readOnly
        ? "#f0f0f0"
        : isEditable
        ? "white"
        : "#f0f0f0"};
    border-color: ${({ disabled, readOnly }) =>
      disabled || readOnly ? undefined : " #666668"};
  }
`;

const GridContainer = styled(Grid)`
  margin: 0 15px;
  border-radius: 8px;
`;

const GridTypo = styled(Typography)`
  font-size: 10px;
  font-weight: 600;
  color: black;
  padding: 0 0 5px 0;
`;
