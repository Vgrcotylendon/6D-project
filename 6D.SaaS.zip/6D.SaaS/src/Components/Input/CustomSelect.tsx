import React from 'react';
import Box from '@mui/material/Box';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import styled from 'styled-components';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { Grid, Typography, FormHelperText } from '@mui/material';

export interface OptionType {
    label: string;
    value: any;
}

interface CustomSelectProps {
    options: Array<OptionType>;
    label: string;
    value?: any;
    onChange?: (event: SelectChangeEvent) => void;
    required?: boolean;
    disabled?: boolean;
    helper?: boolean;
    helperText?: string;
    onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
    error?: boolean;
}

const CustomSelect: React.FC<CustomSelectProps> = ({
    options,
    label,
    value,
    onChange,
    required,
    disabled,
    helper,
    helperText,
    onKeyDown,
    error,
    ...rest
}) => {
    return (
        <GridContainer>
            <GridTypo>
                {label}
                {required && "*"}
            </GridTypo>
            <InputBox disabled={disabled}>
                <FormControl fullWidth error={error}>
                    <Select
                        value={value || ''}
                        onChange={onChange}
                        onKeyDown={onKeyDown}
                        disabled={disabled}
                        {...rest} // Spread additional props
                    >
                        {options.map((option) => (
                            <MenuItem key={option.value} value={option.value}>
                                {option.label}
                            </MenuItem>
                        ))}
                    </Select>
                    {helper && helperText && (
                        <FormHelperText>{helperText}</FormHelperText>
                    )}
                </FormControl>
            </InputBox>
        </GridContainer>
    );
};

export default CustomSelect;

const GridContainer = styled(Grid)`
    margin: 0 15px;
    border-radius: 8px;
`;

const GridTypo = styled(Typography)`
    font-size: 10px;
    font-weight: 600;
    color: black;
    padding: 0 0 5px 0;
`;

const InputBox = styled(Box)<{ disabled?: boolean }>`
    display: flex;
    align-items: center;
    border-radius: 8px;
    border: 1px solid #babcbe;
    padding: 0 10px;
    background-color: ${({ disabled }) => (disabled ? "#babcbe" : "white")};
    height: 45px;
`;
