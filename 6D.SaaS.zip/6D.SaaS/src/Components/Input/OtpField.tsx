import React, { useEffect, useRef, useState } from "react";
import { Box, InputBase } from "@mui/material";
import styled from "styled-components";
import clsx from "clsx";

const OtpContainer = styled(Box)`
  display: flex;
  justify-content: center;
  padding: 10px;
`;

const OtpInput = styled(InputBase)`
  border-color: #c9cacb;
  // border: 1px solid #c9cacb;
  // border: 1px solid #95c69d;
  // border: 1px solid #D77C89;
  // background-color: #ffffff;
  // background-color: #e3ece5;
  // background-color: #EFDFE1;
  input {
    text-align: center;
  }
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
`;

interface OtpFieldProps {
  setOtp: (otp: string) => void;
  time: number;
  otp: string;
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  error: boolean;
  success: boolean;
  clear: boolean;
}

const OtpField: React.FC<OtpFieldProps> = ({
  setOtp,
  time,
  otp,
  onKeyDown,
  error,
  success,
  clear,
}) => {
  const [otpState, setOtpState] = useState(["", "", "", ""]);
  const refs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    setOtp(otpState.join(""));
  }, [otpState, setOtp]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    index: number
  ) => {
    const value = e.target.value.replace(/\D/, "");
    const newOtp = [...otpState];
    newOtp[index] = value;
    setOtpState(newOtp);

    if (value && index < refs.current.length - 1) {
      refs.current[index + 1]?.focus();
    }
  };
  useEffect(() => {
    setOtpState(["", "", "", ""]);
    refs.current[0]?.focus();
  }, [clear]);

  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>,
    index: number
  ) => {
    if (e.key === "Backspace" && !otpState[index] && index > 0) {
      refs.current[index - 1]?.focus();
    }

    // Call the onKeyDown prop if provided
    if (onKeyDown) {
      onKeyDown(e);
    }
  };

  return (
    <OtpContainer>
      {otpState.map((digit, index) => (
        <OtpInput
          className={clsx("OTP", {
            base: otp.length !== 4 && time > 0,
            success: success === true,
            error: error === true,
          })}
          key={index}
          inputRef={(el) => (refs.current[index] = el)}
          placeholder={"_"}
          value={digit}
          onChange={(e) =>
            handleChange(e as React.ChangeEvent<HTMLInputElement>, index)
          }
          onKeyDown={(e) =>
            handleKeyDown(e as React.KeyboardEvent<HTMLInputElement>, index)
          }
          inputProps={{
            maxLength: 1,
            tabIndex: index + 1,
          }}
          // type="number"
          autoFocus={index === 0} // Autofocus on the first input field
        />
      ))}
    </OtpContainer>
  );
};

export default OtpField;
