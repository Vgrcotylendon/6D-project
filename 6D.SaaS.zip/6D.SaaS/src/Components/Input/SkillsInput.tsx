import {
  Box,
  FormHelperText,
  Grid,
  InputBase,
  Typography,
  Chip,
} from "@mui/material";
import React, { useRef } from "react";
import styled from "styled-components";
import ErrorIcon from "@mui/icons-material/Error";

interface TextInputProps {
  id?: string;
  placeholder?: string;
  value?: [];
  name?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  icon?: React.ElementType;
  iconClick?: () => void;
  isEmail?: boolean;
  isMobileNo?: boolean;
  isPassword?: boolean;
  disabled?: boolean;
  required?: boolean;
  label: string;
  type?: string;
  textOnly?: boolean;
  number?: boolean;
  pincode?: boolean;
  helperText?: string;
  helper?: boolean;
  skills: string[];
  onAddSkill: (skill: string) => void;
  onDeleteSkill: any;
  showRequiredError?: boolean;
}

const SkillsInput: React.FC<TextInputProps> = ({
  label,
  id,
  placeholder,
  value,
  name,
  onChange,
  required,
  disabled,
  helperText,
  type,
  helper,
  onDeleteSkill,
  skills,
  onAddSkill,
  showRequiredError,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFocus = () => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    let { value, name } = event.target;
    if (onChange) {
      onChange({
        ...event,
        target: { ...event.target, value, name },
      });
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter" && event.currentTarget.value.trim()) {
      onAddSkill(event.currentTarget.value);
      event.currentTarget.value = "";
    }
  };

  return (
    <>
      <GridContainer>
        <GridTypo>
          {label}
          {required && "*"}
        </GridTypo>
        <InputBox onClick={handleFocus} disabled={disabled}>
          {skills?.map((chip, index) => (
            <Chip
              key={index}
              label={chip}
              onDelete={!disabled ? () => onDeleteSkill(index) : undefined}
              sx={{
                margin: "2px 4px",
                padding: "2px 4px",
                borderRadius: "4px",
                backgroundColor: "#EDF1F4",
                color: disabled ? "#000" : "#000",
              }}
            />
          ))}
         {!disabled && (
            <CustomInput
              id={id}
              // placeholder={skills.length > 0 ? "" : Enter ${label}}
              placeholder={placeholder ?? `Enter ${label}`}
              value={value}
              name={name}
              type={type}
              onChange={handleChange}
              onKeyDown={handleKeyDown}
              inputRef={inputRef}
              fullWidth
              autoFocus={false}
              disabled={disabled}
              size="small"
              minRows={4}
            />
          )}
        </InputBox>
        {helper && skills.length === 0 && showRequiredError && (
          <Box sx={{ minHeight: 30 }}>
            <FormHelperText
              sx={{
                color: "#BF1932",
                ml: "8px",
                fontSize: "12px",
                display: "flex",
                flexDirection: "row",
                alignItems: "flex-start",
              }}
            >
              <>
                <ErrorIcon sx={{ fontSize: "15px", mt: 0.1 }} />
                &nbsp; {label} is required
              </>
            </FormHelperText>
          </Box>
        )}
        {/* {helper && (
          <Box sx={{ minHeight: 30 }}>
            <FormHelperText sx={{ color: "red", mt: "8px", ml: "8px" }}>
              {helperText}
            </FormHelperText>
          </Box>
        )} */}
      </GridContainer>
    </>
  );
};

export default SkillsInput;
const GridContainer = styled(Grid)`
  margin: 0 15px;
  border-radius: 8px;
`;
const GridTypo = styled(Typography)`
  font-size: 10px;
  font-weight: 600;
  color: black;
  padding: 0 0 5px 0;
`;

const InputBox = styled(Box)<{ disabled?: boolean }>`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  border-radius: 8px;
  border: 1px solid #babcbe;
  padding: 10px;
  overflow-y: auto;
  /* background-color: white; */
  background-color: ${({ disabled }) => (disabled ? "#f0f0f0" : "white")};
`;

const CustomInput = styled(InputBase)<{ disabled?: boolean }>`
  width: 100%;
  border-radius: 5px;
  border: none;
  flex-wrap: wrap;
  overflow-y: auto;
  /* background-color: white; */
  background-color: ${({ disabled }) => (disabled ? "#f0f0f0" : "white")};
  padding: 10px;
  height: 45px;
  & input::placeholder {
    color: ${({ disabled }) => (disabled ? "#000" : "#babcbe")};
    opacity: 1;
  }
`;
