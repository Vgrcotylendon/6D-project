import { 
  FormControl, 
  MenuItem, 
  Select, 
  SelectChangeEvent, 
  Typography, 
} from "@mui/material"; 
import React from "react"; 
 
interface DropDownFieldProps { 
  label?: string; 
  labelId?: string; 
  rows?: any; 
  id: string; 
  name: string; 
  value: string; 
  size?: "small" | "medium"; 
  onChange: (event: SelectChangeEvent) => void; 
  options: { value: string | number; label: string }[]; 
  
  // New props for customization
  height?: number | string;
  width?: number | string;
  borderColor?: string;
  borderWidth?: number;
  borderRadius?: number;
  backgroundColor?: string;
  textColor?: string;
} 
 
const DropDownField: React.FC<DropDownFieldProps> = ({ 
  label, 
  labelId, 
  id, 
  name, 
  value, 
  size, 
  onChange, 
  rows, 
  options, 
  
  // New customization props with default values
  height = 30,
  width = 200,
  borderColor = '#ccc',
  borderWidth = 1,
  borderRadius = 4,
  backgroundColor = 'transparent',
  textColor = 'inherit',
}) => { 
  return ( 
    <FormControl 
      sx={{
        width: width,
        '& .MuiSelect-root': {
          height: height,
          backgroundColor: backgroundColor,
          borderColor: borderColor,
          borderWidth: borderWidth,
          borderRadius: borderRadius,
          color: textColor,
        }
      }}
    > 
      <Select 
        labelId={labelId} 
        id={id} 
        name={name} 
        value={value} 
        onChange={onChange} 
        displayEmpty
        sx={{
          height: 30,
          width: 200,
          backgroundColor: backgroundColor,
          '&.MuiOutlinedInput-root': {
            '& fieldset': {
              borderColor: borderColor,
              borderWidth: borderWidth,
              borderRadius: borderRadius,
            },
            '&:hover fieldset': {
              borderColor: borderColor,
            },
            '&.Mui-focused fieldset': {
              borderColor: borderColor,
            }
          }
        }}
      > 
        {options.map((option, index) => ( 
          <MenuItem 
            key={index} 
            value={option.value}
            sx={{
              color: textColor,
            }}
          > 
            <Typography 
              sx={{
                color: textColor,
              }}
            > 
              {option.label}
            </Typography> 
          </MenuItem> 
        ))} 
      </Select> 
    </FormControl> 
  ); 
}; 
 
export default DropDownField;