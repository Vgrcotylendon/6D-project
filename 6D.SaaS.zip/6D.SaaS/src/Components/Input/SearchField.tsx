import { Box, Divider, IconButton, InputBase } from "@mui/material";
import React from "react";
import styled from "styled-components";
import SearchIcon from "@mui/icons-material/Search";

const NavBox = styled(Box)`
  background-color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-radius: 10px;
  width:566px;
`;
const SearchInput = styled(InputBase)`
  width: 566px;
  height:48px;
  padding:8px 16px 8px 16px;
  color:#939597;
`;

export default function SearchField() {
  return (
    <NavBox>
      <IconButton>
        <SearchIcon width="24px" height="24px"/>
      </IconButton>
      <Divider orientation="vertical"  variant="middle" flexItem />
      <SearchInput placeholder="Enter text to search" />
    </NavBox>
  );
}
