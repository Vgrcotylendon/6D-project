import {
  Box,
  Button,
  Card,
  Checkbox,
  Divider,
  IconButton,
  Modal,
  Paper,
  Typography,
} from "@mui/material";
import ArrowCircleRightIcon from "@mui/icons-material/ArrowCircleRight";
import ArrowCircleLeftIcon from "@mui/icons-material/ArrowCircleLeft";
import React, { useEffect, useState } from "react";
import clsx from "clsx";
import styled from "styled-components";
import { TourData } from "../../Data";
import { useDispatch, useSelector } from "react-redux";
import { ChangeTourValue } from "../../Store/TourSlice";
import TourImage from "../../Assets/Videotourimage.jpg";
import Cookies from "universal-cookie";

const CustomBox = styled(Box)`
  display: flex;
  flex-direction: column;
  padding: 10px 15px;
`;
const ButtonBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 10px;
`;
const IconBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
interface StateType {
  tour: {
    value: number;
  };
}

export default function TourModal() {
  const cookies = new Cookies();
  const [status, setStatus] = useState(false);

  const handleChange = () => {
    setStatus(!status);
    // cookies.set("modal", status, );
  };
  const [open, setOpen] = useState(false);
  const value = useSelector((state: StateType) => state.tour.value);
  const dispatch = useDispatch();
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleRight = () => {
    if (value === 6) {
      dispatch(ChangeTourValue(-1));
      handleClose();
    } else {
      dispatch(ChangeTourValue(value + 1));
    }
  };
  const handleLeft = () => {
    dispatch(ChangeTourValue(value - 1));
  };

  useEffect(() => {
    if (value === -1) {
      handleClose();
    }
  }, [value]);

  useEffect(() => {
    handleOpen();
  }, []);

  const IconGroup = () => {
    return (
      <IconBox>
        <Typography className="tourModalIcons" color="info.main">
          {value}&nbsp;/&nbsp;6
        </Typography>
        <IconButton disabled={value === 1}>
          <ArrowCircleLeftIcon
            color="info"
            onClick={() => handleLeft()}
            sx={{ cursor: "pointer" }}
          />
        </IconButton>
        <IconButton disabled={value === 6}>
          <ArrowCircleRightIcon
            color="info"
            onClick={() => handleRight()}
            sx={{ cursor: "pointer" }}
          />
        </IconButton>
      </IconBox>
    );
  };

  return (
    <Modal
      open={open}
      onClose={handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
      sx={{ zIndex: 99 }}
      BackdropProps={{
        onClick: () => {
          dispatch(ChangeTourValue(0));
          cookies.set("modal", status);
          handleClose();
        },
      }}
    >
      <Paper
        elevation={0}
        className={clsx("tourModalPaper", {
          zero: value === 0,
          one: value === 1,
          two: value === 2,
          three: value === 3,
          four: value === 4,
          five: value === 5,
          six: value === 6,
          minus: value === -1,
        })}
        sx={{ position: "relative" }}
      >
        {value === 0 && <img src={TourImage} alt="tourImage" width={280} />}
        {value !== 0 && (
          <Box sx={{ display: "flex", position: "absolute", left: "-4%" }}>
            <Box
              sx={{
                width: 0,
                height: 0,
                borderTop: "20px solid transparent",
                borderBottom: "20px solid transparent",
                borderRight: "10px solid #ffffff",
              }}
            >
              {""}
            </Box>
            <Box
              sx={{
                width: 0,
                height: 40,
                borderLeft: "5px solid #ffffff",
                bgcolor: "#ffffff",
              }}
            >
              {""}
            </Box>
          </Box>
        )}
        <Card elevation={0} className="tourModalCard">
          <CustomBox>
            {value === 0 && <StartTour />}
            {TourData.map(
              (item, index) =>
                value === item.value && (
                  <>
                    <Typography
                      className="tourModalHead"
                      variant="body1"
                      color="info.main"
                    >
                      {item.head}
                    </Typography>
                    <br />
                    <Typography
                      className="tourModal"
                      variant="body1"
                      color="info.main"
                    >
                      {item.content[0]}
                    </Typography>
                    <br />
                    <Typography
                      className="tourModal"
                      variant="body1"
                      color="info.main"
                    >
                      {item.content[1]}
                    </Typography>
                  </>
                )
            )}
          </CustomBox>
          <Divider className="tourModal" />
          <ButtonBox>
            <Button
              className="tourModalButtonSmall"
              onClick={() => {
                dispatch(ChangeTourValue(0));
                cookies.set("modal", status);
                cookies.set("temp", true);
                handleClose();
              }}
              sx={{ color: "#2A62AA" }}
            >
              {"Skip All"}
            </Button>
            {value !== 0 ? (
              <IconGroup />
            ) : (
              <Button
                className="tourModal"
                onClick={() => {
                  dispatch(ChangeTourValue(1));
                }}
              >
                Start Tour
              </Button>
            )}
          </ButtonBox>
        </Card>
        <Typography className="tourCheckbox">
          Don't Show again &nbsp;{" "}
          <Checkbox size="small" checked={status} onChange={handleChange} />
        </Typography>
      </Paper>
    </Modal>
  );
}

const StartTour = () => {
  return (
    <>
      <>
        <Typography className="tourModalHead" variant="body1" color="info.main">
          Your Settings
        </Typography>
        <Typography className="tourModal" variant="body1" color="info.main">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua
        </Typography>
        <br />
        <Typography className="tourModal" variant="body1" color="info.main">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua
        </Typography>
      </>
    </>
  );
};
