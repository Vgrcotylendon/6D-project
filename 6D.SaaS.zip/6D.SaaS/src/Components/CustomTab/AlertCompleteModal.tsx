import { Box, Typography, IconButton } from "@mui/material";
import React from "react";
import CloseIcon from "@mui/icons-material/Close";
import CustomButton from "../Button/CustomButton";

interface fillProps {
  setShow: React.Dispatch<React.SetStateAction<boolean>>;
  setSave?: React.Dispatch<React.SetStateAction<boolean>>;
  save?: boolean;
  setOpen1?: React.Dispatch<React.SetStateAction<boolean>>;
  setShowRequiredError?: React.Dispatch<React.SetStateAction<boolean>>;
  showRequiredError?: boolean;
  setEdit?: React.Dispatch<React.SetStateAction<boolean>>;
  setTrigger?: React.Dispatch<React.SetStateAction<boolean>>;
  value?: number;
  setValue?: (newValue: number) => void;
}

const AlertCompleteModal: React.FC<fillProps> = ({
  value,
  setValue,
  setShow,
  setEdit,
  setTrigger,
  setSave,
  save,
  setShowRequiredError,
  showRequiredError,
  setOpen1,
}) => {
  const handleSave = () => {
    if (showRequiredError === true) {
      setShowRequiredError && setShowRequiredError(true);
      setSave && setSave(false);
      setTrigger && setTrigger(true);
      setShow(false);
    } else {
      setSave && setSave(false);
      setTrigger && setTrigger(true);
      setShow(false);
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        backgroundColor: "#EDF1F4",
        borderRadius: "10px",
        padding: "40px",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {/*       ----- */}
      <IconButton
        size="small"
        onClick={() => setShow(false)}
        sx={{ position: "absolute", top: 10, right: 10 }}
      >
        <CloseIcon />
      </IconButton>

      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: "#FFFFFf",
          borderRadius: "10px",
          padding: "20px",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Typography sx={{ fontWeight: 600, color: "info.main", p: "20px" }}>
          Unsaved Changes
        </Typography>
        <Box
          sx={{
            backgroundColor: "#cac7c7",
            height: "0.5px",
            width: "700px",
          }}
        />
        <Typography
          sx={{ fontWeight: 400, color: "#636060", p: "40px", width: "700px" }}
        >
          You have unsaved changes on this page. If you leave now, your changes
          will be lost. Would you like to save before continuing?
        </Typography>
        <Box
          sx={{
            backgroundColor: "#646262",
            height: "0.3px",
            width: "700px",
          }}
        />
        <Box
          sx={{
            marginTop: "20px",
            display: "flex",
            flexDirection: "row",
            width: "700px",
            justifyContent: "space-between",
          }}
        >
          <CustomButton
            name="Cancel"
            variant="secondary"
            padding="5px 20px 5px 20px"
            onClick={() => setShow(false)}
          />
          <CustomButton
            name="Save and Continue"
            variant="primary"
            padding="8px 20px 8px 20px"
            onClick={handleSave}
            // onClick={()=> setShow(false)}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default AlertCompleteModal;

