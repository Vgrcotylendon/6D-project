import React, { Dispatch, SetStateAction, useState } from "react";
import { Typography, Box, Tabs, Tab, SxProps } from "@mui/material";
import CustomModal from "../Modal/CustomModal";
import AlertCompleteModal from "./AlertCompleteModal";
import FillModal from "../Screens/Profile/FillModal";

interface TabPanelProps {
  children?: React.ReactNode;
  value: number;
  index: number;
  [key: string]: any;
}

const TabPanel: React.FC<TabPanelProps> = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
};

interface CustomTabProps {
  tabs: string[];
  value: number;
  setValue: (newValue: number) => void;
  sx?: SxProps;
  setEdit?: Dispatch<SetStateAction<boolean>>;
  setSave?: Dispatch<SetStateAction<boolean>>;
  setCheck?: Dispatch<SetStateAction<boolean>>;
  save?: any;
  showRequiredError?: boolean;
  setShowRequiredError?: Dispatch<SetStateAction<boolean>>;
  setTrigger?: Dispatch<SetStateAction<boolean>>;
}

const CustomTab: React.FC<CustomTabProps> = ({
  tabs,
  value,
  setValue,
  setTrigger,
  sx,
  showRequiredError,
  setShowRequiredError,
  setEdit,
  setSave,
  save,
  setCheck,
}) => {
  const [show, setShow] = useState(false);
  const [open1, setOpen1] = useState(false);
  const baseStyle = {
    textTransform: "none",
    fontWeight: 400,
    fontSize: "14px",
    color: "#656566",
    pl: 5,
    pr: 5,
    ml: 1,
    mr: 1,
    position: "relative",
    "&:hover": {
      fontWeight: 600,
      "&::after": {
        content: '""',
        position: "absolute",
        left: 0,
        right: 0,
        bottom: 0,
        height: "4px",
        backgroundColor: "#e5e5e5",
      },
    },
  };

  const activeStyle = {
    fontWeight: 600,
    color: "info.main",
    "&:hover": { color: "info.main" },
  };

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    if (save === false) {
      setShow(true);
    } else {
      setValue(newValue);
      if (setCheck) {
        setCheck(false);
      }
      if (setEdit) {
        setEdit(false);
      }
      if (setSave) {
        setSave(true);
      }
    }
  };

  return (
    <>
      <CustomModal
        open={show}
        handleClose={() => setShow(false)}
        // sx={{ height: "auto", mt: 5 }}
        child={
          <AlertCompleteModal
            setSave={setSave}
            setEdit={setEdit}
            setTrigger={setTrigger}
            save={save}
            showRequiredError={showRequiredError}
            setShowRequiredError={setShowRequiredError}
            setOpen1={setOpen1}
            setShow={setShow}
            value={value}
            setValue={setValue}
          />
        }
      />
      <CustomModal
        open={open1}
        handleClose={() => setOpen1(false)}
        // sx={{ height: "auto", mt: 5 }}
        child={<FillModal setOpen1={setOpen1} />}
      />
      <Tabs
        value={value}
        onChange={handleChange}
        centered
        TabIndicatorProps={{
          sx: {
            height: "4px",
            bgcolor: "info.main",
          },
        }}
        sx={{
          display: "flex",
          justifyContent: "center",
          marginTop: "12px",
          ...sx,
        }}
      >
        {tabs.map((label, index) => (
          <Tab
            key={label}
            label={label}
            sx={value === index ? { ...baseStyle, ...activeStyle } : baseStyle}
          />
        ))}
      </Tabs>
    </>
  );
};

export { CustomTab, TabPanel };
