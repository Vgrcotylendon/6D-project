import { app } from "./index";
require("dotenv").config();

app.listen(process.env.SERVER_PORT, () => {
  console.log(`Server is connected at port ${process.env.SERVER_PORT}`);
});
