import dotenv from "dotenv";
import "reflect-metadata";
import { Sequelize } from "sequelize-typescript";
import UserEducation from "../Model/UserEducationModel";

dotenv.config();

export const sequelize = new Sequelize(
  process.env.DB_NAME as string,
  process.env.DB_USER as string,
  process.env.DB_PASS as string,
  {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT as number | undefined,
    dialect: "mysql",
    dialectModule: require("mysql2"),
    logging: false,
  }
);

export const connectDb = async () => {
  try {
    await sequelize.authenticate();
    console.log("CONNECTED to db");
  } catch (error) {
    console.error("Failed to CONNECT", error);
  }
};

export const init = async () => {
  try {
    await sequelize.authenticate();
    console.log("Connection has been established successfully.");
    await sequelize.sync();
  } catch (error) {
    console.error("Unable to connect to the database:", error);
  }
};
