import { configDotenv } from "dotenv";

const nodemailer = require("nodemailer");

configDotenv();

const transport = nodemailer.createTransport({
  service: "gmail",
  host: process.env.HOST,
  port: process.env.PORT,
  auth: {
    user: process.env.USER,
    pass: process.env.PASS,
  },
});
export { transport };
