const twilio = require('twilio');

const accountSid = "AC6a1a806b938876c709122933f1e4ccc9";
const authToken = "43c056dbc7bc636e495555d858a3f837";  

const client = new twilio(accountSid, authToken);

export { client };