import { NextFunction, Request, Response } from "express";
import { VerifyToken } from "./JWTToken";
import { JwtPayload } from "jsonwebtoken";

interface AuthenticatedRequest extends Request {
  user?: JwtPayload | string;
}

const Middleware = async (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    const header = req.header("Authorization");
    if (!header) {
      return res.status(403).json({ message: "Authorization header missing" });
    }
    const token = header.split(" ")[1];
    if (!token) {
      return res.status(403).json({ message: "Token missing" });
    }
    const decoded = VerifyToken(token);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(403).json({ message: "Token is invalid or expired" });
  }
};

export { Middleware };
