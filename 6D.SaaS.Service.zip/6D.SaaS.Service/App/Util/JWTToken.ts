import jwt, { JwtPayload } from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

const GenerateAccessToken = (USER: any) => {
  return jwt.sign({ USER }, process.env.ACCESS_TOKEN_SECRET as string, {
    expiresIn: "240m",
  });
};
const GenerateRefreshToken = (USER: any) => {
  return jwt.sign({ USER }, process.env.REFRESH_TOKEN_SECRET as string, {
    expiresIn: "240m",
  });
};

function VerifyToken(token: string): JwtPayload | string {
  try {
    const decoded = jwt.verify(
      token,
      process.env.ACCESS_TOKEN_SECRET as string
    );
    return decoded;
  } catch (error: any) {
    if (error.name === "TokenExpiredError") {
      throw new Error("Token has expired");
    } else if (error.name === "JsonWebTokenError") {
      throw new Error("Invalid token");
    } else {
      throw new Error("Token verification failed");
    }
  }
}
function VerifyRefreshToken(token: string): JwtPayload | string {
  try {
    const decoded = jwt.verify(
      token,
      process.env.REFRESH_TOKEN_SECRET as string
    );
    return decoded;
  } catch (error: any) {
    if (error.name === "TokenExpiredError") {
      throw new Error("Token has expired");
    } else if (error.name === "JsonWebTokenError") {
      throw new Error("Invalid token");
    } else {
      throw new Error("Token verification failed");
    }
  }
}

export {
  GenerateAccessToken,
  GenerateRefreshToken,
  VerifyToken,
  VerifyRefreshToken,
};
