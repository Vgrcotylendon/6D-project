import { Request, Response } from "express";
import {
  CodeforEmailService,
  CodeforMobileService,
  CreatePasswordService,
  EmailOtpService,
  EmailSignInCheckService,
  EmailSignInService,
  GetUserService,
  MobileOtpService,
  SetPassWord,
  VerifyCodeService,
  VerifyMobileCodeService,
  VerifyMobileSignupService,
  changePasswordServices,
  getPasswordServices,
  socialMediaSignInService,
  socialMediaSignUpService,
  ReSendCodeforSignUpService,
} from "../Service/AuthService";
import { bcrypt } from "../Configuration/Hash";
import ejs from "ejs";
import path from "path";
import sendMail from "../Util/sendMail";

const SendVerifyCodeforEmail = async (req: Request, res: Response) => {
  try {
    const email = req.body.email;
    const code = Math.floor(1000 + Math.random() * 9000);

    const verificationCode = await CodeforEmailService(email, code);

    if (verificationCode) {
      const data = { verificationCode };
      const html = await ejs.renderFile(
        path.join(__dirname, "../mail/activation-mail.ejs"),
        data
      );

      try {
        await sendMail({
          email: email,
          subject: "Confirm Your 6D.SaaS Account with This Code",
          template: "activation-mail.ejs",
          data,
        });
        res
          .status(200)
          .json({ message: "Verification code sent successfully" });
      } catch (error) {
        res.status(500).json({ error: "Error on sending verification code" });
        console.error(error);
      }
    } else {
      res.status(500).json({
        error: "Error sending verification code you don't have invite for 6D",
      });
    }
  } catch (error) {
    res.status(500).json({ error: "Error on sending verification code" });
    console.error(error);
  }
};

// SOCIAL MEDIA SIGNUP
const socialMediaSignUp = async (req: Request, res: Response) => {
  try {
    const { email, accountOrigin } = req.body;

    if (!email || !accountOrigin) {
      return res
        .status(400)
        .json({ error: "Email and account origin are required." });
    }

    const verifySocialMedia = await socialMediaSignUpService(
      email,
      accountOrigin
    );

    if (verifySocialMedia.message === "User already exists. Please sign in.") {
      return res.status(400).json({ message: verifySocialMedia.message });
    }

    return res.status(200).json(verifySocialMedia);
  } catch (error: any) {
    console.error("Error in socialMediaSignUp:", error);
    return res.status(500).json({ error: "Error during signup." });
  }
};

// SOCIAL MEDIA SIGNIN CONTROLLER
const socialMediaSignIn = async (req: Request, res: Response) => {
  try {
    const { email, accountOrigin } = req.body;

    const verifySocialMedia = await socialMediaSignInService(
      email,
      accountOrigin
    );

    res.status(200).json(verifySocialMedia);
  } catch (error: any) {
    if (error.message === "User does not exist. Please sign up.") {
      res.status(400).json({ error: error.message });
    } else {
      res.status(500).json({ error: "Error on Email Verify" });
    }
    console.error(error);
  }
};

// ANY ONE CAN ACCESS WITHOUT INVITE
const NewGenerateEmailVerificationCode = async (
  req: Request,
  res: Response
) => {
  try {
    const email = req.body.email;
    const code = Math.floor(1000 + Math.random() * 9000);

    const verificationCode = await EmailOtpService(email, code);

    if (verificationCode) {
      const data = { verificationCode };
      const html = await ejs.renderFile(
        path.join(__dirname, "../mail/activation-mail.ejs"),
        data
      );

      await sendMail({
        email: email,
        subject: "Confirm Your 6D.SaaS Account with This Code",
        template: "activation-mail.ejs",
        data,
      });

      res.status(200).json({ message: "Verification code sent successfully" });
    } else if (verificationCode === null) {
      res.status(406).json({ message: "User has an account origin" });
    } else {
      res.status(400).json({ error: "You already have an account" });
    }
  } catch (error: any) {
    res.status(500).json({ error: "An error occurred" });
    console.error(error);
  }
};

const SendCodeforMobile = async (req: Request, res: Response) => {
  try {
    const mobileNumber = req.body.mobileNumber;
    const code = Math.floor(1000 + Math.random() * 9000);
    const verificationCode = await CodeforMobileService(mobileNumber, code);
    if (verificationCode) {
      res.status(200).json({
        message: "Verification code sent successfully",
        OTPCode: verificationCode,
      });
    } else {
      res.status(500).json({
        error: "Error sending verification code you don't have invite for 6D",
      });
    }
  } catch (error) {
    res.status(500).json({ error: "Error sending verification code" });
    console.error(error);
  }
};

const ReSendCodeforSignUp = async (req: Request, res: Response) => {
  try {
    const mobileNumber = req.body.mobileNumber;
    const code = Math.floor(1000 + Math.random() * 9000);
    const verificationCode = await ReSendCodeforSignUpService(
      mobileNumber,
      code
    );
    if (verificationCode) {
      res.status(200).json({
        message: "Verification code sent successfully",
        OTPCode: verificationCode,
      });
    } else {
      res.status(500).json({
        error: "Error sending verification code you don't have invite for 6D",
      });
    }
  } catch (error) {
    res.status(500).json({ error: "Error sending verification code" });
    console.error(error);
  }
};

const NewGenerateMobileVerificationCode = async (
  req: Request,
  res: Response
) => {
  try {
    const mobileNumber = req.body.mobileNumber;
    const code = Math.floor(1000 + Math.random() * 9000);
    const verificationCode = await MobileOtpService(mobileNumber, code);
    if (verificationCode) {
      res.status(200).json({
        message: "Verification code sent successfully",
        OTPCode: verificationCode,
      });
    } else {
      res.status(400).json({
        error: "You already have an account",
      });
    }
  } catch (error) {
    res.status(500).json({ error: "Error sending verification code" });
    console.error(error);
  }
};

const VerifyCodeForMobileSignUp = async (req: Request, res: Response) => {
  try {
    const code = parseInt(req.body.code);
    const mobile = req.body.mobileNumber;
    if (isNaN(code) || !mobile) {
      return res.status(400).json({ message: "Invalid request data" });
    }

    const isVerified = await VerifyMobileSignupService(code, mobile);

    if (!isVerified) {
      return res.status(400).json({ message: "OTP does not match" });
    }
    return res
      .status(200)
      .json({ message: "Verified Successfully", isVerified });
  } catch (error) {
    console.error(error);
  }
};

const verifyCodeforMobile = async (req: Request, res: Response) => {
  try {
    const code = parseInt(req.body.code);
    const mobile = req.body.mobileNumber || null;
    if (!mobile) {
      return res.status(400).json({ message: "Mobile number is required" });
    }

    if (isNaN(code) || !mobile) {
      return res.status(400).json({ message: "Invalid request data" });
    }

    const isVerified = await VerifyMobileCodeService(code, mobile);

    if (!isVerified) {
      return res.status(400).json({ message: "OTP does not match" });
    }
    return res
      .status(200)
      .json({ message: "Verified Successfully", isVerified });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error on verifying code" });
  }
};

const VerifyCode = async (req: Request, res: Response) => {
  try {
    const code = parseInt(req.body.code);
    const email = req.body.email;
    if (isNaN(code) || !email) {
      return res.status(400).json({ message: "Invalid request data" });
    }

    const isVerified = await VerifyCodeService(code, email);

    if (!isVerified) {
      return res.status(400).json({ message: "OTP does not match" });
    }

    return res.status(200).json({ message: "Verified Successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error on verifying code" });
  }
};

const CreatePassword = async (req: Request, res: Response) => {
  try {
    const email = req.body.email;
    const Plainpassword = req.body.password;
    const password = await bcrypt.hash(Plainpassword, 10);
    const create = await CreatePasswordService(email, password);
    if (create) {
      return res
        .status(200)
        .json({ message: "Password  Created Successfully", create });
    } else {
      return res.status(400).json({ message: "Some thing went wrong" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error on Creating password" });
  }
};

const EmailSignin = async (req: Request, res: Response) => {
  try {
    const email = req.body.email;
    const password = req.body.password;
    const result = await EmailSignInService(email, password);

    if (result.status === "success") {
      return res
        .status(200)
        .json({ message: "SignIn Successfully", user: result.user });
    } else if (result.status === "email_not_found") {
      return res
        .status(404)
        .json({ message: "Email not found. Please sign up." });
    }
    // else if (result.status === "NOT REGISTERED") {
    //   return res
    //     .status(406)
    //     .json({ message: "Email not found. Please sign up." });
    // }
    else if (result.status === "wrong_password") {
      return res.status(400).json({ message: "Wrong password. Try Again" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error on signin" });
  }
};

const EmailSigninCheck = async (req: Request, res: Response) => {
  try {
    const email = req.body.email;
    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    try {
      const result = await EmailSignInCheckService(email);

      return res.status(200).json(result);
    } catch (error: any) {
      if (error.message === "User not found") {
        return res.status(401).json({ message: "User not found" });
      }
      if (error.message === "User is not enabled") {
        return res.status(404).json({ message: "User is not enabled" });
      }
      if (error.message === "User has an account origin") {
        return res.status(406).json({ message: "User has an account origin" });
      }
      // General error handler if specific cases are not matched
      return res.status(500).json({ message: "An error occurred" });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Error on signin" });
  }
};

const AuthVerify = async (req: Request, res: Response) => {
  const user = (req as any).user;
  res.status(200).json({ message: "Access granted", user });
};
const signOutController = async (req: Request, res: Response) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ message: "Failed to sign out" });
    res.status(200).json({ message: "SignOut successful" });
  });
};

const Getme = async (req: Request, res: Response) => {
  try {
    const refreshToken = req.body.refreshToken;
    const userId = req.body.userId;
    const AccessToken = await GetUserService(refreshToken, userId);
    if (AccessToken) {
      return res.status(200).json({ message: "Access granted", AccessToken });
    } else {
      return res
        .status(400)
        .json({ message: "Error on Getting Token. Try Again" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error on Getting Token" });
  }
};

const generatePassword = () => {
  const uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const numbers = "0123456789";
  const specialChars = "!@#$%^&*()_+[]{}|;:,.<>?";

  const getRandomChar = (str: string) =>
    str[Math.floor(Math.random() * str.length)];

  let password = "";
  password += getRandomChar(uppercase);
  password += getRandomChar(numbers);
  password += getRandomChar(numbers);
  password += getRandomChar(specialChars);

  const allChars = uppercase + numbers + specialChars;
  while (password.length < 8) {
    password += getRandomChar(allChars);
  }

  return password
    .split("")
    .sort(() => Math.random() - 0.5)
    .join("");
};

const ForgotPassword = async (req: Request, res: Response) => {
  try {
    const email = req.body.email;
    const Plainpassword = generatePassword();
    const password = await bcrypt.hash(Plainpassword, 10);

    const verifyEmail = await SetPassWord(email, password);

    if (verifyEmail) {
      const data = { verificationCode: Plainpassword };
      try {
        await sendMail({
          email: email,
          subject: "Forgot Password Reset for Your 6D LMS Account",
          template: "activation-password.ejs",
          data,
        });
        res
          .status(200)
          .json({ message: "temporary password sent successfully" });
      } catch (error) {
        res.status(500).json({ error: "Error on sending temporary password" });
        console.error(error);
      }
    } else {
      res.status(500).json({
        error: "Error sending temporary password you don't have invite for 6D",
      });
    }
  } catch (error) {
    res.status(500).json({ error: "Error on sending temporary password" });
    console.error(error);
  }
};

const getPassword = async (req: Request, res: Response): Promise<Response> => {
  try {
    const userId = Number(req.query.userId);

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: "Required fields: userId missing",
      });
    }

    const result = await getPasswordServices(userId);

    if (result.success) {
      return res.status(200).json({
        password: result.password,
      });
    } else {
      return res.status(500).json({
        success: false,
        message: result.message || "Failed to get password",
      });
    }
  } catch (error) {
    console.error("Error in getPassword:", error);
    return res.status(500).json({
      success: false,
      message: "An internal server error occurred while getting the password",
    });
  }
};

const changePassword = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const userId = Number(req.query.userId);
    const currentPassword = req.query.currentPassword as string;
    const newPassword = req.query.newPassword as string;

    if (!userId || !currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: "Required fields are missing",
      });
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);

    const result = await changePasswordServices(
      userId,
      currentPassword,
      hashedNewPassword
    );

    if (result.success) {
      return res.status(200).json({
        success: true,
        message: "Password updated successfully",
      });
    } else {
      return res.status(500).json({
        success: false,
        message: result.message || "Failed to update password",
      });
    }
  } catch (error) {
    console.error("Error in changePassword:", error);
    return res.status(500).json({
      success: false,
      message: "An internal server error occurred while changing the password",
    });
  }
};

export {
  SendVerifyCodeforEmail,
  VerifyCode,
  CreatePassword,
  EmailSignin,
  SendCodeforMobile,
  verifyCodeforMobile,
  AuthVerify,
  signOutController,
  Getme,
  NewGenerateEmailVerificationCode,
  NewGenerateMobileVerificationCode,
  VerifyCodeForMobileSignUp,
  ForgotPassword,
  getPassword,
  changePassword,
  EmailSigninCheck,
  socialMediaSignUp,
  socialMediaSignIn,
  ReSendCodeforSignUp,
};
