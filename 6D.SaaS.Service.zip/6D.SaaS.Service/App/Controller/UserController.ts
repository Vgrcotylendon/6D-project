import { Request, Response } from "express";
import {
  CreateProfileService,
  getProfileService,
  UpdateProfileService,
} from "../Service/UserService";
import { UserCreationAttributes } from "../Model/UserModel";
import { UserContactCreationAttributes } from "../Model/UserContact";
import { UserDemographicsCreationAttributes } from "../Model/UserDemographics";

const CreateNewProfile = async (req: Request, res: Response) => {
  try {
    const file = req.file?.filename;
    const imageUrl = `./Uploads/${file}`;
    const userData: UserCreationAttributes = {
      UID: parseInt(req.body.UID),
      "6DWORKS_ID": parseInt(req.body.UID),
      FIRST_NAME: req.body.FIRST_NAME,
      LAST_NAME: req.body.LAST_NAME,
      MIDDLE_NAME: req.body.MIDDLE_NAME,
      IS_VERIFIED: req.body.IS_VERIFIED,
      PASSWORD: req.body.PASSWORD || null,
      AVATAR_URL: file && imageUrl,
      AVATAR_PUB_ID: req.body.AVATAR_PUB_ID,
      ROLE: req.body.ROLE,
      AADAAR_ID: parseInt(req.body.AADAAR_ID),
      APAAR_ID: parseInt(req.body.AADAAR_ID),
      DATE_OF_BIRTH: req.body.DATE_OF_BIRTH,
      GENDER: req.body.GENDER,
      NATIONALITY: req.body.NATIONALITY,
    };
    const Usercontact: UserContactCreationAttributes = {
      UCID: parseInt(req.body.UID),
      UID: parseInt(req.body.UID),
      PHONE_NUMBER: req.body.PHONE_NUMBER,
      EMAIL: req.body.EMAIL,
      LINKEDIN: req.body.LINKEDIN,
    };
    const Userdemographics: UserDemographicsCreationAttributes = {
      UD_ID: parseInt(req.body.UID),
      UID: parseInt(req.body.UID),
      MAILING_ADDRESS_LINE_1: req.body.MAILING_ADDRESS_LINE_1,
      MAILING_ADDRESS_LINE_2: req.body.MAILING_ADDRESS_LINE_2,
      MAILING_ADDRESS_CITY: req.body.MAILING_ADDRESS_CITY,
      MAILING_ADDRESS_STATE: req.body.MAILING_ADDRESS_STATE,
      MAILING_ADDRESS_COUNTRY: req.body.MAILING_ADDRESS_COUNTRY,
      MAILING_ADDRESS_PINCODE: req.body.MAILING_ADDRESS_PINCODE,
      PERMANENT_ADDRESS_LINE_1: req.body.PERMANENT_ADDRESS_LINE_1,
      PERMANENT_ADDRESS_LINE_2: req.body.PERMANENT_ADDRESS_LINE_2,
      PERMANENT_ADDRESS_CITY: req.body.PERMANENT_ADDRESS_CITY,
      PERMANENT_ADDRESS_STATE: req.body.PERMANENT_ADDRESS_STATE,
      PERMANENT_ADDRESS_COUNTRY: req.body.PERMANENT_ADDRESS_COUNTRY,
      PERMANENT_ADDRESS_PINCODE: req.body.PERMANENT_ADDRESS_PINCODE,
      IS_ADDRESS_SAME: req.body.IS_ADDRESS_SAME,
    };
    const id = req.body.UID;

    const user = await CreateProfileService(
      id,
      userData,
      Usercontact,
      Userdemographics
    );
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error: "Error on updating profile" });
    console.error(error);
  }
};

const GetUserProfile = async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const user = await getProfileService(id);
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error: "Error on getting profile" });
  }
};

const UpdateProfile = async (req: Request, res: Response) => {
  try {
    const file = req.file?.filename;
    const imageUrl = `./Uploads/${file}`;
    const userData: UserCreationAttributes = {
      "6DWORKS_ID": req.body.SIXDWORKS_ID,
      FIRST_NAME: req.body.FIRST_NAME,
      LAST_NAME: req.body.LAST_NAME,
      MIDDLE_NAME: req.body.MIDDLE_NAME,
      IS_VERIFIED: req.body.IS_VERIFIED,
      PASSWORD: req.body.PASSWORD,
      AVATAR_URL: file && imageUrl,
      AVATAR_PUB_ID: req.body.AVATAR_PUB_ID,
      ROLE: req.body.ROLE,
      AADAAR_ID: parseInt(req.body.AADAAR_ID) || null,
      APAAR_ID: parseInt(req.body.APAAR_ID) || null,
      DATE_OF_BIRTH: req.body.DATE_OF_BIRTH,
      GENDER: req.body.GENDER,
      NATIONALITY: req.body.NATIONALITY,
    };
    const UserContact: UserContactCreationAttributes = {
      UCID: req.body.UCID,
      UID: req.body.UID,
      PHONE_NUMBER: req.body.PHONE_NUMBER,
      EMAIL: req.body.EMAIL,
      LINKEDIN: req.body.LINKEDIN,
    };
    // const demographics:UserDemographicsCreationAttributes
    const id = parseInt(req.params.id);
    const Update = await UpdateProfileService(userData, id, UserContact);
    res.json(Update);
  } catch (error) {
    res.status(500).json({ error: "Error on updating profile" });
  }
};

export { CreateNewProfile, GetUserProfile, UpdateProfile };
