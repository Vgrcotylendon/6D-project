import { Request, Response } from "express";
import { CourseCreationAttributes } from "../Model/CourseModel";
import {
  CreateCourseServices,
  DeleteCourseService,
  getAllCourseByUserIdServices,
  GetCourseServices,
  UpdateCourseServices,
  getAllCourseServices,
  getAllCourseWithStatusServices,
  getCourseDetailsByIdServices,
} from "../Service/CourseService";

const CreateCourse = async (req: Request, res: Response) => {
  try {
    const { COURSETITLE, DESCRIPTION, AUTHOR, AVAILABILITY } = req.body;

    if (!COURSETITLE || !DESCRIPTION || !AUTHOR || !AVAILABILITY) {
      return res
        .status(400)
        .json({ success: false, message: "Some thing is missing" });
    }
    // const file = req?.file?.filename;
    // const imageUrl = `./Uploads/${file}`;
    const course: CourseCreationAttributes = {
      TITLE: COURSETITLE,
      DESCRIPTION,
      THUMBNAIL: "imageURL",
      AUTHOR,
      AVAILABILITY,
    };

    const result = await CreateCourseServices(course);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json(result);
    }
  } catch (error) {
    console.error("Error Created course successfully:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while creating course",
    });
  }
};

const GetCourse = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await GetCourseServices(Id);
    if (result) {
      return res.status(200).json(result);
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to fetch get course" });
    }
  } catch (error) {
    console.error("Error on getting course:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting course",
    });
  }
};

const getAllCourse = async (req: Request, res: Response) => {
  try {
    const result = await getAllCourseServices();
    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to fetch All Courses",
      });
    }
  } catch (error) {
    console.error("Error on getting All Courses:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting All Courses",
    });
  }
};
const getAllCourseWithStatus = async (req: Request, res: Response) => {
  try {
    const UID = Number(req.query.UID);
    const result = await getAllCourseWithStatusServices(UID);
    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to fetch All Courses",
      });
    }
  } catch (error) {
    console.error("Error on getting All Courses:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting All Courses",
    });
  }
};

const GetAllCourseByUserId = async (req: Request, res: Response) => {
  const userId = Number(req.query.userId);
  try {
    const result = await getAllCourseByUserIdServices(userId);
    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to fetch All Courses",
      });
    }
  } catch (error) {
    console.error("Error on getting All Courses:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting All Courses",
    });
  }
};

const UpdateCourse = async (req: Request, res: Response) => {
  try {
    const courseData: CourseCreationAttributes = {
      TITLE: req.body.TITLE,
      DURATION: req.body.DURATION,
      DESCRIPTION: req.body.DESCRIPTION,
      THUMBNAIL: req.body.THUMBNAIL,
      AVAILABILITY: req.body.AVAILABILITY,
    };

    const id = Number(req.query.id);
    const Update = await UpdateCourseServices(courseData, id);
    res.json(Update);
  } catch (error) {
    res.status(500).json({ error: "Error on updating Course" });
  }
};

const DeleteCourse = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await DeleteCourseService(Id);
    if (result) {
      return res
        .status(200)
        .json({ success: true, message: "Deleted successfully" });
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to delete course" });
    }
  } catch (error) {
    console.error("Error on delete course:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while deleting course",
    });
  }
};

const getCourseDetailsById = async (req: Request, res: Response) => {
  try {
    const CID = Number(req.query.CID);
    const result = await getCourseDetailsByIdServices(CID);
    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to fetch All Courses",
      });
    }
  } catch (error) {
    console.error("Error on getting All Courses:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting All Courses",
    });
  }
};
export {
  CreateCourse,
  GetCourse,
  GetAllCourseByUserId,
  getAllCourse,
  UpdateCourse,
  DeleteCourse,
  getAllCourseWithStatus,
  getCourseDetailsById,
};
