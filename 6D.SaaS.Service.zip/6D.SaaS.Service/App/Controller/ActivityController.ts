import { Request, Response } from "express";
import {
  getActivityCountServices,
  getModuleCountServices,
} from "../Service/ActivityService";

const getActivityCount = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const userId = Number(req.query.userId);

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: "Required fields: userId is missing",
      });
    }

    const result = await getActivityCountServices(userId);

    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: result || "Failed to getActivityCountServices",
      });
    }
  } catch (error) {
    console.error("Error getActivityCountServices:", error);
    return res.status(500).json({
      success: false,
      message:
        "An internal server error occurred while getActivityCountServices",
    });
  }
};

const getModuleCount = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const userId = Number(req.query.userId);
    const status = String(req.query.status);

    if (!userId || !status) {
      return res.status(400).json({
        success: false,
        message: "Required fields: userId is missing",
      });
    }

    const result = await getModuleCountServices(userId, status);

    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to get module counts",
      });
    }
  } catch (error) {
    console.error("Error in getModuleCount:", error);
    return res.status(500).json({
      success: false,
      message: "An internal server error occurred while fetching module counts",
    });
  }
};

export { getActivityCount, getModuleCount };
