import { Request, Response } from "express";
import { CourseModuleTopicCreationAttributes } from "../Model/CourseModuleTopicModel";
import {
  CourseModuleTopicServices,
  GetCourseModuleByCIDService,
  MapAssessmentCourseServices,
  GetModuleTopicByMIDService,
  GetModuleAssessmentByMIDService,
  GetAssessmentQuestionByAIDService,
  ExpandAllService,
  NewContinueToLastService,
  NewGetCourseDetailsService,
  NextTaskService,
  PreviousTaskService,
} from "../Service/CourseModuleTopicService";

const MapCourseModuleTopic = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { CID, MID, ModuleOrder, TID, TopicOrder } = req.body;

    if (!CID || !MID || !TID) {
      return res.status(400).json({
        success: false,
        message: "Required fields: CID, MID and TID are missing",
      });
    }

    const map: CourseModuleTopicCreationAttributes = {
      CID,
      MID,
      // ModuleOrder,
      TID,
      // TopicOrder,
    };

    const result = await CourseModuleTopicServices(map);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: result.message || "Failed to map the Course Module Topic",
      });
    }
  } catch (error) {
    console.error("Error creating map the Course Module Topic:", error);
    return res.status(500).json({
      success: false,
      message: "An internal server error occurred while creating the map",
    });
  }
};

const GetCourseModuleByCID = async (req: Request, res: Response) => {
  try {
    const courseId = Number(req.query.courseId);
    const userId = Number(req.query.userId);

    if (!userId || !courseId) {
      return res
        .status(400)
        .json({ success: false, message: "userId or courseId is missing" });
    }

    const result = await GetCourseModuleByCIDService(courseId, userId);

    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in Get Course Module controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const GetModuleTopicByMID = async (req: Request, res: Response) => {
  try {
    const userId = Number(req.query.userId);
    const moduleId = Number(req.query.moduleId);
    const courseId = Number(req.query.courseId);

    if (!userId || !moduleId) {
      return res.status(400).json({
        success: false,
        message: "userId or moduleId is missing",
      });
    }

    const result = await GetModuleTopicByMIDService(userId, courseId, moduleId);

    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in Get Module Topic controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const GetModuleAssessmentByMID = async (req: Request, res: Response) => {
  try {
    const userId = Number(req.query.userId);
    const courseId = Number(req.query.courseId);
    const moduleId = Number(req.query.moduleId);

    if (!userId || !moduleId) {
      return res.status(400).json({
        success: false,
        message: "userId or moduleId is missing",
      });
    }

    const result = await GetModuleAssessmentByMIDService(
      userId,
      courseId,
      moduleId
    );

    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in Get Module Assessment controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const GetAssessmentQuestionByAID = async (req: Request, res: Response) => {
  try {
    const userId = Number(req.query.userId);
    const AID = Number(req.query.AID);
    const CID = Number(req.query.CID);

    if (!userId || !AID) {
      return res.status(400).json({
        success: false,
        message: "userId or AID is missing",
      });
    }
    console.log("CID", CID);

    const result = await GetAssessmentQuestionByAIDService(
      userId,
      AID,
      !CID ? null : CID
    );

    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in Get Assessment Question controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

// Assessment Mapping
const MapAssessmentCourse = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { CID, MID, ModuleOrder, TID, TopicOrder, IdType } = req.body;

    if (!CID || !MID || !TID) {
      return res.status(400).json({
        success: false,
        message: "Required fields: CID, MID and TID are missing",
      });
    }

    const map: CourseModuleTopicCreationAttributes = {
      CID,
      MID,
      ModuleOrder,
      TID,
      TopicOrder,
      IdType,
    };

    const result = await MapAssessmentCourseServices(map);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message:
          result.message || "Failed to map the Assessment Course Module Topic",
      });
    }
  } catch (error) {
    console.error(
      "Error creating map the Assessment Course Module Topic:",
      error
    );
    return res.status(500).json({
      success: false,
      message: "An internal server error occurred while creating the map",
    });
  }
};

const ExpandAllController = async (req: Request, res: Response) => {
  try {
    const userId = Number(req.query.userId);
    const courseId = Number(req.query.courseId);
    const result = await ExpandAllService(userId, courseId);
    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({
        success: false,
        message: result.message || "Failed to get Data",
      });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "An internal server error occurred",
    });
  }
};

const NewContinueToLastController = async (req: Request, res: Response) => {
  try {
    const userId = Number(req.query.userId);
    const courseId = Number(req.query.courseId);
    const result = await NewContinueToLastService(userId, courseId);
    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({
        success: false,
        message: result.message || "Failed to get Course Module Topic",
      });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "An internal server error occurred",
    });
  }
};
const NewGetCourseDetailsController = async (req: Request, res: Response) => {
  try {
    const userId = Number(req.query.userId);
    const courseId = Number(req.query.courseId);
    const result = await NewGetCourseDetailsService(userId, courseId);
    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({
        success: false,
        message: result.message || "Failed to get Course Details",
      });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "An internal server error occurred",
    });
  }
};

const NextTaskController = async (req: Request, res: Response) => {
  try {
    const courseId = Number(req.query.CID);
    const moduleId = Number(req.query.MID);
    const userId = Number(req.query.UID);
    const ModuleOrder = Number(req.query.ModuleOrder);
    const TopicOrder = Number(req.query.TopicOrder);

    if (!userId || !courseId || !ModuleOrder || !TopicOrder || !moduleId) {
      return res.status(400).json({
        success: false,
        message: "userId, courseId, moduleId and topicId is missing",
      });
    }

    const result = await NextTaskService(
      courseId,
      moduleId,
      userId,
      ModuleOrder,
      TopicOrder
    );

    if (result.success) {
      return res.status(200).json(result.data);
    } else if (result.message === "Current modules not yet completed") {
      return res.status(501).json({ success: false, message: result.message });
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in Get Next Topic controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};
const PreviousTaskController = async (req: Request, res: Response) => {
  try {
    const courseId = Number(req.query.CID);
    const moduleId = Number(req.query.MID);
    const userId = Number(req.query.UID);
    const ModuleOrder = Number(req.query.ModuleOrder);
    const TopicOrder = Number(req.query.TopicOrder);

    if (!userId || !courseId || !ModuleOrder || !TopicOrder || !moduleId) {
      return res.status(400).json({
        success: false,
        message: "userId, courseId, moduleId and topicId is missing",
      });
    }

    const result = await PreviousTaskService(
      courseId,
      moduleId,
      userId,
      ModuleOrder,
      TopicOrder
    );

    if (result.success) {
      return res.status(200).json(result.data);
    } else if (result.message === "Current modules not yet completed") {
      return res.status(501).json({ success: false, message: result.message });
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in Get Next Topic controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};
export {
  MapCourseModuleTopic,
  GetCourseModuleByCID,
  GetModuleTopicByMID,
  GetModuleAssessmentByMID,
  MapAssessmentCourse,
  GetAssessmentQuestionByAID,
  ExpandAllController,
  NewContinueToLastController,
  NewGetCourseDetailsController,
  NextTaskController,
  PreviousTaskController,
};
