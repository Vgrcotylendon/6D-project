import { Request, Response } from "express";
import { UserWorkExperienceCreationAttributes } from "../Model/WorkExperienceModel";
import {
  CreateExperienceService,
  DeleteExperinceService,
  GetExperinceService,
  UpdateExperienceService,
} from "../Service/WorkExperienceService";

const CreateExperience = async (req: Request, res: Response) => {
  try {
    const {
      UID,
      COMPANY_NAME,
      EMPLOYMENT_TYPE,
      JOB_TITLE,
      DURATION,
      START_DATE,
      END_DATE,
      ROLE_DESCRIPTION,
      SKILLS,
    } = req.body;

    if (!UID || !COMPANY_NAME || !EMPLOYMENT_TYPE || !JOB_TITLE) {
      return res
        .status(400)
        .json({ success: false, message: "Required fields are missing" });
    }

    const experience: UserWorkExperienceCreationAttributes = {
      UID,
      COMPANY_NAME,
      EMPLOYMENT_TYPE,
      JOB_TITLE,
      DURATION,
      START_DATE,
      END_DATE,
      ROLE_DESCRIPTION,
      SKILLS,
    };

    const result = await CreateExperienceService(experience);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json(result);
    }
  } catch (error) {
    console.error("Error creating experience:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while creating experience",
    });
  }
};
const GetExperienceById = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await GetExperinceService(Id);
    if (result) {
      return res.status(200).json(result);
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to fetch Experience" });
    }
  } catch (error) {
    console.error("Error on getting experience:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting experience",
    });
  }
};
const UpdateExperienceById = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    const {
      UID,
      COMPANY_NAME,
      EMPLOYMENT_TYPE,
      JOB_TITLE,
      DURATION,
      START_DATE,
      END_DATE,
      ROLE_DESCRIPTION,
      SKILLS,
    } = req.body;

    const experience: UserWorkExperienceCreationAttributes = {
      UID,
      COMPANY_NAME,
      EMPLOYMENT_TYPE,
      JOB_TITLE,
      DURATION,
      START_DATE,
      END_DATE,
      ROLE_DESCRIPTION,
      SKILLS,
    };
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await UpdateExperienceService(Id, experience);
    if (result) {
      return res.status(200).json(result);
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to update Experience" });
    }
  } catch (error) {
    console.error("Error on updating experience:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while updating experience",
    });
  }
};
const DeleteExperience = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await DeleteExperinceService(Id);
    if (result) {
      return res
        .status(200)
        .json({ success: true, message: "Deleted successfully" });
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to delete Experience" });
    }
  } catch (error) {
    console.error("Error on delete experience:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while deleting experience",
    });
  }
};
export {
  CreateExperience,
  GetExperienceById,
  DeleteExperience,
  UpdateExperienceById,
};
