import { Request, Response } from "express";
import { VoucherCreationAttributes } from "../Model/VoucherModel";
import {
  CreateVoucherService,
  DeleteVoucherService,
  GetVoucherService,
  UpdateVoucherService,
} from "../Service/VoucherService";

const CreateVoucher = async (req: Request, res: Response) => {
  try {
    const {
      vid,
      voucher_name,
      voucher_code,
      voucher_qr,
      institution,
      field_of_study,
      year_of_study,
      duration_from,
      duration_to,
      status,
      max_shareable,
      created_by,
    } = req.body;
    const voucher: VoucherCreationAttributes = {
      vid,
      voucher_name,
      voucher_code,
      voucher_qr,
      institution,
      field_of_study,
      year_of_study,
      duration_from,
      duration_to,
      status,
      max_shareable,
      created_by,
    };

    const result = await CreateVoucherService(voucher);
    return res.status(result.success ? 200 : 500).json(result);
  } catch (error) {
    console.error("Error in CreateVoucher controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const GetVoucher = async (req: Request, res: Response) => {
  try {
    const result = await GetVoucherService();
    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(404).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in GetVoucher controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const UpdateVoucher = async (req: Request, res: Response) => {
  try {
    const Id = req.params.id;
    const {
      voucher_name,
      voucher_code,
      voucher_qr,
      institution,
      field_of_study,
      year_of_study,
      duration_from,
      duration_to,
      status,
      max_shareable,
      created_by,
    } = req.body;

    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const voucher: VoucherCreationAttributes = {
      voucher_name,
      voucher_code,
      voucher_qr,
      institution,
      field_of_study,
      year_of_study,
      duration_from,
      duration_to,
      status,
      max_shareable,
      created_by,
    };

    const result = await UpdateVoucherService(Id, voucher);
    return res.status(result.success ? 200 : 404).json(result);
  } catch (error) {
    console.error("Error in UpdateVoucher controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const DeleteVoucher = async (req: Request, res: Response) => {
  try {
    const Id = req.params.id;
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const result = await DeleteVoucherService(Id);
    return res.status(result.success ? 200 : 404).json(result);
  } catch (error) {
    console.error("Error in DeleteVoucher controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export { CreateVoucher, GetVoucher, UpdateVoucher, DeleteVoucher };
