import { Request, Response } from "express";
import { CertificationCreationAttributes } from "../Model/CertificationModel";
import {
  CreateCertificationService,
  DeleteCertificationService,
  GetCertificationService,
  UpdateCertificationService,
} from "../Service/CertificationService";

const CreateCertification = async (req: Request, res: Response) => {
  try {
    const { TITLE, DESCRIPTION, MODULES, LENGTH, PROVIDER, IS_READY, AUTHOR } =
      req.body;

    if (
      !TITLE ||
      !DESCRIPTION ||
      !MODULES ||
      !LENGTH ||
      !PROVIDER ||
      !IS_READY ||
      !AUTHOR
    ) {
      return res
        .status(400)
        .json({ success: false, message: "All fields are required" });
    }

    const Certification: CertificationCreationAttributes = {
      TITLE,
      DESCRIPTION,
      MODULES,
      LENGTH,
      PROVIDER,
      IS_READY,
      AUTHOR,
    };

    const result = await CreateCertificationService(Certification);

    if (result) {
      return res
        .status(200)
        .json({ success: true, message: "Certification created successfully" });
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to create Certification" });
    }
  } catch (error) {
    console.error("Error in CreateCertification:", error);
    return res
      .status(500)
      .json({ success: false, message: "Failed to create Certification" });
  }
};
const GetCertification = async (req: Request, res: Response) => {
  try {
    const result = await GetCertificationService();

    if (result.length > 0) {
      return res.status(200).json(result);
    } else {
      return res
        .status(404)
        .json({ success: false, message: "No certifications found" });
    }
  } catch (error) {
    console.error("Error in GetCertification:", error);
    return res
      .status(500)
      .json({ success: false, message: "Failed to fetch certifications" });
  }
};
const UpdateCertification = async (req: Request, res: Response) => {
  try {
    const { TITLE, DESCRIPTION, MODULES, LENGTH, PROVIDER, IS_READY, AUTHOR } =
      req.body;
    const CID = req.params.id;
    if (!CID) {
      return res.status(400).json({ success: true, message: "ID is missing" });
    }
    const Certification: CertificationCreationAttributes = {
      TITLE,
      DESCRIPTION,
      MODULES,
      LENGTH,
      PROVIDER,
      IS_READY,
      AUTHOR,
    };
    const result = await UpdateCertificationService(CID, Certification);
    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(400).json(result);
    }
  } catch (error) {
    console.error(error);
  }
};
const DeleteCertification = async (req: Request, res: Response) => {
  try {
    const CID = parseInt(req.params.id, 10);

    if (isNaN(CID)) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid ID format" });
    }

    const result = await DeleteCertificationService(CID);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(404).json(result);
    }
  } catch (error) {
    console.error("Error in DeleteCertification:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server Error" });
  }
};
export {
  CreateCertification,
  GetCertification,
  UpdateCertification,
  DeleteCertification,
};
