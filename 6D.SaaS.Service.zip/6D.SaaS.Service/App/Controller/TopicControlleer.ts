import { Request, Response } from "express";
import { TopicCreationAttributes } from "../Model/TopicModel";
import {
  CreateTopicServices,
  GetTopicService,
  UpdateTopicService,
  DeleteTopicService,
  UserTopicStatusService,
  getTopicDetailsByTIDService,
} from "../Service/TopicService";
import { UserTopicCreationAttributes } from "../Model/UserTopicModel";

const CreateTopic = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { NAME, CONTENT, CONTENT_TYPE, METADATA, DURATION } = req.body;

    if (!NAME || !CONTENT || !CONTENT_TYPE || !METADATA || !DURATION) {
      return res.status(400).json({
        success: false,
        message:
          "Required fields: NAME, CONTENT, CONTENT_TYPE, and METADATA are missing",
      });
    }

    const topic: TopicCreationAttributes = {
      NAME,
      CONTENT,
      CONTENT_TYPE,
      METADATA,
      DURATION,
    };

    const result = await CreateTopicServices(topic);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: result.message || "Failed to create the topic",
      });
    }
  } catch (error) {
    console.error("Error creating topic:", error);
    return res.status(500).json({
      success: false,
      message: "An internal server error occurred while creating the topic",
    });
  }
};

const GetTopic = async (req: Request, res: Response) => {
  try {
    const result = await GetTopicService();

    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in GetTopic controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const getTopicDetailsByTID = async (req: Request, res: Response) => {
  try {
    const CID = Number(req.query.CID);
    const MID = Number(req.query.MID);
    const UID = Number(req.query.UID);
    const TID = Number(req.query.TID);
    if (!TID) {
      return res
        .status(400)
        .json({ success: false, message: "TID is missing" });
    }
    const result = await getTopicDetailsByTIDService(CID, MID, TID, UID);
    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in getTopicDetailsByTID controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const UpdateTopic = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const { NAME, CONTENT, CONTENT_TYPE, METADATA } = req.body;
    const editTopic: TopicCreationAttributes = {
      NAME,
      CONTENT,
      CONTENT_TYPE,
      METADATA,
    };

    const result = await UpdateTopicService(Id, editTopic);

    if (result.success) {
      return res.status(200).json({ success: true, message: result.message });
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in Update Topic controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const DeleteTopic = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const result = await DeleteTopicService(Id);

    if (result.success) {
      return res.status(200).json({ success: true, message: result.message });
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in Delete Topic controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const UserTopicStatus = async (req: Request, res: Response) => {
  try {
    const userTopicId = Number(req.query.userTopicId);
    const topicId = Number(req.query.topicId);
    const userId = Number(req.query.userId);
    const status = String(req.query.status || "").trim();
    const progress = String(req.query.progress || "").trim();
    const MID = Number(req.query.MID);
    const CID = Number(req.query.CID);

    if (!topicId || !userId || !status) {
      return res
        .status(400)
        .json({ success: false, message: "Missing required parameters." });
    }

    if (!status) {
      return res
        .status(400)
        .json({ success: false, message: "Status is required." });
    }

    const updateFields: Partial<UserTopicCreationAttributes> = {
      STATUS: status,
      PROGRESS: progress,
    };

    const result = await UserTopicStatusService(
      userTopicId,
      topicId,
      userId,
      updateFields,
      MID,
      CID
    );

    if (result.success) {
      return res.status(200).json({ success: true, message: result.message });
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in Update User Topic Status controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export {
  CreateTopic,
  GetTopic,
  UpdateTopic,
  DeleteTopic,
  UserTopicStatus,
  getTopicDetailsByTID,
};
