import { Request, Response } from "express";
import { ModuleCreationAttributes } from "../Model/ModuleModel";
import {
  CreateModuleServices,
  DeleteModuleServices,
  GetAllModuleServices,
  GetModuleServices,
  UpdateModuleServices,
} from "../Service/ModuleService";

const CreateModule = async (req: Request, res: Response) => {
  try {
    const { NAME } = req.body;
    if (!NAME) {
      return res
        .status(400)
        .json({ success: false, message: "Required fields are missing" });
    }
    const module: ModuleCreationAttributes = {
      NAME,
    };
    const result = await CreateModuleServices(module);
    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json(result);
    }
  } catch (error) {
    console.error("Error Creating Module:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while creating the Module",
    });
  }
};

const GetModule = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await GetModuleServices(Id);
    if (result) {
      return res.status(200).json(result);
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to fetch getting Module" });
    }
  } catch (error) {}
};

const GetAllModule = async (req: Request, res: Response) => {
  try {
    const result = await GetAllModuleServices();
    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to fetch All Module",
      });
    }
  } catch (error) {
    console.error("Error on getting All Module:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting All Module",
    });
  }
};

const UpdateModule = async (req: Request, res: Response) => {
  try {
    const { NAME, DURATION, STATUS } = req.body;
    if (!NAME && !DURATION && !STATUS) {
      return res
        .status(400)
        .json({ success: false, message: "No fields to update" });
    }
    const moduleData: ModuleCreationAttributes = {
      NAME,
      DURATION,
      STATUS,
    };
    const id = Number(req.query.id);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: "Invalid ID" });
    }
    const updateResult = await UpdateModuleServices(moduleData, id);
    if (updateResult) {
      return res.status(200).json(updateResult);
    } else {
      return res.status(500).json(updateResult);
    }
  } catch (error) {
    console.error("Error updating module:", error);
    return res
      .status(500)
      .json({ success: false, message: "Error on updating Module" });
  }
};

const DeleteModule = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await DeleteModuleServices(Id);
    if (result) {
      return res
        .status(200)
        .json({ success: true, message: "Deleted successfully" });
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to delete Module" });
    }
  } catch (error) {
    console.error("Error on delete Module:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while deleting Module",
    });
  }
};

export { CreateModule, GetModule, GetAllModule, UpdateModule, DeleteModule };
