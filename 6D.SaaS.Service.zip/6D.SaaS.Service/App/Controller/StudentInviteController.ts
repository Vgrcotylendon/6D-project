import { Request, Response } from "express";
import { StudentInviteCreationAttributes } from "../Model/StudentInviteModel";
import {
  createStudentInviteService,
  DeleteStudentInviteService,
  getAllStudentIviteService,
  getStudentIviteService,
  UpdateStudentInviteService,
} from "../Service/StudentInviteService";

const CreateStudentInvite = async (req: Request, res: Response) => {
  try {
    const {
      sid,
      first_name,
      middle_name,
      last_name,
      field_of_study,
      year_of_study,
      semester,
    } = req.body;

    if (
      !sid ||
      !first_name ||
      !middle_name ||
      !last_name ||
      !field_of_study ||
      !year_of_study ||
      !semester
    ) {
      return res
        .status(400)
        .json({ success: false, message: "Required fields are missing" });
    }

    const studentInvite: StudentInviteCreationAttributes = {
      sid,
      first_name,
      middle_name,
      last_name,
      field_of_study,
      year_of_study,
      semester,
    };

    const result = await createStudentInviteService(studentInvite);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json(result);
    }
  } catch (error) {
    console.error("Error Create Student Invite:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while creating Student Invite",
    });
  }
};

const getStudentInvite = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await getStudentIviteService(Id);
    if (result) {
      return res.status(200).json(result);
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to fetch Student invite" });
    }
  } catch (error) {
    console.error("Error on getting user invite:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting Student invite",
    });
  }
};

const getAllStudentInvite = async (req: Request, res: Response) => {
  try {
    const result = await getAllStudentIviteService();
    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to fetch All Student invite",
      });
    }
  } catch (error) {
    console.error("Error on getting All user invite:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting All Student invite",
    });
  }
};

const UpdateStudentInvite = async (req: Request, res: Response) => {
  try {
    const userData: StudentInviteCreationAttributes = {
      first_name: req.body.first_name,
      middle_name: req.body.middle_name,
      last_name: req.body.last_name,
      field_of_study: req.body.field_of_study,
      year_of_study: req.body.year_of_study,
      semester: req.body.semester,
    };

    const id = Number(req.query.id);
    const Update = await UpdateStudentInviteService(userData, id);
    res.json(Update);
  } catch (error) {
    res.status(500).json({ error: "Error on updating Student Invite" });
  }
};

const DeleteStudentInvite = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await DeleteStudentInviteService(Id);
    if (result) {
      return res
        .status(200)
        .json({ success: true, message: "Deleted successfully" });
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to delete Student Invite" });
    }
  } catch (error) {
    console.error("Error on delete Student Invite:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while deleting Student Invite",
    });
  }
};

export {
  CreateStudentInvite,
  getStudentInvite,
  getAllStudentInvite,
  UpdateStudentInvite,
  DeleteStudentInvite,
};
