import { Request, Response } from "express";
import { UserCourseCreationAttributes } from "../Model/UserCourseModel";
import {
  EnRollCourseServices,
  getEnRollCourseByUIdService,
} from "../Service/EnRollService";

const EnRollCourse = async (req: Request, res: Response): Promise<Response> => {
  try {
    const {
      CID,
      UID,
      STATUS,
      PROGRESS,
      //   ATTEMPT
    } = req.body;

    if (
      !CID ||
      !UID
      // ||
      // !STATUS ||
      // !PROGRESS
      //   || !ATTEMPT
    ) {
      return res.status(400).json({
        success: false,
        message: "Required fields: CID, UID, STATUS and PROGRESS are missing",
      });
    }

    const enRollCourse: UserCourseCreationAttributes = {
      CID,
      UID,
      STATUS,
      PROGRESS,
      //   ATTEMPT,
    };

    const result = await EnRollCourseServices(enRollCourse);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: result.message || "Failed to map the Course Module Topic",
        data: result.data ? result.data : null,
      });
    }
  } catch (error) {
    console.error("Error creating map the Course Module Topic:", error);
    return res.status(500).json({
      success: false,
      message: "An internal server error occurred while creating the map",
    });
  }
};

const getEnRollCourseByUId = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res
        .status(400)
        .json({ success: false, message: "User ID is missing" });
    }

    const result = await getEnRollCourseByUIdService(Id);

    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in getEnRollCourseByUId controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export { EnRollCourse, getEnRollCourseByUId };
