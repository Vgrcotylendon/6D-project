import { Request, Response } from "express";
import {
  CreateUserCertificationService,
  DeleteUserCertificationService,
  GetUserCertificationService,
  UpdateUserCertificationService,
} from "../Service/UserCertificationService";
import { UserCertificationCreationAttributes } from "../Model/UserCertificationModel";

const CreateUserCertification = async (req: Request, res: Response) => {
  try {
    const { UID, CID, STATUS } = req.body;
    const usercertification: UserCertificationCreationAttributes = {
      UID,
      CID,
      STATUS,
    };

    const result = await CreateUserCertificationService(usercertification);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json(result);
    }
  } catch (error) {
    console.error("Error in CreateUserCertification controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const GetUserCertification = async (req: Request, res: Response) => {
  try {
    const result = await GetUserCertificationService();

    if (result.success) {
      if (result.data && result.data.length > 0) {
        return res.status(200).json(result.data);
      } else {
        return res
          .status(404)
          .json({ success: false, message: "No user certifications found" });
      }
    } else {
      return res.status(500).json({
        success: false,
        message: result.message || "Internal server error",
      });
    }
  } catch (error) {
    console.error("Error in GetUserCertification controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const UpdateUserCertification = async (req: Request, res: Response) => {
  try {
    const Id = req.params.id;
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const { UID, CID, STATUS } = req.body;
    const usercertification: UserCertificationCreationAttributes = {
      UID,
      CID,
      STATUS,
    };

    const result = await UpdateUserCertificationService(Id, usercertification);
    if (result.success) {
      return res.status(200).json({ success: true, message: result.message });
    } else {
      return res.status(404).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in UpdateUserCertification controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const DeleteUserCertification = async (req: Request, res: Response) => {
  try {
    const Id = req.params.id;
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const result = await DeleteUserCertificationService(Id);
    if (result.success) {
      return res.status(200).json({ success: true, message: result.message });
    } else {
      return res.status(404).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in DeleteUserCertification controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export {
  CreateUserCertification,
  GetUserCertification,
  UpdateUserCertification,
  DeleteUserCertification,
};
