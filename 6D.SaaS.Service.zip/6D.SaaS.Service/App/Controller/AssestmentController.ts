import { Request, Response } from "express";
import { AssessmentCreationAttributes } from "../Model/AssestmentModel";
import {
  CreateAssessmentService,
  CreateQuestionService,
  GetQuestionService,
  DeleteAssessmentService,
  GetAssessmentService,
  UpdateAssessmentService,
  mapAssessmentService,
  AnswerQuestionService,
  MapFinalAssessmentService,
  GetAssessmentStatusService,
  GetResultForFinalAssessmentService,
  SubmitAnswerFor_FA,
  SubmitFinalAssessmentService,
  ReAttempt_FA_Service,
  AddQuestionsForAssessment,
} from "../Service/AssestmentService";
import { QuestionCreationAttributes } from "../Model/QuestionModel";
import { UserAnswerCreationAttributes } from "../Model/UserAnswerModel";

const CreateAssessment = async (req: Request, res: Response) => {
  try {
    const { NAME, DURATION, AUTHOR, STATUS } = req.body;

    if (!NAME || !DURATION || !AUTHOR || !STATUS) {
      return res
        .status(400)
        .json({ success: false, message: "All fields are required" });
    }

    const Assessment: AssessmentCreationAttributes = {
      NAME,
      DURATION,
      AUTHOR,
      STATUS,
    };

    const result = await CreateAssessmentService(Assessment);

    if (result) {
      return res.status(200).json({
        success: true,
        message: "Assessment created successfully",
      });
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to create Assessment" });
    }
  } catch (error) {
    console.error("Error in CreateAssestment:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server Error" });
  }
};

const GetAssessment = async (req: Request, res: Response) => {
  try {
    const result = await GetAssessmentService();
    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to get assessment",
      });
    }
  } catch (error) {
    console.error("Error in GetAssessment controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const UpdateAssessment = async (req: Request, res: Response) => {
  try {
    const Id = req.params.id;
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const { AID, NAME, DURATION, AUTHOR, STATUS } = req.body;
    const assessment: AssessmentCreationAttributes = {
      AID,
      NAME,
      DURATION,
      AUTHOR,
      STATUS,
    };

    const result = await UpdateAssessmentService(Id, assessment);

    if (result.success) {
      return res.status(200).json({ success: true, message: result.message });
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in UpdateAssessment controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const DeleteAssessment = async (req: Request, res: Response) => {
  try {
    const Id = req.params.id;
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const result = await DeleteAssessmentService(Id);

    if (result.success) {
      return res.status(200).json({ success: true, message: result.message });
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in DeleteAssessment controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

//Question *****************************************************************************

const CreateQuestion = async (req: Request, res: Response) => {
  try {
    const { Question, Type, QuestionType, Choices, CorrectAnswer, Hint } =
      req.body;

    if (!Question || !QuestionType || !CorrectAnswer || !Choices) {
      return res.status(400).json({
        success: false,
        message:
          "Question, QuestionType, Choices, and CorrectAnswer are required",
      });
    }

    const question: QuestionCreationAttributes = {
      Question,
      Type,
      QuestionType,
      Hint,
    };

    const result = await CreateQuestionService(
      question,
      CorrectAnswer,
      Choices
    );

    if (result) {
      return res.status(200).json({
        success: true,
        message: "Question created successfully",
      });
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to create question",
      });
    }
  } catch (error) {
    console.error("Error in Create Question:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const GetAllQuestion = async (req: Request, res: Response) => {
  try {
    const result = await GetQuestionService();

    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to get questions",
      });
    }
  } catch (error) {
    console.error("Error in getQuestion:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const AddQuestionsForAssessmentContoller = async (
  req: Request,
  res: Response
) => {
  try {
    const { AID, QID } = req.body;

    if (!AID || !QID) {
      return res
        .status(400)
        .json({ success: false, message: "All fields are required" });
    }

    const result = await AddQuestionsForAssessment(AID, QID);

    if (result) {
      return res.status(200).json({
        success: true,
        message: "add question to assessment  successfully",
      });
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to add question to assessment",
      });
    }
  } catch (error) {
    console.error("Error in adding question to assessment:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server Error" });
  }
};

const AnswerQuestion = async (req: Request, res: Response) => {
  try {
    const { ChoiceID, QID, UID, AID, IsCorrect, userQID, time, MID, CID } =
      req.body;

    if (!ChoiceID || !QID || !UID || !AID) {
      return res.status(400).json({
        success: false,
        message: "ChoiceID, QID, UID, and AID are required",
      });
    }

    const userAnswer: UserAnswerCreationAttributes = {
      ChoiceID,
      QID,
      CID,
      UID,
      AID,
      IsCorrect,
    };

    const result = await AnswerQuestionService(
      userAnswer,
      QID,
      UID,
      AID,
      userQID,
      time,
      MID,
      CID
    );

    if (result) {
      return res.status(200).json({
        success: true,
        message: "User answer saved successfully",
      });
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to save user answer",
      });
    }
  } catch (error) {
    console.error("Error in user answer:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

//MAP-ASSESSMENT-QUESTION
const mapAssessment = async (req: Request, res: Response) => {
  try {
    const {
      assessmentId,
      questionIds,
      CID,
      MID,
      ModuleOrder,
      TID,
      TopicOrder,
      IdType,
    } = req.body;

    if (!assessmentId || !questionIds || !CID || !MID || !IdType) {
      return res.status(400).json({
        success: false,
        message: "assessmentId, questionIds, MID and CID are required",
      });
    }

    const questionIdsArray = questionIds.split(",").map(Number);

    const result = await mapAssessmentService(
      assessmentId,
      questionIdsArray,
      CID,
      MID,
      ModuleOrder,
      TID,
      TopicOrder,
      IdType
    );

    if (result) {
      return res.status(200).json({
        success: true,
        message: "Assessment mapped successfully",
      });
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to map Assessment",
      });
    }
  } catch (error) {
    console.error("Error in map Assessment:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const MapFinalAssessmentController = async (req: Request, res: Response) => {
  try {
    const {
      CID,
      AID,
      cut_off_score,
      assessment_instructions,
      attempt_instructions,
    } = req.body;
    const result = await MapFinalAssessmentService(
      CID,
      AID,
      Number(cut_off_score),
      assessment_instructions,
      attempt_instructions
    );
    if (result.success) {
      res.status(201).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to map Final Assessment",
      });
    }
  } catch (error) {
    console.error("Error in map Final Assessment:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const GetFinalAssessmentQuestionStatusController = async (
  req: Request,
  res: Response
) => {
  try {
    const { AID, CID, UID } = req.query;
    if (!AID || !CID || !UID) {
      return res.status(400).json({
        success: false,
        message: "AID, CID, UID All fields are required",
      });
    }
    const result = await GetAssessmentStatusService(
      Number(AID),
      Number(CID),
      Number(UID)
    );
    if (result.success) {
      res.status(200).json(result.data);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to fetch the data",
      });
    }
  } catch (error) {
    console.error("Error Fetching status:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const SubmitAnswerFor_FAController = async (req: Request, res: Response) => {
  try {
    const { ChoiceID, QID, UID, AID, IsCorrect, userQID, time, CID } = req.body;

    if (!ChoiceID || !QID || !UID || !AID) {
      return res.status(400).json({
        success: false,
        message: "ChoiceID, QID, UID, and AID are required",
      });
    }
    console.log("UID", UID);

    const userAnswer: UserAnswerCreationAttributes = {
      ChoiceID,
      QID,
      CID,
      UID,
      AID,
      IsCorrect,
    };

    const result = await SubmitAnswerFor_FA(
      userAnswer,
      QID,
      UID,
      AID,
      userQID,
      time,
      CID
    );

    if (result) {
      return res.status(200).json({
        success: true,
        message: "FA answer saved successfully",
      });
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to save user answer",
      });
    }
  } catch (error) {
    console.error("Error in user answer:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const SubmitFinalAssessmentController = async (req: Request, res: Response) => {
  try {
    const { AID, CID, UID, TimeTakenMins } = req.query;
    if (!AID || !CID || !UID) {
      return res.status(400).json({
        success: false,
        message: "AID, CID, UID All fields are required",
      });
    }
    const result = await SubmitFinalAssessmentService(
      Number(AID),
      Number(CID),
      Number(UID),
      TimeTakenMins
    );
    if (result.success) {
      res.status(200).json(result);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to post the data",
      });
    }
  } catch (error) {
    console.error("Error in user answer:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const GetResultForFinalAssessmentController = async (
  req: Request,
  res: Response
) => {
  try {
    const { CID, UID } = req.query;
    if (!CID || !UID) {
      return res.status(400).json({
        success: false,
        message: "AID, CID, UID All fields are required",
      });
    }
    const result = await GetResultForFinalAssessmentService(
      Number(UID),
      Number(CID)
    );
    if (result.success) {
      res.status(200).json(result.data);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to fetch the data",
      });
    }
  } catch (error) {
    console.error("Error Fetching status:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const ReAttempt_FA_Contoller = async (req: Request, res: Response) => {
  try {
    const { CID, UID } = req.query;
    if (!CID || !UID) {
      return res.status(400).json({
        success: false,
        message: " CID, UID All fields are required",
      });
    }
    const result = await ReAttempt_FA_Service(Number(UID), Number(CID));
    if (result.success) {
      res.status(200).json(result.data);
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to fetch the data",
      });
    }
  } catch (error) {
    console.error("Error Fetching status:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

export {
  CreateAssessment,
  GetAssessment,
  UpdateAssessment,
  DeleteAssessment,
  CreateQuestion,
  GetAllQuestion,
  mapAssessment,
  AnswerQuestion,
  MapFinalAssessmentController,
  GetFinalAssessmentQuestionStatusController,
  SubmitAnswerFor_FAController,
  SubmitFinalAssessmentController,
  GetResultForFinalAssessmentController,
  ReAttempt_FA_Contoller,
  AddQuestionsForAssessmentContoller,
};
