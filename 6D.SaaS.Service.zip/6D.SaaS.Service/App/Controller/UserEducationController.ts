import { Request, Response } from "express";
import {
  CreateUserEducationService,
  GetEducationService,
} from "../Service/UserEducationService";
import { UserEducationCreationAttributes } from "../Model/UserEducationModel";

const CreateUserEducation = async (req: Request, res: Response) => {
  console.log("sdasdasd")
  try {
    console.log("11111111111111111")
    const {
      UID,
      MAJOR,
      GRADUATION_YEAR,
      TERM,
      INSTITUTION_ID,
      INSTITUTION_NAME,
      DOJ,
      PLACEMENT_CELL_CO_ID,
      COUNTRY,
      STATE,
      CITY,
      ADDRESS_LINE_1,
      ADDRESS_LINE_2,
      PINCODE
    } = req.body;
    const education: UserEducationCreationAttributes = {
      UID,
      MAJOR,
      GRADUATION_YEAR,
      TERM,
      INSTITUTION_ID,
      INSTITUTION_NAME,
      DOJ,
      PLACEMENT_CELL_CO_ID,
      COUNTRY,
      STATE,
      CITY,
      ADDRESS_LINE_1,
      ADDRESS_LINE_2,
      PINCODE
    };
    const result = await CreateUserEducationService(education);

    if (result) {
      return res
        .status(200)
        .json({ success: true, message: "Education updated successfully" });
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to update Education" });
    }
  } catch (error) {
    console.error("Error on updating experience:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while updating Education",
    });
  }
};
const GetUserEducation = async (req: Request, res: Response) => {
  try {
    const UID = req.params.uid;

    if (!UID) {
      return res
        .status(400)
        .json({ success: false, message: "Required fields are missing" });
    }
    const result = await GetEducationService(UID);
    if (result) {
      return res.status(200).json(result);
    } else {
      return res
        .status(500)
        .json({ success: false, message: "error on getting education" });
    }
  } catch (error) {
    console.error(error);
  }
};

export { CreateUserEducation, GetUserEducation };
