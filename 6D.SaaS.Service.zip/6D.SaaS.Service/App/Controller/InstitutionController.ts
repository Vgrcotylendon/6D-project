import { Request, Response } from "express";
import {
  CreateInstitutionService,
  DeleteInstitutionService,
  GetInstitutionService,
  UpdateInstitutionService,
} from "../Service/InstitutionService";
import { InstitutionCreationAttributes } from "../Model/InstitutionModel";

const CreateInstitution = async (req: Request, res: Response) => {
  try {
    const {
      Institution_name,
      Industry,
      Headquarters,
      website,
      company_size,
      founded_year,
      overview,
      ADDRESS_LINE_1,
      ADDRESS_LINE_2,
      CITY,
      STATE,
      COUNTRY,
      PINCODE,
    } = req.body;

    if (
      !Institution_name ||
      !Industry ||
      !Headquarters ||
      !website ||
      !company_size ||
      !founded_year ||
      !overview ||
      !ADDRESS_LINE_1 ||
      !ADDRESS_LINE_2 ||
      !CITY ||
      !STATE ||
      !COUNTRY ||
      !PINCODE
    ) {
      return res
        .status(400)
        .json({ success: false, message: "Required fields are missing" });
    }

    const institution: InstitutionCreationAttributes = {
      Institution_name,
      Industry,
      Headquarters,
      website,
      company_size,
      founded_year,
      overview,
      ADDRESS_LINE_1,
      ADDRESS_LINE_2,
      CITY,
      STATE,
      COUNTRY,
      PINCODE,
    };

    const result = await CreateInstitutionService(institution);

    if (result.success) {
      return res.status(200).json({ success: true, message: result.message });
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in CreateInstitution controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const GetInstitution = async (req: Request, res: Response) => {
  try {
    const result = await GetInstitutionService();
    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(404).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in GetInstitution controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const UpdateInstitution = async (req: Request, res: Response) => {
  try {
    const Id = req.params.id;
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const {
      Institution_name,
      Industry,
      Headquarters,
      website,
      company_size,
      founded_year,
      overview,
      ADDRESS_LINE_1,
      ADDRESS_LINE_2,
      CITY,
      STATE,
      COUNTRY,
      PINCODE,
    } = req.body;

    const institution: InstitutionCreationAttributes = {
      Institution_name,
      Industry,
      Headquarters,
      website,
      company_size,
      founded_year,
      overview,
      ADDRESS_LINE_1,
      ADDRESS_LINE_2,
      CITY,
      STATE,
      COUNTRY,
      PINCODE,
    };

    const result = await UpdateInstitutionService(Id, institution);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(404).json(result);
    }
  } catch (error) {
    console.error("Error in UpdateInstitution controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const DeleteInstitution = async (req: Request, res: Response) => {
  try {
    const Id = req.params.id;
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const result = await DeleteInstitutionService(Id);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(404).json(result);
    }
  } catch (error) {
    console.error("Error in DeleteInstitution controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export {
  CreateInstitution,
  GetInstitution,
  UpdateInstitution,
  DeleteInstitution,
};
