import { Request, Response } from "express";
import { UserInviteCreationAttributes } from "../Model/UserInviteModel";
import {
  CreateUserInviteService,
  DeleteUserInviteService,
  GetAllUserInviteService,
  GetUserInviteService,
  UpdateUserInviteService,
} from "../Service/UserInviteSerivice";

const CreateInviteForUser = async (req: Request, res: Response) => {
  try {
    const { ID, EMAIL, ROLES, INVITE_SENT } = req.body;

    if (!ID || !EMAIL || !ROLES || !INVITE_SENT) {
      return res
        .status(400)
        .json({ success: false, message: "Required fields are missing" });
    }

    const Invite: UserInviteCreationAttributes = {
      ID,
      EMAIL,
      ROLES,
      INVITE_SENT,
    };

    const result = await CreateUserInviteService(Invite);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json(result);
    }
  } catch (error) {
    console.error("Error Create User Invite:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while creating User Invite",
    });
  }
};

const GetUserInviteById = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await GetUserInviteService(Id);
    if (result) {
      return res.status(200).json(result);
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to fetch user invite" });
    }
  } catch (error) {
    console.error("Error on getting user invite:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting user invite",
    });
  }
};

const GetAllUserInvite = async (req: Request, res: Response) => {
  try {
    const result = await GetAllUserInviteService();
    if (result) {
      return res.status(200).json(result);
    } else {
      return res
        .status(404)
        .json({ success: false, message: "No user invites found" });
    }
  } catch (error) {
    console.error("Error on getting user invites:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while getting user invites",
    });
  }
};

const UpdateUserInvite = async (req: Request, res: Response) => {
  try {
    const userData: UserInviteCreationAttributes = {
      EMAIL: req.body.EMAIL,
      ROLES: req.body.ROLES,
      INVITE_SENT: req.body.INVITE_SENT,
    };

    const id = Number(req.query.id);
    const Update = await UpdateUserInviteService(userData, id);
    res.json(Update);
  } catch (error) {
    res.status(500).json({ error: "Error on updating User Invite" });
  }
};

const DeleteUserInvite = async (req: Request, res: Response) => {
  try {
    const Id = Number(req.query.id);
    if (!Id) {
      return res.status(400).json({ success: false, message: "Id is missing" });
    }
    const result = await DeleteUserInviteService(Id);
    if (result) {
      return res
        .status(200)
        .json({ success: true, message: "Deleted successfully" });
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Failed to delete User Invite" });
    }
  } catch (error) {
    console.error("Error on delete experience:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while deleting User Invite",
    });
  }
};

export {
  CreateInviteForUser,
  GetUserInviteById,
  GetAllUserInvite,
  UpdateUserInvite,
  DeleteUserInvite,
};
