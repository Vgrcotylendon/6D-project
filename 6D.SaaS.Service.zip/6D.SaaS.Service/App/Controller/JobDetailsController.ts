import { Request, Response } from "express";
import {
  CreateJobDetailsService,
  DeleteJobDetailsService,
  GetJobDetailsService,
  UpdateJobDetailsService,
} from "../Service/JobDetailsService";
import { JobDetailsCreationAttributes } from "../Model/JobDetailsModel";

const CreateJobDetails = async (req: Request, res: Response) => {
  try {
    const {
      job_name,
      job_title,
      hiring_company,
      work_location,
      employment_type,
      work_mode,
      positions,
      stipend,
      submission_date,
      hiring_date,
      role_description,
      responsibilities,
      required_certification,
    } = req.body;

    const jobDetails: JobDetailsCreationAttributes = {
      job_name,
      job_title,
      hiring_company,
      work_location,
      employment_type,
      work_mode,
      positions,
      stipend,
      submission_date,
      hiring_date,
      role_description,
      responsibilities,
      required_certification,
    };

    const result = await CreateJobDetailsService(jobDetails);

    if (result.success) {
      return res
        .status(200)
        .json({ success: true, message: result.message, data: result.data });
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in CreateJobDetails controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const GetJobDetails = async (req: Request, res: Response) => {
  try {
    const result = await GetJobDetailsService();

    if (result.success) {
      return res.status(200).json(result.data);
    } else {
      return res.status(500).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in GetJobDetails controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const UpdateJobDetails = async (req: Request, res: Response) => {
  try {
    const Id = req.params.id;
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const {
      job_name,
      job_title,
      hiring_company,
      work_location,
      employment_type,
      work_mode,
      positions,
      stipend,
      submission_date,
      hiring_date,
      role_description,
      responsibilities,
      required_certification,
    } = req.body;

    const jobDetails: JobDetailsCreationAttributes = {
      job_name,
      job_title,
      hiring_company,
      work_location,
      employment_type,
      work_mode,
      positions,
      stipend,
      submission_date,
      hiring_date,
      role_description,
      responsibilities,
      required_certification,
    };

    const result = await UpdateJobDetailsService(Id, jobDetails);

    if (result.success) {
      return res.status(200).json({ success: true, message: result.message });
    } else {
      return res.status(404).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in UpdateJobDetails controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

const DeleteJobDetails = async (req: Request, res: Response) => {
  try {
    const Id = req.params.id;
    if (!Id) {
      return res.status(400).json({ success: false, message: "ID is missing" });
    }

    const result = await DeleteJobDetailsService(Id);

    if (result.success) {
      return res.status(200).json({ success: true, message: result.message });
    } else {
      return res.status(404).json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error("Error in DeleteJobDetails controller:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export { CreateJobDetails, GetJobDetails, UpdateJobDetails, DeleteJobDetails };
