import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateInviteForUser,
  DeleteUserInvite,
  GetAllUserInvite,
  GetUserInviteById,
  UpdateUserInvite,
} from "../Controller/UserInviteController";

const UserInviteRoutes = express.Router();

UserInviteRoutes.post("/CreateUserInvite", Middleware, CreateInviteForUser);
UserInviteRoutes.get("/GetUserInvite", Middleware, GetUserInviteById);
UserInviteRoutes.get("/GetAllUserInvite", Middleware, GetAllUserInvite);
UserInviteRoutes.put("/UpdateUserInvite", Middleware, UpdateUserInvite);
UserInviteRoutes.delete("/DeleteUserInvite", Middleware, DeleteUserInvite);

export { UserInviteRoutes };
