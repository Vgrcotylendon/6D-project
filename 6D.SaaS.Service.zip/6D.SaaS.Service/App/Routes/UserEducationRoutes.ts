import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateUserEducation,
  GetUserEducation,
} from "../Controller/UserEducationController";

const UserEducationRoutes = express.Router();

UserEducationRoutes.post(
  "/createUserEducation",
  Middleware,
  CreateUserEducation
);
UserEducationRoutes.get("/getUserEducation/:uid", Middleware, GetUserEducation);

export { UserEducationRoutes };
