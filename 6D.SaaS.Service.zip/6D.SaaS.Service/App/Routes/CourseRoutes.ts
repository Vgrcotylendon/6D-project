import express from "express";
import { Request, Router } from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateCourse,
  DeleteCourse,
  GetAllCourseByUserId,
  GetCourse,
  UpdateCourse,
  getAllCourse,
  getAllCourseWithStatus,
  getCourseDetailsById,
} from "../Controller/CourseController";
import path from "path";
import multer from "multer";

const CourseRoutes = express.Router();

const storage = multer.diskStorage({
  destination: function (
    req: Request,
    file: Express.Multer.File,
    cb: (error: Error | null, destination: string) => void
  ) {
    cb(null, path.join(__dirname, "../../uploads"));
  },
  filename: function (
    req: Request,
    file: Express.Multer.File,
    cb: (error: Error | null, filename: string) => void
  ) {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage });

CourseRoutes.post(
  "/CreateCourse",
  Middleware,
  upload.single("image"),
  CreateCourse
);
// CourseRoutes.post("/CreateCourse", Middleware, CreateCourse);
CourseRoutes.get("/getCourse", Middleware, GetCourse);
CourseRoutes.get("/getAllCourse", Middleware, getAllCourse);
CourseRoutes.get("/getAllCourseWithStatus", Middleware, getAllCourseWithStatus);
CourseRoutes.get("/getAllCourseByUserId", Middleware, GetAllCourseByUserId);
CourseRoutes.get("/getCourseDetailsBy-CID", Middleware, getCourseDetailsById);
CourseRoutes.put("/UpdateCourse", Middleware, UpdateCourse);
CourseRoutes.delete("/DeleteCourse", Middleware, DeleteCourse);

export { CourseRoutes };
