import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateTopic,
  GetTopic,
  UpdateTopic,
  DeleteTopic,
  UserTopicStatus,
  getTopicDetailsByTID,
} from "../Controller/TopicControlleer";

const TopicRoutes = express.Router();

TopicRoutes.post("/CreateTopic", Middleware, CreateTopic);
TopicRoutes.get("/getTopic", Middleware, GetTopic);
TopicRoutes.get("/getTopicDetailsByTID", Middleware, getTopicDetailsByTID);
TopicRoutes.put("/UpdateTopic", Middleware, UpdateTopic);
TopicRoutes.delete("/DeleteTopic", Middleware, DeleteTopic);

// User Topic
TopicRoutes.put("/UpdateUserTopicStatus", Middleware, UserTopicStatus);

export { TopicRoutes };
