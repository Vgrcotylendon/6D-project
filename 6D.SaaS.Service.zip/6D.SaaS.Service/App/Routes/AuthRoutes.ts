import { Request, Response, Router } from "express";
import {
  AuthVerify,
  CreatePassword,
  EmailSignin,
  Getme,
  SendVerifyCodeforEmail,
  SendCodeforMobile,
  signOutController,
  VerifyCode,
  verifyCodeforMobile,
  NewGenerateMobileVerificationCode,
  NewGenerateEmailVerificationCode,
  VerifyCodeForMobileSignUp,
  ForgotPassword,
  socialMediaSignUp,
  socialMediaSignIn,
  getPassword,
  changePassword,
  EmailSigninCheck,
  ReSendCodeforSignUp,
} from "../Controller/AuthController";
import { Middleware } from "../Util/Middleware";
export const AuthRoutes = Router();

//mobile - SIGNUP
AuthRoutes.post("/sendcode-new-mobile", NewGenerateMobileVerificationCode);
AuthRoutes.post("/verifyCodeforMobile", verifyCodeforMobile);
AuthRoutes.post("/reSendCodeforMobileInSignUp", ReSendCodeforSignUp);

//mobile - SIGNIN
AuthRoutes.post("/sendCodeforMobile", SendCodeforMobile);

//email
AuthRoutes.post("/sendCode", SendVerifyCodeforEmail);
AuthRoutes.post("/sendcode-new-email", NewGenerateEmailVerificationCode);
AuthRoutes.post("/verifyMobile-signup", VerifyCodeForMobileSignUp);

//social media email signIn/signUp without code and pass
AuthRoutes.post("/socialMediaSignUp", socialMediaSignUp);
AuthRoutes.post("/socialMediaSignIn", socialMediaSignIn);

AuthRoutes.post("/verifyCode", VerifyCode);
AuthRoutes.post("/createPassword", CreatePassword);
AuthRoutes.post("/EmailSignIn", EmailSignin);
AuthRoutes.post("/CheckEmailSignIn", EmailSigninCheck);
//token
AuthRoutes.get("/verify-token", Middleware, AuthVerify);
AuthRoutes.post("/getme", Middleware, Getme);
//signout
AuthRoutes.post("/signout", Middleware, signOutController);
AuthRoutes.post("/forgotPassword", ForgotPassword);

// CHANGE PASSWORD
AuthRoutes.get("/getPassword", Middleware, getPassword);
AuthRoutes.post("/changePassword", Middleware, changePassword);
