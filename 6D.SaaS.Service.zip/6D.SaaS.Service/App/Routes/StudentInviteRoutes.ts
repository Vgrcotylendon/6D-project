import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateStudentInvite,
  getAllStudentInvite,
  getStudentInvite,
  UpdateStudentInvite,
  DeleteStudentInvite,
} from "../Controller/StudentInviteController";

const StudentInviteRoutes = express.Router();

StudentInviteRoutes.post(
  "/CreateStudentInvite",
  Middleware,
  CreateStudentInvite
);
StudentInviteRoutes.get("/getStudentInvite", Middleware, getStudentInvite);
StudentInviteRoutes.get(
  "/getAllStudentInvite",
  Middleware,
  getAllStudentInvite
);
StudentInviteRoutes.put(
  "/UpdateStudentInvite",
  Middleware,
  UpdateStudentInvite
);
StudentInviteRoutes.delete(
  "/DeleteStudentInvite",
  Middleware,
  DeleteStudentInvite
);

export { StudentInviteRoutes };
