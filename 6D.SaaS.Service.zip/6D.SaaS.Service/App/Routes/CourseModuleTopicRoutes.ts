import express from "express";
import { Middleware } from "../Util/Middleware";

import {
  MapCourseModuleTopic,
  GetCourseModuleByCID,
  MapAssessmentCourse,
  GetModuleTopicByMID,
  GetModuleAssessmentByMID,
  GetAssessmentQuestionByAID,
  ExpandAllController,
  NewContinueToLastController,
  NewGetCourseDetailsController,
  NextTaskController,
  PreviousTaskController,
} from "../Controller/CourseModuleTopicController";

const CourseModuleTopicRoutes = express.Router();

CourseModuleTopicRoutes.post(
  "/Course-Module-Topic",
  Middleware,
  MapCourseModuleTopic
);

CourseModuleTopicRoutes.get(
  "/getCourse-Module-ByCourseId",
  Middleware,
  GetCourseModuleByCID
);

CourseModuleTopicRoutes.get(
  "/getModule-Topic-ByModuleId",
  Middleware,
  GetModuleTopicByMID
);

CourseModuleTopicRoutes.get(
  "/getModule-Assessment-ByModuleId",
  Middleware,
  GetModuleAssessmentByMID
);


CourseModuleTopicRoutes.get(
  "/getAssessment-Question-ByAID",
  Middleware,
  GetAssessmentQuestionByAID
);

// Assessment map
CourseModuleTopicRoutes.post(
  "/Course-Module-Topic-Assessment",
  Middleware,
  MapAssessmentCourse
);

//New Continue to next topic
CourseModuleTopicRoutes.get(
  "/new-Continue-to-lastTopic",
  Middleware,
  NewContinueToLastController
);

//New Continue to next topic
CourseModuleTopicRoutes.get(
  "/new-GetCourseDetails",
  Middleware,
  NewGetCourseDetailsController
);

// NewNextController

//NEXT TOPIC
CourseModuleTopicRoutes.get("/new-nextTask", Middleware, NextTaskController);

//PREVIOUS TOPIC
CourseModuleTopicRoutes.get(
  "/new-previousTask",
  Middleware,
  PreviousTaskController
);

// expand all modules
CourseModuleTopicRoutes.get("/expandAll", Middleware, ExpandAllController);

export { CourseModuleTopicRoutes };
