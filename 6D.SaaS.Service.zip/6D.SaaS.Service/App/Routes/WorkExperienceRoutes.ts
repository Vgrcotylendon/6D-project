import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateExperience,
  DeleteExperience,
  GetExperienceById,
  UpdateExperienceById,
} from "../Controller/WorkExperienceController";

const ExperienceRoutes = express.Router();

ExperienceRoutes.post("/createExperience", Middleware, CreateExperience);
ExperienceRoutes.get("/getExperience", Middleware, GetExperienceById);
ExperienceRoutes.put("/updateExperience", Middleware, UpdateExperienceById);
ExperienceRoutes.delete("/deleteExperience", Middleware, DeleteExperience);

export { ExperienceRoutes };
