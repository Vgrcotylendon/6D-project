import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateModule,
  GetModule,
  GetAllModule,
  UpdateModule,
  DeleteModule,
} from "../Controller/ModuleController";

const ModuleRoutes = express.Router();

ModuleRoutes.post("/CreateModule", Middleware, CreateModule);
ModuleRoutes.get("/GetModule", Middleware, GetModule);
ModuleRoutes.get("/GetAllModule", Middleware, GetAllModule);
ModuleRoutes.put("/UpdateModule", Middleware, UpdateModule);
ModuleRoutes.delete("/DeleteModule", Middleware, DeleteModule);

export { ModuleRoutes };
