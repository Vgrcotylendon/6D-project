import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateInstitution,
  DeleteInstitution,
  GetInstitution,
  UpdateInstitution,
} from "../Controller/InstitutionController";

const InstitutionRoutes = express.Router();

InstitutionRoutes.post("/createInstitution", Middleware, CreateInstitution);
InstitutionRoutes.get("/getInstitution", Middleware, GetInstitution);
InstitutionRoutes.put("/updateInstitution/:id", Middleware, UpdateInstitution);
InstitutionRoutes.delete(
  "/deleteInstitution/:id",
  Middleware,
  DeleteInstitution
);

export { InstitutionRoutes };
