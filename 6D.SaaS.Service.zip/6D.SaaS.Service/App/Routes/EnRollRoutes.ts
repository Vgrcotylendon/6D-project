import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  EnRollCourse,
  getEnRollCourseByUId,
} from "../Controller/EnRollController";

const EnRollRoutes = express.Router();

EnRollRoutes.post("/Course", Middleware, EnRollCourse);

EnRollRoutes.get("/getEnRollCourse-ByUId", Middleware, getEnRollCourseByUId);

export { EnRollRoutes };
