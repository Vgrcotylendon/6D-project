import express from "express";
import { Middleware } from "../Util/Middleware";

import {
  CreateCertification,
  DeleteCertification,
  GetCertification,
  UpdateCertification,
} from "../Controller/CertificationController";

const CertificationRoutes = express.Router();

CertificationRoutes.post(
  "/createCertification",
  Middleware,
  CreateCertification
);
CertificationRoutes.get("/getCertification", Middleware, GetCertification);
CertificationRoutes.put(
  "/updateCertification/:id",
  Middleware,
  UpdateCertification
);
CertificationRoutes.delete(
  "/deleteCertification/:id",
  Middleware,
  DeleteCertification
);

export { CertificationRoutes };
