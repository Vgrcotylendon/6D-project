import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateJobDetails,
  DeleteJobDetails,
  GetJobDetails,
  UpdateJobDetails,
} from "../Controller/JobDetailsController";

const JobDetailsRoutes = express.Router();

JobDetailsRoutes.post("/CreateJobDetails", Middleware, CreateJobDetails);
JobDetailsRoutes.get("/GetJobDetails", Middleware, GetJobDetails);
JobDetailsRoutes.put("/UpdateJobDetails/:id", Middleware, UpdateJobDetails);
JobDetailsRoutes.delete("/DeleteJobDetails/:id", Middleware, DeleteJobDetails);

export { JobDetailsRoutes };
