import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateUserCertification,
  DeleteUserCertification,
  GetUserCertification,
  UpdateUserCertification,
} from "../Controller/UserCertificationController";

const UserCertificationRoutes = express.Router();

UserCertificationRoutes.post(
  "/createUserCertification",
  Middleware,
  CreateUserCertification
);
UserCertificationRoutes.get(
  "/getUserCertification",
  Middleware,
  GetUserCertification
);
UserCertificationRoutes.put(
  "/updateUserCertification/:id",
  Middleware,
  UpdateUserCertification
);
UserCertificationRoutes.delete(
  "/deleteUserCertification/:id",
  Middleware,
  DeleteUserCertification
);

export { UserCertificationRoutes };
