import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateAssessment,
  DeleteAssessment,
  GetAssessment,
  UpdateAssessment,
  CreateQuestion,
  GetAllQuestion,
  mapAssessment,
  AnswerQuestion,
  MapFinalAssessmentController,
  GetFinalAssessmentQuestionStatusController,
  SubmitAnswerFor_FAController,
  GetResultForFinalAssessmentController,
  SubmitFinalAssessmentController,
  ReAttempt_FA_Contoller,
  AddQuestionsForAssessmentContoller,
} from "../Controller/AssestmentController";

const AssessmentRoutes = express.Router();

AssessmentRoutes.post("/createAssessment", Middleware, CreateAssessment);
AssessmentRoutes.get("/getAssessment", Middleware, GetAssessment);
AssessmentRoutes.put("/updateAssessment/:id", Middleware, UpdateAssessment);
AssessmentRoutes.delete("/deleteAssessment/:id", Middleware, DeleteAssessment);

//Question
AssessmentRoutes.post("/createQuestion", Middleware, CreateQuestion);
AssessmentRoutes.get("/getAllQuestion", Middleware, GetAllQuestion);
AssessmentRoutes.post("/userAnswers", Middleware, AnswerQuestion);

//ADD-ASSESSMENT-QUESTION
AssessmentRoutes.post(
  "/add-questionForAssessment",
  Middleware,
  AddQuestionsForAssessmentContoller
);

//MAP-ASSESSMENT-QUESTION
AssessmentRoutes.post("/map-assessment-question", Middleware, mapAssessment);

//MAP-FINAL-ASSESSMENT-QUESTION
AssessmentRoutes.post(
  "/map-finalAssessment",
  Middleware,
  MapFinalAssessmentController
);

// SUBMITFINAL-ASSESSMENT-QUESTION
AssessmentRoutes.post(
  "/submitAnswerFor-FA",
  Middleware,
  SubmitAnswerFor_FAController
);

//FINAL-ASSESSMENT-QUESTION STATUS
AssessmentRoutes.get(
  "/getFinalAssessmentQuestionStatus",
  Middleware,
  GetFinalAssessmentQuestionStatusController
);

//SUBMIT FINAL-ASSESSMENT
AssessmentRoutes.post(
  "/submitFinalAssessment",
  Middleware,
  SubmitFinalAssessmentController
);

//FINAL-ASSESSMENT-RESULT
AssessmentRoutes.get(
  "/getResultForFinalAssessment",
  Middleware,
  GetResultForFinalAssessmentController
);

// RE-ATTEMPt FINAL ASSESMENT
AssessmentRoutes.get(
  "/reAttemptFinalAssessment",
  Middleware,
  ReAttempt_FA_Contoller
);

export { AssessmentRoutes };
