import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  CreateVoucher,
  DeleteVoucher,
  GetVoucher,
  UpdateVoucher,
} from "../Controller/VoucherController";

const VoucherRoutes = express.Router();

VoucherRoutes.post("/CreateVoucher", Middleware, CreateVoucher);
VoucherRoutes.get("/GetVoucher", Middleware, GetVoucher);
VoucherRoutes.put("/UpdateVoucher/:id", Middleware, UpdateVoucher);
VoucherRoutes.delete("/DeleteVoucher/:id", Middleware, DeleteVoucher);

export { VoucherRoutes };
