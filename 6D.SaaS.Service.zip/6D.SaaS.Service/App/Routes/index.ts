import express, { Router } from "express";
import path from "path";
import { userRoutes } from "./UserRoutes";
import { AuthRoutes } from "./AuthRoutes";
import { ExperienceRoutes } from "./WorkExperienceRoutes";
import { UserEducationRoutes } from "./UserEducationRoutes";
import { UserInviteRoutes } from "./UserInviteRoutes";
import { CertificationRoutes } from "./CertificateRoutes";
import { AssessmentRoutes } from "./AssessmentRoutes";
import { StudentInviteRoutes } from "./StudentInviteRoutes";
import { CourseRoutes } from "./CourseRoutes";
import { VoucherRoutes } from "./VoucherRoutes";
import { UserCertificationRoutes } from "./UserCertificationRoutes";
import { InstitutionRoutes } from "./InstitutionRoutes";
import { ModuleRoutes } from "./ModuleRoutes";
import { JobDetailsRoutes } from "./JobDetailsRoutes";
import { TopicRoutes } from "./TopicRoutes";
import { CourseModuleTopicRoutes } from "./CourseModuleTopicRoutes";
import { EnRollRoutes } from "./EnRollRoutes";
import { ActivityRoutes } from "./ActivityRoutes";

const Routes = Router();
Routes.use("/user", userRoutes);
Routes.use("/auth", AuthRoutes);
Routes.use("/institution", InstitutionRoutes);
Routes.use("/jobDetails", JobDetailsRoutes);
Routes.use("/voucher", VoucherRoutes);
Routes.use("/certification", CertificationRoutes);
Routes.use("/usercertification", UserCertificationRoutes);
Routes.use("/experience", ExperienceRoutes);
Routes.use("/education", UserEducationRoutes);
Routes.use("/userInvite", UserInviteRoutes);
Routes.use("/StudentInvite", StudentInviteRoutes);

Routes.use("/Course", CourseRoutes);
Routes.use("/Module", ModuleRoutes);
Routes.use("/Topic", TopicRoutes);

Routes.use("/map", CourseModuleTopicRoutes);

Routes.use("/enRoll", EnRollRoutes);

// Activity - Dashboard
Routes.use("/activity", ActivityRoutes);

//Assessments
Routes.use("/assessment", AssessmentRoutes);

Routes.use("/uploads", express.static(path.join(__dirname, "../../uploads")));

export { Routes };
