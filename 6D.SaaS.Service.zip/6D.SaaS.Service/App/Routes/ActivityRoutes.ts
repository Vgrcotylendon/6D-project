import express from "express";
import { Middleware } from "../Util/Middleware";
import {
  getActivityCount,
  getModuleCount,
} from "../Controller/ActivityController";

const ActivityRoutes = express.Router();

ActivityRoutes.get("/myDashboardCount", Middleware, getActivityCount);
ActivityRoutes.get("/myDashboardModuleCount", Middleware, getModuleCount);

export { ActivityRoutes };
