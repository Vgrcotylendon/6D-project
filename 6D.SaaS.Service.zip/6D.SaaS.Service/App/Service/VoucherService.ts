import { Voucher, VoucherCreationAttributes } from "../Model/VoucherModel";

const CreateVoucherService = async (voucher: VoucherCreationAttributes) => {
  try {
    await Voucher.create(voucher);
    return { success: true, message: "Voucher created successfully" };
  } catch (error) {
    console.error("Error creating voucher:", error);
    return { success: false, message: "Failed to create voucher" };
  }
};

const GetVoucherService = async () => {
  try {
    const result = await Voucher.findAll();
    if (result.length > 0) {
      return { success: true, data: result };
    } else {
      return { success: false, message: "No vouchers found" };
    }
  } catch (error) {
    console.error("Error fetching vouchers:", error);
    return { success: false, message: "Failed to fetch vouchers" };
  }
};

const UpdateVoucherService = async (
  Id: string,
  voucher: VoucherCreationAttributes
) => {
  try {
    const existingVoucher = await Voucher.findOne({ where: { vid: Id } });
    if (!existingVoucher) {
      return { success: false, message: "Voucher not found" };
    }

    const [updateCount] = await Voucher.update(voucher, { where: { vid: Id } });
    if (updateCount > 0) {
      return { success: true, message: "Voucher updated successfully" };
    } else {
      return { success: false, message: "Failed to update voucher" };
    }
  } catch (error) {
    console.error("Error updating voucher:", error);
    return { success: false, message: "Internal server error" };
  }
};

const DeleteVoucherService = async (Id: string) => {
  try {
    const existingVoucher = await Voucher.findOne({ where: { vid: Id } });
    if (!existingVoucher) {
      return { success: false, message: "Voucher not found" };
    }

    const deleteCount = await Voucher.destroy({ where: { vid: Id } });
    if (deleteCount > 0) {
      return { success: true, message: "Voucher deleted successfully" };
    } else {
      return { success: false, message: "Failed to delete voucher" };
    }
  } catch (error) {
    console.error("Error deleting voucher:", error);
    return { success: false, message: "Internal server error" };
  }
};
export {
  CreateVoucherService,
  GetVoucherService,
  UpdateVoucherService,
  DeleteVoucherService,
};
