import {
  StudentInvite,
  StudentInviteCreationAttributes,
} from "../Model/StudentInviteModel";

const createStudentInviteService = async (
  studentInvite: StudentInviteCreationAttributes
) => {
  try {
    const newStudentInvite = await StudentInvite.create(studentInvite);
    if (newStudentInvite) {
      return { success: true, message: "Student Invite sent successfully" };
    } else {
      return { success: false, message: "Failed to send Student Invite" };
    }
  } catch (error) {
    console.error("Error to send Student Invite:", error);
    return {
      success: false,
      message: "An error occurred while sending Invite",
    };
  }
};

const getStudentIviteService = async (id: number) => {
  try {
    const studentInvite = await StudentInvite.findOne({ where: { sid: id } });
    if (studentInvite) {
      return studentInvite;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on fetching Student Invite:", error);
    return {
      success: false,
      message: "An error occurred while getting Student Invite",
    };
  }
};

const getAllStudentIviteService = async () => {
  try {
    const AllStudentInvite = await StudentInvite.findAll();
    if (AllStudentInvite) {
      return AllStudentInvite;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on fetching All Student Invite:", error);
    return {
      success: false,
      message: "An error occurred while getting All Student Invite",
    };
  }
};

const UpdateStudentInviteService = async (
  studentInvite: StudentInviteCreationAttributes,
  id: number
) => {
  try {
    const user = await StudentInvite.findOne({ where: { sid: id } });
    if (!user) {
      throw new Error("user not found");
    }
    await StudentInvite.update(studentInvite, { where: { sid: id } });
    const updatedStudentInvite = await StudentInvite.findOne({
      where: { sid: id },
    });
    return updatedStudentInvite;
  } catch (error) {
    console.error(error);
    throw new Error("Failed to update Student Invite");
  }
};

const DeleteStudentInviteService = async (id: number) => {
  try {
    const studentInvite = await StudentInvite.destroy({ where: { sid: id } });
    if (studentInvite) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on deleting Student Invite:", error);
    return {
      success: false,
      message: "An error occurred while delete Student Invite",
    };
  }
};

export {
  createStudentInviteService,
  getStudentIviteService,
  getAllStudentIviteService,
  UpdateStudentInviteService,
  DeleteStudentInviteService,
};
