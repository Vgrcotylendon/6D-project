import {
  UserContact,
  UserContactCreationAttributes,
} from "../Model/UserContact";
import {
  UserDemographics,
  UserDemographicsCreationAttributes,
} from "../Model/UserDemographics";
import { User, UserCreationAttributes } from "../Model/UserModel";

const CreateProfileService = async (
  id: string,
  userData: UserCreationAttributes,
  Usercontact: UserContactCreationAttributes,
  Userdemographics: UserDemographicsCreationAttributes
) => {
  try {
    const FindUser = await User.findByPk(id);

    if (FindUser) {
      await User.update(userData, { where: { UID: id } });
      await UserContact.update(Usercontact, { where: { UID: id } });
      await UserDemographics.update(Userdemographics, { where: { UID: id } });
      const user = await User.findByPk(id);
      const Contact = await UserContact.findByPk(id);
      const demographics = await UserDemographics.findByPk(id);
      if (user && Contact && demographics) {
        return {
          success: true,
          message: "Successfully updated details",
        };
      }
    } else {
      const user = await User.create(userData);
      const Contact = await UserContact.create(Usercontact);
      const demographics = await UserDemographics.create(Userdemographics);
      if (user && Contact && demographics) {
        return {
          success: true,
          message: "Successfully created details",
        };
      }
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to create user");
  }
};

const getProfileService = async (id: number) => {
  try {
    // const user = await User.findByPk(id);
    const user = await User.findOne({ where: { UID: id } });
    const Contact = await UserContact.findOne({ where: { UID: id } });
    const demographics = await UserDemographics.findOne({ where: { UID: id } });
    if (user && Contact && demographics) {
      const userData = user.toJSON();
      const contactData = Contact.toJSON();
      const demographicsData = demographics.toJSON();

      return {
        ...userData,
        ...contactData,
        ...demographicsData,
      };
    } else {
      return {
        success: false,
        message: "failed to fetch details",
      };
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to get user profile");
  }
};

const UpdateProfileService = async (
  userData: UserCreationAttributes,
  id: number,
  UserContact: UserContactCreationAttributes
) => {
  try {
    const user = await User.findByPk(id);
    if (!user) {
      throw new Error("user not found");
    }
    await User.update(userData, { where: { UID: id } });
    const updatedUser = await User.findByPk(id);
    return updatedUser;
  } catch (error) {
    console.error(error);
    throw new Error("Failed to update user profile");
  }
};

export { CreateProfileService, getProfileService, UpdateProfileService };
