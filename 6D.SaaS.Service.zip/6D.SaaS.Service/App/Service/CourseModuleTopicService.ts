import { Answer } from "../Model/AnswerModel";
import { AssessmentQuestionAnswer } from "../Model/AssessmentQ&AModel";
import { Assessment } from "../Model/AssestmentModel";
import { Course } from "../Model/CourseModel";
import {
  CourseModuleTopic,
  CourseModuleTopicCreationAttributes,
} from "../Model/CourseModuleTopicModel";
import { Module } from "../Model/ModuleModel";
import { Question } from "../Model/QuestionModel";
import { Topic } from "../Model/TopicModel";
import { UserAnswer } from "../Model/UserAnswerModel";
import {
  UserAssessment,
  UserAssessmentCreationAttributes,
} from "../Model/UserAssessmentModel";
import { UserCourse } from "../Model/UserCourseModel";
import {
  UserModule,
  UserModuleCreationAttributes,
} from "../Model/UserModuleModel";
import { UserQuestion } from "../Model/UserQuestionModel";
import {
  UserTopic,
  UserTopicCreationAttributes,
} from "../Model/UserTopicModel";
import { Choice } from "../Model/ChoiceModel";
import { getTopicDetailsByTIDService } from "./TopicService";

interface StatusItem {
  AID: number;
  UID: number;
  Status: string;
  attempt: number;
}

const CourseModuleTopicServices = async (
  map: CourseModuleTopicCreationAttributes
) => {
  try {
    const GetModule = await CourseModuleTopic.findAll({
      where: { CID: map.CID },
    });
    // console.log(
    //   "GetModule",
    //   GetModule.map((i) => ({
    //     MapID: i.MapID,
    //     CID: i.CID,
    //     MID: i.MID,
    //     ModuleOrder: i.ModuleOrder,
    //     TID: i.TID,
    //     TopicOrder: i.TopicOrder,
    //     IdType: i.IdType,
    //   }))
    // );

    const newGetModule = GetModule.filter(
      (i) => i.IdType !== "Final Assessment"
    );
    const Filtered_Module = newGetModule.filter((i) => i.MID === map.MID);

    const ModuleOrder =
      newGetModule.length === 0
        ? 1
        : map.MID === Filtered_Module[0]?.MID
        ? Number(Filtered_Module[0]?.ModuleOrder)
        : Number(newGetModule[newGetModule.length - 1]?.ModuleOrder) + 1;

    // const moduleOrder = !newGetModule
    // ? 1
    // : MID === Filtered_Module[0]?.MID
    // ? Number(Filtered_Module[0]?.ModuleOrder)
    // : Number(newGetModule[newGetModule.length - 1]?.ModuleOrder) + 1;

    const TopicOrder =
      map.MID === Filtered_Module[0]?.MID
        ? Number(Filtered_Module[Filtered_Module.length - 1]?.TopicOrder) + 1
        : 1;

    const newMap = await CourseModuleTopic.create({
      ...map,
      ModuleOrder: ModuleOrder.toString(),
      TopicOrder: TopicOrder.toString(),
    });

    // const newMap = await CourseModuleTopic.create({ ...map });
    if (newMap) {
      return { success: true, message: "Module Created successfully" };
    } else {
      return { success: false, message: "Failed to Create Module" };
    }
  } catch (error) {
    console.error("Error to Create Module:", error);
    return {
      success: false,
      message: "An error occurred while Creating Module",
    };
  }
};

//  NEW GetCourseModuleByCIDService FETCHING COURSE AND MODULE DETAILS ONLY RESULT TIME DELAY REDUCED
const GetCourseModuleByCIDService = async (
  courseId: number,
  userId: number
): Promise<{
  success: boolean;
  data?: any[];
  message?: string;
}> => {
  try {
    const courseModuleTopics = await CourseModuleTopic.findAll({
      where: { CID: courseId },
    });

    const Filtered_FA = courseModuleTopics
      .filter((module) => module.IdType === "Final Assessment")
      .map((i) => ({
        AID: i.MID,
        UID: userId,
        STATUS: "Not Started",
        PROGRESS: "0",
      }));
    // console.log("Filtered_FA", Filtered_FA);

    const existing_FA = await UserAssessment.findAll({
      where: {
        UID: Filtered_FA.map((module) => module.UID),
        AID: Filtered_FA.map((module) => module.AID),
        CID: courseId,
      },
    });
    // console.log(
    //   "existing_FA",
    //   existing_FA.map((i) => ({
    //     UM_ID: i.UA_ID,
    //     CID: i.CID,
    //     MID: i.AID,
    //     UID: i.UID,
    //     STATUS: i.Status,
    //     PROGRESS: i.Attempt,
    //   }))
    // );
    const newFA = Filtered_FA.filter(
      (filteredModule) =>
        !existing_FA.some(
          (existingModule) => existingModule.AID === filteredModule.AID
        )
    );
    // console.log("newFA", newFA);
    const uniqueFA = Array.from(new Set(newFA.map((item) => item.AID))).map(
      (AID) => {
        const foundItem = newFA.find((item) => item.AID === AID);
        return {
          ...foundItem,
          CID: courseId,
          TimeTakenMins: "0",
          Status: "Not yet started",
        };
      }
    );
    // console.log("uniqueFA", uniqueFA);

    if (uniqueFA.length > 0) {
      await UserAssessment.bulkCreate(
        uniqueFA as UserAssessmentCreationAttributes[]
      );
    }
    interface Module {
      MID: number;
      UID: number;
      STATUS: string | undefined;
      PROGRESS: string | undefined;
    }

    const Filtered_Modules: Module[] = courseModuleTopics
      .filter(
        (module) =>
          !(
            (module.TID === null && module.IdType === "Assessment") ||
            module.IdType === "Final Assessment"
          )
      )
      .map((i) => ({
        MID: i.MID,
        UID: userId,
        STATUS: "Not Started",
        PROGRESS: "0",
        CID: courseId,
      }));
    // console.log("Filtered_Modules", Filtered_Modules);

    const existingModules = await UserModule.findAll({
      where: {
        UID: Filtered_Modules.map((module) => module.UID),
        MID: Filtered_Modules.map((module) => module.MID),
        CID: courseId,
      },
    });

    const newModules = Filtered_Modules.filter(
      (filteredModule) =>
        !existingModules.some(
          (existingModule) => existingModule.MID === filteredModule.MID
        )
    );

    // console.log("newModules", newModules);

    const uniqueArray = Array.from(
      new Set(newModules.map((item) => item.MID))
    ).map((MID) => newModules.find((item) => item.MID === MID));

    if (newModules.length > 0) {
      await UserModule.bulkCreate(
        uniqueArray as UserModuleCreationAttributes[]
      );
    }

    const tasks = courseModuleTopics
      .filter((i) => i.IdType !== "Assessment" || "Final Assessment")
      .map((i) => ({ CID: i.CID, MID: i.MID, TID: i.TID, IdType: i.IdType }));

    const userTopics = await UserTopic.findAll({
      where: { TID: tasks.map((task) => task.TID), UID: userId, CID: courseId },
    });

    const userTopicMap = new Map(
      userTopics.map((userTopic) => [userTopic.TID, userTopic.toJSON()])
    );

    const tasksWithUserTopics = tasks.map((task) => {
      const userTopic = userTopicMap.get(task.TID);
      return {
        ...task,
        status: userTopic?.STATUS,
      };
    });

    const uniqueTopicResult = Object.values(
      tasksWithUserTopics.reduce((acc, task) => {
        const { MID, status } = task;

        if (!acc[MID]) {
          acc[MID] = { MID, noOfTasks: 0, taskCompleted: 0 };
        }

        acc[MID].noOfTasks += 1;
        if (status === "COMPLETED") {
          acc[MID].taskCompleted += 1;
        }

        return acc;
      }, {} as { [key: number]: { MID: number; noOfTasks: number; taskCompleted: number } })
    );

    //-----------------------------------------------------------

    const Assesments = courseModuleTopics
      .filter((i) => i.IdType === "Assessment" && i.TID !== null)
      .map((i) => ({ CID: i.CID, MID: i.MID, TID: i.TID }));

    const userAssesments = await UserAssessment.findAll({
      where: {
        AID: Assesments.map((task) => task.TID),
        UID: userId,
        CID: courseId,
      },
    });
    // console.log("Assesments", Assesments);

    // console.log(
    //   "userAssesments",
    //   userAssesments.map((i) => ({
    //     UA_ID: i.UA_ID,
    //     AID: i.AID,
    //     UID: i.UID,
    //     Status: i.Status,
    //     TimeTakenMins: i.TimeTakenMins,
    //     Attempt: i.Attempt,
    //   }))
    // );
    const userAssesmentMap = new Map(
      userAssesments.map((userAsses) => [userAsses.AID, userAsses.toJSON()])
    );

    // console.log("userAssesmentMap", userAssesmentMap);

    const tasksWithUseruseAssesment = Assesments.map((task) => {
      const userTopic = userAssesmentMap.get(task.TID);
      return {
        ...task,
        status: userTopic?.Status,
      };
    });
    // console.log("tasksWithUseruseAssesment", tasksWithUseruseAssesment);

    const uniqueAssesementResult = Object.values(
      tasksWithUseruseAssesment.reduce((acc, task) => {
        const { MID, status } = task;

        if (!acc[MID]) {
          acc[MID] = { MID, noOfTasks: 0, taskCompleted: 0 };
        }

        acc[MID].noOfTasks += 1;
        if (status === "COMPLETED") {
          acc[MID].taskCompleted += 1;
        }

        return acc;
      }, {} as { [key: number]: { MID: number; noOfTasks: number; taskCompleted: number } })
    );

    // console.log("uniqueTopicResult", uniqueTopicResult);
    // console.log("uniqueAssesementResult", uniqueAssesementResult);
    interface Result {
      MID: number;
      noOfTasks: number;
      taskCompleted: number;
    }
    const mergedResults: Record<number, Result> = {};

    uniqueTopicResult.forEach((item) => {
      mergedResults[item.MID] = {
        MID: item.MID,
        noOfTasks: item.noOfTasks,
        taskCompleted: item.taskCompleted,
      };
    });

    uniqueAssesementResult.forEach((item) => {
      if (mergedResults[item.MID]) {
        mergedResults[item.MID].noOfTasks += item.noOfTasks;
        mergedResults[item.MID].taskCompleted += item.taskCompleted;
      } else {
        mergedResults[item.MID] = {
          MID: item.MID,
          noOfTasks: item.noOfTasks,
          taskCompleted: item.taskCompleted,
        };
      }
    });

    const resultArray: Result[] = Object.values(mergedResults);

    const courseMap: { [key: number]: any } = {};

    const [userModules, userCourses] = await Promise.all([
      UserModule.findAll({ where: { UID: userId, CID: courseId } }),
      UserCourse.findAll({ where: { UID: userId, CID: courseId } }),
    ]);

    await Promise.all(
      courseModuleTopics
        .filter((i) => i.IdType !== "Final Assessment")
        .map(async (topic) => {
          const { CID, MID, IdType, TopicOrder, ModuleOrder } =
            topic.dataValues;

          const [course, module] = await Promise.all([
            Course.findOne({ where: { CID } }),
            Module.findOne({ where: { MID } }),
          ]);
          if (!course || !module) return;

          const courseData = course.toJSON();
          const moduleData = module.toJSON();

          if (!courseMap[CID]) {
            courseMap[CID] = {
              ...courseData,
              Module: [],
            };
          }

          // if (IdType === "Assessment") {
          let moduleEntry = courseMap[CID].Module.find(
            (m: any) => m.MID === MID
          );

          if (!moduleEntry) {
            moduleEntry = {
              ...moduleData,
              ModuleOrder,
            };
            courseMap[CID].Module.push(moduleEntry);
          }
          // }

          const userModuleData = userModules.find((um) => um.MID === MID);
          if (userModuleData) {
            const moduleEntry = courseMap[CID].Module.find(
              (m: any) => m.MID === MID
            );
            if (moduleEntry) {
              moduleEntry.UM_ID = userModuleData.UM_ID;
              moduleEntry.STATUS = userModuleData.STATUS;
              moduleEntry.PROGRESS = userModuleData.PROGRESS;
            }
          }

          const userCourseData = userCourses.find((uc) => uc.CID === CID);
          if (userCourseData) {
            courseMap[CID].UC_ID = userCourseData.UC_ID;
            courseMap[CID].STATUS = userCourseData.STATUS;
            courseMap[CID].PROGRESS = userCourseData.PROGRESS;
          }
        })
    );

    // const Modules = () => {
    //   const taskMIDs = resultArray.map((task: any) => task.MID);

    //   result.forEach((course: any) => {
    //     course.Module = course.Module.map((module: any) => {
    //       if (taskMIDs.includes(module.MID)) {
    //         const matchingTask = resultArray.find(
    //           (task: any) => task.MID === module.MID
    //         );

    //         if (matchingTask) {
    //           module.noOfTasks = matchingTask.noOfTasks;
    //           module.taskCompleted = matchingTask.taskCompleted;
    //         }
    //       }

    //       return module;
    //     });
    //   });

    //   return result[0]?.Module;
    // };

    const FinalAssessments = courseModuleTopics
      .filter((j) => j.IdType === "Final Assessment")
      .map((i) => ({
        MapID: i.MapID,
        CID: i.CID,
        MID: i.MID,
        TID: i.TID,
        IdType: i.IdType,
      }));

    const getStatus = await UserAssessment.findAll({
      where: {
        AID: FinalAssessments.map((i) => i.MID),
        UID: userId,
        CID: courseId,
      },
    });
    let neWFinalAssessment: any = [];

    if (FinalAssessments[0]?.MID) {
      const NewFinalAssesment = await Assessment.findAll({
        where: { AID: FinalAssessments && FinalAssessments[0]?.MID },
      });
      const {
        AID,
        NAME,
        cut_off_score,
        assessment_instructions,
        attempt_instructions,
        ...others
      } = NewFinalAssesment[0];
      const attemptLength = courseModuleTopics.filter(
        (i) => i.IdType === "Final Assessment"
      ).length;

      const { UA_ID, CID, UID, Status, Attempt, user_final_score } =
        getStatus[0];
      neWFinalAssessment = [
        {
          AID: AID,
          NAME: NAME,
          cut_off_score: cut_off_score,
          assessment_instructions: assessment_instructions,
          attempt_instructions: attempt_instructions,
          UA_ID: UA_ID,
          CID: CID,
          UID: UID,
          Status: Status,
          Attempt: Attempt,
          user_final_score: user_final_score,
          attemptLength: attemptLength,
        },
      ];
    }

    //------------------------------------
    //------------------------------------
    //------------------------------------

    const Filtered_courseModuleTopics = courseModuleTopics.filter(
      (i) => i.IdType !== "Final Assessment"
    );

    // console.log(
    //   "Filtered_courseModuleTopics",
    //   Filtered_courseModuleTopics.map((i) => ({
    //     CID: i.CID,
    //     MID: i.MID,
    //     TID: i.TID,
    //     IdType: i.IdType,
    //   }))
    // );

    const countMIDTasks = () => {
      const result: any = {};

      Filtered_courseModuleTopics.forEach((item: any) => {
        if (result[item.MID]) {
          result[item.MID]++;
        } else {
          result[item.MID] = 1;
        }
      });

      return Object.entries(result).map(([mid, noOfTasks]) => ({
        mid: Number(mid),
        noOfTasks,
      }));
    };

    const newTaskCount = countMIDTasks();
    // console.log("newTaskCount", newTaskCount);

    const getAsses = await UserAssessment.findAll({
      where: {
        UID: userId,
        CID: courseId,
        AID: Filtered_courseModuleTopics.map(
          (i) => i.IdType === "Assessment" && i.TID
        ),
      },
    });
    // console.log(
    //   "getAsses",
    //   getAsses.map((i) => ({
    //     UA_ID: i.UA_ID,
    //     CID: i.CID,
    //     AID: i.AID,
    //     UID: i.UID,
    //     Status: i.Status,
    //     Attempt: i.Attempt,
    //     user_final_score: i.user_final_score,
    //   }))
    // );
    const getTopic = await UserTopic.findAll({
      where: {
        UID: userId,
        CID: courseId,
        TID: Filtered_courseModuleTopics.map((i) => i.IdType === null && i.TID),
      },
    });
    // console.log(
    //   "getTopic",
    //   getTopic.map((i) => ({
    //     UT_ID: i.UT_ID,
    //     CID: i.CID,
    //     TID: i.TID,
    //     UID: i.UID,
    //     PROGRESS: i.PROGRESS,
    //     STATUS: i.STATUS,
    //   }))
    // );

    const calculateCompletedTasks = () => {
      // Initialize noOfCompletedTasks in newTaskCount
      const taskCountMap = newTaskCount.reduce((map: any, task) => {
        map[task.mid] = { ...task, noOfCompletedTasks: 0 };
        return map;
      }, {});

      // Process getTopic for completed tasks with IdType as null
      getTopic.forEach((topic: any) => {
        if (topic.STATUS === "COMPLETED") {
          const mid = Filtered_courseModuleTopics.find(
            (item: any) => item.TID === topic.TID && item.IdType === null
          )?.MID;
          if (mid && taskCountMap[mid]) {
            taskCountMap[mid].noOfCompletedTasks += 1;
          }
        }
      });

      // Process getAsses for completed tasks with IdType as Assessment
      getAsses.forEach((assessment: any) => {
        if (assessment.Status === "COMPLETED") {
          const mid = Filtered_courseModuleTopics.find(
            (item: any) =>
              item.TID === assessment.AID && item.IdType === "Assessment"
          )?.MID;
          if (mid && taskCountMap[mid]) {
            taskCountMap[mid].noOfCompletedTasks += 1;
          }
        }
      });

      // Convert back to an array
      return Object.values(taskCountMap);
    };

    // console.log("calculateCompletedTasks", calculateCompletedTasks());

    //------------------------------------
    //------------------------------------
    //------------------------------------

    const result = Object.values(courseMap);
    const Topics = courseModuleTopics.filter(
      (i) => i.IdType === null && i.TID !== null
    );
    console.log(
      "Topics--------------------------------------------------------",
      Topics.map((i) => ({
        MapID: i.MapID,
        CID: i.CID,
        MID: i.MID,
        ModuleOrder: i.ModuleOrder,
        TID: i.TID,
        TopicOrder: i.TopicOrder,
        IdType: i.IdType,
      }))
    );
    const NewTopic = await Topic.findAll({
      where: { TID: Topics.map((i) => i.TID) },
    });

    console.log(
      "NewTopic------------------------------------------------------------------------------------------------------"
    );
    NewTopic.forEach((i) => {
      console.log(i.dataValues);
    });

    const TopicsWithDuration = Topics.map((i) => {
      const TID = NewTopic.find((j) => j.TID === i.TID);
      return {
        TOPIC_DURATION: TID?.DURATION,
        ...i?.dataValues,
      };
    });
    console.log(
      "TopicsWithDuration------------------------------------------------------------------------------------------",
      TopicsWithDuration
    );

    const Durations: any[] = Object.values(
      TopicsWithDuration.reduce((acc: any, topic: any) => {
        const mid = topic.MID;
        const duration: any = Number(topic.TOPIC_DURATION);

        if (!acc[mid]) {
          acc[mid] = { MID: mid, DURATION: 0 };
        }

        acc[mid].DURATION += duration;
        return acc;
      }, {})
    );

    Durations.forEach(
      (item: any) => (item.DURATION = item.DURATION.toString())
    );

    const formatTime = (TimeSpent: any) => {
      const hours = Math.floor(TimeSpent / 60);
      const mins = Math.round(TimeSpent % 60);
      return `${hours} hrs ${mins} min`;
    };
    const NewModule = result[0].Module.map((i: any) => {
      const duration = Durations.find((j: any) => j.MID === i.MID);
      return {
        ...i,
        DURATION: formatTime(Number(duration?.DURATION)),
      };
    }).sort(
      (a: any, b: any) => parseInt(a.ModuleOrder) - parseInt(b.ModuleOrder)
    );
    const newResult = [
      {
        ...result[0],
        Module: NewModule,
        FinalAssessment: neWFinalAssessment || [],
        TaskDetails: calculateCompletedTasks(),
      },
    ];

    return { success: true, data: newResult };
  } catch (error) {
    console.error("Error fetching Course Module details:", error);
    return {
      success: false,
      message: "Failed to fetch Course Module details",
    };
  }
};

const GetModuleTopicByMIDService = async (
  userId: number,
  courseId: number,
  moduleId: number
): Promise<{
  success: boolean;
  data?: any[];
  message?: string;
}> => {
  try {
    const courseModuleTopics = await CourseModuleTopic.findAll({
      where: { MID: moduleId, CID: courseId },
      order: [["MapID", "ASC"]],
    });

    //------------------------------------------------
    interface Topic {
      UT_ID?: number;
      MID: number;
      UID: number;
      TID: number;
      STATUS: string | undefined;
      PROGRESS: string | undefined;
    }

    const Filtered_Topics: Topic[] = courseModuleTopics
      .filter((module) => module.IdType !== "Assessment")
      .map((i) => ({
        MID: i.MID,
        TID: i.TID,
        UID: userId,
        STATUS: "Not Started",
        PROGRESS: "0",
        TopicOrder: i.TopicOrder,
        ModuleOrder: i.ModuleOrder,
      }));

    const existingTopics = await UserTopic.findAll({
      where: {
        UID: Filtered_Topics.map((module) => module.UID),
        TID: Filtered_Topics.map((module) => module.TID),
      },
    });
    const existingTIDs = existingTopics.map((topic) => topic.TID);
    const newTopics = Filtered_Topics.filter(
      (filteredTopic) =>
        !existingTopics.some(
          (existingTopic) => existingTopic.TID === filteredTopic.TID
        )
    );

    const uniqueArray = Array.from(new Set(newTopics.map((item) => item.TID)))
      .map((TID) => {
        const foundItem = newTopics.find((item) => item.TID === TID);
        if (foundItem) {
          return {
            ...foundItem,
            CID: courseId,
          };
        }
        return null;
      })
      .filter((item) => item !== null);

    // const uniqueArray = Array.from(
    //   new Set(newAsses.map((item) => item.AID)) // Get unique AIDs
    // )
    //   .map((AID) => {
    //     const foundItem = newAsses.find((item) => item.AID === AID);
    //     if (foundItem) {
    //       return {
    //         ...foundItem,
    //         CID: courseId,
    //       };
    //     }
    //     return null;
    //   })
    //   .filter((item) => item !== null);

    if (newTopics.length > 0) {
      await UserTopic.bulkCreate(uniqueArray as UserTopicCreationAttributes[]);
    }
    //------------------------------------------------

    const userTopics = await UserTopic.findAll({
      where: { UID: userId },
    });

    const topicsData = <any>[];

    await Promise.all(
      courseModuleTopics.map(async (topic) => {
        const { TID, IdType, TopicOrder, ModuleOrder } = topic.dataValues;

        if (IdType !== "Assessment") {
          const fetchedTopic = await Topic.findOne({
            where: { TID },
          });

          const userTopicData = userTopics.find((ut) => ut.TID === TID);

          if (fetchedTopic && userTopicData) {
            topicsData.push({
              TID: fetchedTopic.TID,
              NAME: fetchedTopic.NAME,
              DURATION: fetchedTopic.DURATION,
              // CONTENT: fetchedTopic.CONTENT,
              // CONTENT_TYPE: fetchedTopic.CONTENT_TYPE,
              // METADATA: fetchedTopic.METADATA,
              UT_ID: userTopicData.UT_ID,
              STATUS: userTopicData.STATUS,
              PROGRESS: userTopicData.PROGRESS,
              TopicOrder: TopicOrder,
              ModuleOrder: ModuleOrder,
            });
          }
        }
      })
    );

    return {
      success: true,
      data: topicsData.sort((a: any, b: any) => a.TID - b.TID),
    };
  } catch (error) {
    console.error("Error fetching Module Topic details:", error);
    return {
      success: false,
      message: "Failed to fetch Module Topic details",
    };
  }
};

// ASSESSMENT
const GetModuleAssessmentByMIDService = async (
  userId: number,
  courseId: number,
  moduleId: number
): Promise<{
  success: boolean;
  data?: any[];
  message?: string;
}> => {
  try {
    const courseModuleTopics = await CourseModuleTopic.findAll({
      where: { MID: moduleId, CID: courseId },
    });

    interface Assessment {
      UID: number;
      TID: number;
      AID?: number;
      Status: string;
      PROGRESS: number;
    }
    const Filtered_Assesement: Assessment[] = courseModuleTopics
      .filter((module) => module.IdType === "Assessment" && module.TID !== null)
      .map((i) => ({
        TID: i.TID,
        AID: i.TID,
        CID: i.CID,
        UID: userId,
        Status: "Not Started",
        PROGRESS: 0,
      }));

    const validAIDs = Filtered_Assesement.map((module) => module.AID).filter(
      (aid): aid is number => aid !== undefined
    );

    const existingAssesement = await UserAssessment.findAll({
      where: {
        UID: userId,
        AID: validAIDs,
        CID: courseId,
      },
    });

    const newAsses = Filtered_Assesement.filter(
      (filteredTopic) =>
        !existingAssesement.some(
          (existingassesement) => existingassesement.AID === filteredTopic.AID
        )
    );
    // const uniqueArray = Array.from(
    //   new Set(newAsses.map((item) => item.AID))
    // ).map((AID) => newAsses.find((item) => item.AID === AID));
    const uniqueArray = Array.from(
      new Set(newAsses.map((item) => item.AID)) // Get unique AIDs
    )
      .map((AID) => {
        const foundItem = newAsses.find((item) => item.AID === AID);
        if (foundItem) {
          return {
            ...foundItem,
            CID: courseId,
          };
        }
        return null;
      })
      .filter((item) => item !== null);

    // console.log("uniqueArray", uniqueArray);

    if (uniqueArray.length > 0) {
      await UserAssessment.bulkCreate(
        uniqueArray as UserAssessmentCreationAttributes[]
      );
    }

    const assessmentQuestionAnswers = await AssessmentQuestionAnswer.findAll({
      where: {
        AID: validAIDs,
      },
    });

    for (const answer of assessmentQuestionAnswers) {
      const { QID, AID } = answer;

      const existingUserQuestion = await UserQuestion.findOne({
        where: { QID, UID: userId, CID: courseId },
      });

      if (!existingUserQuestion) {
        await UserQuestion.create({
          QID,
          AID,
          CID: courseId,
          UID: userId,
          Status: "Not Started",
        });
      }
    }

    //----------------------------------------

    const userAssessmentDetails = await UserAssessment.findAll({
      where: { UID: userId, CID: courseId },
    });

    const assessmentDetailsArray: any[] = [];

    await Promise.all(
      courseModuleTopics.map(async (topic) => {
        const { TID, IdType, TopicOrder, ModuleOrder } = topic.dataValues;

        if (IdType === "Assessment" && TID !== null) {
          const assessmentDetails = await Assessment.findOne({
            where: { AID: TID },
          });

          const userAssessmentData = userAssessmentDetails.find(
            (ut) => ut.AID === TID
          );

          if (assessmentDetails && userAssessmentData) {
            assessmentDetailsArray.push({
              AID: assessmentDetails.AID,
              NAME: assessmentDetails.NAME,
              duration: assessmentDetails.DURATION,
              author: assessmentDetails.AUTHOR,
              UA_ID: userAssessmentData.UA_ID,
              Status: userAssessmentData.Status,
              TimeTakenMins: userAssessmentData.TimeTakenMins,
              Attempt: userAssessmentData.Attempt,
              TopicOrder: TopicOrder,
              ModuleOrder: ModuleOrder,
            });
          }
        }
      })
    );

    return {
      success: true,
      data: assessmentDetailsArray.sort((a: any, b: any) => a.AID - b.AID),
    };
  } catch (error) {
    console.error("Error fetching Module Assessment details:", error);
    return {
      success: false,
      message: "Failed to fetch Module Assessment details",
    };
  }
};

const GetAssessmentQuestionByAIDService = async (
  userId: number,
  AID: number,
  CID?: number | null
): Promise<{
  success: boolean;
  data?: any[];
  message?: string;
}> => {
  try {
    const assessmentQuestionDetails = await AssessmentQuestionAnswer.findAll({
      where: { AID: AID },
      order: [["QuestionOrder", "ASC"]],
    });

    const userQuestionDetails = await UserQuestion.findAll({
      where: { UID: userId, AID: AID },
    });

    const userAnswerDetails = await UserAnswer.findAll({
      where: { UID: userId },
    });

    const assessmentDetailsArray: any[] = [];

    await Promise.all(
      assessmentQuestionDetails.map(async (item) => {
        const { QID, AnsID } = item.dataValues;

        const questionDetails = await Question.findOne({
          where: { QID: QID },
        });

        const answerDetails = await Answer.findOne({
          where: { AnsID: AnsID },
        });

        const userQuestionData = userQuestionDetails.find(
          (userQuestion) => userQuestion.QID === QID
        );
        // console.log("userQuestionData", userQuestionData);

        const userAnswerData = userAnswerDetails.find(
          (userAnswer) => userAnswer.QID === QID && userAnswer.AID === AID
        );

        const choiceDetails = await Choice.findAll({
          where: { QID: QID },
        });

        const userAssessment = await UserAssessment.findOne({
          where: {
            AID: AID,
            UID: userId,
          },
        });
        let Mid: number | string = "";
        let modulename = "";
        let ModuleOrder: string = "";
        let TopicOrder: string = "";
        if (CID !== null) {
          const ModuleDetails = await CourseModuleTopic.findAll({
            where: {
              TID: AID,
              CID: CID,
            },
          });
          // console.log(
          //   "ModuleDetails",
          //   ModuleDetails.map((i) => ({
          //     MapID: i.MapID,
          //     CID: i.CID,
          //     MID: i.MID,
          //     ModuleOrder: i.ModuleOrder,
          //     TID: i.TID,
          //     TopicOrder: i.TopicOrder,
          //     IdType: i.IdType,
          //   }))
          // );

          const OrderDetails = ModuleDetails.filter(
            (i) => i.CID === CID && i.TID === AID && i.IdType === "Assessment"
          );
          // console.log(
          //   "OrderDetails",
          //   OrderDetails.map((i) => ({
          //     MapID: i.MapID,
          //     CID: i.CID,
          //     MID: i.MID,
          //     ModuleOrder: i.ModuleOrder,
          //     TID: i.TID,
          //     TopicOrder: i.TopicOrder,
          //     IdType: i.IdType,
          //   }))
          // );

          let module: any;
          if (ModuleDetails[0]?.MID) {
            module = await Module.findAll({
              where: {
                MID: OrderDetails[0]?.MID,
              },
            });
          }

          modulename = module[0]?.NAME ?? "";
          Mid = module[0]?.MID ?? "";
          ModuleOrder = OrderDetails[0]?.ModuleOrder ?? "";
          TopicOrder = OrderDetails[0]?.TopicOrder ?? "";
        }

        // console.log("ModuleOrder", ModuleOrder);
        // console.log("TopicOrder", TopicOrder);

        // if (CID) {
        //   const get = await UserModule.findOne({
        //     where: { STATUS: "Not Started", UID: userId, MID: Mid, CID: CID },
        //   });
        //   await UserModule.update(
        //     { STATUS: "InProgress" },
        //     { where: { UID: userId, MID: Mid, CID: CID } }
        //   );
        // }

        if (questionDetails && answerDetails) {
          assessmentDetailsArray.push({
            MID: Mid ?? Mid,
            moduleName: modulename,
            ModuleOrder: ModuleOrder,
            TopicOrder: TopicOrder,
            AID: AID,
            QID: questionDetails.QID,
            userQId: userQuestionData?.UQ_ID,
            questionStatus: userQuestionData?.Status,
            timeTaken: userQuestionData?.TimeTakenMins,
            QUESTION: questionDetails.Question,
            TYPE: questionDetails.Type,
            QUESTION_TYPE: questionDetails.QuestionType,
            CHOICE: choiceDetails,
            CORRECT_ANS_ID: questionDetails.CorrectAnswer,
            HINT: questionDetails.Hint,
            ANSWER_ID: answerDetails.AnsID,
            ANSWER: answerDetails.Answer,
            USER_ANSWER: userAnswerData ? userAnswerData : null,
          });
        }
      })
    );
    const sortedAssessmentDetails = assessmentDetailsArray.sort(
      (a, b) => a.QID - b.QID
    );

    return {
      success: true,
      data: sortedAssessmentDetails,
      // data: assessmentDetailsArray.sort((a: any, b: any) => a.QID - b.QID),
    };
  } catch (error) {
    console.error("Error fetching Assessment Question details:", error);
    return {
      success: false,
      message: "Failed to fetch Assessment Question details",
    };
  }
};

const MapAssessmentCourseServices = async (
  map: CourseModuleTopicCreationAttributes
) => {
  try {
    const newMap = await CourseModuleTopic.create(map);
    if (newMap) {
      return {
        success: true,
        message: "Assessment Mapp Created successfully",
      };
    } else {
      return { success: false, message: "Failed to Map Assessment" };
    }
  } catch (error) {
    console.error("Error to Map Assessment:", error);
    return {
      success: false,
      message: "An error occurred while Map Assessment",
    };
  }
};

const ExpandAllService = async (userId: number, courseId: number) => {
  try {
    const getAll = await CourseModuleTopic.findAll({
      where: { CID: courseId },
    });
    // console.log(
    //   "getAll",
    //   getAll.map((i) => ({
    //     MapID: i.MapID,
    //     CID: i.CID,
    //     MID: i.MID,
    //     TID: i.TID,
    //     IdType: i.IdType,
    //   }))
    // );
    const newModulesforTopics = getAll
      .filter((i) => i.IdType !== "Assessment")
      .map((i) => ({
        MapID: i.MapID,
        CID: i.CID,
        MID: i.MID,
        TID: i.TID,
        IdType: i.IdType,
        ModuleOrder: i.ModuleOrder,
        TopicOrder: i.TopicOrder,
      }));
    // console.log("newModulesforTopics", newModulesforTopics);

    const topicStatus = await UserTopic.findAll({
      where: {
        TID: newModulesforTopics.map((i) => i.IdType !== "Assessment" && i.TID),
        UID: userId,
      },
    });
    const topicDetails = await Topic.findAll({
      where: {
        TID: topicStatus.map((i) => i.TID),
      },
    });
    const results = topicStatus.map((statusItem) => {
      const topicDetail = topicDetails.find(
        (detail) => detail.TID === statusItem.TID
      );

      if (topicDetail) {
        return {
          ...statusItem.dataValues,
          NAME: topicDetail.dataValues.NAME,
          TID: topicDetail.dataValues.TID,
          DURATION: topicDetail.DURATION,
        };
      }
      return statusItem;
    });
    // console.log("results", results);

    const newTopics = results.map((i) => {
      const m = newModulesforTopics.find((j) => j.TID === i.TID);
      if (m) {
        return {
          ...i,
          MID: m.MID,
          CID: m.CID,
          IdType: m.IdType,
          TopicOrder: m.TopicOrder,
          ModuleOrder: m.ModuleOrder,
        };
      }
      return i;
    });
    const newModulesforAsses = getAll
      .filter((i) => i.IdType === "Assessment")
      .map((i) => ({
        MapID: i.MapID,
        CID: i.CID,
        MID: i.MID,
        TID: i.TID,
        IdType: i.IdType,
        ModuleOrder: i.ModuleOrder,
        TopicOrder: i.TopicOrder,
      }));
    // console.log("newModulesforAsses", newModulesforAsses);
    const AssesStatus = await UserAssessment.findAll({
      where: {
        AID: newModulesforAsses.map((i) => i.IdType === "Assessment" && i.TID),
        UID: userId,
      },
    });
    // console.log(
    //   "AssesStatus",
    //   Array.from(
    //     new Map(
    //       AssesStatus.map((i) => ({
    //         UA_ID: i.UA_ID,
    //         AID: i.AID,
    //         UID: i.UID,
    //         Status: i.Status,
    //         TimeTakenMins: i.TimeTakenMins,
    //         Attempt: i.Attempt,
    //       })).map((item) => [item.AID, item])
    //     ).values()
    //   )
    // );
    const uniqueAssessStatus = Array.from(
      new Map(
        AssesStatus.map((i) => ({
          UA_ID: i.UA_ID,
          AID: i.AID,
          UID: i.UID,
          Status: i.Status,
          TimeTakenMins: i.TimeTakenMins,
          Attempt: i.Attempt,
        })).map((item) => [item.AID, item])
      ).values()
    );

    // console.log("uniqueAssessStatus", uniqueAssessStatus);

    const AssesDetails = await Assessment.findAll({
      where: {
        AID: uniqueAssessStatus.map((i) => i.AID),
      },
    });
    // console.log(
    //   "AssesDetails",
    //   AssesDetails.map((i) => ({
    //     AID: i.AID,
    //     NAME: i.NAME,
    //     DURATION: i.DURATION,
    //     AUTHOR: i.AUTHOR,
    //     STATUS: i.STATUS,
    //   }))
    // );

    const Assesresults = uniqueAssessStatus.map((statusItem) => {
      const topicDetail = AssesDetails.find(
        (detail) => detail.AID === statusItem.AID
      );
      // console.log("topicDetail", topicDetail);

      if (topicDetail) {
        return {
          ...statusItem,
          NAME: topicDetail.NAME,
          AID: topicDetail.AID,
        };
      }
      return statusItem;
    });
    // console.log("Assesresults", Assesresults);

    const newAsses = Assesresults.map((i) => {
      const m = newModulesforAsses.find((j) => j.TID === i.AID);
      // console.log("4444444444444444444444444", m?.MapID, m?.CID);

      if (m) {
        return {
          ...i,
          MID: m.MID,
          CID: m.CID,
          IdType: m.IdType,
          ModuleOrder: m.ModuleOrder,
          TopicOrder: m.TopicOrder,
        };
      }
      return i;
    });
    let data: any[] = [
      {
        topics: newTopics,
        Assessment: newAsses,
      },
    ];

    // console.log("data", data);
    const Newresult = [
      ...newTopics.map((t: any) => ({
        ModuleOrder: parseInt(t.ModuleOrder),
        TopicOrder: parseInt(t.TopicOrder),
        Type: "Topic",
        TID: t.TID,
        NAME: t.NAME,
        DURATION: t.DURATION,
        Id: t.TID,
        STATUS: t.STATUS,
        MID: t.MID,
        CID: t.CID,
        IdType: t.IdType,
      })),
      ...newAsses.map((a: any) => ({
        ModuleOrder: parseInt(a.ModuleOrder),
        TopicOrder: parseInt(a.TopicOrder),
        Type: "Assessment",
        AID: a.AID,
        NAME: a.NAME,
        Id: a.AID,
        Status: a.Status,
        MID: a.MID,
        CID: a.CID,
        IdType: a.IdType,
      })),
    ].sort((a: any, b: any) =>
      a.ModuleOrder === b.ModuleOrder
        ? a.TopicOrder - b.TopicOrder
        : a.ModuleOrder - b.ModuleOrder
    );

    // console.log("Newresult", Newresult);

    let result = true;
    if (result) {
      return {
        success: true,
        message: "Success",
        data: Newresult,
      };
    } else {
      return { success: false, message: "Failed to Fetch" };
    }
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "An error occurred",
    };
  }
};

const NewContinueToLastService = async (userId: number, courseId: number) => {
  try {
    const CourseModules = await CourseModuleTopic.findAll({
      where: { CID: courseId },
    });
    // console.log("CourseModules", CourseModules);

    // const result: any = { Modules: [], FA_Assessment: [] };
    // CourseModules.forEach((item: any) => {
    //   if (item.IdType === "Final Assessment") {
    //     result.FA_Assessment.push(item);
    //   } else {
    //     let module = result.Modules.find((mod: any) => mod.MID === item.MID);
    //     if (!module) {
    //       module = { MID: item.MID, Topics: [], Assessment: [] };
    //       result.Modules.push(module);
    //     }
    //     if (item.IdType === "Assessment") {
    //       module.Assessment.push(item);
    //     } else if (item.IdType === null) {
    //       module.Topics.push(item);
    //     }
    //   }
    // });
    // console.log(result.Modules, "vghuiooiuhgbv");

    let lastTopic;

    //-------------------------------------------------------
    //-------------------------------------------------------
    //-------------------------------------------------------
    //-------------------------------------------------------

    const Modules: any = { Modules: [] };

    CourseModules.forEach((item: any) => {
      let module = Modules.Modules.find((mod: any) => mod.MID === item.MID);
      if (!module && item.IdType !== "Final Assessment") {
        module = { MID: item.MID, ModuleOrder: item.ModuleOrder };
        Modules.Modules.push(module);
      }
    });

    const getModuleStatus = await Promise.all(
      Modules.Modules.map(async (i: any) => {
        const status = await UserModule.findOne({
          where: {
            UID: userId,
            CID: courseId,
            MID: i.MID,
          },
        });

        return {
          ...i,
          status: status?.STATUS,
          UID: userId,
          CID: courseId,
        };
      })
    );

    const LastModule = getModuleStatus
      .filter((i) => i.status !== "COMPLETED")
      .sort((a, b) => parseInt(a.ModuleOrder) - parseInt(b.ModuleOrder));

    // console.log("LastModule", LastModule);
    if (LastModule.length === 0) {
      // console.log("FA_A");

      const FinalAssessments = CourseModules.filter(
        (j) => j.IdType === "Final Assessment"
      ).map((i) => ({
        MapID: i.MapID,
        CID: i.CID,
        MID: i.MID,
        TID: i.TID,
        IdType: i.IdType,
      }));

      const getStatus = await UserAssessment.findAll({
        where: {
          AID: FinalAssessments.map((i) => i.MID),
          UID: userId,
          CID: courseId,
        },
      });

      const NewFinalAssesment = await Assessment.findAll({
        where: { AID: FinalAssessments[0]?.MID },
      });
      let neWFinalAssessment = [];
      const {
        AID,
        NAME,
        cut_off_score,
        assessment_instructions,
        attempt_instructions,
        ...others
      } = NewFinalAssesment[0];

      const { UA_ID, CID, UID, Status, Attempt, user_final_score } =
        getStatus[0];
      // neWFinalAssessment = [
      //   {
      //     AID: AID,
      //     NAME: NAME,
      //     cut_off_score: cut_off_score,
      //     assessment_instructions: assessment_instructions,
      //     attempt_instructions: attempt_instructions,
      //     UA_ID: UA_ID,
      //     CID: CID,
      //     UID: UID,
      //     Status: Status,
      //     Attempt: Attempt,
      //     user_final_score: user_final_score,
      //     assessmentType: "Final Assessment",
      //   },
      // ];

      lastTopic = [
        {
          AID: AID,
          NAME: NAME,
          cut_off_score: cut_off_score,
          assessment_instructions: assessment_instructions,
          attempt_instructions: attempt_instructions,
          UA_ID: UA_ID,
          CID: CID,
          UID: UID,
          Status: Status,
          Attempt: Attempt,
          user_final_score: user_final_score,
          assessmentType: "Final Assessment",
        },
      ];
    } else if (LastModule) {
      // console.log("LastModule", LastModule);

      const newModule =
        CourseModules &&
        CourseModules.filter((i: any) => {
          const c = LastModule[0]?.MID === i.MID;

          return (
            c && {
              MapID: i.MapID,
              CID: i.CID,
              MID: i.MID,
              ModuleOrder: i.ModuleOrder,
              TID: i.TID,
              TopicOrder: i.TopicOrder,
              IdType: i.IdType,
            }
          );
        });

      // console.log("newModule");
      // newModule.forEach((i) => {
      //   console.log(i.dataValues);
      // });

      const getTopicStatus = await Promise.all(
        newModule.map(async (i: any) => {
          if (i.IdType === null) {
            const status = await UserTopic.findOne({
              where: {
                UID: userId,
                CID: courseId,
                TID: i.IdType === null && i.TID,
              },
            });

            return {
              ...i.dataValues,
              status: status?.STATUS,
              UID: userId,
              CID: courseId,
            };
          } else if (i.IdType === "Assessment") {
            const status = await UserAssessment.findOne({
              where: {
                UID: userId,
                CID: courseId,
                AID: i.IdType === "Assessment" && i.TID,
              },
            });

            return {
              ...i.dataValues,
              status: status?.Status,
              UID: userId,
              CID: courseId,
            };
          }
        })
      );
      console.log("getTopicStatus", getTopicStatus);

      // const newTopic = getTopicStatus.filter(
      //   (i) => i.IdType === null && i.status !== "COMPLETED"
      // );
      // const newAsses = getTopicStatus.filter(
      //   (i) => i.IdType === "Assessment" && i.status !== "COMPLETED"
      // );

      const newDetails = getTopicStatus
        .filter((i) => i?.status !== "COMPLETED")
        .sort((a, b) => parseInt(a.TopicOrder) - parseInt(b.TopicOrder));

      if (newDetails?.length > 0 && newDetails[0]?.IdType === null) {
        const topicResult = await getTopicDetailsByTIDService(
          courseId,
          newDetails[0].MID,
          newDetails[0].TID,
          userId
        );
        lastTopic = topicResult?.data;
      } else if (newDetails[0]?.IdType === "Assessment") {
        const assessmentResult = await GetAssessmentQuestionByAIDService(
          userId,
          newDetails[0].TID,
          courseId
        );
        lastTopic = assessmentResult?.data;
      }
      // if (newTopic?.length > 0 && newTopic[0]?.IdType === null) {
      //   const topicResult = await getTopicDetailsByTIDService(
      //     courseId,
      //     newTopic[0].MID,
      //     newTopic[0].TID,
      //     userId
      //   );
      //   lastTopic = topicResult?.data;
      // } else if (
      //   newTopic?.length === 0 &&
      //   newAsses[0]?.IdType === "Assessment"
      // ) {
      //   const assessmentResult = await GetAssessmentQuestionByAIDService(
      //     userId,
      //     newAsses[0].TID,
      //     courseId
      //   );
      //   lastTopic = assessmentResult?.data;
      // }
    }

    //-------------------------------------------------------
    //-------------------------------------------------------
    //-------------------------------------------------------
    //-------------------------------------------------------
    // else console.log("lastTopic", lastTopic);

    return {
      success: true,
      message: "Success",
      data: lastTopic,
    };
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "An error occurred",
    };
  }
};

const NewGetCourseDetailsService = async (userId: number, courseId: number) => {
  try {
    const CourseModules = await CourseModuleTopic.findAll({
      where: { CID: courseId },
    });
    // console.log("CourseModules", CourseModules);

    const result: any = { Modules: [], FA_Assessment: [] };
    CourseModules.forEach((item: any) => {
      if (item.IdType === "Final Assessment") {
        result.FA_Assessment.push(item);
      } else {
        let module = result.Modules.find((mod: any) => mod.MID === item.MID);
        if (!module) {
          module = { MID: item.MID, Topics: [], Assessment: [] };
          result.Modules.push(module);
        }
        if (item.IdType === "Assessment") {
          module.Assessment.push(item);
        } else if (item.IdType === null) {
          module.Topics.push(item);
        }
      }
    });
    // console.log(result.Modules, "vghuiooiuhgbv");
    const updateStatus = async () => {
      // Iterate over Modules
      const updatedModules = await Promise.all(
        result.Modules.map(async (module: any, index: number) => {
          // Update Topics with status
          const updatedTopics = await Promise.all(
            module.Topics.map(async (topic: any, index: number) => {
              const topicStatus = await UserTopic.findOne({
                where: { UID: userId, CID: courseId, TID: topic.TID },
              });
              const data = topic?.dataValues;
              return {
                // MapID: data?.MapID,
                // CID: data?.CID,
                // MID: data?.MID,
                // ModuleOrder: data?.ModuleOrder,

                // TopicOrder: data?.TopicOrder,
                // IdType: data?.IdType,
                topicNo: index + 1,
                TID: data?.TID,
                status: topicStatus?.STATUS,
              };
            })
          );

          // Update Assessments with status
          const updatedAssessments = await Promise.all(
            module.Assessment.map(async (assessment: any, index: number) => {
              const assessmentStatus = await UserAssessment.findOne({
                where: { UID: userId, CID: courseId, AID: assessment.TID },
              });
              const data = assessment?.dataValues;
              return {
                // MapID: data?.MapID,
                // CID: data?.CID,
                // MID: data?.MID,
                // ModuleOrder: data?.ModuleOrder,
                // TopicOrder: data?.TopicOrder,
                // IdType: data?.IdType,
                assessmentNo: index + 1,
                AID: assessmentStatus?.AID,
                status: assessmentStatus?.Status,
              };
            })
          );

          const ModuleStatus = await UserModule.findOne({
            where: { UID: userId, CID: courseId, MID: module.MID },
          });

          return {
            CID: courseId,
            moduleNo: index + 1,
            status: ModuleStatus?.STATUS,
            ...module,
            Topics: updatedTopics,
            Assessment: updatedAssessments,
          };
        })
      );

      // Update Final Assessments
      const updatedFA_Assessment = await Promise.all(
        result.FA_Assessment.map(async (fa: any, index: number) => {
          const faStatus = await UserAssessment.findOne({
            where: { UID: userId, CID: courseId, AID: fa.MID },
          });

          const AssessmentDetails = await Assessment.findOne({
            where: { AID: faStatus?.AID },
          });
          const data = fa?.dataValues;
          const assessmentData = AssessmentDetails?.dataValues;
          return {
            // MapID: data?.MapID,
            // CID: data?.CID,
            // MID: data?.MID,
            // ModuleOrder: data?.ModuleOrder,
            // TopicOrder: data?.TopicOrder,
            // IdType: data?.IdType,
            AID: faStatus?.AID,
            status: faStatus?.Status,
            NAME: assessmentData?.NAME,
            cut_off_score: assessmentData?.cut_off_score,
            assessment_instructions: assessmentData?.assessment_instructions,
            attempt_instructions: assessmentData?.attempt_instructions,
          };
        })
      );

      return {
        Modules: updatedModules,
        FA_Assessment: [updatedFA_Assessment[0]],
      };
    };
    const newResult = await updateStatus();

    return { success: true, message: "", data: [newResult] };

    // Usage
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "An error occurred",
    };
  }
};

const NextTaskService = async (
  courseId: number,
  moduleId: number,
  userId: number,
  ModuleOrder: number,
  TopicOrder: number
) => {
  try {
    const CourseModule = await CourseModuleTopic.findAll({
      where: { CID: courseId },
    });
    //================================================================UPDATING MODULE===============
    const FilteredTopicModules = CourseModule.filter(
      (i: any) =>
        i.MID === moduleId &&
        Number(i.ModuleOrder) === Number(ModuleOrder) &&
        i.IdType === null
    );
    const FilteredAssesModules = CourseModule.filter(
      (i: any) =>
        i.MID === moduleId &&
        Number(i.ModuleOrder) === Number(ModuleOrder) &&
        i.IdType === "Assessment"
    );

    const UserTopics = await UserTopic.findAll({
      where: {
        TID: FilteredTopicModules.map((i: any) => i.TID),
        UID: userId,
        CID: courseId,
      },
    });
    const Userassessment = await UserAssessment.findAll({
      where: {
        AID: FilteredAssesModules.map((i: any) => i.TID),
        UID: userId,
        CID: courseId,
      },
    });

    const IsAllTopicsCompleted =
      UserTopics.length &&
      UserTopics.every((i: any) => i.STATUS === "COMPLETED");
    const IsAllAssessCompleted =
      Userassessment.length &&
      Userassessment.every((i: any) => i.Status === "COMPLETED");

    // console.log(
    //   "CourseModule--------------------------------------------------",
    //   CourseModule.map((i: any) => ({
    //     MapID: i.MapID,
    //     CID: i.CID,
    //     MID: i.MID,
    //     ModuleOrder: i.ModuleOrder,
    //     TID: i.TID,
    //     TopicOrder: i.TopicOrder,
    //     IdType: i.IdType,
    //   }))
    // );

    // console.log(
    //   "FilteredTopicModules",
    //   FilteredTopicModules.map((i: any) => ({
    //     UT_ID: i.UT_ID,
    //     CID: i.CID,
    //     TID: i.TID,
    //     UID: i.UID,
    //     PROGRESS: i.PROGRESS,
    //     STATUS: i.STATUS,
    //   }))
    // );

    // console.log("moduleId", moduleId);
    // console.log("userId", userId);
    // console.log("userId", userId);
    // console.log("ModuleOrder", ModuleOrder);
    // console.log("TopicOrder", TopicOrder);

    // console.log(
    //   "FilteredTopicModules------------------------NEXT TOPIC---------------------------",
    //   FilteredTopicModules
    // );
    // console.log(
    //   "FilteredAssesModules------------------------NEXT TOPIC---------------------------",
    //   FilteredAssesModules
    // );
    // console.log(
    //   "UserTopics------------------------NEXT TOPIC---------------------------",
    //   UserTopics.map((i) => ({
    //     UT_ID: i.UT_ID,
    //     CID: i.CID,
    //     TID: i.TID,
    //     UID: i.UID,
    //     PROGRESS: i.PROGRESS,
    //     STATUS: i.STATUS,
    //   }))
    // );
    // console.log(
    //   "Userassessment------------------------NEXT TOPIC---------------------------",
    //   Userassessment.map((i) => ({
    //     UA_ID: i.UA_ID,
    //     CID: i.CID,
    //     AID: i.AID,
    //     UID: i.UID,
    //     Status: i.Status,
    //     TimeTakenMins: i.TimeTakenMins,
    //     Attempt: i.Attempt,
    //     user_final_score: i.user_final_score,
    //   }))
    // );
    // console.log(
    //   "IsAllTopicsCompleted------------------------NEXT TOPIC---------------------------",
    //   IsAllTopicsCompleted
    // );
    // console.log(
    //   "IsAllAssessCompleted------------------------NEXT TOPIC---------------------------",
    //   IsAllAssessCompleted
    // );

    if (IsAllTopicsCompleted && IsAllAssessCompleted) {
      await UserModule.update(
        { STATUS: "COMPLETED", PROGRESS: "100" },
        { where: { UID: userId, CID: courseId, MID: moduleId } }
      );
    }
    //================================================================

    const NewCourseModule = CourseModule.filter(
      (i) => i.IdType !== "Final Assessment"
    ).sort((a, b) =>
      Number(a.ModuleOrder) === Number(b.ModuleOrder)
        ? Number(a.TopicOrder) - Number(b.TopicOrder)
        : Number(a.ModuleOrder) - Number(b.ModuleOrder)
    );

    const TaskIndex = NewCourseModule.findIndex(
      (i) =>
        Number(i.ModuleOrder) === ModuleOrder &&
        Number(i.TopicOrder) === TopicOrder
    );

    let result: any = [];

    const Find =
      NewCourseModule[TaskIndex + 1] && NewCourseModule[TaskIndex + 1];

    const getUserStatus = await UserModule.findOne({
      where: { MID: moduleId, UID: userId, CID: courseId },
    });
    const status = getUserStatus?.STATUS === "COMPLETED";

    if (
      NewCourseModule[TaskIndex + 1] &&
      NewCourseModule[TaskIndex + 1].MID !== moduleId
    ) {
      if (status) {
        result = [
          {
            MapID: Find.MapID,
            CID: Find.CID,
            MID: Find.MID,
            ModuleOrder: Find.ModuleOrder,
            TID: Find.IdType === null ? Find.TID : null,
            AID: Find.IdType === "Assessment" ? Find.TID : null,
            TopicOrder: Find.TopicOrder,
            IdType: Find.IdType,
            type: Find.IdType === "Assessment" ? "Assessment" : "Topic",
          },
        ];
      } else {
        return {
          success: false,
          message:
            "Complete all the tasks in the current module to move to the next module.",
        };
      }
    } else if (!NewCourseModule[TaskIndex + 1]) {
      if (status) {
        const FinalAssessment = CourseModule.filter(
          (i) => i.IdType === "Final Assessment"
        );

        const GetAssessmentDetails = await Assessment.findOne({
          where: { AID: FinalAssessment[0]?.MID },
        });
        const GetUserAssess = await UserAssessment.findOne({
          where: { AID: FinalAssessment[0]?.MID, UID: userId, CID: courseId },
        });
        return {
          success: true,
          message: "success",
          data: [
            {
              ...GetAssessmentDetails?.dataValues,
              UserStatus: GetUserAssess?.Status,
              type: "Final Assessment",
            },
          ],
        };
      } else {
        return {
          success: false,
          message:
            "Complete all the tasks in the current module to move to the next module.",
        };
      }
    } else if (NewCourseModule[TaskIndex + 1].MID === moduleId) {
      result = [
        {
          MapID: Find.MapID,
          CID: Find.CID,
          MID: Find.MID,
          ModuleOrder: Find.ModuleOrder,
          TID: Find.IdType === null ? Find.TID : null,
          AID: Find.IdType === "Assessment" ? Find.TID : null,
          TopicOrder: Find.TopicOrder,
          IdType: Find.IdType,
          type: Find.IdType === "Assessment" ? "Assessment" : "Topic",
        },
      ];
    }
    return { success: true, message: "success", data: result };
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "An error occurred",
    };
  }
};
const PreviousTaskService = async (
  courseId: number,
  moduleId: number,
  userId: number,
  ModuleOrder: number,
  TopicOrder: number
) => {
  try {
    const CourseModule = await CourseModuleTopic.findAll({
      where: { CID: courseId },
    });
    const NewCourseModule = CourseModule.filter(
      (i) => i.IdType !== "Final Assessment"
    ).sort((a, b) =>
      Number(a.ModuleOrder) === Number(b.ModuleOrder)
        ? Number(a.TopicOrder) - Number(b.TopicOrder)
        : Number(a.ModuleOrder) - Number(b.ModuleOrder)
    );

    const TaskIndex = NewCourseModule.findIndex(
      (i) =>
        Number(i.ModuleOrder) === ModuleOrder &&
        Number(i.TopicOrder) === TopicOrder
    );

    let result: any = [];

    const Find =
      NewCourseModule[TaskIndex - 1] && NewCourseModule[TaskIndex - 1];

    if (
      NewCourseModule[TaskIndex - 1] &&
      NewCourseModule[TaskIndex - 1].MID !== moduleId
    ) {
      const getUserStatus = await UserModule.findOne({
        where: { MID: moduleId, UID: userId, CID: courseId },
      });

      result = [
        {
          MapID: Find.MapID,
          CID: Find.CID,
          MID: Find.MID,
          ModuleOrder: Find.ModuleOrder,
          TID: Find.IdType === null ? Find.TID : null,
          AID: Find.IdType === "Assessment" ? Find.TID : null,
          TopicOrder: Find.TopicOrder,
          IdType: Find.IdType,
          type: Find.IdType === "Assessment" ? "Assessment" : "Topic",
        },
      ];
    }
    //  else if (!NewCourseModule[TaskIndex - 1]) {

    // }
    else if (NewCourseModule[TaskIndex - 1].MID === moduleId) {
      result = [
        {
          MapID: Find.MapID,
          CID: Find.CID,
          MID: Find.MID,
          ModuleOrder: Find.ModuleOrder,
          TID: Find.IdType === null ? Find.TID : null,
          AID: Find.IdType === "Assessment" ? Find.TID : null,
          TopicOrder: Find.TopicOrder,
          IdType: Find.IdType,
          type: Find.IdType === "Assessment" ? "Assessment" : "Topic",
        },
      ];
    }
    return { success: true, message: "success", data: result };
  } catch (error) {
    console.error(error);
    return {
      success: false,
      message: "An error occurred",
    };
  }
};

export {
  CourseModuleTopicServices,
  GetCourseModuleByCIDService,
  MapAssessmentCourseServices,
  GetModuleTopicByMIDService,
  GetModuleAssessmentByMIDService,
  GetAssessmentQuestionByAIDService,
  ExpandAllService,
  NewContinueToLastService,
  NewGetCourseDetailsService,
  NextTaskService,
  PreviousTaskService,
};
