import { error } from "console";
import { Module, ModuleCreationAttributes } from "../Model/ModuleModel";

const CreateModuleServices = async (module: ModuleCreationAttributes) => {
  try {
    const createModule = {
      ...module,
      STATUS: "Y",
    };
    const newModule = await Module.create(createModule);
    if (newModule) {
      return { success: true, message: "Module Created successfully" };
    } else {
      return { success: false, message: "Failed to Create Module" };
    }
  } catch (error) {
    console.error("Error to Create Module:", error);
    return {
      success: false,
      message: "An error occurred while Creating Module",
    };
  }
};

const GetModuleServices = async (id: number) => {
  try {
    const module = await Module.findOne({ where: { MID: id } });
    if (module) {
      return module;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on fetching Module:", error);
    return {
      success: false,
      message: "An error occurred while getting module",
    };
  }
};

const GetAllModuleServices = async () => {
  try {
    const AllModule = await Module.findAll();
    if (AllModule) {
      return AllModule;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on fetching All Module:", error);
    return {
      success: false,
      message: "An error occurred while getting All Module",
    };
  }
};

const UpdateModuleServices = async (
  module: ModuleCreationAttributes,
  id: number
) => {
  try {
    const userModule = await Module.findOne({ where: { MID: id } });
    if (!userModule) {
      throw new Error("Module not found");
    }
    await Module.update(module, { where: { MID: id } });
    const updatedModule = await Module.findOne({
      where: { MID: id },
    });
    return updatedModule;
  } catch (error) {
    console.error(error);
    throw new Error("Failed to update Module");
  }
};

const DeleteModuleServices = async (id: number) => {
  try {
    const module = await Module.destroy({ where: { MID: id } });
    if (module) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on deleting Module:", error);
    return {
      success: false,
      message: "An error occurred while delete Module",
    };
  }
};

export {
  CreateModuleServices,
  GetModuleServices,
  GetAllModuleServices,
  UpdateModuleServices,
  DeleteModuleServices,
};
