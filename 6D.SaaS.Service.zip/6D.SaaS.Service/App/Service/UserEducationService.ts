import { Institution } from "../Model/InstitutionModel";
import UserEducation, {
  UserEducationCreationAttributes,
} from "../Model/UserEducationModel";

const CreateUserEducationService = async (
  education: UserEducationCreationAttributes
) => {
  try {
    const existingEducation = await UserEducation.findOne({
      where: { UID: education.UID },
    });

    if (existingEducation) {
      const update = await UserEducation.update(education, {
        where: { UID: education.UID },
      });
      if (update) {
        return true;
      } else {
        return false;
      }
    } else {
      const newEducation = await UserEducation.create(education);
      if (newEducation) {
        return true;
      } else {
        return false;
      }
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to update education");
  }
};

const GetEducationService = async (UID: string) => {
  try {
    const result = await UserEducation.findOne({ where: { UID: UID } });
    if (result) {
      const Inst = await Institution.findOne({
        where: { IID: result.INSTITUTION_ID },
      });

      return { ...result.toJSON(), ...Inst?.toJSON() };
    } else {
      return false;
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to fetch education");
  }
};
export { CreateUserEducationService, GetEducationService };
