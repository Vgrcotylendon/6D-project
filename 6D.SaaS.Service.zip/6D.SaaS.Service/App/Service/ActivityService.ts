import { Course } from "../Model/CourseModel";
import { CourseModuleTopic } from "../Model/CourseModuleTopicModel";
import { Topic } from "../Model/TopicModel";
import { UserAssessment } from "../Model/UserAssessmentModel";
import { UserCourse } from "../Model/UserCourseModel";
import { UserModule } from "../Model/UserModuleModel";
import { UserTopic } from "../Model/UserTopicModel";
 
const getActivityCountServices = async (userId: number) => {
  try {
    const result = await UserCourse.findAll({
      where: {
        UID: userId,
      },
    });
 
    const AssessmentSpent = await UserAssessment.findAll({
      where: { UID: userId, Status: "COMPLETED" },
    });
 
    const TopicSpent = await UserTopic.findAll({
      where: { UID: userId, STATUS: "COMPLETED" },
    });
    const TopicDuration = await Topic.findAll({
      where: { TID: TopicSpent.map((i) => i.TID) },
    });
 
    const totalDurationForTopoics = TopicDuration.reduce((acc, topic) => {
      return acc + Number(topic.DURATION);
    }, 0);
 
    const totalMinutesForAssessment = AssessmentSpent.reduce(
      (acc: any, item: any) => {
        const time = item.TimeTakenMins;
        if (time === "0" || time === "00:00:00") return acc; // Skip invalid times
 
        // Convert time to total minutes
        const [hours, minutes, seconds] = time.split(":").map(Number);
        const total = hours * 60 + minutes + seconds / 60;
        return acc + total;
      },
      0
    );
 
    const TimeSpent =
      Number(totalMinutesForAssessment) + Number(totalDurationForTopoics);
 
    // console.log("TimeSpent", TimeSpent);
    // console.log(
    //   "TimeSpentForAssessment",
    //   TimeSpentForAssessment,
    //   "totalMinutesForAssessment",
    //   totalMinutesForAssessment
    // );
    // console.log(
    //   "TimeSpentForTopic",
    //   TimeSpentForTopic,
    //   "totalDurationForTopoics",
    //   totalDurationForTopoics
    // );
 
    const NotStarted = result.filter(
      (course) => course.STATUS === "Not Started"
    ).length;
    const Inprogress = result.filter(
      (course) => course.STATUS === "InProgress"
    ).length;
 
    const newInprogress = NotStarted + Inprogress;
 
    const data = {
      Enrolled: result.length,
      InProgress: newInprogress,
      DisQualified: result.filter((course) => course.STATUS === "DISQUALIFIED")
        .length,
      Certified: result.filter((course) => course.STATUS === "COMPLETED")
        .length,
      TimeSpent: TimeSpent.toString().split(".")[0],
    };
 
    return data;
  } catch (error) {
    console.error("Error in getActivityCountServices:", error);
    throw new Error("Database operation failed");
  }
};
 
const getModuleCountServices = async (userId: number, status: string) => {
  try {
    let queryFilter = { UID: userId } as { UID: number; STATUS?: string };
 
    if (status !== "Enrolled") {
      queryFilter.STATUS = status;
    }
    let userCourses: any;
    if (queryFilter.STATUS === "InProgress") {
      const InProgressCourses = await UserCourse.findAll({
        where: {
          UID: userId,
          STATUS: "InProgress",
        },
      });
 
      const NotStartedCourses = await UserCourse.findAll({
        where: {
          UID: userId,
          STATUS: "Not Started",
        },
      });
      userCourses = [...InProgressCourses, ...NotStartedCourses];
    } else {
      userCourses = await UserCourse.findAll({
        where: queryFilter,
      });
    }
 
    if (userCourses.length === 0) {
      return {
        success: true,
        data: [],
        message: "No courses found for the user",
      };
    }
    const moduleCounts = [];
 
    for (const course of userCourses) {
      const courseId = course.CID;
 
      const courseDetails = await Course.findOne({ where: { CID: courseId } });
 
      if (!courseDetails) continue;
 
      const courseModules = await CourseModuleTopic.findAll({
        where: { CID: courseId },
      });
 
      const uniqueCourseModules = Array.from(
        new Set(
          courseModules.map(
            (module) => module.IdType !== "Final Assessment" && module.MID
          )
        )
      );
 
      const TotalModules = courseModules.map((i) => Number(i.ModuleOrder));
 
      const totalModules = Math.max(...TotalModules);
 
      let completedModules = 0;
      let pendingModules = 0;
 
      for (const moduleMID of uniqueCourseModules) {
        const userModule = await UserModule.findOne({
          where: {
            MID: moduleMID.toString(),
            UID: userId,
          },
        });
 
        if (userModule) {
          if (userModule.STATUS === "COMPLETED") {
            completedModules++;
          } else {
            pendingModules++;
          }
        }
        // else {
        //   pendingModules++;
        // }
      }
 
      moduleCounts.push({
        courseId: courseId,
        course: courseDetails.TITLE,
        totalModules: totalModules,
        completed: completedModules,
        pending: pendingModules,
        courseStatus: course.STATUS,
        courseProgress: course.PROGRESS,
        timespent: 0,
      });
    }
    // console.log("moduleCounts---------------", moduleCounts);
 
    const courseDetails = await Promise.all(
      moduleCounts.map(async (userCourse: any) => {
        const AssessmentSpent = await UserAssessment.findAll({
          where: { UID: userId, CID: userCourse.courseId, Status: "COMPLETED" },
        });
 
        const TopicSpent = await UserTopic.findAll({
          where: { UID: userId, CID: userCourse.courseId, STATUS: "COMPLETED" },
        });
 
        const TopicDuration = await Topic.findAll({
          where: { TID: TopicSpent.map((i) => i.TID) },
        });
 
        const totalDurationForTopics = TopicDuration.reduce((acc, topic) => {
          return acc + Number(topic.DURATION);
        }, 0);
 
        const totalMinutesForAssessment = AssessmentSpent.reduce(
          (acc: any, item: any) => {
            const time = item.TimeTakenMins;
            if (time === "0" || time === "00:00:00") return acc;
 
            const [hours, minutes, seconds] = time.split(":").map(Number);
            const total = hours * 60 + minutes + seconds / 60;
            return acc + total;
          },
          0
        );
 
        const TimeSpent =
          Number(totalMinutesForAssessment) + Number(totalDurationForTopics);
 
        const formatTime = () => {
          const hours = Math.floor(TimeSpent / 60);
          const mins = Math.round(TimeSpent % 60);
          return `${hours} hrs ${mins} min`;
        };
 
        return {
          ...userCourse,
          timespent: TimeSpent.toString().split(".")[0],
        };
      })
    );
 
    const result = courseDetails;
    // console.log("result-----===============================", result);
 
    return result;
  } catch (error) {
    console.error("Error in getModuleCountServices:", error);
    throw new Error("Database operation failed");
  }
};
 
export { getActivityCountServices, getModuleCountServices };