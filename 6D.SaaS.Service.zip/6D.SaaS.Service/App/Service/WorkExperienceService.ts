import UserWorkExperience, {
  UserWorkExperienceCreationAttributes,
} from "../Model/WorkExperienceModel";

const CreateExperienceService = async (
  experience: UserWorkExperienceCreationAttributes
) => {
  try {

    const newExperience = await UserWorkExperience.create(experience);

    if (newExperience) {
      return { success: true, message: "Experience added successfully" };
    } else {
      return { success: false, message: "Failed to add Experience" };
    }
  } catch (error) {
    console.error("Error adding experience:", error);
    return {
      success: false,
      message: "An error occurred while adding Experience",
    };
  }
};

const GetExperinceService = async (Id: number) => {
  try {

    const experience = await UserWorkExperience.findAll({ where: { UID: Id } });
    if (experience) {
      return experience;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on fetching experience:", error);
    return {
      success: false,
      message: "An error occurred while getting Experience",
    };
  }
};
const UpdateExperienceService = async (
  Id: number,
  Experience: UserWorkExperienceCreationAttributes
) => {
  try {

    const experience = await UserWorkExperience.findOne({ where: { EID: Id } });

    if (experience) {
      experience.COMPANY_NAME = Experience.COMPANY_NAME;
      experience.EMPLOYMENT_TYPE = Experience.EMPLOYMENT_TYPE;
      experience.JOB_TITLE = Experience.JOB_TITLE;
      experience.DURATION = Experience.DURATION;
      experience.START_DATE = Experience.START_DATE;
      experience.END_DATE = Experience.END_DATE;
      experience.ROLE_DESCRIPTION = Experience.ROLE_DESCRIPTION;
      experience.SKILLS = Experience.SKILLS;
      await experience.save();
      const updatedExperience = await UserWorkExperience.findOne({
        where: { EID: Id },
      });

      return updatedExperience;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on updating experience:", error);
    return {
      success: false,
      message: "An error occurred while updating Experience",
    };
  }
};
const DeleteExperinceService = async (Id: number) => {
  try {

    const experience = await UserWorkExperience.destroy({ where: { EID: Id } });

    if (experience) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on deleting experience:", error);
    return {
      success: false,
      message: "An error occurred while delete Experience",
    };
  }
};
export {
  CreateExperienceService,
  GetExperinceService,
  UpdateExperienceService,
  DeleteExperinceService,
};
