import {
  JobDetails,
  JobDetailsCreationAttributes,
} from "../Model/JobDetailsModel";

const CreateJobDetailsService = async (
  jobDetails: JobDetailsCreationAttributes
): Promise<{
  success: boolean;
  message: string;
  data?: JobDetailsCreationAttributes;
}> => {
  try {
    const result = await JobDetails.create(jobDetails);
    return {
      success: true,
      message: "Job details created successfully",
      data: result,
    };
  } catch (error) {
    console.error("Error creating job details:", error);
    return { success: false, message: "Failed to create job details" };
  }
};

const GetJobDetailsService = async (): Promise<{
  success: boolean;
  data?: JobDetailsCreationAttributes[];
  message?: string;
}> => {
  try {
    const result = await JobDetails.findAll();
    return { success: true, data: result };
  } catch (error) {
    console.error("Error retrieving job details:", error);
    return { success: false, message: "Failed to retrieve job details" };
  }
};
const UpdateJobDetailsService = async (
  Id: string,
  jobDetails: JobDetailsCreationAttributes
): Promise<{ success: boolean; message: string }> => {
  try {
    const [affectedRows] = await JobDetails.update(jobDetails, {
      where: { jid: Id },
    });

    if (affectedRows === 0) {
      return {
        success: false,
        message: "Job Details not found or no changes made",
      };
    }

    return { success: true, message: "Job Details updated successfully" };
  } catch (error) {
    console.error("Error updating Job Details:", error);
    return { success: false, message: "Failed to update Job Details" };
  }
};
const DeleteJobDetailsService = async (
  Id: string
): Promise<{ success: boolean; message: string }> => {
  try {
    const result = await JobDetails.destroy({ where: { jid: Id } });

    if (result === 0) {
      return { success: false, message: "Job Details not found" };
    }

    return { success: true, message: "Job Details deleted successfully" };
  } catch (error) {
    console.error("Error deleting Job Details:", error);
    return { success: false, message: "Failed to delete Job Details" };
  }
};

export {
  CreateJobDetailsService,
  GetJobDetailsService,
  UpdateJobDetailsService,
  DeleteJobDetailsService,
};
