import { Result } from "express-validator";
import {
  Institution,
  InstitutionCreationAttributes,
} from "../Model/InstitutionModel";

const CreateInstitutionService = async (
  institution: InstitutionCreationAttributes
) => {
  try {
    const result = await Institution.create(institution);
    if (result) {
      return { success: true, message: "Institution created successfully" };
    } else {
      return { success: false, message: "Failed to create institution" };
    }
  } catch (error) {
    console.error("Error creating institution:", error);
    return { success: false, message: "Failed to create institution" };
  }
};

const GetInstitutionService = async () => {
  try {
    const result = await Institution.findAll();
    if (result.length > 0) {
      return { success: true, data: result };
    } else {
      return { success: false, message: "No institutions found" };
    }
  } catch (error) {
    console.error("Error fetching institutions:", error);
    return { success: false, message: "Failed to fetch institutions" };
  }
};

const UpdateInstitutionService = async (
  Id: string,
  institution: InstitutionCreationAttributes
) => {
  try {
    const [updated] = await Institution.update(institution, {
      where: { IID: Id },
    });
    if (updated) {
      return { success: true, message: "Institution updated successfully" };
    } else {
      return { success: false, message: "Institution not found" };
    }
  } catch (error) {
    console.error("Error updating institution:", error);
    return { success: false, message: "Failed to update institution" };
  }
};

const DeleteInstitutionService = async (Id: string) => {
  try {
    const deleted = await Institution.destroy({
      where: { IID: Id },
    });
    if (deleted) {
      return { success: true, message: "Institution deleted successfully" };
    } else {
      return { success: false, message: "Institution not found" };
    }
  } catch (error) {
    console.error("Error deleting institution:", error);
    return { success: false, message: "Failed to delete institution" };
  }
};

export {
  CreateInstitutionService,
  GetInstitutionService,
  UpdateInstitutionService,
  DeleteInstitutionService,
};
