import { UserInvite, UserInviteCreationAttributes } from "../Model/UserInviteModel";

const CreateUserInviteService = async (Invite: UserInviteCreationAttributes) => {
  try { 
    const newInvite = await UserInvite.create(Invite);
    if (newInvite) {
      return { success: true, message: "Invite sent successfully" };
    } else {
      return { success: false, message: "Failed to send Invite" };
    }
  } catch (error) {
    console.error("Error to send Invite:", error);
    return {
      success: false,
      message: "An error occurred while sending Invite",
    };
  }
};

const GetUserInviteService = async (Id: number) => {
    try {
       const userInvite = await UserInvite.findOne({ where: { ID: Id } });
  
      if (userInvite) {
        return userInvite;
      } else {
        return false;
      }
    } catch (error) {
      console.error("Error on fetching userInvite:", error);
      return {
        success: false,
        message: "An error occurred while getting userInvite",
      };
    }
  };

  const GetAllUserInviteService = async () => {
    try {;
       const userInvite = await UserInvite.findAll();
  
      if (userInvite.length>0) {
        return userInvite;
      } else {
        return false;
      }
    } catch (error) {
      console.error("Error on fetching All user Invite:", error);
      return {
        success: false,
        message: "An error occurred while getting All user Invite",
      };
    }
  };

  const UpdateUserInviteService = async (userInviteData: UserInviteCreationAttributes,id: number) => {
    try {
      const user = await UserInvite.findByPk(id);
      if (!user) {
        throw new Error("user not found");
      }
      await UserInvite.update(userInviteData, { where: { ID: id } });
      const updatedUserInvite = await UserInvite.findByPk(id);
      return updatedUserInvite;
    } catch (error) {
      console.error(error);
      throw new Error("Failed to update user Invite");
    }
  };

  const DeleteUserInviteService = async (Id: number) => {
    try {
  
      const result = await UserInvite.destroy({ where: { ID: Id } });
  
      if (result) {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      console.error("Error on deleting user Invite:", error);
      return {
        success: false,
        message: "An error occurred while delete user Invite",
      };
    }
  };

export { CreateUserInviteService,GetUserInviteService ,GetAllUserInviteService, UpdateUserInviteService, DeleteUserInviteService};
