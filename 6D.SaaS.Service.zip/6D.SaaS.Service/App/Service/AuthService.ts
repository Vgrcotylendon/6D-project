import { bcrypt } from "../Configuration/Hash";
import { MobileUsers } from "../Model/MobileOtpModel";
import { UserCredentials } from "../Model/UserCredModel";
import { User } from "../Model/UserModel";
import { UserTokens } from "../Model/UserTokenModel";
import {
  GenerateAccessToken,
  GenerateRefreshToken,
  VerifyRefreshToken,
} from "../Util/JWTToken";
import moment from "moment";

const CodeforEmailService = async (email: string, code: number) => {
  try {
    const user = await UserCredentials.findOne({
      where: { email },
    });
    if (user) {
      const attempt = user.attempt || 0;
      // if (user.enabled === "Y" && attempt <= 4) {
      if (attempt <= 3) {
        user.code = code;
        user.attempt = attempt + 1;
        await user.save();
        return user.code;
      }
    } else {
      return false;
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to send verification code");
  }
};

const EmailOtpService = async (email: string, code: number) => {
  try {
    const user = await UserCredentials.findOne({ where: { email } });

    if (user) {
      if (user.accountOrigin !== null) {
        return null;
      }
      if (user.enabled === "Y") return false;

      const [updateCount] = await UserCredentials.update(
        { code, enabled: "N", attempt: 0 },
        { where: { email } }
      );

      return updateCount > 0 ? code : null;
    } else {
      const newUser = await UserCredentials.create({
        email,
        code,
        enabled: "N",
        attempt: 0,
      });

      return newUser ? code : null;
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to send verification code");
  }
};

// SOCIAL MEDIA SIGNUP
const socialMediaSignUpService = async (
  email: string,
  accountOrigin: string
) => {
  try {
    const existingUser = await UserCredentials.findOne({
      where: { email },
    });
    if (existingUser) {
      if (existingUser.enabled === "Y" && existingUser.accountOrigin === null) {
        return {
          message: "User already exists. Please sign in.",
        };
      } else {
        await UserCredentials.update(
          { accountOrigin, enabled: "Y" },
          { where: { email } }
        );

        const updatedUser = await UserCredentials.findOne({ where: { email } });

        const profile = await User.findByPk(updatedUser?.ID);
        const education = await User.findOne({
          where: { UID: updatedUser?.ID },
        });

        const USER = {
          userId: updatedUser?.ID,
          userName: updatedUser?.userName || null,
          email: updatedUser?.email,
          mobile: updatedUser?.mobile || null,
          profile: profile?.AVATAR_URL || null,
          accountOrigin: "GOOGLE",
          PROFILE_STATUS: profile ? true : false,
          EDUCATION_STATUS: education ? true : false,
        };

        const token = GenerateAccessToken(USER);
        const refreshToken = GenerateRefreshToken(USER);

        return {
          message: "SignUp Successfully",
          userId: updatedUser?.ID,
          userName: updatedUser?.userName || null,
          email: updatedUser?.email,
          mobile: updatedUser?.mobile || null,
          profile: profile?.AVATAR_URL || null,
          accountOrigin: "GOOGLE",
          PROFILE_STATUS: profile ? true : false,
          EDUCATION_STATUS: education ? true : false,
          token,
          refreshToken,
        };
      }
    }

    const newUser = await UserCredentials.create({
      email,
      accountOrigin,
      enabled: "Y",
    });

    const profile = await User.findByPk(newUser.ID);
    const education = await User.findOne({
      where: { UID: newUser?.ID },
    });

    const USER = {
      userId: newUser.ID,
      userName: newUser.userName || null,
      email: newUser.email,
      mobile: newUser.mobile || null,
      profile: profile?.AVATAR_URL || null,
      accountOrigin: "GOOGLE",
      PROFILE_STATUS: profile ? true : false,
      EDUCATION_STATUS: education ? true : false,
    };

    const token = GenerateAccessToken(USER);
    const refreshToken = GenerateRefreshToken(USER);

    return {
      message: "SignUp Successfully",
      userId: newUser.ID,
      userName: newUser.userName || null,
      email: newUser.email,
      mobile: newUser.mobile || null,
      profile: profile?.AVATAR_URL || null,
      accountOrigin: "GOOGLE",
      PROFILE_STATUS: profile ? true : false,
      EDUCATION_STATUS: education ? true : false,
      token,
      refreshToken,
    };
  } catch (error) {
    console.error("Error in socialMediaSignUpService:", error);
    throw new Error("Failed to sign up the user.");
  }
};

// SOCIAL MEDIA SIGNIN SERVICE
const socialMediaSignInService = async (
  email: string,
  accountOrigin: string
) => {
  try {
    const existingUser = await UserCredentials.findOne({
      where: {
        email,
        accountOrigin,
      },
    });
    if (existingUser) {
      const profile = await User.findByPk(existingUser.ID);
      const education = await User.findOne({
        where: { UID: existingUser?.ID },
      });

      const USER = {
        userId: existingUser.ID,
        userName: existingUser.userName || null,
        email: existingUser.email,
        mobile: existingUser.mobile || null,
        profile: profile?.AVATAR_URL ? profile?.AVATAR_URL : null,
        PROFILE_STATUS: profile ? true : false,
        EDUCATION_STATUS: education ? true : false,
        accountOrigin: "GOOGLE",
      };

      const token = GenerateAccessToken(USER);
      const refreshToken = GenerateRefreshToken(USER);

      return {
        message: "SignIn Successfully",
        userId: existingUser.ID,
        token,
        refreshToken,
        userName: existingUser.userName || null,
        email: existingUser.email,
        mobile: existingUser.mobile || null,
        profile: profile?.AVATAR_URL ? profile?.AVATAR_URL : null,
        PROFILE_STATUS: profile ? true : false,
        EDUCATION_STATUS: education ? true : false,
        accountOrigin: "GOOGLE",
      };
      // throw new Error("User does not exist. Please sign up.");
    } else if (!existingUser) {
      const NewUser = await socialMediaSignUpService(email, accountOrigin);
      // console.log("NewUser----------------------", NewUser);

      return NewUser;
    }
  } catch (error) {
    console.error("Error in socialMediaSignInService:", error);
    throw new Error("Failed to verify your email.");
  }
};

const MobileOtpService = async (
  mobile: string,
  code: number
): Promise<number | boolean> => {
  try {
    const user = await UserCredentials.findOne({
      where: { mobile },
    });

    if (user && user.enabled === "N") {
      await UserCredentials.update(
        { code, enabled: "N" },
        { where: { mobile } }
      );
      return code;
    }

    if (!user) {
      await UserCredentials.create({
        mobile,
        code,
        enabled: "N",
      });
      return code;
    }

    return false;
  } catch (error) {
    console.error("Failed to send verification code:", error);
    throw new Error("Failed to send verification code");
  }
};

const CodeforMobileService = async (mobile: string, code: number) => {
  try {
    const user = await UserCredentials.findOne({
      where: { mobile },
    });

    if (user && user.enabled === "Y") {
      const otpExits = await MobileUsers.findOne({
        where: { MobileNumber: mobile.toString() },
      });

      const profile = await User.findByPk(user.ID);
      const userInfo = {
        userId: user.ID,
        userName: user.userName,
        email: user.email,
        profile: profile?.AVATAR_URL,
      };

      if (otpExits) {
        await MobileUsers.update(
          { code: code },
          { where: { MobileNumber: mobile.toString() } }
        );

        // user.attempt = user.attempt ? user.attempt + 1 : 1;
        if (user.attempt === 3) {
          user.enabled = "N";
        }

        await user.save();
        return { code, user: userInfo };
      } else {
        const otp = await MobileUsers.create({
          MobileNumber: mobile.toString(),
          code: code,
          enabled: "Y",
        });
        await UserTokens.create({
          tokenId: user.ID,
        });

        user.attempt = user.attempt ? user.attempt + 1 : 1;
        if (user.attempt === 3) {
          user.enabled = "N";
        }

        await user.save();
        return { code: otp.code, user: userInfo };
      }
    } else {
      return false;
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to send verification code");
  }
};

const ReSendCodeforSignUpService = async (mobile: string, code: number) => {
  try {
    const user = await UserCredentials.findOne({
      where: { mobile },
    });
    if (user && user.enabled === "N") {
      const otpExits = await MobileUsers.findOne({
        where: { MobileNumber: mobile.toString() },
      });

      const profile = await User.findByPk(user.ID);
      const userInfo = {
        userId: user.ID,
        userName: user.userName,
        email: user.email,
        profile: profile?.AVATAR_URL,
      };

      if (otpExits) {
        await MobileUsers.update(
          { code: code },
          { where: { MobileNumber: mobile.toString() } }
        );

        // user.attempt = user.attempt ? user.attempt + 1 : 1;
        if (user.attempt === 3) {
          user.enabled = "N";
        }

        await user.save();
        return { code, user: userInfo };
      } else {
        const otp = await MobileUsers.create({
          MobileNumber: mobile.toString(),
          code: code,
          enabled: "Y",
        });
        await UserTokens.create({
          tokenId: user.ID,
        });

        user.attempt = user.attempt ? user.attempt + 1 : 1;
        if (user.attempt === 3) {
          user.enabled = "N";
        }

        await user.save();
        return { code: otp.code, user: userInfo };
      }
    } else {
      return false;
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to send verification code");
  }
};

const VerifyMobileSignupService = async (code: number, mobile: string) => {
  try {
    const users = await UserCredentials.findOne({
      where: { mobile: mobile.toString() },
    });

    if (users && users.code === code) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to verify code");
  }
};

const VerifyMobileCodeService = async (code: number, mobile: string) => {
  try {
    const users = await UserCredentials.findOne({
      where: { mobile: mobile.toString() },
    });

    let userExits = await MobileUsers.findOne({
      where: { MobileNumber: mobile.toString() },
    });

    if (!userExits) {
      userExits = await MobileUsers.create({
        MobileNumber: mobile.toString(),
        code: users?.dataValues?.code,
      });
    }

    if (
      users &&
      (code === users?.dataValues?.code || code === userExits.code)
    ) {
      await UserCredentials.update({ enabled: "Y" }, { where: { mobile } });
      const profile = await User.findByPk(users.ID);
      const education = await User.findOne({
        where: { UID: users?.ID },
      });

      const USER = {
        userId: users?.ID,
        userName: users?.userName,
        email: users?.email,
        mobile: users?.mobile,
        profile: profile?.AVATAR_URL ? profile?.AVATAR_URL : null,
        PROFILE_STATUS: profile ? true : false,
        EDUCATION_STATUS: education ? true : false,
      };
      const token = GenerateAccessToken(USER);
      const refreshToken = GenerateRefreshToken(USER);
      const UpdateToken = await UserTokens.findOne({
        where: { tokenId: users.ID },
      });
      const time = moment().format("YYYY-MM-DD hh:mm:ss A");
      if (!UpdateToken) {
        await UserTokens.create({
          tokenId: users.ID,
          Token: token,
          refreshToken: refreshToken,
          accessTokenValidity: "Y",
          refreshTokenValidity: "Y",
          createdTime: time,
          userName: users.userName || "",
        });
      } else {
        await UpdateToken.update({
          Token: token,
          accessTokenValidity: "Y",
          refreshToken: refreshToken,
          createdTime: time,
          userName: users.userName || "",
          refreshTokenValidity: "Y",
        });
      }
      const user = {
        ...USER,
        token: token,
        refreshToken: refreshToken,
      };

      await userExits.save();
      return user;
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to verify code");
  }
};

const VerifyCodeService = async (code: number, email: string) => {
  try {
    const user = await UserCredentials.findOne({
      where: { email },
    });
    if (user && code === user.code) {
      await user.save();
      return true;
    } else if (user && code !== user.code) {
      // user.attempt = user.attempt ? user.attempt + 1 : 1;
      await user.save();
    }
    return false;
  } catch (error) {
    console.error(error);
    throw new Error("Failed to verify code");
  }
};

const CreatePasswordService = async (email: string, password: string) => {
  try {
    const userCredentials = await UserCredentials.findOne({ where: { email } });
    if (!userCredentials) {
      return false;
    }
    const profile = await User.findByPk(userCredentials.ID);
    const education = await User.findOne({
      where: { UID: userCredentials?.ID },
    });

    const USER = {
      userId: userCredentials.ID,
      userName: userCredentials.userName,
      email: userCredentials.email,
      mobile: userCredentials.mobile,
      profile: profile?.AVATAR_URL || null,
      PROFILE_STATUS: profile ? true : false,
      EDUCATION_STATUS: education ? true : false,
    };

    const token = GenerateAccessToken(USER);
    const refreshToken = GenerateRefreshToken(USER);

    userCredentials.password = password;
    userCredentials.enabled = "Y";
    await userCredentials.save();

    const currentTime = moment().format("YYYY-MM-DD hh:mm:ss A");
    await UserTokens.create({
      tokenId: userCredentials.ID,
      Token: token,
      refreshToken: refreshToken,
      accessTokenValidity: "Y",
      refreshTokenValidity: "Y",
      createdTime: currentTime,
      userName: userCredentials.userName || "",
    });

    return {
      ...USER,
      token,
      refreshToken,
    };
  } catch (error) {
    console.error("Error creating password:", error);
    throw new Error("Failed to create password");
  }
};

const EmailSignInService = async (email: string, password: string) => {
  try {
    const users = await UserCredentials.findOne({
      where: { email },
    });
    if (!users) {
      return { status: "email_not_found" };
    }
    if (users && users.enabled === "N") {
      return { status: "email_not_found" };
    }
    const Dcrypt = await bcrypt.compare(password, users.password);
    if (!Dcrypt) {
      return { status: "wrong_password" };
    }

    const profile = await User.findByPk(users.ID);
    const education = await User.findOne({
      where: { UID: users?.ID },
    });
    const userId = users.ID.toString();
    const USER = {
      userId: users.ID,
      userName: users.userName,
      email: users.email,
      mobile: users.mobile,
      profile: profile?.AVATAR_URL ? profile?.AVATAR_URL : null,
      PROFILE_STATUS: profile ? true : false,
      EDUCATION_STATUS: education ? true : false,
    };
    const token = GenerateAccessToken(USER);
    const refreshToken = GenerateRefreshToken(USER);

    const UpdateToken = await UserTokens.findOne({
      where: { tokenId: users.ID },
    });
    const time = moment().format("YYYY-MM-DD hh:mm:ss A");

    await UpdateToken?.update({
      Token: token,
      accessTokenValidity: "Y",
      refreshToken: refreshToken,
      createdTime: time,
      userName: users.userName || "",
      refreshTokenValidity: "Y",
    });

    const user = {
      ...USER,
      token: token,
      refreshToken: refreshToken,
    };

    return { status: "success", user };
  } catch (error) {
    console.error(error);
    throw new Error("Failed to SignIn");
  }
};

const EmailSignInCheckService = async (email: string) => {
  try {
    const user = await UserCredentials.findOne({
      where: { email },
    });

    if (!user) {
      throw new Error("User not found");
    }

    if (user.enabled !== "Y") {
      throw new Error("User is not enabled");
    }

    if (user.accountOrigin !== null) {
      throw new Error("User has an account origin");
    }

    return true;
  } catch (error) {
    console.error(error);
    throw error;
  }
};
const GetUserService = async (refreshToken: any, id: any) => {
  const UserToken = await UserTokens.findOne({
    where: { tokenId: id },
  });

  const users = await UserCredentials.findByPk(id);
  const profile = await User.findByPk(id);
  const education = await User.findOne({
    where: { UID: id },
  });
  if (UserToken && users && profile) {
    const USER = {
      userId: users.ID,
      userName: users.userName,
      email: users.email,
      mobile: users.mobile,
      profile: profile?.AVATAR_URL ? profile?.AVATAR_URL : null,
      PROFILE_STATUS: profile ? true : false,
      EDUCATION_STATUS: education ? true : false,
    };
    const NewAccessToken = GenerateAccessToken(USER);
    UserToken.Token = NewAccessToken;
    await UserToken.save();
    return NewAccessToken;
  } else {
    return false;
  }
};

const SetPassWord = async (email: string, passWord: string) => {
  try {
    const user = await UserCredentials.findOne({
      where: { email },
    });

    if (user && user.enabled === "Y" && user.accountOrigin !== "GOOGLE") {
      const attempt = user.attempt || 0;
      if (attempt <= 4) {
        user.password = passWord;
        user.attempt = attempt + 1;
        await user.save();
        return user.password;
      }
    } else {
      return false;
    }
  } catch (error) {
    console.error(error);
    throw new Error("Failed to send verification code");
  }
};

const getPasswordServices = async (
  userId: number
): Promise<{
  success: boolean;
  password?: string | null;
  message?: string;
}> => {
  try {
    const user = await UserCredentials.findOne({ where: { ID: userId } });
    if (!user) {
      return {
        success: false,
        message: "User not found or password is null",
      };
    }

    return {
      success: true,
      password: user.password,
    };
  } catch (error) {
    console.error("Error in getPasswordServices:", error);
    return {
      success: false,
      message: "Error retrieving password",
    };
  }
};

const changePasswordServices = async (
  userId: number,
  currentPassword: string,
  newPassword: string
): Promise<{
  success: boolean;
  message?: string;
}> => {
  try {
    const user = await UserCredentials.findOne({ where: { ID: userId } });

    if (!user) {
      return {
        success: false,
        message: "User not found",
      };
    }

    if (currentPassword === user.password) {
      user.password = newPassword;
      await user.save();

      return {
        success: true,
        message: "Password updated successfully",
      };
    } else {
      return {
        success: false,
        message: "Current password is incorrect",
      };
    }
  } catch (error) {
    console.error("Error in changePasswordServices:", error);
    return {
      success: false,
      message: "Error updating password",
    };
  }
};

export {
  CodeforEmailService,
  VerifyCodeService,
  CreatePasswordService,
  EmailSignInService,
  CodeforMobileService,
  VerifyMobileCodeService,
  GetUserService,
  EmailOtpService,
  MobileOtpService,
  VerifyMobileSignupService,
  SetPassWord,
  socialMediaSignUpService,
  socialMediaSignInService,
  getPasswordServices,
  changePasswordServices,
  EmailSignInCheckService,
  ReSendCodeforSignUpService,
};
