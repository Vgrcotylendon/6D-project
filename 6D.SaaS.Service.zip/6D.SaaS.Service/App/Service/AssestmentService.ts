import { Answer } from "../Model/AnswerModel";
import { AssessmentQuestionAnswer } from "../Model/AssessmentQ&AModel";
import {
  Assessment,
  AssessmentCreationAttributes,
} from "../Model/AssestmentModel";
import { Choice } from "../Model/ChoiceModel";
import {
  CourseModuleTopic,
  CourseModuleTopicCreationAttributes,
} from "../Model/CourseModuleTopicModel";
import { Question, QuestionCreationAttributes } from "../Model/QuestionModel";
import {
  UserAnswer,
  UserAnswerCreationAttributes,
} from "../Model/UserAnswerModel";
import { UserAssessment } from "../Model/UserAssessmentModel";
import { UserCourse } from "../Model/UserCourseModel";
import { UserModule } from "../Model/UserModuleModel";
import { UserQuestion } from "../Model/UserQuestionModel";
import { UserTopic } from "../Model/UserTopicModel";

const CreateAssessmentService = async (
  assestment: AssessmentCreationAttributes
) => {
  try {
    const result = await Assessment.create(assestment);
    return result;
  } catch (error) {
    console.error("Error in CreateAssestmentService:", error);
    throw new Error("Database operation failed");
  }
};

const GetAssessmentService = async (): Promise<any[]> => {
  try {
    const result = await Assessment.findAll();
    return result;
  } catch (error) {
    console.error("Error fetching assessments:", error);
    throw new Error("Failed to fetch assessments");
  }
};

const UpdateAssessmentService = async (
  Id: string,
  assessment: AssessmentCreationAttributes
): Promise<{ success: boolean; message: string }> => {
  try {
    const [updatedRows] = await Assessment.update(assessment, {
      where: { AID: Id },
    });
    if (updatedRows === 0) {
      return {
        success: false,
        message: "Assessment not found or no changes applied",
      };
    }
    return { success: true, message: "Assessment updated successfully" };
  } catch (error) {
    console.error("Error updating assessment:", error);
    return { success: false, message: "Failed to update assessment" };
  }
};

const DeleteAssessmentService = async (
  Id: string
): Promise<{ success: boolean; message: string }> => {
  try {
    const result = await Assessment.destroy({ where: { AID: Id } });
    if (result === 0) {
      return {
        success: false,
        message: "Assessment not found or already deleted",
      };
    }
    return { success: true, message: "Assessment deleted successfully" };
  } catch (error) {
    console.error("Error deleting assessment:", error);
    return { success: false, message: "Failed to delete assessment" };
  }
};

//Question *****************************************************************************

const CreateQuestionService = async (
  question: QuestionCreationAttributes,
  CorrectAnswer: string,
  Choices: Array<{ Choice: string; IsCorrect: number }>
) => {
  try {
    const answerData = {
      Answer: CorrectAnswer,
    };

    const answerResult = await Answer.create(answerData);
    const AnsID = answerResult.AnsID;

    const questionData = {
      ...question,
      CorrectAnswer: AnsID,
    };

    const questionResult = await Question.create(questionData);

    const QID = questionResult.QID;

    const choicesToInsert = Choices.map((choice) => ({
      QID: QID,
      Choice: choice.Choice,
      IsCorrect: choice.IsCorrect === 1,
    }));

    const choiceResults = await Choice.bulkCreate(choicesToInsert);

    return choiceResults;
  } catch (error) {
    console.error("Error in CreateQuestionService:", error);
    throw new Error("Database operation failed");
  }
};

const GetQuestionService = async (): Promise<any[]> => {
  try {
    const result = await Question.findAll();
    return result;
  } catch (error) {
    console.error("Error fetching all questions:", error);
    throw new Error("Failed to fetch questions");
  }
};

const AnswerQuestionService = async (
  userAnswer: UserAnswerCreationAttributes,
  QID: number,
  UID: number,
  AID: number,
  userQID: number,
  time: string,
  MID: number,
  CID: number
) => {
  try {
    const CourseStatus = await UserCourse.findOne({ where: { CID, UID } });
    const ModuleStatus = await UserModule.findOne({
      where: { CID, UID, MID },
    });
    if (CourseStatus?.STATUS === "Not Started") {
      CourseStatus.STATUS = "InProgress";
      await CourseStatus.save();
    }
    if (ModuleStatus?.STATUS === "Not Started") {
      await UserModule.update(
        { STATUS: "InProgress" },
        { where: { CID, UID, MID } }
      );
    }
    const result = await UserAnswer.create(userAnswer);

    if (result) {
      console.log("success");

      await UserQuestion.update(
        {
          Status: "COMPLETED",
          TimeTakenMins: time,
        },
        {
          where: { UQ_ID: userQID, AID: AID, CID: CID },
        }
      );
    }

    const listAssessmentQuestion = await AssessmentQuestionAnswer.findAll({
      where: { AID: AID },
    });
    await UserAssessment.update(
      {
        //  Status: "COMPLETED",
        TimeTakenMins: time,
      },
      { where: { AID: AID, UID: UID, CID: CID } }
    );

    const allQuestionsCompleted = await Promise.all(
      listAssessmentQuestion.map(async (question) => {
        const userQuestion = await UserQuestion.findOne({
          where: {
            QID: question.QID,
            UID: UID,
            AID: AID,
            CID: CID,
          },
        });
        return userQuestion?.Status === "COMPLETED";
      })
    );

    const isAssessmentCompleted = allQuestionsCompleted.every(Boolean);
    console.log("isAssessmentCompleted", isAssessmentCompleted);

    if (isAssessmentCompleted) {
      const updateAssessment = await UserAssessment.update(
        {
          Status: "COMPLETED",
          // TimeTakenMins: time,
        },
        { where: { AID: AID, UID: UID, CID: CID } }
      );

      // Update module progress
      const courseTopics = await CourseModuleTopic.findAll({
        where: { MID: MID, CID: CID },
      });

      const TotalTopicIds = courseTopics
        .filter((e) => e.TID !== null)
        .map((topic) => topic.TID);

      const topicIds = courseTopics
        .filter((e) => e.IdType !== "Assessment")
        .map((topic) => topic.TID);

      const topicAssessmentIds = courseTopics
        .filter((e) => e.IdType === "Assessment")
        .map((topic) => topic.TID);

      const userAssessment = await UserAssessment.findAll({
        where: { AID: topicAssessmentIds, UID: UID, CID: CID },
      });

      const userTopics = await UserTopic.findAll({
        where: { TID: topicIds, UID: UID, CID: CID },
      });

      const completedAssessmentCount = userAssessment.filter(
        (userAss) => userAss.Status === "COMPLETED"
      ).length;

      const completedTopicsCount = userTopics.filter(
        (userTopic) => userTopic.STATUS === "COMPLETED"
      ).length;

      const totalTopicsCount = TotalTopicIds.length;
      const progress = Math.round(
        ((completedTopicsCount + completedAssessmentCount) / totalTopicsCount) *
          100
      );

      const userModule = await UserModule.findOne({
        where: { MID: MID, UID: UID, CID: CID },
      });
      console.log("userModule", userModule);

      if (userModule) {
        const moduleStatus =
          completedTopicsCount + completedAssessmentCount === totalTopicsCount
            ? "COMPLETED"
            : "InProgress";
        console.log("moduleStatus", moduleStatus);
        console.log("completedTopicsCount", completedTopicsCount);

        console.log("completedAssessmentCount", completedAssessmentCount);
        console.log("totalTopicsCount", totalTopicsCount);
        console.log("progress", progress);
        console.log(
          " completedTopicsCount + completedAssessmentCount === totalTopicsCount",
          completedTopicsCount + completedAssessmentCount === totalTopicsCount
        );

        // await UserModule.update(
        //   {
        //     STATUS:
        //       completedTopicsCount + completedAssessmentCount ===
        //       totalTopicsCount
        //         ? "COMPLETED"
        //         : "InProgress",
        //     PROGRESS: `${progress}`,
        //   },
        //   { where: { MID: MID, UID: UID, CID: CID } }
        // );

        userModule.STATUS =
          completedTopicsCount + completedAssessmentCount === totalTopicsCount
            ? "COMPLETED"
            : "InProgress";
        userModule.PROGRESS === `${progress}`;
        await userModule.save();
      }

      // -------------- UPDATE COURSE PROGRESS

      const AllCourseModules = await CourseModuleTopic.findAll({
        where: { CID: CID },
      });

      const FinalAssessments = AllCourseModules.filter(
        (i: any) => i.IdType === "Final Assessment"
      );
      let NoOfTasks: any;

      if (FinalAssessments.length > 0) {
        NoOfTasks = AllCourseModules.length + 1 - FinalAssessments.length;
      } else {
        NoOfTasks = AllCourseModules.length;
      }

      const moduleTopicIds = AllCourseModules.filter(
        (e) => e.IdType === null
      ).map((topic) => topic.TID);
      const moduleAsses = AllCourseModules.filter(
        (e) => e.IdType === "Assessment"
      ).map((topic) => topic.TID);

      const userTopicsForMOdule = await UserTopic.findAll({
        where: { TID: moduleTopicIds, UID: UID },
      });
      const userAssessForMOdule = await UserAssessment.findAll({
        where: { AID: moduleAsses, UID: UID },
      });

      const completedModuleTopicsCount = userTopicsForMOdule.filter(
        (userTopic) => userTopic.STATUS === "COMPLETED"
      ).length;
      const completedModuleAssesCount = userAssessForMOdule.filter(
        (userTopic) => userTopic.Status === "COMPLETED"
      ).length;

      const TotalCompletedTasks =
        completedModuleAssesCount + completedModuleTopicsCount;
      const courseProgress = (TotalCompletedTasks / NoOfTasks) * 100;

      // console.log(
      //   "completedModuleAssesCount===========================",
      //   completedModuleAssesCount
      // );
      // console.log(
      //   "completedModuleTopicsCount===========================",
      //   completedModuleTopicsCount
      // );
      // console.log(
      //   "TotalCompletedTasks===========================",
      //   TotalCompletedTasks
      // );
      // console.log("NoOfTasks===========================", NoOfTasks);
      // console.log("courseProgress===========================", courseProgress);
      // console.log(
      //   "courseProgress===========================",
      //   Math.round(TotalCompletedTasks / NoOfTasks) * 100
      // );

      if (FinalAssessments.length > 0) {
        NoOfTasks = AllCourseModules.length - 1 + FinalAssessments.length;
      } else {
        NoOfTasks = AllCourseModules.length;
      }

      const CourseStatus =
        TotalCompletedTasks === NoOfTasks ? "COMPLETED" : "InProgress";

      await UserCourse.update(
        { STATUS: CourseStatus, PROGRESS: `${courseProgress}` },
        {
          where: { CID: CID, UID: UID },
        }
      );

      // Update course progress
      // const courseModules = await CourseModuleTopic.findAll({
      //   where: { CID: CID },
      // });

      // const TotalModuleTopicIds = courseModules
      //   .filter((e) => e.TID !== null)
      //   .map((topic) => topic.TID);

      // const topicModuleAssessmentIds = courseTopics
      //   .filter((e) => e.IdType === "Assessment")
      //   .map((topic) => topic.TID);

      // const moduleTopicIds = courseModules
      //   .filter((e) => e.IdType !== "Assessment")
      //   .map((topic) => topic.TID);

      // const userTopicsForModule = await UserTopic.findAll({
      //   where: { TID: moduleTopicIds, UID: UID },
      // });

      // const userModuleAssessment = await UserAssessment.findAll({
      //   where: { AID: topicModuleAssessmentIds, UID: UID },
      // });

      // const completedModuleAssessmentCount = userModuleAssessment.filter(
      //   (userAss) => userAss.Status === "COMPLETED"
      // ).length;

      // const completedModuleTopicsCount = userTopicsForModule.filter(
      //   (userTopic: any) => userTopic.STATUS === "COMPLETED"
      // ).length;

      // const GetFinal = courseModules.filter(
      //   (i: any) => i.IdType === "Final Assessment"
      // );

      // const totalModuleTopicsCount = TotalModuleTopicIds.length;
      // const courseProgress = Math.round(
      //   ((completedModuleAssessmentCount + completedModuleTopicsCount) /
      //     totalModuleTopicsCount) *
      //     GetFinal.length ===
      //     0
      //     ? 100
      //     : 90
      // );

      // const userCourse = await UserCourse.findOne({
      //   where: { CID: CID, UID: UID },
      // });
      // console.log("courseProgress", courseProgress);
      // console.log(
      //   "completedModuleTopicsCount === totalModuleTopicsCount",
      //   completedModuleTopicsCount === totalModuleTopicsCount
      //     ? "COMPLETED"
      //     : "InProgress"
      // );

      // if (userCourse) {
      //   const moduleStatus =
      //     completedModuleTopicsCount === totalModuleTopicsCount
      //       ? "COMPLETED"
      //       : "InProgress";
      //   if (moduleStatus === "COMPLETED" && GetFinal.length === 0) {
      //     userCourse.STATUS = moduleStatus;
      //     userCourse.PROGRESS = `${courseProgress}`;
      //     await userCourse.save();
      //   } else if (moduleStatus !== "COMPLETED") {
      //     userCourse.STATUS = moduleStatus;
      //     userCourse.PROGRESS = `${courseProgress}`;
      //     await userCourse.save();
      //   }
      // }

      // const TotalModuleTopicIds = courseModules
      //   .filter((e) => e.IdType !== "Final Assessment")
      //   .map((topic) => topic.TID);

      // const moduleTopicIds = courseModules
      //   .filter((e) => e.IdType === null)
      //   .map((topic) => topic.TID);
      // const moduleAsses = courseModules
      //   .filter((e) => e.IdType === "Assessment")
      //   .map((topic) => topic.TID);

      // const userTopicsForMOdule = await UserTopic.findAll({
      //   where: { TID: moduleTopicIds, UID: UID },
      // });
      // const userAssessForMOdule = await UserAssessment.findAll({
      //   where: { AID: moduleAsses, UID: UID },
      // });

      // const completedModuleTopicsCount = userTopicsForMOdule.filter(
      //   (userTopic) => userTopic.STATUS === "COMPLETED"
      // ).length;
      // const completedModuleAssesCount = userAssessForMOdule.filter(
      //   (userTopic) => userTopic.Status === "COMPLETED"
      // ).length;

      // const TotalTasks = completedModuleAssesCount + completedModuleTopicsCount;

      // const GetFinal = courseModules.filter(
      //   (i: any) => i.IdType === "Final Assessment"
      // );

      // const totalModuleTopicsCount = TotalModuleTopicIds.length;
      // const percent = GetFinal.length === 0 ? 100 : 90;
      // const courseProgress =
      //   Math.round(TotalTasks / totalModuleTopicsCount) * percent;

      // const userCourse = await UserCourse.findOne({
      //   where: { CID: CID, UID: UID },
      // });
      // console.log(
      //   "TotalTasks------------------------------------------------------",
      //   TotalTasks
      // );
      // console.log(
      //   "totalModuleTopicsCount------------------------------------------------------",
      //   totalModuleTopicsCount
      // );
      // console.log(
      //   "percent------------------------------------------------------",
      //   percent
      // );
      // console.log(
      //   "(TotalTasks / totalModuleTopicsCount)------------------------------------------------------",
      //   (TotalTasks / totalModuleTopicsCount) * percent
      // );
      // console.log(
      //   "courseProgress------------------------------------------------------",
      //   courseProgress
      // );
      // console.log(
      //   "moduleStatus------------------------------------------",
      //   TotalTasks === totalModuleTopicsCount ? "COMPLETED" : "InProgress"
      // );

      // if (userCourse) {
      //   const moduleStatus =
      //     TotalTasks === totalModuleTopicsCount ? "COMPLETED" : "InProgress";
      //   if (moduleStatus === "COMPLETED" && GetFinal.length === 0) {
      //     // userCourse.STATUS = moduleStatus;
      //     // userCourse.PROGRESS = `${courseProgress}`;
      //     // await userCourse.save();
      //     await UserCourse.update(
      //       { STATUS: moduleStatus, PROGRESS: `${courseProgress}` },
      //       {
      //         where: { CID: CID, UID: UID },
      //       }
      //     );
      //   } else if (moduleStatus !== "COMPLETED") {
      //     // userCourse.STATUS = moduleStatus;
      //     // userCourse.PROGRESS = `${courseProgress}`;
      //     // await userCourse.save();
      //     await UserCourse.update(
      //       { STATUS: moduleStatus, PROGRESS: `${courseProgress}` },
      //       {
      //         where: { CID: CID, UID: UID },
      //       }
      //     );
      //   }
      // }
    } else {
      const allQuestionsCompleted = await Promise.all(
        listAssessmentQuestion.map(async (question) => {
          const userQuestion = await UserQuestion.findOne({
            where: {
              QID: question.QID,
              UID: UID,
              AID: AID,
              CID: CID,
            },
          });
          return userQuestion?.Status === "COMPLETED";
        })
      );

      const isAssessmentCompleted = allQuestionsCompleted.every(Boolean);

      if (isAssessmentCompleted) {
        await UserAssessment.update(
          {
            Status: "COMPLETED",
            // TimeTakenMins: time,
          },
          { where: { AID: AID, UID: UID, CID: CID } }
        );

        // await UserAssessment.update(
        //   { Status: "InProgress" },
        //   { where: { AID: AID, UID: UID, CID: CID } }
        // );
      }
    }

    return result;
  } catch (error) {
    console.error("Error in User answer:", error);
    throw new Error("Database operation failed");
  }
};

const AddQuestionsForAssessment = async (AID: any, QID: any) => {
  try {
    const results = await Promise.all(
      QID.map(async (questionId: any) => {
        const answer = await Question.findOne({
          where: { QID: Number(questionId) },
        });
        console.log("questionId", questionId);

        if (!answer || !answer.CorrectAnswer) {
          throw new Error(
            `Answer not found or undefined for questionId: ${questionId}`
          );
        }

        const AnsID = answer.CorrectAnswer;

        const mapData = {
          AID: AID,
          QID: questionId,
          AnsID: AnsID,
        };

        const result = await AssessmentQuestionAnswer.create(mapData);

        if (!result) {
          throw new Error(
            `Failed to create AssessmentQuestionAnswer for questionId: ${questionId}`
          );
        }

        return result;
      })
    );
    return {
      success: true,
      message: "",
    };
  } catch (error) {
    console.error("Error in Assessment mapping:", error);
    throw new Error("Database operation failed: " + error);
  }
};

//Map Assessment *****************************************************************************

const mapAssessmentService = async (
  assessmentId: number,
  questionIds: number[],
  CID: number,
  MID: number,
  ModuleOrder: string,
  TID: number,
  TopicOrder: string,
  IdType: string
) => {
  try {
    const GetModule = await CourseModuleTopic.findAll({
      where: { CID: CID },
    });
    const results = await Promise.all(
      questionIds.map(async (questionId) => {
        const answer = await Question.findOne({ where: { QID: questionId } });

        if (!answer || !answer.CorrectAnswer) {
          throw new Error(
            `Answer not found or undefined for questionId: ${questionId}`
          );
        }

        const AnsID = answer.CorrectAnswer;

        const mapData = {
          AID: assessmentId,
          QID: questionId,
          AnsID: AnsID,
        };

        const result = await AssessmentQuestionAnswer.create(mapData);

        if (!result) {
          throw new Error(
            `Failed to create AssessmentQuestionAnswer for questionId: ${questionId}`
          );
        }

        return result;
      })
    );
    // console.log(
    //   "GetModule",
    //   GetModule.map((i) => ({
    //     MapID: i.MapID,
    //     CID: i.CID,
    //     MID: i.MID,
    //     ModuleOrder: i.ModuleOrder,
    //     TID: i.TID,
    //     TopicOrder: i.TopicOrder,
    //     IdType: i.IdType,
    //   }))
    // );
    const newGetModule = GetModule.filter(
      (i) => i.IdType !== "Final Assessment"
    );

    const Filtered_Module = newGetModule.filter((i) => i.MID === MID);
    console.log("Filtered_Module", Filtered_Module);

    const moduleOrder =
      newGetModule.length === 0
        ? 1
        : Filtered_Module[0]?.MID && MID === Filtered_Module[0]?.MID
        ? Number(Filtered_Module[0]?.ModuleOrder)
        : Number(newGetModule[newGetModule.length - 1]?.ModuleOrder) + 1;

    console.log("moduleOrder", moduleOrder);
    console.log(
      "Number(Filtered_Module[0]?.ModuleOrder)",
      Number(Filtered_Module[0]?.ModuleOrder)
    );
    console.log(
      "Number(newGetModule[newGetModule.length - 1]?.ModuleOrder) + 1",
      Number(newGetModule[newGetModule.length - 1]?.ModuleOrder) + 1
    );

    const topicOrder =
      MID === Filtered_Module[0]?.MID
        ? Number(Filtered_Module[Filtered_Module.length - 1]?.TopicOrder) + 1
        : 1;
    const map: CourseModuleTopicCreationAttributes = {
      CID,
      MID,
      ModuleOrder: moduleOrder.toString(),
      TID,
      TopicOrder: topicOrder.toString(),
      IdType,
    };

    const courseModuleTopic = await CourseModuleTopic.create(map);

    if (!courseModuleTopic) {
      throw new Error("Failed to create CourseModuleTopic");
    }

    return true;
  } catch (error) {
    console.error("Error in Assessment mapping:", error);
    throw new Error("Database operation failed: " + error);
  }
};

const MapFinalAssessmentService = async (
  CID: any,
  AID: any,
  cut_off_score: number,
  assessment_instructions: string,
  attempt_instructions: string
) => {
  try {
    const data = AID.map((i: any) => ({
      CID: CID,
      MID: i,
      IdType: "Final Assessment",
      TopicOrder: null,
      ModuleOrder: null,
      TID: null,
    }));
    console.log(data);

    const newAssesment = await CourseModuleTopic.bulkCreate(data);
    const AddInstructions = await Assessment.update(
      {
        assessment_instructions:
          assessment_instructions ||
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        attempt_instructions:
          attempt_instructions ||
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        cut_off_score: cut_off_score || 50,
      },
      { where: { AID: AID.map((i: any) => i) } }
    );
    console.log("newAssesment", newAssesment);

    if (!newAssesment) {
      throw new Error("Database operation failed: ");
    }

    return { success: true, message: "Final Assessment mapped successfully" };
  } catch (error) {
    console.error("Error in Final Assessment mapping:", error);
    throw new Error("Database operation failed: " + error);
  }
};

const GetAssessmentStatusService = async (
  AID: number,
  CID: number,
  UID: number
) => {
  try {
    const GetQuestionId = await AssessmentQuestionAnswer.findAll({
      where: { AID: AID },
    });
    GetQuestionId.forEach((item) => {
      console.log(item.dataValues);
    });

    const status = await UserQuestion.findAll({
      where: {
        UID: UID,
        CID: CID,
        QID: GetQuestionId.map((i) => i.QID),
        AID: AID,
      },
    });

    status.forEach((item) => {
      console.log(item.dataValues);
    });

    return { success: true, message: "status", data: status };
  } catch (error) {
    console.error("Error Fetching status:", error);
    throw new Error("Database operation failed: " + error);
  }
};

const SubmitAnswerFor_FA = async (
  userAnswer: UserAnswerCreationAttributes,
  QID: number,
  UID: number,
  AID: number,
  userQID: number,
  time: string,
  CID: number
) => {
  try {
    const result = await UserAnswer.create(userAnswer);

    console.log("result", result);
    console.log("time", time);

    if (result) {
      await UserQuestion.update(
        {
          Status: "COMPLETED",
          TimeTakenMins: time,
        },
        {
          where: { UQ_ID: userQID, AID: AID, CID: CID, QID: QID },
        }
      );
    }

    const listAssessmentQuestion = await AssessmentQuestionAnswer.findAll({
      where: { AID: AID },
    });
    await UserAssessment.update(
      {
        //  Status: "COMPLETED",
        TimeTakenMins: time,
      },
      { where: { AID: AID, UID: UID } }
    );

    const allQuestionsCompleted = await Promise.all(
      listAssessmentQuestion.map(async (question) => {
        const userQuestion = await UserQuestion.findOne({
          where: {
            QID: question.QID,
            UID: UID,
          },
        });
        return userQuestion?.Status === "COMPLETED";
      })
    );

    const isAssessmentCompleted = allQuestionsCompleted.every(Boolean);

    if (isAssessmentCompleted) {
      await UserAssessment.update(
        {
          Status: "COMPLETED",
          // TimeTakenMins: time,
        },
        { where: { AID: AID, UID: UID, CID: CID } }
      );

      // Update module progress
    }
    return { success: true, message: "User answer updated successfully" };
  } catch (error) {
    console.error("Error Fetching data:", error);
    throw new Error("Database operation failed: " + error);
  }
};

const SubmitFinalAssessmentService = async (
  AID: number,
  CID: number,
  UID: number,
  TimeTakenMins: any
) => {
  try {
    const getUserAssessment = await UserAssessment.findAll({
      where: { UID: UID, AID: AID, CID: CID },
    });
    console.log("getUserAssessment");
    getUserAssessment.forEach((i) => {
      console.log(i.dataValues);
    });
    const GetScore = await UserAnswer.findAll({
      where: { UID: UID, AID: AID, CID: CID },
    });

    console.log("GetScore");
    GetScore.forEach((i) => {
      console.log(i.dataValues);
    });
    const FinalScore = GetScore.reduce((acc, i) => {
      return i.IsCorrect ? acc + 10 : acc;
    }, 0);
    console.log("TimeTakenMins", TimeTakenMins);
    const Questions = await AssessmentQuestionAnswer.findAll({
      where: { AID: AID },
    });
    const TotaNoQuestion = Questions.length;
    const TotalMarksForAssessment = Questions.length * 10;
    const ObtainedMarks = FinalScore;
    const MarkPercentage = (ObtainedMarks / TotalMarksForAssessment) * 100;

    const UpdateFinalScore = await UserAssessment.update(
      {
        user_final_score: MarkPercentage,
        Status: "COMPLETED",
        Attempt: 1,
        TimeTakenMins: TimeTakenMins.toString(),
      },
      {
        where: {
          UID: UID,
          AID: AID,
          CID: CID,
        },
      }
    );

    const GetAssess = await Assessment.findOne({ where: { AID: AID } });
    console.log(UpdateFinalScore);
    if (
      GetAssess?.cut_off_score &&
      GetAssess?.cut_off_score <= MarkPercentage
    ) {
      await UserCourse.update(
        { STATUS: "COMPLETED", PROGRESS: "100" },
        { where: { CID: CID, UID: UID } }
      );
    }
    //  else {
    //   await UserCourse.update(
    //     { STATUS: "DISQUALIFIED", PROGRESS: "0" },
    //     { where: { CID: CID, UID: UID } }
    //   );
    // }

    const GetFA = await CourseModuleTopic.findAll({
      where: { IdType: "Final Assessment", CID: CID },
    });

    const getStatus = await UserAssessment.findAll({
      where: { AID: GetFA.map((i) => i.MID), CID: CID, UID: UID },
    });

    const getAid = await Assessment.findAll({
      where: { AID: GetFA.map((i) => i.MID) },
    });
    const Assess = (id: number) => {
      const index = getAid.findIndex((i) => i.AID === id);
      const aid = getAid[index];
      return aid;
    };

    const Update = getStatus.map(async (i, index) => {
      const newAssessment = Assess(i.AID);

      if (
        index === getStatus.length - 1 &&
        i.Status === "COMPLETED" &&
        i.AID === newAssessment.AID &&
        i.user_final_score !== undefined &&
        newAssessment?.cut_off_score &&
        newAssessment?.cut_off_score !== undefined &&
        i.user_final_score < newAssessment.cut_off_score
      ) {
        await UserCourse.update(
          { STATUS: "DISQUALIFIED", PROGRESS: "100" },
          { where: { CID: CID, UID: UID } }
        );
        // await UserModule.destroy({ where: { CID: CID, UID: UID } });
        // await UserTopic.destroy({ where: { CID: CID, UID: UID } });
        // await UserAssessment.destroy({ where: { CID: CID, UID: UID } });
        // await UserQuestion.destroy({ where: { CID: CID, UID: UID } });
        // await UserAnswer.destroy({ where: { CID: CID, UID: UID } });
      }
    });

    // const newStatus = getStatus.every((i) => {
    //   if (i.Status === "COMPLETED" && i.user_final_score !== undefined) {
    //     const aidItem = getAid.find((j) => j.AID === i.AID);

    //     return aidItem !== undefined &&
    //       aidItem.cut_off_score !== undefined &&
    //       aidItem
    //       ? i.user_final_score >= aidItem.cut_off_score
    //       : false;
    //   }
    //   return false;
    // });
    // if (newStatus) {
    //   await UserCourse.update(
    //     { STATUS: "DISQUALIFIED", PROGRESS: "0" },
    //     { where: { CID: CID, UID: UID } }
    //   );
    //   await UserModule.destroy({ where: { CID: CID, UID: UID } });
    //   await UserTopic.destroy({ where: { CID: CID, UID: UID } });
    //   await UserAssessment.destroy({ where: { CID: CID, UID: UID } });
    //   await UserQuestion.destroy({ where: { CID: CID, UID: UID } });
    //   await UserAnswer.destroy({ where: { CID: CID, UID: UID } });
    // }

    return { success: true, message: "success" };
  } catch (error) {
    console.error("Error on posting data:", error);
    throw new Error("Database operation failed: " + error);
  }
};
const GetResultForFinalAssessmentService = async (UID: number, CID: number) => {
  try {
    const getAssessmentData = await CourseModuleTopic.findAll({
      where: { CID: CID, IdType: "Final Assessment" },
    });

    const getUserAssessment = await UserAssessment.findAll({
      where: { UID: UID, AID: getAssessmentData.map((i) => i.MID), CID: CID },
    });

    const getAssessmentDetails = await Assessment.findAll({
      where: { AID: getAssessmentData.map((i) => i.MID) },
    });

    const uniqueResults = Array.from(
      new Map(getUserAssessment.map((item) => [item.AID, item])).values()
    );

    console.log(uniqueResults);

    let newResult = [];

    newResult = uniqueResults.map((i) => ({
      UID: i.UID,
      CID: i.CID,
      AID: i.AID,
      STATUS: i.Status,
      timeTaken: i.TimeTakenMins,
      CUT_OFF:
        getAssessmentDetails[
          getAssessmentDetails.findIndex((J) => J.AID === i.AID)
        ].cut_off_score,
      FINAL_SCORE: i.user_final_score,
    }));

    console.log("getUserAssessment", getUserAssessment);
    console.log("newResult", newResult);

    return { success: true, message: "success", data: newResult };
  } catch (error) {
    console.error("Error Fetching data:", error);
    throw new Error("Database operation failed: " + error);
  }
};

const ReAttempt_FA_Service = async (UID: number, CID: number) => {
  try {
    const courseModuleTopics = await CourseModuleTopic.findAll({
      where: { CID: CID, IdType: "Final Assessment" },
    });

    const getStatus = await UserAssessment.findAll({
      where: {
        AID: courseModuleTopics.map((i) => i.MID),
        UID: UID,
        CID: CID,
        Status: "Not yet started",
      },
    });

    // const randomIndex = Math.floor(Math.random() * getStatus?.length);
    const randomItem = getStatus[0];

    const NewFinalAssesment = await Assessment.findAll({
      where: { AID: randomItem?.AID },
    });
    return { success: true, message: "success", data: NewFinalAssesment };
  } catch (error) {
    console.error("Error Fetching data:", error);
    throw new Error("Database operation failed: " + error);
  }
};

export {
  CreateAssessmentService,
  GetAssessmentService,
  UpdateAssessmentService,
  DeleteAssessmentService,
  CreateQuestionService,
  GetQuestionService,
  mapAssessmentService,
  AddQuestionsForAssessment,
  AnswerQuestionService,
  MapFinalAssessmentService,
  GetAssessmentStatusService,
  SubmitAnswerFor_FA,
  SubmitFinalAssessmentService,
  GetResultForFinalAssessmentService,
  ReAttempt_FA_Service,
};
// GetAssessmentQuestionByAIDService
