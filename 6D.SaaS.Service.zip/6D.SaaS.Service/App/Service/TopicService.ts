import { Module } from "../Model/ModuleModel";
import { CourseModuleTopic } from "../Model/CourseModuleTopicModel";
import { Topic, TopicCreationAttributes } from "../Model/TopicModel";
import { UserAssessment } from "../Model/UserAssessmentModel";
import { UserCourse } from "../Model/UserCourseModel";
import { UserModule } from "../Model/UserModuleModel";
import {
  UserTopic,
  UserTopicCreationAttributes,
} from "../Model/UserTopicModel";
import { where } from "sequelize";

const CreateTopicServices = async (topic: TopicCreationAttributes) => {
  try {
    const newTopic = await Topic.create(topic);
    if (newTopic) {
      return {
        success: true,
        message: "Module Created successfully",
        data: newTopic,
      };
    } else {
      return { success: false, message: "Failed to Create Module" };
    }
  } catch (error) {
    console.error("Error to Create Module:", error);
    return {
      success: false,
      message: "An error occurred while Creating Module",
    };
  }
};

const GetTopicService = async (): Promise<{
  success: boolean;
  data?: any[];
  message?: string;
}> => {
  try {
    const result = await Topic.findAll();
    return { success: true, data: result };
  } catch (error) {
    console.error("Error fetching topic:", error);
    return { success: false, message: "Failed to fetch topic" };
  }
};

const getTopicDetailsByTIDService = async (
  CID: number,
  MID: number,
  TID: number,
  UID: number
): Promise<{
  success: boolean;
  data?: any;
  message?: string;
}> => {
  try {
    const courseMapList = await CourseModuleTopic.findAll({
      where: {
        CID: CID,
      },
    });

    const CourseStatus = await UserCourse.findOne({ where: { CID, UID } });
    const ModuleStatus = await UserModule.findOne({
      where: { CID, UID, MID },
    });
    if (CourseStatus?.STATUS === "Not Started") {
      CourseStatus.STATUS = "InProgress";
      await CourseStatus.save();
    }
    if (ModuleStatus?.STATUS === "Not Started") {
      await UserModule.update(
        { STATUS: "InProgress" },
        { where: { CID, UID, MID } }
      );
    }

    const uniqueCourseMapList = courseMapList.filter(
      (value, index, self) =>
        index ===
        self.findIndex((t) => t.dataValues.MID === value.dataValues.MID)
    );

    const sortedCourseMapList = uniqueCourseMapList.sort(
      (a, b) => a.dataValues.MID - b.dataValues.MID
    );

    const targetIndex = sortedCourseMapList.findIndex(
      (item) => item.dataValues.MID === MID
    );

    const userTopicDetails = await UserTopic.findOne({
      where: {
        TID: TID,
        UID: UID,
        CID: CID,
      },
    });

    const userModuleDetails = await UserModule.findOne({
      where: {
        MID: MID,
        UID: UID,
        CID: CID,
      },
    });

    if (!userTopicDetails) {
      return { success: false, message: "User topic details not found" };
    }

    const result = await Topic.findOne({
      where: { TID: TID },
    });
    if (!result) {
      return { success: false, message: "Topic not found" };
    }

    const updatedStatus =
      userTopicDetails.STATUS === "COMPLETED" ? "COMPLETED" : "InProgress";

    if (updatedStatus === "InProgress") {
      userTopicDetails.STATUS = "InProgress";
      await userTopicDetails.save();
      // await userTopicDetails.update({ STATUS: "InProgress" });
      // if (userModuleDetails) {
      //   userModuleDetails.STATUS = "InProgress";
      //   await userModuleDetails.save();
      //   // await userModuleDetails.update({ STATUS: "InProgress" });
      // }
    }

    const OrderDetails = courseMapList.filter(
      (i) => i.MID === MID && i.TID === TID && i.IdType === null
    );

    const moduleName = await Module.findOne({ where: { MID: MID } });

    return {
      success: true,
      data: {
        TID: result.TID,
        NAME: result.NAME,
        CONTENT: result.CONTENT,
        CONTENT_TYPE: result.CONTENT_TYPE,
        METADATA: result.METADATA,
        UT_ID: userTopicDetails?.UT_ID,
        PROGRESS: userTopicDetails?.PROGRESS,
        STATUS: updatedStatus,
        CID: CID,
        MID: MID,
        moduleStatus: userModuleDetails?.STATUS,
        moduleIndex: targetIndex + 1,
        ModuleOrder: OrderDetails[0].ModuleOrder,
        TopicOrder: OrderDetails[0].TopicOrder,
        moduleName: moduleName?.NAME,
      },
    };
  } catch (error) {
    console.error("Error fetching topic:", error);
    return { success: false, message: "Failed to fetch topic" };
  }
};

const UpdateTopicService = async (
  Id: number,
  editTopic: TopicCreationAttributes
): Promise<{ success: boolean; message: string }> => {
  try {
    const [updatedRows] = await Topic.update(editTopic, {
      where: { TID: Id },
    });

    if (updatedRows === 0) {
      return {
        success: false,
        message: "Topic not found or no changes applied",
      };
    }
    return { success: true, message: "Topic updated successfully" };
  } catch (error) {
    console.error("Error updating topic:", error);
    return { success: false, message: "Failed to update topic" };
  }
};

const DeleteTopicService = async (
  Id: number
): Promise<{ success: boolean; message: string }> => {
  try {
    const result = await Topic.destroy({ where: { TID: Id } });
    if (result === 0) {
      return {
        success: false,
        message: "Topic not found or already deleted",
      };
    }
    return { success: true, message: "Topic deleted successfully" };
  } catch (error) {
    console.error("Error deleting topic:", error);
    return { success: false, message: "Failed to delete topic" };
  }
};

const UserTopicStatusService = async (
  userTopicId: number,
  topicId: number,
  userId: number,
  updateFields: Partial<UserTopicCreationAttributes>,
  MID: number,
  CID: number
): Promise<{ success: boolean; message: string }> => {
  try {
    const userTopic = await UserTopic.findOne({
      where: { TID: topicId, UID: userId, UT_ID: userTopicId },
    });

    if (!userTopic) {
      return {
        success: false,
        message: "Topic not found or already deleted",
      };
    }

    await userTopic.update(updateFields);

    // -------------- UPDATE MODULE PROGRESS
    const courseTopics = await CourseModuleTopic.findAll({
      where: { MID: MID, CID: CID },
    });

    // const TotalTopicIds = courseTopics
    //   .filter((e) => e.TID !== null)
    //   .map((topic) => topic.TID);

    // const topicIds = courseTopics
    //   .filter((e) => e.IdType !== "Assessment" || "Final Assessment")
    //   .map((topic) => topic.TID);
    const TotalTopicIds = courseTopics
      .filter((e) => e.IdType !== "Final Assessment")
      .map((topic) => topic.TID);

    const topicIds = courseTopics
      .filter((e) => e.IdType === null && e.TID !== null)
      .map((topic) => topic.TID);

    const userTopics = await UserTopic.findAll({
      where: { TID: topicIds, UID: userId, CID: CID },
    });

    const completedTopicsCount = userTopics.filter(
      (userTopic) => userTopic.STATUS === "COMPLETED"
    ).length;

    const userAssessment = await UserAssessment.findAll({
      where: {
        UID: userId,
        CID: CID,
        AID: courseTopics.map((i) => i.IdType === "Assessment" && i.TID),
      },
    });

    const completedAssessmentCount = userAssessment.filter(
      (userAss) => userAss.Status === "COMPLETED"
    ).length;

    const totalTopicsCount = TotalTopicIds.length;
    const progress = Math.round(
      (completedTopicsCount + completedAssessmentCount / totalTopicsCount) * 100
    );

    const userModule = await UserModule.findOne({
      where: { MID: MID, UID: userId, CID: CID },
    });
    const moduleStatus =
      completedTopicsCount + completedAssessmentCount === totalTopicsCount
        ? "COMPLETED"
        : "InProgress";

    if (userModule) {
      const moduleStatus =
        completedTopicsCount + completedAssessmentCount === totalTopicsCount
          ? "COMPLETED"
          : "InProgress";
      await UserModule.update(
        {
          STATUS: moduleStatus,
          PROGRESS: `${progress}`,
        },
        { where: { MID: MID, UID: userId, CID: CID } }
      );
    }

    // -------------- UPDATE COURSE PROGRESS

    const AllCourseModules = await CourseModuleTopic.findAll({
      where: { CID: CID },
    });

    const FinalAssessments = AllCourseModules.filter(
      (i: any) => i.IdType === "Final Assessment"
    );
    let NoOfTasks: any;

    if (FinalAssessments.length > 0) {
      NoOfTasks = AllCourseModules.length + 1 - FinalAssessments.length;
    } else {
      NoOfTasks = AllCourseModules.length;
    }

    const moduleTopicIds = AllCourseModules.filter(
      (e) => e.IdType === null
    ).map((topic) => topic.TID);
    const moduleAsses = AllCourseModules.filter(
      (e) => e.IdType === "Assessment"
    ).map((topic) => topic.TID);

    const userTopicsForMOdule = await UserTopic.findAll({
      where: { TID: moduleTopicIds, UID: userId },
    });
    const userAssessForMOdule = await UserAssessment.findAll({
      where: { AID: moduleAsses, UID: userId },
    });

    const completedModuleTopicsCount = userTopicsForMOdule.filter(
      (userTopic) => userTopic.STATUS === "COMPLETED"
    ).length;
    const completedModuleAssesCount = userAssessForMOdule.filter(
      (userTopic) => userTopic.Status === "COMPLETED"
    ).length;

    const TotalCompletedTasks =
      completedModuleAssesCount + completedModuleTopicsCount;
    const courseProgress = (TotalCompletedTasks / NoOfTasks) * 100;

    if (FinalAssessments.length > 0) {
      NoOfTasks = AllCourseModules.length - 1 + FinalAssessments.length;
    } else {
      NoOfTasks = AllCourseModules.length;
    }

    const CourseStatus =
      TotalCompletedTasks === NoOfTasks ? "COMPLETED" : "InProgress";

    await UserCourse.update(
      { STATUS: CourseStatus, PROGRESS: `${courseProgress}` },
      {
        where: { CID: CID, UID: userId },
      }
    );

    // const courseModules = await CourseModuleTopic.findAll({
    //   where: { CID: CID },
    // });

    // const TotalModuleTopicIds = courseModules
    //   .filter((e) => e.IdType !== "Final Assessment")
    //   .map((topic) => topic.TID);

    // const moduleTopicIds = courseModules
    //   .filter((e) => e.IdType === null)
    //   .map((topic) => topic.TID);
    // const moduleAsses = courseModules
    //   .filter((e) => e.IdType === "Assessment")
    //   .map((topic) => topic.TID);

    // const userTopicsForMOdule = await UserTopic.findAll({
    //   where: { TID: moduleTopicIds, UID: userId },
    // });
    // const userAssessForMOdule = await UserAssessment.findAll({
    //   where: { AID: moduleAsses, UID: userId },
    // });

    // const completedModuleTopicsCount = userTopicsForMOdule.filter(
    //   (userTopic) => userTopic.STATUS === "COMPLETED"
    // ).length;
    // const completedModuleAssesCount = userAssessForMOdule.filter(
    //   (userTopic) => userTopic.Status === "COMPLETED"
    // ).length;

    // const TotalTasks = completedModuleAssesCount + completedModuleTopicsCount;

    // const GetFinal = courseModules.filter(
    //   (i: any) => i.IdType === "Final Assessment"
    // );

    // const totalModuleTopicsCount = TotalModuleTopicIds.length;
    // const percent = GetFinal.length === 0 ? 100 : 90;
    // const courseProgress =
    //   Math.round(TotalTasks / totalModuleTopicsCount) * percent;

    // const userCourse = await UserCourse.findOne({
    //   where: { CID: CID, UID: userId },
    // });
    // // console.log(
    // //   "TotalTasks------------------------------------------------------",
    // //   TotalTasks
    // // );
    // // console.log(
    // //   "totalModuleTopicsCount------------------------------------------------------",
    // //   totalModuleTopicsCount
    // // );
    // // console.log(
    // //   "percent------------------------------------------------------",
    // //   percent
    // // );
    // // console.log(
    // //   "(TotalTasks / totalModuleTopicsCount)------------------------------------------------------",
    // //   (TotalTasks / totalModuleTopicsCount) * percent
    // // );
    // // console.log(
    // //   "courseProgress------------------------------------------------------",
    // //   courseProgress
    // // );
    // // console.log(
    // //   "moduleStatus------------------------------------------",
    // //   TotalTasks === totalModuleTopicsCount ? "COMPLETED" : "InProgress"
    // // );

    // if (userCourse) {
    //   const moduleStatus =
    //     TotalTasks === totalModuleTopicsCount ? "COMPLETED" : "InProgress";
    //   if (moduleStatus === "COMPLETED" && GetFinal.length === 0) {
    //     userCourse.STATUS = moduleStatus;
    //     userCourse.PROGRESS = `${courseProgress}`;
    //     await UserCourse.update(
    //       { STATUS: moduleStatus, PROGRESS: `${courseProgress}` },
    //       {
    //         where: { CID: CID, UID: userId },
    //       }
    //     );
    //     await userCourse.save();
    //   } else if (moduleStatus !== "COMPLETED") {
    //     await UserCourse.update(
    //       { STATUS: moduleStatus, PROGRESS: `${courseProgress}` },
    //       {
    //         where: { CID: CID, UID: userId },
    //       }
    //     );
    //   }
    // }

    return { success: true, message: "User topic status updated successfully" };
  } catch (error) {
    console.error("Error updating user topic status:", error);
    return { success: false, message: "Failed to update user topic status" };
  }
};

export {
  CreateTopicServices,
  GetTopicService,
  UpdateTopicService,
  DeleteTopicService,
  UserTopicStatusService,
  getTopicDetailsByTIDService,
};
