import { AssessmentQuestionAnswer } from "../Model/AssessmentQ&AModel";
import { Course } from "../Model/CourseModel";
import { CourseModuleTopic } from "../Model/CourseModuleTopicModel";
import { Topic } from "../Model/TopicModel";
import { UserAssessment } from "../Model/UserAssessmentModel";
import {
  UserCourse,
  UserCourseCreationAttributes,
} from "../Model/UserCourseModel";
import UserEducation from "../Model/UserEducationModel";
import { User } from "../Model/UserModel";
import {
  UserModule,
  UserModuleCreationAttributes,
} from "../Model/UserModuleModel";
import { UserQuestion } from "../Model/UserQuestionModel";
import {
  UserTopic,
  UserTopicCreationAttributes,
} from "../Model/UserTopicModel";

const EnRollCourseServices = async (
  enRollCourse: UserCourseCreationAttributes
) => {
  try {
    const existingEnrollment = await UserCourse.findOne({
      where: {
        UID: enRollCourse.UID,
        CID: enRollCourse.CID,
      },
    });

    if (existingEnrollment) {
      return {
        success: false,
        message: "User is already enrolled in this course",
      };
    }
    const profile = await User.findByPk(enRollCourse.UID);
    const education = await UserEducation.findOne({
      where: { UID: enRollCourse.UID },
    });

    if (!profile || !education) {
      return {
        success: false,
        message: "user details pending",
        data: {
          profile_status: !profile ? false : true,
          education_status: !education ? false : true,
        },
      };
    } else {
      const newMap = await UserCourse.create(enRollCourse);

      if (newMap) {
        const courseModules = await CourseModuleTopic.findAll({
          where: { CID: enRollCourse.CID },
        });

        const userTopics = courseModules
          .filter((module) => module.IdType === null && module.TID !== null)
          .map((module) => ({
            TID: module.TID,
            UID: enRollCourse.UID,
            PROGRESS: enRollCourse.PROGRESS,
            STATUS: enRollCourse.STATUS,
            CID: enRollCourse.CID,
          }));

        const userModulesMap = new Map<
          string,
          {
            MID: number;
            CID: number;
            UID: number;
            STATUS: string | undefined;
            PROGRESS: string | undefined;
          }
        >();

        courseModules.forEach((module) => {
          if (module.IdType === null) {
            const key = `${enRollCourse.UID}-${module.MID}`;
            if (!userModulesMap.has(key) && enRollCourse.CID !== undefined) {
              userModulesMap.set(key, {
                MID: module.MID,
                UID: enRollCourse.UID,
                CID: enRollCourse.CID,
                STATUS: enRollCourse.STATUS,
                PROGRESS: enRollCourse.PROGRESS,
              });
            }
          }
        });

        const userModules = Array.from(userModulesMap.values());

        await UserTopic.bulkCreate(userTopics as UserTopicCreationAttributes[]);

        const existingModules = await UserModule.findAll({
          where: {
            UID: enRollCourse.UID,
            MID: courseModules.map((module) => module.MID),
          },
        });

        const existingMIDs = existingModules.map((module) => module.MID);
        const newModules = userModules.filter(
          (module) => !existingMIDs.includes(module.MID)
        );
        console.log("newModules", newModules);

        if (newModules.length > 0) {
          await UserModule.bulkCreate(
            newModules as UserModuleCreationAttributes[]
          );
        }

        for (const e of courseModules) {
          if (e.IdType === "Final Assessment" && e.TID === null) {
            try {
              const courseAssessment = await AssessmentQuestionAnswer.findAll({
                where: { AID: e.MID },
              });

              const NewAssesMents = Array.from(
                new Set(courseAssessment.map((item) => item.AID))
              ).map((aid) => courseAssessment.find((item) => item.AID === aid));

              console.log("courseAssessment", courseAssessment);
              console.log("NewAssesMents", NewAssesMents);

              for (const assessment of NewAssesMents) {
                if (
                  assessment &&
                  assessment.AID !== undefined &&
                  enRollCourse &&
                  enRollCourse?.CID !== undefined
                ) {
                  await UserAssessment.create({
                    AID: assessment?.AID,
                    CID: enRollCourse?.CID,
                    UID: enRollCourse.UID,
                    Status: "Not yet started",
                    TimeTakenMins: "0",
                    Attempt: 0,
                  });
                }
              }
              for (const assessment of courseAssessment) {
                if (
                  assessment &&
                  assessment.QID !== undefined &&
                  enRollCourse &&
                  enRollCourse?.CID !== undefined
                )
                  await UserQuestion.create({
                    QID: assessment.QID,
                    AID: assessment?.AID,
                    CID: enRollCourse.CID,
                    UID: enRollCourse.UID,
                    Status: "Not yet started",
                    TimeTakenMins: "0",
                  });
              }
            } catch (error) {
              console.log("Error fetching assessments:", error);
            }
          }
          if (e.IdType === "Assessment" && e.TID) {
            try {
              const courseAssessment = await AssessmentQuestionAnswer.findAll({
                where: { AID: e.TID },
              });

              const NewAssesMents = Array.from(
                new Set(courseAssessment.map((item) => item.AID))
              ).map((aid) => courseAssessment.find((item) => item.AID === aid));

              console.log("NewAssesMents", NewAssesMents);

              for (const assessment of NewAssesMents) {
                if (
                  assessment &&
                  assessment.AID !== undefined &&
                  enRollCourse &&
                  enRollCourse?.CID !== undefined
                ) {
                  await UserAssessment.create({
                    AID: assessment.AID,
                    CID: enRollCourse?.CID,
                    UID: enRollCourse.UID,
                    Status: "Not yet started",
                    TimeTakenMins: "0",
                    Attempt: 0,
                  });
                }
              }
              for (const assessment of courseAssessment) {
                if (
                  assessment &&
                  assessment.QID !== undefined &&
                  enRollCourse &&
                  enRollCourse?.CID !== undefined
                )
                  await UserQuestion.create({
                    QID: assessment.QID,
                    AID: assessment?.AID,
                    CID: enRollCourse?.CID,
                    UID: enRollCourse.UID,
                    Status: "Not yet started",
                    TimeTakenMins: "0",
                  });
              }
            } catch (error) {
              console.log("Error fetching assessments:", error);
            }
          } else {
            console.log("wrong");
          }
        }

        return { success: true, message: "Course Enrolled successfully" };
      } else {
        return { success: false, message: "Failed to enroll in course" };
      }
    }
  } catch (error) {
    console.error("Error enrolling in course:", error);
    return {
      success: false,
      message: "An error occurred while enrolling in the course",
    };
  }
};

const getEnRollCourseByUIdService = async (
  Id: number
): Promise<{
  success: boolean;
  data?: any[];
  message?: string;
}> => {
  try {
    const userCourses = await UserCourse.findAll({
      where: { UID: Id },
    });

    if (userCourses.length === 0) {
      return {
        success: true,
        data: [],
        message: "No courses found for the user",
      };
    }

    const courseDetailsPromises = userCourses.map(async (userCourse) => {
      const courseDetails = await Course.findOne({
        where: { CID: userCourse.CID },
      });
      const AssessmentSpent = await UserAssessment.findAll({
        where: { UID: Id, CID: userCourse.CID },
      });

      const TopicSpent = await UserTopic.findAll({
        where: { UID: Id, STATUS: "COMPLETED", CID: userCourse.CID },
      });
      const TopicDuration = await Topic.findAll({
        where: { TID: TopicSpent.map((i) => i.TID) },
      });

      const totalDurationForTopoics = TopicDuration.reduce((acc, topic) => {
        return acc + Number(topic.DURATION);
      }, 0);

      const totalMinutesForAssessment = AssessmentSpent.reduce(
        (acc: any, item: any) => {
          const time = item.TimeTakenMins;
          if (time === "0" || time === "00:00:00") return acc;

          const [hours, minutes, seconds] = time.split(":").map(Number);
          const total = hours * 60 + minutes + seconds / 60;
          return acc + total;
        },
        0
      );

      const TimeSpent =
        Number(totalMinutesForAssessment) + Number(totalDurationForTopoics);
      const formatTime = () => {
        const hours = Math.floor(TimeSpent / 60);
        const mins = Math.round(TimeSpent % 60);
        return `${hours} hrs ${mins} min`;
      };

      return {
        ...userCourse.toJSON(),
        // TIME_SPENT: TimeSpent.toString().split(".")[0],
        TIME_SPENT: formatTime(),
        courseDetails: courseDetails ? courseDetails.toJSON() : null,
      };
    });

    const detailedUserCourses = await Promise.all(courseDetailsPromises);

    return { success: true, data: detailedUserCourses };
  } catch (error) {
    console.error("Error fetching user courses and course details:", error);
    return {
      success: false,
      message: "Failed to fetch user courses and course details",
    };
  }
};

export { EnRollCourseServices, getEnRollCourseByUIdService };
