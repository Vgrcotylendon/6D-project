import { where } from "sequelize";
import {
  Certification,
  CertificationCreationAttributes,
} from "../Model/CertificationModel";

const CreateCertificationService = async (
  certification: CertificationCreationAttributes
) => {
  try {
    await Certification.create(certification);
    return true;
  } catch (error) {
    console.error("Error in CreateCertificationService:", error);
    return false;
  }
};
const GetCertificationService = async () => {
  try {
    const result = await Certification.findAll();
    return result;
  } catch (error) {
    console.error("Error in GetCertificationService:", error);
    throw new Error("Error fetching certifications");
  }
};
const UpdateCertificationService = async (
  CID: any,
  certification: CertificationCreationAttributes
) => {
  try {
    const existing = await Certification.findOne({
      where: { CID: CID },
    });

    if (!existing) {
      return { success: false, message: "Certification not found" };
    }

    const [affectedRows] = await Certification.update(certification, {
      where: { CID: CID },
    });

    if (affectedRows === 0) {
      return { success: false, message: "No rows updated" };
    }

    return { success: true, message: "Certification updated successfully" };
  } catch (error) {
    console.error("Error in UpdateCertificationService:", error);
    return { success: false, message: "Error updating certification" };
  }
};
const DeleteCertificationService = async (CID: number) => {
  try {
    const result = await Certification.destroy({ where: { CID } });

    if (result > 0) {
      return { success: true, message: "Certification deleted successfully" };
    } else {
      return { success: false, message: "Certification not found" };
    }
  } catch (error) {
    console.error("Error on deleting certification:", error);
    return {
      success: false,
      message: "An error occurred while deleting the certification",
    };
  }
};
export {
  CreateCertificationService,
  GetCertificationService,
  UpdateCertificationService,
  DeleteCertificationService,
};
