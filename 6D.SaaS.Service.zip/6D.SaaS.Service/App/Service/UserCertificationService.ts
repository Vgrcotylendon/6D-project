import {
  UserCertification,
  UserCertificationCreationAttributes,
} from "../Model/UserCertificationModel";

const CreateUserCertificationService = async (
  usercertification: UserCertificationCreationAttributes
): Promise<{ success: boolean; message: string }> => {
  try {
    await UserCertification.create(usercertification);
    return {
      success: true,
      message: "User certification created successfully",
    };
  } catch (error) {
    console.error("Error creating user certification:", error);
    return { success: false, message: "Failed to create user certification" };
  }
};

const GetUserCertificationService = async () => {
  try {
    const result = await UserCertification.findAll();
    return { success: true, data: result };
  } catch (error) {
    console.error("Error fetching user certifications:", error);
    return { success: false, message: "Failed to fetch user certifications" };
  }
};

const UpdateUserCertificationService = async (
  id: string,
  usercertification: UserCertificationCreationAttributes
): Promise<{ success: boolean; message?: string }> => {
  try {
    const existing = await UserCertification.findOne({ where: { UCID: id } });
    if (!existing) {
      return { success: false, message: "User certification not found" };
    }

    const [updatedRows] = await UserCertification.update(usercertification, {
      where: { UCID: id },
    });

    if (updatedRows > 0) {
      return {
        success: true,
        message: "User certification updated successfully",
      };
    } else {
      return { success: false, message: "No changes were made" };
    }
  } catch (error) {
    console.error("Error updating user certification:", error);
    return { success: false, message: "Failed to update user certification" };
  }
};

const DeleteUserCertificationService = async (id: string) => {
  try {
    const existing = await UserCertification.findOne({ where: { UCID: id } });
    if (!existing) {
      return { success: false, message: "User certification not found" };
    }

    const deletedRows = await UserCertification.destroy({
      where: { UCID: id },
    });

    if (deletedRows > 0) {
      return {
        success: true,
        message: "User certification deleted successfully",
      };
    } else {
      return { success: false, message: "No record was deleted" };
    }
  } catch (error) {
    console.error("Error deleting user certification:", error);
    return { success: false, message: "Failed to delete user certification" };
  }
};

export {
  CreateUserCertificationService,
  GetUserCertificationService,
  UpdateUserCertificationService,
  DeleteUserCertificationService,
};
