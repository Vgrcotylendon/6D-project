import { Course, CourseCreationAttributes } from "../Model/CourseModel";
import { UserCourse } from "../Model/UserCourseModel";
import { Module } from "../Model/ModuleModel";
import { Topic } from "../Model/TopicModel";
import { CourseModuleTopic } from "../Model/CourseModuleTopicModel";
import { Assessment } from "../Model/AssestmentModel";
import { where } from "sequelize";

const CreateCourseServices = async (course: CourseCreationAttributes) => {
  try {
    const courseWithAvailability = {
      ...course,
      DURATION: course.DURATION ? Number(course.DURATION) : 0,
    };

    const Creatingcourse = await Course.create(courseWithAvailability);
    if (Creatingcourse) {
      return { success: true, message: "Course Created successfully" };
    } else {
      return { success: false, message: "Failed to create course" };
    }
  } catch (error) {
    console.error("Error to  create course:", error);
    return {
      success: false,
      message: "An error occurred while  Creating Course",
    };
  }
};

const GetCourseServices = async (id: number) => {
  try {
    const getcourse = await Course.findOne({ where: { CID: id } });
    if (getcourse) {
      return getcourse;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on fetching get-course:", error);
    return {
      success: false,
      message: "An error occurred while getting course",
    };
  }
};

const getAllCourseServices = async () => {
  try {
    const getcourse = await Course.findAll();
    if (getcourse) {
      return getcourse;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on fetching get-course:", error);
    return {
      success: false,
      message: "An error occurred while getting course",
    };
  }
};
const getAllCourseWithStatusServices = async (UID: number) => {
  try {
    // console.log(UID);
    const getcourse = await Course.findAll();

    const CourseModule = await CourseModuleTopic.findAll({
      where: { CID: getcourse.map((i: any) => i.CID) },
    });
    // console.log(
    //   "CourseModule----------------------------",
    //   CourseModule.map((i) => ({
    //     MapID: i.MapID,
    //     CID: i.CID,
    //     MID: i.MID,
    //     ModuleOrder: i.ModuleOrder,
    //     TID: i.TID,
    //     TopicOrder: i.TopicOrder,
    //     IdType: i.IdType,
    //   }))
    // );

    const ModulesCID = CourseModule.map((i: any) => i.CID);
    // console.log(
    //   "ModulesCID========================================",
    //   ModulesCID
    // );

    const GetUserCourse = await UserCourse.findAll({
      where: { UID: Number(UID) },
    });
    const getStatus = (id: any) => {
      const index = GetUserCourse.findIndex((i) => i.CID === id);
      // console.log("index", index);

      const status = GetUserCourse[index];
      // console.log("status", status);

      return status ? status : null;
    };

    const courseWithStatus = getcourse
      .filter((i) => i.AVAILABILITY === "Y" && ModulesCID.includes(i.CID))
      .map((i: any) => {
        const details = getStatus(i.CID);
        // console.log("i.CID", i.CID);

        return {
          ...i.dataValues,
          enrolled: details && details.STATUS ? "Y" : "N",
        };
      })
      .filter((i) => i.enrolled === "N");
    // console.log("courseWithStatus", courseWithStatus);

    const addTimeSpent = await Promise.all(
      courseWithStatus.map(async (i: any) => {
        const TIDs = CourseModule.filter(
          (j: any) => i.CID === j.CID && j.TID !== null && j.IdType === null
        );

        const newTime = await Promise.all(
          TIDs.map(async (k: any) => {
            const TopicDuration = await Topic.findAll({
              where: {
                TID: k.TID,
              },
            });

            const totalDurationForTopics = TopicDuration.reduce(
              (acc, topic) => {
                return acc + Number(topic.DURATION);
              },
              0
            );

            const TimeSpent = Number(totalDurationForTopics);

            return TimeSpent;
          })
        );

        const time = newTime.reduce((acc: any, i: any) => {
          return i + acc;
        }, 0);

        return { ...i, timespent: time.toString() };
      })
    );

    const result = addTimeSpent;

    if (getcourse) {
      return result;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on fetching get-course:", error);
    return {
      success: false,
      message: "An error occurred while getting course",
    };
  }
};

const getAllCourseByUserIdServices = async (userId: number) => {
  try {
    const getAllCourses = await Course.findAll();
 
    const getUserCourses = await UserCourse.findAll({ where: { UID: userId } });
    const userEnrolledCourses = getUserCourses.map((course) => course.CID);
 
    const courseMap: { [key: number]: any } = {};
    const userStatus = getUserCourses.map((course) => ({
      STATUS: course.STATUS,
      CID: course.CID,
    }));
    console.log("userStatus", userStatus);
 
    const getCourseDetail = (id: number) => {
      const index = userStatus.findIndex((i) => i.CID === id);
      const details = userStatus[index]?.STATUS;
      if (details) {
        return details;
      } else {
        return "";
      }
    };
 
    await Promise.all(
      getAllCourses.map(async (course) => {
        const { CID } = course;
 
        const userEnrolled = userEnrolledCourses.includes(CID);
 
        const courseModuleTopics = await CourseModuleTopic.findAll({
          where: { CID },
        });
 
        const courseDetail = getCourseDetail(CID);
        console.log("courseDetail", courseDetail);
 
        await Promise.all(
          courseModuleTopics.map(async (courseModuleTopic) => {
            const { MID, TID, IdType } = courseModuleTopic;
            console.log(" MID, TID, IdType", MID, TID, IdType);
 
            if (!courseMap[CID]) {
              courseMap[CID] = {
                ...course.toJSON(),
                userEnrolled,
                // userStatus: courseDetail !== undefined ? courseDetail : "",
                userStatus:
                  getCourseDetail(CID) !== undefined
                    ? getCourseDetail(CID)
                    : "",
              };
            }
          })
        );
      })
    );
 
    const result = Object.values(courseMap);
 
    const addTimeSpent = await Promise.all(
      result.map(async (i: any) => {
        const CourseMloldules = await CourseModuleTopic.findAll({
          where: { CID: i.CID },
        });
        const TIDs = CourseMloldules.filter(
          (j: any) => i.CID === j.CID && j.TID !== null && j.IdType === null
        );
 
        const newTime = await Promise.all(
          TIDs.map(async (k: any) => {
            const TopicDuration = await Topic.findAll({
              where: {
                TID: k.TID,
              },
            });
 
            const totalDurationForTopics = TopicDuration.reduce(
              (acc, topic) => {
                return acc + Number(topic.DURATION);
              },
              0
            );
 
            const TimeSpent = Number(totalDurationForTopics);
 
            return TimeSpent;
          })
        );
 
        const time = newTime.reduce((acc: any, i: any) => {
          return i + acc;
        }, 0);
 
        return { ...i, timespent: time.toString() };
      })
    );
 
    return addTimeSpent;
  } catch (error) {
    console.error("Error fetching courses:", error);
    return {
      success: false,
      message: `An error occurred while getting courses: ${error}`,
    };
  }
};

const UpdateCourseServices = async (
  course: CourseCreationAttributes,
  id: number
) => {
  try {
    const user = await Course.findOne({ where: { CID: id } });
    if (!user) {
      throw new Error("user not found");
    }
    await Course.update(course, { where: { CID: id } });
    const updatedCourse = await Course.findOne({
      where: { CID: id },
    });
    return updatedCourse;
  } catch (error) {
    console.error(error);
    throw new Error("Failed to update course");
  }
};

const DeleteCourseService = async (id: number) => {
  try {
    const course = await Course.destroy({ where: { CID: id } });
    if (course) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error on deleting course:", error);
    return {
      success: false,
      message: "An error occurred while delete Course ",
    };
  }
};

const getCourseDetailsByIdServices = async (CID: number) => {
  try {
    const getcourseModule = await CourseModuleTopic.findAll({
      where: { CID: CID },
    });
    const CourseDetails = await Course.findOne({ where: { CID } });

    const GetModuleDetails = async () => {
      const FilteredModules = getcourseModule.filter(
        (i) => i.IdType !== "Final Assessment"
      );

      const detailedModules = await Promise.all(
        FilteredModules.map(async (i: any) => {
          const moduleName = await Module.findOne({ where: { MID: i.MID } });
          const TopicName = await Topic.findOne({ where: { TID: i.TID } });
          const AssessName = await Assessment.findOne({
            where: { AID: i.IdType === "Assessment" && i.TID },
          });
          // console.log(
          //   "AID: i.IdType === Assessment && i.TID--------------------------------------",
          //   i.IdType === "Assessment" && i.TID
          // );
          // console.log(
          //   "AssessName--------------------------------------",
          //   AssessName
          // );

          return {
            ...i.dataValues,
            moduleName: moduleName?.NAME,
            DURATION: moduleName?.DURATION,
            topicName: i.IdType === null ? TopicName?.NAME : null,
            TOPIC_DURATION: i.IdType === null ? TopicName?.DURATION : null,
            assessmentName: i.IdType === "Assessment" ? AssessName?.NAME : null,
          };
        })
      );

      return detailedModules.sort(
        (a, b) =>
          parseInt(a.ModuleOrder) - parseInt(b.ModuleOrder) ||
          parseInt(a.TopicOrder) - parseInt(b.TopicOrder)
      );
    };

    const newModules = await GetModuleDetails();
    const transformModules = () => {
      const transformed = [];

      const moduleMap = newModules.reduce((acc, module) => {
        const moduleKey = module.MID;
        if (!acc[moduleKey]) {
          acc[moduleKey] = {
            CID: module.CID,
            MID: module.MID,
            ModuleOrder: module.ModuleOrder,
            DURATION: module.DURATION,
            moduleName: module.moduleName,
            topics: [],
          };
        }

        // Add the topic details to the topics array
        acc[moduleKey].topics.push({
          TID: module.TID,
          TopicOrder: module.TopicOrder,
          IdType: module.IdType,
          topicName: module.topicName,
          assessmentName: module.assessmentName,
          TOPIC_DURATION: module?.TOPIC_DURATION,
        });

        return acc;
      }, {});

      // Convert the map values to an array
      for (const key in moduleMap) {
        transformed.push(moduleMap[key]);
      }

      return transformed.sort(
        (a, b) =>
          parseInt(a.ModuleOrder) - parseInt(b.ModuleOrder) ||
          parseInt(a.TopicOrder) - parseInt(b.TopicOrder)
      );
    };

    const NewModules = await transformModules();

    const FinalAsses = getcourseModule?.filter(
      (i) => i.IdType === "Final Assessment"
    );
    console.log("FinalAsses----------------------------------", FinalAsses);

    let result;
    if (FinalAsses.length > 0) {
      const GetFinalAssessment = await Assessment.findOne({
        where: { AID: FinalAsses[0]?.MID },
      });

      result = [
        {
          ...CourseDetails?.dataValues,
          Module: NewModules,
          FinalAssessment: GetFinalAssessment
            ? [{ ...GetFinalAssessment?.dataValues }]
            : [],
        },
      ];
      return result;
    } else {
      result = [
        {
          ...CourseDetails?.dataValues,
          Module: NewModules,
          FinalAssessment: [],
        },
      ];

      return result;
    }
  } catch (error) {
    console.error("Error on fetching get-course:", error);
    return {
      success: false,
      message: "An error occurred while getting course",
    };
  }
};
export {
  CreateCourseServices,
  GetCourseServices,
  getAllCourseWithStatusServices,
  getAllCourseByUserIdServices,
  getAllCourseServices,
  UpdateCourseServices,
  DeleteCourseService,
  getCourseDetailsByIdServices,
};
