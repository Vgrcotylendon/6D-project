import { Model, DataTypes } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { User } from "./UserModel";
import { Course } from "./CourseModel";

interface UserCourseAttributes {
  UC_ID: number;
  CID?: number;
  UID: number;
  STATUS?: string;
  PROGRESS?: string;
  ATTEMPT?: number;
  ENROLLED_ON?: Date;
  TIME_SPENT?: number | null;
}

interface UserCourseCreationAttributes
  extends Omit<UserCourseAttributes, "UC_ID"> {}

class UserCourse
  extends Model<UserCourseAttributes, UserCourseCreationAttributes>
  implements UserCourseAttributes
{
  public UC_ID!: number;
  public CID?: number;
  public UID!: number;
  public STATUS?: string;
  public PROGRESS?: string;
  public ATTEMPT?: number;
  public ENROLLED_ON!: Date;
  public TIME_SPENT!: number | null;
}

UserCourse.init(
  {
    UC_ID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    CID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: "Course",
        key: "CID",
      },
    },
    UID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "User",
        key: "UID",
      },
    },
    STATUS: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PROGRESS: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    ATTEMPT: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    ENROLLED_ON: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    TIME_SPENT: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: null,
    },
  },
  {
    sequelize,
    tableName: "User Course",
    timestamps: false,
  }
);

UserCourse.belongsTo(User, { foreignKey: "UID" });
UserCourse.belongsTo(Course, { foreignKey: "CID" });

export { UserCourse, UserCourseCreationAttributes };
