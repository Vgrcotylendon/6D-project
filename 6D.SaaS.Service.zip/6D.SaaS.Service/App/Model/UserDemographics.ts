import { DataTypes, Model, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface UserDemographicsAttributes {
  UD_ID: number;
  UID?: number;
  MAILING_ADDRESS_LINE_1?: string;
  MAILING_ADDRESS_LINE_2?: string;
  MAILING_ADDRESS_CITY?: string;
  MAILING_ADDRESS_STATE?: string;
  MAILING_ADDRESS_COUNTRY?: string;
  MAILING_ADDRESS_PINCODE?: string;
  PERMANENT_ADDRESS_LINE_1?: string;
  PERMANENT_ADDRESS_LINE_2?: string;
  PERMANENT_ADDRESS_CITY?: string;
  PERMANENT_ADDRESS_STATE?: string;
  PERMANENT_ADDRESS_COUNTRY?: string;
  PERMANENT_ADDRESS_PINCODE?: string;
  IS_ADDRESS_SAME?: string;
}

interface UserDemographicsCreationAttributes
  extends Optional<UserDemographicsAttributes, "UD_ID"> {}

class UserDemographics
  extends Model<UserDemographicsAttributes, UserDemographicsCreationAttributes>
  implements UserDemographicsAttributes
{
  public UD_ID!: number;
  public UID?: number;
  public MAILING_ADDRESS_LINE_1?: string;
  public MAILING_ADDRESS_LINE_2?: string;
  public MAILING_ADDRESS_CITY?: string;
  public MAILING_ADDRESS_STATE?: string;
  public MAILING_ADDRESS_COUNTRY?: string;
  public MAILING_ADDRESS_PINCODE?: string;
  public PERMANENT_ADDRESS_LINE_1?: string;
  public PERMANENT_ADDRESS_LINE_2?: string;
  public PERMANENT_ADDRESS_CITY?: string;
  public PERMANENT_ADDRESS_STATE?: string;
  public PERMANENT_ADDRESS_COUNTRY?: string;
  public PERMANENT_ADDRESS_PINCODE?: string;
  public IS_ADDRESS_SAME?: string;
}
UserDemographics.init(
  {
    UD_ID: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    UID: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    MAILING_ADDRESS_LINE_1: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    MAILING_ADDRESS_LINE_2: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    MAILING_ADDRESS_CITY: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    MAILING_ADDRESS_STATE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    MAILING_ADDRESS_COUNTRY: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    MAILING_ADDRESS_PINCODE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PERMANENT_ADDRESS_LINE_1: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PERMANENT_ADDRESS_LINE_2: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PERMANENT_ADDRESS_CITY: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PERMANENT_ADDRESS_STATE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PERMANENT_ADDRESS_COUNTRY: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PERMANENT_ADDRESS_PINCODE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    IS_ADDRESS_SAME: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "User Demographics",
    timestamps: false,
  }
);

export { UserDemographics, UserDemographicsCreationAttributes };
