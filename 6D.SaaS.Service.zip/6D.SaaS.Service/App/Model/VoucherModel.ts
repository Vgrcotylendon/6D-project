import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { Institution } from "./InstitutionModel";
import { User } from "./UserModel";

interface VoucherAttributes {
  vid: number | null;
  voucher_name: string | null;
  voucher_code: string | null;
  voucher_qr: string | null;
  institution: string | null;
  field_of_study: string | null;
  year_of_study: string | null;
  duration_from: string | null;
  duration_to: string | null;
  status: string | null;
  max_shareable: string | null;
  created_by: string | null;
}

interface VoucherCreationAttributes
  extends Optional<VoucherAttributes, "vid"> {}

class Voucher
  extends Model<VoucherAttributes, VoucherCreationAttributes>
  implements VoucherAttributes
{
  public vid!: number | null;
  public voucher_name!: string | null;
  public voucher_code!: string | null;
  public voucher_qr!: string | null;
  public institution!: string | null;
  public field_of_study!: string | null;
  public year_of_study!: string | null;
  public duration_from!: string | null;
  public duration_to!: string | null;
  public status!: string | null;
  public max_shareable!: string | null;
  public created_by!: string | null;
}

Voucher.init(
  {
    vid: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: true,
    },
    voucher_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    voucher_code: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    voucher_qr: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    institution: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    field_of_study: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    year_of_study: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    duration_from: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    duration_to: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    status: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    max_shareable: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    created_by: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "Voucher",
    timestamps: false,
  }
);

export { Voucher, VoucherCreationAttributes };
