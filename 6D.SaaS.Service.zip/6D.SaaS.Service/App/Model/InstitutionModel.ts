import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface InstitutionAttributes {
  IID: number | null;
  Institution_name: string | null;
  Industry: string | null;
  Headquarters: string | null;
  website: string | null;
  company_size: number | null;
  founded_year: string | null;
  overview: string | null;
  ADDRESS_LINE_1: string | null;
  ADDRESS_LINE_2: string | null;
  CITY: string | null;
  STATE: string | null;
  COUNTRY: string | null;
  PINCODE: string | null;
}

interface InstitutionCreationAttributes
  extends Optional<InstitutionAttributes, "IID"> {}

class Institution
  extends Model<InstitutionAttributes, InstitutionCreationAttributes>
  implements InstitutionAttributes
{
  public IID!: number | null;
  public Institution_name!: string | null;
  public Industry!: string | null;
  public Headquarters!: string | null;
  public website!: string | null;
  public company_size!: number | null;
  public founded_year!: string | null;
  public overview!: string | null;
  public ADDRESS_LINE_1!: string | null;
  public ADDRESS_LINE_2!: string | null;
  public CITY!: string | null;
  public STATE!: string | null;
  public COUNTRY!: string | null;
  public PINCODE!: string | null;
}

Institution.init(
  {
    IID: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: true,
    },
    Institution_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
      unique: true,
    },
    Industry: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    Headquarters: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    website: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    company_size: {
      type: DataTypes.FLOAT,
      allowNull: true,
    },
    founded_year: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    overview: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    ADDRESS_LINE_1: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    ADDRESS_LINE_2: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    CITY: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    STATE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    COUNTRY: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PINCODE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "Institution",
    timestamps: false,
  }
);

export { Institution, InstitutionCreationAttributes };
