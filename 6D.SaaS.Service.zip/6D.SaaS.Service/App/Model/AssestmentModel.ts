import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { User } from "./UserModel";

interface AssessmentAttributes {
  AID: number;
  NAME?: string;
  DURATION?: string;
  AUTHOR?: number;
  STATUS?: string;
  cut_off_score?: number;
  assessment_instructions?: string;
  attempt_instructions?: string;
}

interface AssessmentCreationAttributes
  extends Optional<AssessmentAttributes, "AID"> {}

class Assessment
  extends Model<AssessmentAttributes, AssessmentCreationAttributes>
  implements AssessmentAttributes
{
  public AID!: number;
  public NAME?: string;
  public DURATION?: string;
  public AUTHOR?: number;
  public STATUS?: string;
  public cut_off_score?: number;
  public assessment_instructions?: string;
  public attempt_instructions?: string;
}

Assessment.init(
  {
    AID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    NAME: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    DURATION: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    AUTHOR: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: "User",
        key: "6DWORKS_ID",
      },
    },
    STATUS: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    cut_off_score: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    assessment_instructions: {
      type: DataTypes.STRING(5000),
      allowNull: true,
    },
    attempt_instructions: {
      type: DataTypes.STRING(5000),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "Assessment",
    timestamps: false,
  }
);

Assessment.belongsTo(User, { foreignKey: "AUTHOR" });

export { Assessment, AssessmentCreationAttributes };
