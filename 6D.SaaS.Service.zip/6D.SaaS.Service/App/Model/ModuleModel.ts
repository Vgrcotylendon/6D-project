import { Model, DataTypes } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface ModuleAttributes {
  MID: number;
  NAME?: string;
  DURATION?: string;
  STATUS?: string;
  // AUTHOR?: number;
}

interface ModuleCreationAttributes extends Omit<ModuleAttributes, "MID"> {}

class Module
  extends Model<ModuleAttributes, ModuleCreationAttributes>
  implements ModuleAttributes
{
  public MID!: number;
  public NAME?: string;
  public DURATION?: string;
  public STATUS?: string;
  // public AUTHOR?: number;
}

Module.init(
  {
    MID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
    },
    NAME: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    DURATION: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    STATUS: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    // AUTHOR: {
    //   type: DataTypes.INTEGER,
    //   allowNull: true,
    //   references: {
    //     model: "User",
    //     key: "6DWORKS_ID",
    //   },
    // },
  },
  {
    sequelize,
    tableName: "Module",
    timestamps: false,
  }
);

export { Module, ModuleCreationAttributes };
