import { DataTypes, Model, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface UserWorkExperienceAttributes {
  EID: number;
  UID?: number;
  COMPANY_NAME?: string;
  EMPLOYMENT_TYPE?: string;
  JOB_TITLE?: string;
  DURATION?: string;
  START_DATE?: Date;
  END_DATE?: Date;
  ROLE_DESCRIPTION?: string;
  SKILLS?: string[];
}

interface UserWorkExperienceCreationAttributes
  extends Optional<UserWorkExperienceAttributes, "EID"> {}

class UserWorkExperience
  extends Model<
    UserWorkExperienceAttributes,
    UserWorkExperienceCreationAttributes
  >
  implements UserWorkExperienceAttributes
{
  public EID!: number;
  public UID?: number;
  public COMPANY_NAME?: string;
  public EMPLOYMENT_TYPE?: string;
  public JOB_TITLE?: string;
  public DURATION?: string;
  public START_DATE?: Date;
  public END_DATE?: Date;
  public ROLE_DESCRIPTION?: string;
  public SKILLS?: string[];
}
UserWorkExperience.init(
  {
    EID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    UID: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    COMPANY_NAME: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    EMPLOYMENT_TYPE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    JOB_TITLE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    DURATION: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    START_DATE: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    END_DATE: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    ROLE_DESCRIPTION: {
      type: DataTypes.STRING(10000),
      allowNull: true,
    },
    SKILLS: {
      type: DataTypes.JSON,
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "User Work Experience",
    timestamps: false,
  }
);
export default UserWorkExperience;
export { UserWorkExperienceCreationAttributes };
