import { Model, DataTypes } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { User } from "./UserModel";
import { Module } from "./ModuleModel";
import { Course } from "./CourseModel";

interface UserModuleAttributes {
  UM_ID: number;
  CID?: number;
  MID?: number;
  UID: number;
  STATUS?: string;
  PROGRESS?: string;
}

interface UserModuleCreationAttributes extends UserModuleAttributes {}

class UserModule
  extends Model<UserModuleAttributes, UserModuleCreationAttributes>
  implements UserModuleAttributes
{
  public UM_ID!: number;
  public CID?: number;
  public MID?: number;
  public UID!: number;
  public STATUS?: string;
  public PROGRESS?: string;
}

UserModule.init(
  {
    UM_ID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    CID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Course",
        key: "CID",
      },
    },
    MID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: "Module",
        key: "MID",
      },
    },
    UID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "User",
        key: "UID",
      },
    },
    STATUS: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PROGRESS: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "User Module",
    timestamps: false,
  }
);

UserModule.belongsTo(User, { foreignKey: "UID" });
UserModule.belongsTo(Course, { foreignKey: "CID" });
UserModule.belongsTo(Module, { foreignKey: "MID" });

export { UserModule, UserModuleCreationAttributes };
