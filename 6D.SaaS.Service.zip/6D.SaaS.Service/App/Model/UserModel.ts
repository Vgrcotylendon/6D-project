import { DataTypes, Model, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface UserAttributes {
  UID?: number;
  "6DWORKS_ID"?: number | null;
  FIRST_NAME?: string | null;
  LAST_NAME?: string | null;
  MIDDLE_NAME?: string | null;
  IS_VERIFIED?: string | null;
  PASSWORD?: string | null;
  AVATAR_URL?: string | null;
  AVATAR_PUB_ID?: number | null;
  ROLE?: string | null;
  AADAAR_ID?: number | null;
  APAAR_ID?: number | null;
  DATE_OF_BIRTH?: Date | null;
  GENDER?: string | null;
  NATIONALITY?: string | null;
}

interface UserCreationAttributes extends Optional<UserAttributes, "UID"> {}

class User
  extends Model<UserAttributes, UserCreationAttributes>
  implements UserAttributes
{
  public UID!: number;
  public "6DWORKS_ID"!: number | null;
  public FIRST_NAME!: string | null;
  public LAST_NAME!: string | null;
  public MIDDLE_NAME!: string | null;
  public IS_VERIFIED!: string | null;
  public PASSWORD!: string | null;
  public AVATAR_URL!: string | null;
  public AVATAR_PUB_ID!: number | null;
  public ROLE!: string | null;
  public AADAAR_ID!: number | null;
  public APAAR_ID!: number | null;
  public DATE_OF_BIRTH!: Date | null;
  public GENDER!: string | null;
  public NATIONALITY!: string | null;
}

User.init(
  {
    UID: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    "6DWORKS_ID": {
      type: DataTypes.INTEGER,
      unique: true,
    },
    FIRST_NAME: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    LAST_NAME: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    MIDDLE_NAME: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    IS_VERIFIED: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    PASSWORD: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    AVATAR_URL: {
      type: DataTypes.STRING(555),
      allowNull: true,
    },
    AVATAR_PUB_ID: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    ROLE: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    AADAAR_ID: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    APAAR_ID: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    DATE_OF_BIRTH: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    GENDER: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    NATIONALITY: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  { sequelize, tableName: "User", timestamps: false }
);

export { User, UserCreationAttributes };
