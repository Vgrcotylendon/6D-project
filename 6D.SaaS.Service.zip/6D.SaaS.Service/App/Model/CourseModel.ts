import { Model, DataTypes } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface CourseAttributes {
  CID: number;
  TITLE?: string;
  DESCRIPTION?: string;
  DURATION?: number;
  THUMBNAIL?: string;
  AVAILABILITY?: string;
  AUTHOR?: string;
}

interface CourseCreationAttributes extends Omit<CourseAttributes, "CID"> {}

class Course
  extends Model<CourseAttributes, CourseCreationAttributes>
  implements CourseAttributes
{
  public CID!: number;
  public TITLE?: string;
  public DURATION?: number;
  public DESCRIPTION?: string;
  public THUMBNAIL?: string;
  public AVAILABILITY?: string;
  public AUTHOR?: string;
}

Course.init(
  {
    CID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    TITLE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    DESCRIPTION: {
      type: DataTypes.STRING(10000),
      allowNull: true,
    },
    DURATION: {
      type: DataTypes.FLOAT,
      allowNull: true,
    },
    THUMBNAIL: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    AVAILABILITY: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    AUTHOR: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "Course",
    timestamps: false,
  }
);

export { Course, CourseCreationAttributes };
