import { Model, DataTypes } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface CertificationAttributes {
  CID: number;
  TITLE: string;
  DESCRIPTION?: string;
  MODULES?: string;
  LENGTH?: string;
  PROVIDER: string;
  IS_READY: string;
  AUTHOR: number;
}

interface CertificationCreationAttributes
  extends Omit<CertificationAttributes, "CID"> {}

class Certification
  extends Model<CertificationAttributes, CertificationCreationAttributes>
  implements CertificationAttributes
{
  public CID!: number;
  public TITLE!: string;
  public DESCRIPTION!: string;
  public MODULES!: string;
  public LENGTH!: string;
  public PROVIDER!: string;
  public IS_READY!: string;
  public AUTHOR!: number;
}

Certification.init(
  {
    CID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    TITLE: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    DESCRIPTION: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    MODULES: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    LENGTH: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PROVIDER: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    IS_READY: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    AUTHOR: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "User",
        key: "6DWORKS_ID",
      },
    },
  },
  {
    sequelize,
    tableName: "Certification",
    timestamps: false,
  }
);

export { Certification, CertificationCreationAttributes };
