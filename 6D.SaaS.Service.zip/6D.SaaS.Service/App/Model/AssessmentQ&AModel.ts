import { Model, DataTypes } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface AssessmentQuestionAnswerAttributes {
  AID: number;
  QID: number;
  QuestionOrder?: string;
  AnsID: number;
  AnswerOrder?: string;
}

interface AssessmentQuestionAnswerCreationAttributes
  extends AssessmentQuestionAnswerAttributes {}

class AssessmentQuestionAnswer
  extends Model<
    AssessmentQuestionAnswerAttributes,
    AssessmentQuestionAnswerCreationAttributes
  >
  implements AssessmentQuestionAnswerAttributes
{
  public AID!: number;
  public QID!: number;
  public QuestionOrder?: string;
  public AnsID!: number;
  public AnswerOrder?: string;
}

AssessmentQuestionAnswer.init(
  {
    AID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      references: {
        model: "Assessment",
        key: "AID",
      },
    },
    QID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      references: {
        model: "Question",
        key: "QID",
      },
    },
    QuestionOrder: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    AnsID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      references: {
        model: "Answer",
        key: "AnsID",
      },
    },
    AnswerOrder: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "AssessmentQuestionAnswer",
    timestamps: false,
  }
);

export { AssessmentQuestionAnswer, AssessmentQuestionAnswerCreationAttributes };
