import { DataTypes, Model, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface userCredential {
  ID: number;
  email: string | null;
  mobile: string | null;
  code: number | null;
  enabled: string | null;
  userName?: string | null;
  password: string | null;
  attempt?: number | null;
  accountOrigin?: string | null;
}

interface userCredentialsAttributes extends Optional<userCredential, "ID"> {}

class UserCredentials
  extends Model<userCredential, userCredentialsAttributes>
  implements userCredential
{
  public ID: number;
  public email: string | null;
  public mobile: string | null;
  public code: number | null;
  public enabled: string | null;
  public userName: string | null;
  public password!: string | null;
  public attempt: number | null;
  public accountOrigin: string | null;
}

UserCredentials.init(
  {
    ID: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    mobile: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    code: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    enabled: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    userName: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    attempt: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    accountOrigin: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "UserCredentials",
    timestamps: false,
  }
);

export { UserCredentials, userCredentialsAttributes };
