import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { User } from "./UserModel";
import { Choice } from "./ChoiceModel";
import { Question } from "./QuestionModel";
import { Assessment } from "./AssestmentModel";
import { Course } from "./CourseModel";

interface UserAnswerAttributes {
  UA_ID: number;
  CID: number;
  AID: number;
  ChoiceID: string;
  QID: number;
  UID: number;
  IsCorrect?: boolean;
}

interface UserAnswerCreationAttributes
  extends Optional<UserAnswerAttributes, "UA_ID"> {}

class UserAnswer
  extends Model<UserAnswerAttributes, UserAnswerCreationAttributes>
  implements UserAnswerAttributes
{
  public UA_ID!: number;
  public CID!: number;
  public AID!: number;
  public ChoiceID!: string;
  public QID!: number;
  public UID!: number;
  public IsCorrect?: boolean;
}

UserAnswer.init(
  {
    UA_ID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    CID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Course",
        key: "CID",
      },
    },
    AID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Assessment",
        key: "AID",
      },
    },
    ChoiceID: {
      type: DataTypes.STRING(50),
      allowNull: false,
      // references: {
      //   model: "Choice",
      //   key: "ChoiceID",
      // },
    },
    QID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Question",
        key: "QID",
      },
    },
    UID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "User",
        key: "UID",
      },
    },
    IsCorrect: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "UserAnswer",
    timestamps: false,
  }
);

UserAnswer.belongsTo(User, { foreignKey: "UID" });
// UserAnswer.belongsTo(Choice, { foreignKey: "ChoiceID" });
UserAnswer.belongsTo(Course, { foreignKey: "CID" });
UserAnswer.belongsTo(Question, { foreignKey: "QID" });
UserAnswer.belongsTo(Assessment, { foreignKey: "AID" });

export { UserAnswer, UserAnswerCreationAttributes };
