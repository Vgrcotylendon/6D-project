import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { User } from "./UserModel";
import { UserInvite } from "./UserInviteModel";

interface UserContactAttributes {
  UCID?: number;
  UID?: number;
  PHONE_NUMBER?: string;
  EMAIL?: string;
  LINKEDIN?: string;
}

interface UserContactCreationAttributes
  extends Optional<UserContactAttributes, "UCID"> {}

class UserContact
  extends Model<UserContactAttributes, UserContactCreationAttributes>
  implements UserContactAttributes
{
  public UCID!: number;
  public UID!: number;
  public PHONE_NUMBER!: string;
  public EMAIL!: string;
  public LINKEDIN!: string;
}

UserContact.init(
  {
    UCID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      primaryKey: true,
      autoIncrement: true,
    },
    UID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: User,
        key: "6DWORKS_ID",
      },
    },
    PHONE_NUMBER: {
      type: DataTypes.STRING(15),
      allowNull: true,
    },
    EMAIL: {
      type: DataTypes.STRING,
      allowNull: true,
      // references: {
      //   model: UserInvite,
      //   key: "EMAIL",
      // },
    },
    LINKEDIN: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "User Contact",
    timestamps: false,
  }
);


export { UserContact, UserContactCreationAttributes };
