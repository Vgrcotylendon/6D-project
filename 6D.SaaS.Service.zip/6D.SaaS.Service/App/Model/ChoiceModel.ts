import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { Question } from "./QuestionModel";

interface ChoiceAttributes {
  ChoiceID: number;
  QID: number;
  Choice: string;
  IsCorrect: boolean;
}

interface ChoiceCreationAttributes
  extends Optional<ChoiceAttributes, "ChoiceID"> {}

class Choice
  extends Model<ChoiceAttributes, ChoiceCreationAttributes>
  implements ChoiceAttributes
{
  public ChoiceID!: number;
  public QID!: number;
  public Choice!: string;
  public IsCorrect!: boolean;
}

Choice.init(
  {
    ChoiceID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    QID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Question",
        key: "QID",
      },
    },
    Choice: {
      type: DataTypes.STRING(10000),
      allowNull: false,
    },
    IsCorrect: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
    },
  },
  {
    sequelize,
    tableName: "Choices",
    timestamps: false,
  }
);

Choice.belongsTo(Question, { foreignKey: "QID" });

export { Choice, ChoiceCreationAttributes };
