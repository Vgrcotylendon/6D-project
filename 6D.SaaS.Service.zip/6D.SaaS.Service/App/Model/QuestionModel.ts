import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface QuestionAttributes {
  QID: number;
  Question?: string;
  Type?: string;
  QuestionType?: string;
  CorrectAnswer?: number;
  Hint?: string;
}

interface QuestionCreationAttributes
  extends Optional<QuestionAttributes, "QID"> {}

class Question
  extends Model<QuestionAttributes, QuestionCreationAttributes>
  implements QuestionAttributes
{
  public QID!: number;
  public Question?: string;
  public Type?: string;
  public QuestionType?: string;
  public CorrectAnswer?: number;
  public Hint?: string;
}

Question.init(
  {
    QID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    Question: {
      type: DataTypes.STRING(10000),
      allowNull: true,
    },
    Type: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    QuestionType: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    CorrectAnswer: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: "Answer",
        key: "AnsID",
      },
    },
    Hint: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "Question",
    timestamps: false,
  }
);

export { Question, QuestionCreationAttributes };
