import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface StudentInviteAttributes {
  sid?: number;
  first_name?: string;
  middle_name?: string;
  last_name?: string;
  field_of_study?: string;
  year_of_study?: string;
  semester?: string;
}

interface StudentInviteCreationAttributes
  extends Optional<StudentInviteAttributes, "sid"> {}

class StudentInvite
  extends Model<StudentInviteAttributes, StudentInviteCreationAttributes>
  implements StudentInviteAttributes
{
  public sid!: number;
  public first_name!: string;
  public middle_name!: string;
  public last_name!: string;
  public field_of_study!: string;
  public year_of_study!: string;
  public semester!: string;
}

StudentInvite.init(
  {
    sid: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    first_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    middle_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    last_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    field_of_study: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    year_of_study: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    semester: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "Student_Invites",
    timestamps: false,
  }
);

export { StudentInviteCreationAttributes, StudentInvite };
