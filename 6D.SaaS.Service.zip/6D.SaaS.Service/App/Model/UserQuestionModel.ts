import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { User } from "./UserModel";
import { Question } from "./QuestionModel";
import { Course } from "./CourseModel";
import { Assessment } from "./AssestmentModel";

interface UserQuestionAttributes {
  UQ_ID: number;
  AID: number;
  CID: number;
  QID: number;
  UID: number;
  Status?: string;
  TimeTakenMins?: string;
}

interface UserQuestionCreationAttributes
  extends Optional<UserQuestionAttributes, "UQ_ID"> {}

class UserQuestion
  extends Model<UserQuestionAttributes, UserQuestionCreationAttributes>
  implements UserQuestionAttributes
{
  public UQ_ID!: number;
  public AID!: number;
  public CID!: number;
  public QID!: number;
  public UID!: number;
  public Status?: string;
  public TimeTakenMins?: string;
}

UserQuestion.init(
  {
    UQ_ID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    CID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Course",
        key: "CID",
      },
    },
    AID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Assessment",
        key: "AID",
      },
    },
    QID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Question",
        key: "QID",
      },
    },
    UID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "User",
        key: "UID",
      },
    },
    Status: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    TimeTakenMins: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "UserQuestion",
    timestamps: false,
  }
);

UserQuestion.belongsTo(User, { foreignKey: "UID" });
UserQuestion.belongsTo(Course, { foreignKey: "CID" });
UserQuestion.belongsTo(Assessment, { foreignKey: "AID" });
UserQuestion.belongsTo(Question, { foreignKey: "QID" });

export { UserQuestion, UserQuestionCreationAttributes };
