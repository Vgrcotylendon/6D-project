import { init } from "../Configuration/Config";
import { Assessment } from "./AssestmentModel";
import { Certification } from "./CertificationModel";
import { Course } from "./CourseModel";
import { Institution } from "./InstitutionModel";
import { JobDetails } from "./JobDetailsModel";
import { MobileUsers } from "./MobileOtpModel";
import { Module } from "./ModuleModel";
import { StudentInvite } from "./StudentInviteModel";
import { UserCertification } from "./UserCertificationModel";
import { UserContact } from "./UserContact";
import { UserCredentials } from "./UserCredModel";
import { UserDemographics } from "./UserDemographics";
import UserEducation from "./UserEducationModel";
import { UserInvite } from "./UserInviteModel";
import { User } from "./UserModel";
import { UserTokens } from "./UserTokenModel";
import { Voucher } from "./VoucherModel";
import UserWorkExperience from "./WorkExperienceModel";
import { Answer } from "./AnswerModel";
import { AssessmentQuestionAnswer } from "./AssessmentQ&AModel";
import { CourseModuleTopic } from "./CourseModuleTopicModel";
import { Question } from "./QuestionModel";
import { Topic } from "./TopicModel";
import { UserAnswer } from "./UserAnswerModel";
import { UserAssessment } from "./UserAssessmentModel";
import { UserCourse } from "./UserCourseModel";
import { UserModule } from "./UserModuleModel";
import { UserQuestion } from "./UserQuestionModel";
import { UserTopic } from "./UserTopicModel";
import { Choice } from "./ChoiceModel";

export const Model = async () => {
  try {
    await init();

    // First create the tables that do not have dependencies
    await User.sync();
    await StudentInvite.sync();
    await UserInvite.sync();
    await UserCredentials.sync();
    await MobileUsers.sync();
    await UserTokens.sync();
    await Institution.sync();
    await JobDetails.sync();
    await Voucher.sync();
    await Course.sync();
    await Module.sync();
    await Assessment.sync();
    await Certification.sync();
    await UserCertification.sync();
    await UserContact.sync();
    await UserDemographics.sync();
    await UserEducation.sync();
    await UserWorkExperience.sync();
    await Answer.sync();
    await Question.sync(); // Question should be created before it is referenced
    await Topic.sync();
    await CourseModuleTopic.sync();

    // Now create Choice since it's referenced in UserAnswer
    await Choice.sync(); // Sync the Choice table first

    // Sync tables that depend on others, after ensuring their dependencies are created
    await UserCourse.sync();
    await UserModule.sync();
    await UserTopic.sync();
    await UserAnswer.sync(); // Now UserAnswer can be synced since Choice is created
    await AssessmentQuestionAnswer.sync();
    await UserAssessment.sync();
    await UserQuestion.sync();

    console.log("Models synced.");
  } catch (error) {
    console.error("Error in Model function:", error);
  }
};
