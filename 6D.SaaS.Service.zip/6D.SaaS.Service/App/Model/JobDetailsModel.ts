import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface JobDetailsAttributes {
  jid: number | null;
  job_name: string | null;
  job_title: string | null;
  hiring_company: string | null;
  work_location: string | null;
  employment_type: string | null;
  work_mode: string | null;
  positions: string | null;
  stipend: string | null;
  submission_date: Date | null;
  hiring_date: Date | null;
  role_description: string | null;
  responsibilities: string | null;
  required_certification: string | null;
}

interface JobDetailsCreationAttributes
  extends Optional<JobDetailsAttributes, "jid"> {}

class JobDetails
  extends Model<JobDetailsAttributes, JobDetailsCreationAttributes>
  implements JobDetailsAttributes
{
  public jid!: number | null;
  public job_name!: string | null;
  public job_title!: string | null;
  public hiring_company!: string | null;
  public work_location!: string | null;
  public employment_type!: string | null;
  public work_mode!: string | null;
  public positions!: string | null;
  public stipend!: string | null;
  public submission_date!: Date | null;
  public hiring_date!: Date | null;
  public role_description!: string | null;
  public responsibilities!: string | null;
  public required_certification!: string | null;
}

JobDetails.init(
  {
    jid: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: true,
    },
    job_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    job_title: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    hiring_company: {
      type: DataTypes.STRING(255),
      allowNull: true,
      references: {
        model: "Institution",
        key: "Institution_name",
      },
    },
    work_location: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    employment_type: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    work_mode: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    positions: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    stipend: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    submission_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    hiring_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    role_description: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    responsibilities: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    required_certification: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "Job Details",
    timestamps: false,
  }
);

export { JobDetails, JobDetailsCreationAttributes };
