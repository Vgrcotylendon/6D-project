import { Model, DataTypes } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface UserCertificationAttributes {
  UCID: number;
  UID?: number;
  CID?: number;
  STATUS?: string;
}

interface UserCertificationCreationAttributes
  extends Omit<UserCertificationAttributes, "UCID"> {}
  class UserCertification
  extends Model<
    UserCertificationAttributes,
    UserCertificationCreationAttributes
  >
  implements UserCertificationAttributes
{
  public UCID!: number;
  public UID!: number;
  public CID!: number;
  public STATUS!: string;
}

UserCertification.init(
  {
    UCID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    UID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: "User",
        key: "6DWORKS_ID",
      },
    },
    CID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: "Certification",
        key: "CID",
      },
    },
    STATUS: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "User Certification",
    timestamps: false,
  }
);

export { UserCertification, UserCertificationCreationAttributes };
