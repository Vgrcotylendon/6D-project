import { DataTypes, Model, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { User } from "./UserModel";

interface UserEducationAttributes {
  UEID?: number;
  UID?: number;
  MAJOR?: string;
  GRADUATION_YEAR?: string;
  TERM?: string;
  INSTITUTION_ID?: string;
  INSTITUTION_NAME?:string;
  DOJ?: Date;
  PLACEMENT_CELL_CO_ID?: number;
  COUNTRY?: string;
  STATE?: string;
  CITY?: string;
  ADDRESS_LINE_1?: string;
  ADDRESS_LINE_2?: string;
  PINCODE?: string;
}

interface UserEducationCreationAttributes
  extends Optional<UserEducationAttributes, "UEID"> {}

class UserEducation
  extends Model<UserEducationAttributes, UserEducationCreationAttributes>
  implements UserEducationAttributes
{
  public UEID!: number;
  public UID?: number;
  public MAJOR?: string;
  public GRADUATION_YEAR?: string;
  public TERM?: string;
  public INSTITUTION_ID?: string;
  public INSTITUTION_NAME?:string;
  public DOJ?: Date;
  public PLACEMENT_CELL_CO_ID?: number;
  public COUNTRY?: string;
  public STATE?: string;
  public CITY?: string;
  public ADDRESS_LINE_1?: string;
  public ADDRESS_LINE_2?: string;
  public PINCODE?: string;
}
UserEducation.init(
  {
    UEID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      primaryKey: true,
      autoIncrement: true,
    },
    UID: {
      type: DataTypes.INTEGER,
      // primaryKey: true,
      references: {
        model: User,
        key: "6DWORKS_ID",
      },
    },
    MAJOR: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    GRADUATION_YEAR: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    TERM: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    INSTITUTION_ID: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    INSTITUTION_NAME: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    DOJ: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    PLACEMENT_CELL_CO_ID: {
      type: DataTypes.INTEGER,
      references: {
        model: User,
        key: "6DWORKS_ID",
      },
    },
    COUNTRY: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    STATE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    CITY: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    ADDRESS_LINE_1: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    ADDRESS_LINE_2: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    PINCODE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize: sequelize,
    tableName: "User Education",
    timestamps: false, // Assuming there are no createdAt or updatedAt fields
  }
);

export { UserEducationCreationAttributes };
export default UserEducation;
