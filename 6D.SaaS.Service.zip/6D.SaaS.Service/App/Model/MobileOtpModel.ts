import { DataTypes, Model, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface MobileUser {
  Id: number;
  MobileNumber: string | null;
  code: number | null;
  attempt: number | null;
  enabled: string | null;
}

interface userMobileAttributes extends Optional<MobileUser, "Id"> {}

class MobileUsers
  extends Model<MobileUser, userMobileAttributes>
  implements MobileUser
{
  public Id: number;
  public MobileNumber: string | null;
  public code: number | null;
  public enabled: string;
  public attempt: number | null;
}

MobileUsers.init(
  {
    Id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    MobileNumber: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    code: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    enabled: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    attempt: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "MobileUsers",
    timestamps: false,
  }
);

export { MobileUsers, userMobileAttributes };
