import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface AnswerAttributes {
  AnsID: number;
  Answer?: string;
}

interface AnswerCreationAttributes
  extends Optional<AnswerAttributes, "AnsID"> {}

class Answer
  extends Model<AnswerAttributes, AnswerCreationAttributes>
  implements AnswerAttributes
{
  public AnsID!: number;
  public Answer?: string;
}

Answer.init(
  {
    AnsID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
    },
    Answer: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "Answer",
    timestamps: false,
  }
);

export { Answer, AnswerCreationAttributes };
