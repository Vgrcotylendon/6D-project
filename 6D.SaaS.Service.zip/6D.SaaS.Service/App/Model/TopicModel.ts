import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface TopicAttributes {
  TID: number;
  NAME: string;
  CONTENT?: string;
  CONTENT_TYPE?: string;
  DURATION?: string;
  METADATA?: string;
}

interface TopicCreationAttributes extends Optional<TopicAttributes, "TID"> {}

class Topic
  extends Model<TopicAttributes, TopicCreationAttributes>
  implements TopicAttributes
{
  public TID!: number;
  public NAME!: string;
  public CONTENT?: string;
  public CONTENT_TYPE?: string;
  public DURATION?: string;
  public METADATA?: string;
}

Topic.init(
  {
    TID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    NAME: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    CONTENT: {
      type: DataTypes.STRING(10000),
      // type: DataTypes.TEXT("long"),
      allowNull: true,
    },
    CONTENT_TYPE: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    METADATA: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    DURATION: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "Topic",
    timestamps: false,
  }
);

export { Topic, TopicCreationAttributes };
