import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { User } from "./UserModel"; // Import User model
import { Assessment } from "./AssestmentModel";
import { Course } from "./CourseModel";

interface UserAssessmentAttributes {
  UA_ID: number;
  CID: number;
  AID: number;
  UID: number;
  Status?: string;
  TimeTakenMins?: string;
  Attempt?: number;
  user_final_score?: number;
}

interface UserAssessmentCreationAttributes
  extends Optional<UserAssessmentAttributes, "UA_ID"> {}

class UserAssessment
  extends Model<UserAssessmentAttributes, UserAssessmentCreationAttributes>
  implements UserAssessmentAttributes
{
  public UA_ID!: number;
  public CID!: number;
  public AID!: number;
  public UID!: number;
  public Status?: string;
  public TimeTakenMins?: string;
  public Attempt?: number;
  public user_final_score?: number;
}

UserAssessment.init(
  {
    UA_ID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    CID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Course",
        key: "CID",
      },
    },
    AID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Assessment",
        key: "AID",
      },
    },
    UID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "User",
        key: "UID",
      },
    },
    Status: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    TimeTakenMins: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    Attempt: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    user_final_score: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "UserAssessment",
    timestamps: false,
  }
);

UserAssessment.belongsTo(User, { foreignKey: "UID" });
UserAssessment.belongsTo(Course, { foreignKey: "CID" });
UserAssessment.belongsTo(Assessment, { foreignKey: "AID" });

export { UserAssessment, UserAssessmentCreationAttributes };
