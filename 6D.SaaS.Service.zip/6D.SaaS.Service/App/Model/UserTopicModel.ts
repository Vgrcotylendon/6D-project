import { Model, DataTypes } from "sequelize";
import { sequelize } from "../Configuration/Config";
import { User } from "./UserModel";
import { Topic } from "./TopicModel";
import { Course } from "./CourseModel";

interface UserTopicAttributes {
  UT_ID: number;
  CID: number;
  TID: number;
  UID: number;
  PROGRESS: string;
  STATUS: string;
}

interface UserTopicCreationAttributes extends UserTopicAttributes {}

class UserTopic
  extends Model<UserTopicAttributes, UserTopicCreationAttributes>
  implements UserTopicAttributes
{
  public UT_ID!: number;
  public CID!: number;
  public TID!: number;
  public UID!: number;
  public PROGRESS!: string;
  public STATUS!: string;
}

UserTopic.init(
  {
    UT_ID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    CID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Course",
        key: "CID",
      },
    },
    TID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Topic",
        key: "TID",
      },
    },
    UID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "User",
        key: "UID",
      },
    },
    PROGRESS: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    STATUS: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    sequelize,
    tableName: "User Topic",
    timestamps: false,
  }
);

UserTopic.belongsTo(User, { foreignKey: "UID" });
UserTopic.belongsTo(Course, { foreignKey: "CID" });
UserTopic.belongsTo(Topic, { foreignKey: "TID" });

export { UserTopic, UserTopicCreationAttributes };
