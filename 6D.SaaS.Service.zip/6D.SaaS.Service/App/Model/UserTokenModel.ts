import { DataTypes, Model, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface userToken {
  ID: number;
  tokenId: number;
  Token: string | null;
  accessTokenValidity: string | null;
  refreshToken: string | null;
  createdTime: string | null;
  userName?: string;
  refreshTokenValidity: string | null;
}

interface userTokenAttributes extends Optional<userToken, "ID"> {}

class UserTokens
  extends Model<userToken, userTokenAttributes>
  implements userToken
{
  public ID: number;
  public tokenId: number;
  public Token: string | null;
  public accessTokenValidity: string | null;
  public refreshToken: string | null;
  public createdTime: string | null;
  public userName: string;
  public refreshTokenValidity: string | null;
}

UserTokens.init(
  {
    ID: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    tokenId: {
      type: DataTypes.INTEGER,
    },
    Token: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    accessTokenValidity: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    refreshToken: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    createdTime: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    userName: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    refreshTokenValidity: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "UserToken",
    timestamps: false,
  }
);

export { UserTokens, userTokenAttributes };
