import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface UserInviteAttributes {
  ID: number;
  EMAIL: string;
  ROLES: string;
  INVITE_SENT: string;
}

interface UserInviteCreationAttributes
  extends Optional<UserInviteAttributes, "ID"> {}

class UserInvite
  extends Model<UserInviteAttributes, UserInviteCreationAttributes>
  implements UserInviteAttributes
{
  public ID!: number;
  public EMAIL!: string;
  public ROLES!: string;
  public INVITE_SENT!: string;
}

UserInvite.init(
  {
    ID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
    },
    EMAIL: {
      type: DataTypes.STRING,
      allowNull: false,
      primaryKey: true,
      // unique: "user _invite__e_m_a_i_l",
    },
    ROLES: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    INVITE_SENT: {
      type: DataTypes.CHAR(0),
      allowNull: false,
      defaultValue: "N",
      comment: "Flag to specify if an invite was sent",
    },
  },
  {
    sequelize,
    tableName: "User Invite",
    timestamps: false,
    // indexes: [
    //   {
    //     unique: true,
    //     fields: ["EMAIL"],
    //   },
    // ],
  }
);

export { UserInvite, UserInviteCreationAttributes };
