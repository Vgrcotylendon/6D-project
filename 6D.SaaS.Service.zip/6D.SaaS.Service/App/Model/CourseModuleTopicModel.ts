import { Model, DataTypes, Optional } from "sequelize";
import { sequelize } from "../Configuration/Config";

interface CourseModuleTopicAttributes {
  MapID: number;
  CID: number;
  MID: number;
  ModuleOrder?: string;
  TID: number;
  TopicOrder?: string;
  IdType?: string;
}

interface CourseModuleTopicCreationAttributes
  extends Optional<CourseModuleTopicAttributes, "MapID"> {}

class CourseModuleTopic
  extends Model<
    CourseModuleTopicAttributes,
    CourseModuleTopicCreationAttributes
  >
  implements CourseModuleTopicAttributes
{
  public MapID!: number;
  public CID!: number;
  public MID!: number;
  public ModuleOrder?: string;
  public TID!: number;
  public TopicOrder?: string;
  public IdType?: string;
}

CourseModuleTopic.init(
  {
    MapID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    CID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Course",
        key: "CID",
      },
    },
    MID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      // references: {
      //   model: "Module",
      //   key: "MID",
      // },
    },
    ModuleOrder: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    TID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      // references: {
      //   model: "Topic",
      //   key: "TID",
      // },
    },
    TopicOrder: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    IdType: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: "CourseModuleTopic",
    timestamps: false,
  }
);

export { CourseModuleTopic, CourseModuleTopicCreationAttributes };
