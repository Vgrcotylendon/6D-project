import dotenv from "dotenv";
import express from "express";
import bodyparser from "body-parser";
import path from "path";
import cors from "cors";
import { connectDb, init, sequelize } from "./App/Configuration/Config";
import { rateLimit } from "express-rate-limit";
import { AuthRoutes } from "./App/Routes/AuthRoutes";
import { userRoutes } from "./App/Routes/UserRoutes";
import session from "express-session";
import { Routes } from "./App/Routes";
import { Model } from "./App/Model";

export const app = express();

// dotenv.config()
connectDb();
init();
Model();
sequelize.sync();

app.use(cors());
app.use(bodyparser.json());
app.use(
  session({
    secret: process.env.SESSION_SECRET as string,
    resave: false,
    saveUninitialized: false,
  })
);

// cors => cross origin resource sharing
app.use(
  cors({
    origin: [
      "http://localhost:3000",
      "https://6dworks-lms.vercel.app",
      "http://192.168.1.9:8081",
      "http://localhost:8081",
    ],
    credentials: true,
  })
);

// api requests limit
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: "draft-7",
  legacyHeaders: false,
});

app.get("/", (req, res) =>
  res.status(200).json({
    success: true,
    message: "Express on Vercel",
  })
);

app.use("/6D", Routes);
app.use("/uploads", express.static(path.join(__dirname, "./uploads")));

app.listen(process.env.SERVER_PORT, () => {
  console.log(`Server is connected at port ${process.env.SERVER_PORT}`);
});

// Body Parser
// app.use(express.json({ limit: "50mb" }));

app.all("*", (req, res, next) => {
  const err = new Error(`Route ${req.originalUrl} not found` as any);
  res.status(404);
  next(err);
});

app.use(limiter);
