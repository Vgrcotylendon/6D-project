import { app } from '../index'
require('dotenv').config()

app.listen(process.env.SERVER_PORT, () => {
  (`Server is connected at port ${process.env.SERVER_PORT}`)
})

export default app
